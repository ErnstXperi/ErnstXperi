from urllib import parse

import pytest

from core_api.stb.assertions import CoreAssertions
from set_top_box.client_api.wtw.en_us.labels import WhatToWatchLabels
from tools.logger.logger import Logger
from set_top_box.test_settings import Settings
from set_top_box.conf_constants import HydraBranches


class WhatToWatchBase(CoreAssertions):
    wtw_labels = WhatToWatchLabels()
    EXM_SCREEN_NAME = "WhatToWatch"
    log = Logger(__name__)

    def nav_to_show_on_strip(self, show_name, confirm=True, use_preview_panel=False, btn="right"):
        """
        This method navigate to show on strip.
        Args:
            show_name (str): show name
            confirm (bool): one of (True or False)
            use_preview_panel (bool): one of (True or False)
            btn (str): scroll to right or left
        :return: str: show title
        """
        self.log.info(f"seeking for {show_name} in strip")
        counter = 0
        if use_preview_panel:
            current = self.get_preview_panel().get('title', None)
        else:
            current = self.strip_focus()
        ret = ''
        while True:
            if isinstance(show_name, list):
                for show_arry in show_name:
                    for show in show_arry:
                        if isinstance(show, str):
                            if show in current or current in show:
                                ret = show
            else:
                if show_name in current or current in show_name:
                    ret = show_name
            if ret:
                break
            if btn == "right":
                self.press_right_button()
            else:
                self.press_left_button()
            self.pause(2)  # no event for that
            previous = current
            if use_preview_panel:
                current = self.get_preview_panel().get('title', None)
            else:
                self.screen.get_json()
                current = self.strip_focus()
            counter += 1
            if current == previous or counter > 50:
                raise Exception(f"{show_name} wasn't found on strip")
        if confirm:
            self.press_ok_button()
        return ret

    def nav_to_browse_options_menu(self, tester=None, attempt=3):
        self.menu_navigate_left_right(1, 0)
        while attempt > 0:
            state = self.wait_for_screen_ready(self.wtw_labels.LBL_WTW_SIDE_PANEL, 100000)
            if state:
                break
            attempt -= 1
        self.screen.refresh()

    def get_images_in_focused_strip(self):
        return self.get_strip_list()

    def navigate_to_wtw_strip(self, destination, matcher_type='in'):
        """
        Navigating to strip on wtw screen based on its title.
        TODO
        https://jira.tivo.com/browse/IPTV-16716
        """
        self.nav_to_browse_options_menu()
        self.select_menu(self.wtw_labels.LBL_WTW_BROWSE_OPTS_HOME)
        all_items = []
        for retry in range(15):
            self.screen.refresh()
            menu_array = self.get_menu_item_array()
            curr_menu = self.get_focused_item(menu_array)
            if self.is_item_matched(curr_menu, destination, matcher_type):
                break
            if all_items and all_items[-1] == curr_menu:
                raise LookupError("Among {} there is no destination {}".format(all_items, destination))
            else:
                self.press_down_button()
                all_items.append(curr_menu)
        else:
            raise LookupError("Among {} there is no destination {}".format(all_items, destination))

    def quick_update_wtw(self):
        self.press_back_button()
        self.press_ok_button(refresh=False)
        self.wait_for_screen_ready(self.wtw_labels.LBL_WTW_PRIMARY_SCREEN, 30000)
        self.pause(6)
        self.screen.refresh()

    def nav_to_netflix_strip(self):
        """
        Navigating the the Netflix strip.
        The Home category should be previously selected in the What to Watch screen
        """
        self.log.info("Navigating to the Netflix strip")
        # TODO
        # Need to get strip index by checking the partnerId
        # Can be done once service side is redy - https://jira.tivo.com/browse/SERV-86260
        lst = self.service_api.get_feed_item_results(self.wtw_labels.LBL_WTW_FEED_NAME_SCREENS_ALL, dspl_cnt=50)
        label = self.wtw_labels.LBL_WTW_NETFLIX_PROVIDER
        strip_index = None
        for item in lst:
            if label in item['details']['caption']:
                strip_index = lst.index(item)
        if not strip_index:
            raise Exception("Service did not return the Netflix strip")
        self.navigate_by_XY(strip_index, "Y")

    def check_carousel_focused(self, name):
        self.pause(10)
        self.screen.refresh()
        return name.lower() == self.get_focused_item(self.get_menu_item_array())['text'].lower()

    def get_wtw_nav_caption_according_to_ad(self, tester, ad_obj):
        """
        get Caption info about WTW page where AD will lead
        e.g. Guide AD (like footer, banner, header) can lead to specific WTW Page like:
            WTW: Home
            WTW: Box Sets
            WTW: Movies
            etc.
            Caption is a key word of the specific WTW page. E.g. 'Home' or 'Movies', etc. Needs for verification.
        :param: guide_ad_obj (footer, header, banner)
        :return: caption parameter
        """
        self.log.info("get WTW Navigation info")
        # guide ad has a 'kernel' key. Zero_slot ad has 'action' key instead of 'kernel'
        if 'kernel' in ad_obj.keys():
            key = 'kernel'
        elif 'action' in ad_obj.keys():
            key = 'action'
        else:
            raise LookupError("Can't continue because there are no 'kernel' and 'action' keys \n"
                              "(this data is needed to determine where ad should lead us). \n"
                              "guide_ad_obj: {}".format(ad_obj))
        if 'uri' not in ad_obj[key].keys():
            raise LookupError("Can't get a data to which screen ad should lead us \n"
                              "because there is no 'uri' key in guide_ad_obj: {}".format(ad_obj))
        ad_dict = dict(parse.parse_qs(parse.urlsplit(ad_obj[key]['uri']).query))
        category = ad_dict.get('category')[0]
        wtw_nav_info = tester.service_api.get_wtw_nav_info()
        for wtw_nav_item in wtw_nav_info['items']:
            if category in wtw_nav_item['kernel']['feedName']:
                self.log.debug("Expected url where AD should lead us: {}".format(wtw_nav_item['details']['caption']))
                return wtw_nav_item['details']['caption']
        else:
            raise AssertionError("AD's category {} is not in WTW Nav kernel feedNames: \n"
                                 " {}".format(category, wtw_nav_info))

    def find_and_nav_to_hero_promotion_using_gui(self,
                                                 tester,
                                                 action_type=None,
                                                 screen_name=None,
                                                 link_to_top_of_screen=False,
                                                 is_carousel=False,
                                                 feed_name="/promotions/whatToWatchHero",
                                                 streamer_only=False,
                                                 need_deeplink=False):
        """
        goes to a hero promotion with current action type and returns the hero promotion
        :param action_type: ad kernel action type
        :param screen_name: is a part of ad's URI that contained in Kernel
        :param bool link_to_top_of_screen: True: add '$' after screen_name to use in regexp
                                    and find URI that will ended exactly with screen name
        :param bool is_carousel: True: using regexp to find Ads with URI that contains &carousel=
        :param feed_name: search ads by feed name:
            /promotions/whatToWatchHero
        :param streamer_only: get ads for streamers only
        :param need_deeplink: uri must contain a deeplink
        :return: AD obj
        """
        self.log.info("go to wtw hero promotion, action_type = {}".format(action_type))
        hero_promotion_list = tester.service_api.get_ads_list(action_type,
                                                              screen_name,
                                                              link_to_top_of_screen,
                                                              feed_name,
                                                              streamer_only,
                                                              need_deeplink)
        self.log.debug("List of hero promotions we got from API: \n {}".format(hero_promotion_list))
        if not hero_promotion_list:
            pytest.skip("Hero promotion with action type: {} is not found".format(action_type))
        # Link to to top of WTW screen is unique and can't be sorted because there are no parameters to sort by
        if link_to_top_of_screen:
            filtered_hero_promotion_list = hero_promotion_list
        else:
            filtered_hero_promotion_list = tester.service_api.filter_out_ui_navigation_ads_list(tester,
                                                                                                hero_promotion_list,
                                                                                                is_carousel)
            self.log.debug("Filtered hero promotion list: \n {}".format(filtered_hero_promotion_list))
            if not filtered_hero_promotion_list:
                pytest.skip("We have no hero promotions after filtering.\n"
                            "Full list of ADs we got from API:\n {}".format(hero_promotion_list))
        if 'whatToWatchHero' in feed_name:
            return self.navigate_to_and_get_hero_promotion(tester, filtered_hero_promotion_list)
        else:
            pytest.skip("This method provides a navigation only to '/promotions/whatToWatchHero'\n"
                        "You're trying to navigate to {}".format(feed_name))

    def navigate_to_and_get_hero_promotion(self, tester, filtered_hero_promotion_list):
        """
        Find and navigate to program in guide channel list that will match to guide banner from list
        :param filtered_hero_promotion_list: list of footer ads
        :return: guide banner
        """
        self.log.info("Go through hero promotions and check if current focused is matching to expected")
        for rotation in range(5):
            for slide in range(5):
                self.screen.refresh()
                self.wait_for_screen_ready(self.wtw_labels.LBL_WHAT_TO_WATCH)
                hero_promotion = self.get_ad_matches_to_hero_promotion(filtered_hero_promotion_list)
                if hero_promotion:
                    self.log.debug("Expected hero promotion: {} is found and focused. Returning it".format(hero_promotion))
                    return hero_promotion
                self.screen.base.press_right()
            else:
                self.log.info("We went through all hero promotions and didn't find the expected one. Doing rotation.")
                tester.home_page.go_to_what_to_watch(tester)
        else:
            pytest.skip("We did rotation 5 times and did navigation through all hero promotions each time"
                        "but didn't find expected Hero promotion\n"
                        "List of expected hero promotions:\n {}".format(filtered_hero_promotion_list))

    def get_ad_matches_to_hero_promotion(self, filtered_hero_promotion_list):
        """
        method can be used in guide. Search a program that will match to expected guide ad
        :params: guide ads list
        :return: guide ad that will match to a program
        """
        hero_promotion = None
        promotile_title = self.screen.get_screen_dump_item('promotile', 'title')
        self.log.debug("Current Hero Promotion from screen dump 'Promotile Title':\n {}".format(promotile_title))
        for hero in filtered_hero_promotion_list:
            self.log.debug("Current Hero Promotion from filtered hero promotion list:\n {}".format(hero))
            if promotile_title == hero['details']['caption']:
                self.log.debug("Current promo: {} is matching to expected hero promotion: {}\n"
                               "Returning it".format(promotile_title, hero_promotion))
                hero_promotion = hero
        return hero_promotion

    def nav_to_wtw_movies(self, tester):
        """
        method can be used in WTW
            Open left menu (browse options) and select Movie category and verifies movie screen is opened
        """
        self.nav_to_browse_options_menu(tester)
        self.select_menu(self.wtw_labels.LBL_MOVIES)
        self.wait_for_screen_ready(self.wtw_labels.LBL_WHAT_TO_WATCH_MOVIES)
        self.screen.refresh()
        self.verify_screen_title(self.wtw_labels.LBL_WHAT_TO_WATCH_MOVIES)

    def nav_to_info_card_action_mode(self, tester):
        """
        method can be used in WTW to open Info Card Action mode for selected item (movie, etc.)
        """
        self.press_info_or_long_press_enter_on_wtw()
        tester.watchvideo_assertions.verify_overlay_mode(self.wtw_labels.LBL_WTW_INFO_CARD_OVERLAY_VIEW)
        if Settings.hydra_branch() < Settings.hydra_branch("b-hydra-streamer-1-11"):
            menu_item = tester.watchvideo_labels.LBL_MORE_INFO
        else:
            menu_item = self.wtw_labels.LBL_WTW_INFO_CARD_OPTIONS
        self.select_menu(menu_item)

    def get_wtw_hero_ads_as_per_action_type(self, tester, action_type=None):
        self.log.info("go to Ads in wtw hero.")
        hero_ads_list = tester.service_api.get_wtw_hero_promo_ads(action_type)
        self.log.debug("wtw hero promo ads from service_api.get_wtw_hero_promo_ads(): {}".format(hero_ads_list))
        if not hero_ads_list:
            pytest.skip("Hero promotion with action type: {} is not found".format(action_type))
        return hero_ads_list

    def get_hero_promo_on_screen(self, filtered_hero_promotion_list):
        self.log.info("Go through hero promotions and check if current focused is matching to expected")
        for i in range(5):
            self.screen.refresh()
            self.wait_for_screen_ready(self.wtw_labels.LBL_WHAT_TO_WATCH)
            hero_promotion = self.get_ad_matches_to_hero_promotion_from_ui_element_search(filtered_hero_promotion_list)
            if hero_promotion:
                self.log.debug("Expected hero promotion: {} is found and focused. Returning it".format(hero_promotion))
                break
            self.screen.base.press_right()

    def get_ad_matches_to_hero_promotion_from_ui_element_search(self, filtered_hero_promotion_list):
        hero_promotion = None
        promotile_title = self.screen.get_screen_dump_item('promotile', 'title')
        for hero in filtered_hero_promotion_list:
            if promotile_title == hero['displayName']:
                self.log.debug("Current promo: {} is matching to expected hero promotion: {}\n"
                               "Returning it".format(promotile_title, hero_promotion))
                hero_promotion = hero
        return hero_promotion

    def navigate_to_top_of_app_for_from_wtw_hero_ad(self, tester, filtered_hero_promotion_list):
        self.screen.base.press_enter()
        self.pause(10)
        for uri in filtered_hero_promotion_list:
            uri_access = uri['action']['uri']
        tester.home_assertions.verify_foreground_package_matches_uri(uri_access)

    def navigate_to_category_strip(self, strip_index):
        self.log.info("Navigating to category strip")
        self.navigate_by_XY(strip_index, "Y")

    def select_strip_from_wtw_panel(self, tester, strip_name):
        self.nav_to_browse_options_menu(tester)
        self.wait_for_screen_ready(tester.home_labels.LBL_WTW_SIDE_PANEL, 100000)
        self.select_menu(strip_name)
        self.wait_for_screen_ready()
        self.screen.refresh()

    def find_and_nav_to_episode(self):
        """
        This method finds the episode and navigates to it.
        :return: str: episode title
        """
        self.log.info("Find and navigate to the episode.")
        self.select_strip_from_wtw_panel(self, self.wtw_labels.LBL_ON_TV_TODAY)
        lst = self.service_api.get_feed_item_results(self.wtw_labels.LBL_WTW_FEED_NAME_SCREENS_ON_NOW, dspl_cnt=1)
        title = None
        for category in lst:
            if self.wtw_labels.LBL_ON_NOW_TV_SHOWS in category.caption:
                results = self.service_api.get_feed_item_find_results(category.carousel)
                if results:
                    for item in results:
                        content_id = item[2] if len(item) > 2 else None
                        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_19) \
                           and not Settings.is_prod() \
                           and not Settings.is_staging():
                            content = self.service_api.get_preview_offer(content_id, mode='content')
                            if content.episode_title:
                                title = content.title
                                break
                        else:
                            content = self.service_api.get_content_search_response(item[1], content_id)
                            if content['content'][0]['isEpisode'] is True:
                                title = content['content'][0]['title']
                                break
                    if title is not None:
                        break
                else:
                    self.log.info("feed item find results were empty: {}".format(results))
        else:
            pytest.skip("Episode not found. feed_item_results: {}".format(lst))
        self.nav_to_show_on_strip(title, False, True)
        return title

    def get_carousel_from_service(self, feed_name="/screens/all"):
        carousel = []
        api = self.service_api.get_feed_item_response if "screens" in feed_name else self.service_api.get_feed_item_results
        response = api(feed_name=feed_name, dspl_cnt=3)
        get_list = response.carousels if "screens" in feed_name else response.feeditems
        check_list = get_list.feedItems if isinstance(get_list, dict) else get_list
        for name in check_list:
            self.log.info("name: {}".format(name))
            if bool(name.caption):
                carousel.append(name.caption)
        return carousel if bool(carousel) else None

    def get_feed_name(self, feedtype):
        feed_dict = self.service_api.get_feed_item_list(display_count=10)
        self.log.info(f"feedtype: {feedtype} in get feed item list: {feed_dict}")
        if not feed_dict:
            raise AssertionError("Get feed item list response is empty.")
        if feed_dict.get(feedtype):
            self.log.info("feed list: {}".format(feed_dict.get(feedtype)))
            return feed_dict.get(feedtype)
        else:
            pytest.skip("failed to get feed list")

    def get_carousel_caption(self, carousel):
        """
        api to get carousel caption
        """
        self.log.info("Getting caption name for {}".format(carousel))
        response = self.service_api.get_feed_item_find_results(carousel, caption=True)
        self.log.info("caption for carousel {} is {}".format(carousel, response))
        return response

    def wtw_hero_ad_availablability(self):
        self.log.info("Get available ads")
        promo = self.screen.get_screen_dump_item('promotile')
        if promo:
            self.log.info("Promo available")
        else:
            return False

    def navigate_to_carousel(self, tester, carousel):
        """
        api to navigate to carousels in wtw secondary screen
        Ex: On TV week movies.. etc
        """
        self.log.step("Navigating to carousel: {}".format(carousel))
        tester.home_page.nav_to_top_menuitem_in_list()
        self.screen.refresh()
        menu = self.menu_list()
        for i in range(10):
            if carousel in menu:
                self.log.info("Carousel {} found in {}".format(carousel, menu))
                self.nav_to_menu(carousel)
                break
            else:
                menu = tester.home_page.nav_to_next_menu_list_page()
                if menu is False:
                    self.log.info("reached end of menu list")
                    break

    def verify_hero_promo_wtw(self):
        promotile_title = self.screen.get_screen_dump_item()
        if 'promotile' in promotile_title:
            return self.screen.get_screen_dump_item('promotile', 'title')

    def random_navigation_on_wtw_screen(self, tester):
        """
        This method performs navigations to right, left, down and up on WTW screen. Next, long press is done to bring up
        info card and presses back to dismiss it.
        """
        self.screen.base.press_right()
        self.screen.base.press_left()
        self.screen.base.press_down()
        self.screen.base.press_up()

    def get_carousel_names(self, visible_only=True):
        max_scroll_limit = 20
        carousel_names = []
        for _iter in range(1, max_scroll_limit):
            menu_items = self.get_menu_item()
            if not menu_items:
                raise LookupError("The current screen doesnt contain carousels")
            cur_carousel_name = menu_items[0].get('text', " ").replace(" ", "")
            if cur_carousel_name in carousel_names:
                break
            else:
                carousel_names.append(cur_carousel_name)
                if not visible_only:
                    self.press_down_button()
                    self.wait_for_screen_ready()
                    self.screen.refresh()
        return carousel_names

    def press_info_or_long_press_enter_on_wtw(self, using_info_button=True):
        self.log.info("Pressing info button/long press enter based on device type")

        def show_info_card_overlay(press_info):
            if press_info:
                self.press_info_button()
            else:
                self.press_long_ok()
            self.wait_for_screen_ready(self.wtw_labels.LBL_WTW_INFO_CARD_OVERLAY_VIEW)
            self.screen.refresh()

        show_info_card_overlay(using_info_button)
        if not self.is_overlay_shown():
            if Settings.is_managed():
                show_info_card_overlay(using_info_button)
            else:
                show_info_card_overlay(press_info=False)
