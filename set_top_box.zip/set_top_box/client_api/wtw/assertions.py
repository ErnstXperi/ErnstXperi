from hamcrest import assert_that, contains_string, equal_to, has_item, equal_to_ignoring_case

from set_top_box.client_api.wtw.page import WhatToWatchBase
from tools.logger.logger import Logger


class WhatToWatchAssertions(WhatToWatchBase):
    log = Logger(__name__)

    def verify_wtw_screen_title(self):
        self.verify_screen_title(self.wtw_labels.LBL_WHAT_TO_WATCH)

    def verify_netflix_strip_is_displayed(self):
        """
        Verifying if Netflix strip is displayed in the What to Watch screen.
        What to Watch screen should be displayed before calling this method
        """
        self.log.info("Verifying that the Netflix strip is shown")
        self.wtw_page.nav_to_netflix_strip()
        label = self.wtw_labels.LBL_WTW_NETFLIX_PROVIDER
        self.screen.refresh()
        cur_item = self.menu_item_option_focus()
        assert_that(cur_item, contains_string(label), f"{label} strip is not displayed")

    def verify_netflix_strip_not_present(self):
        self.log.info("Verifying that the Netflix strip is not present")
        label = self.wtw_labels.LBL_WTW_NETFLIX
        for strip in range(20):
            cur_item = self.menu_item_option_focus()
            if label == cur_item:
                raise AssertionError("Netflix Originals strip displayed")
            else:
                self.screen.base.press_down()
                self.wait_for_screen_ready(timeout=30000)
                self.screen.refresh()

    def verify_current_strip_title(self, strip_lable):
        """
            Verifying current strip title.
        """
        self.log.info("Verifying that the Netflix strip is shown")
        self.screen.refresh()
        cur_item = self.menu_item_option_focus()
        assert_that(cur_item, contains_string(strip_lable), f"{strip_lable} strip is not displayed")

    def verify_wtw_stability(self, tester):
        for i in range(8):
            tester.watchvideo_page.press_right_multiple_times(no_of_times=15)
            tester.watchvideo_page.press_left_multiple_times(no_of_times=13)
            self.screen.base.press_down()

    def is_WTW_category_available(self, category):
        """
        Checking category available in WTW screen
        Returns index of category
        """
        self.log.info("Checking given category is available in WTW screen")
        all_screen_label = self.service_api.get_feed_item_results(self.wtw_labels.LBL_WTW_FEED_NAME_SCREENS_ALL, dspl_cnt=50)
        strip_index = None
        for index, screen_label in enumerate(all_screen_label):
            if category == screen_label.caption:
                strip_index = index
                break
        if not strip_index:
            raise Exception("Service does not have given catogory")
        return strip_index

    def verify_category_strip_is_displayed(self, category):
        """
        Verifying particular category strip is displayed.
        """
        self.log.info("Verifying {}  strip is shown".format(category))
        self.screen.refresh()
        current_item = self.menu_item_option_focus()
        assert_that(current_item, contains_string(category), f"{category} strip is not displayed")

    def verify_wtw_sidepanel_is_not_displayed(self):
        self.log.info("Verifying sidepanel screen is not shown")
        self.screen.refresh()
        if not self.is_overlay_shown():
            self.log.info("Sidepanel screen is not shown")
        else:
            raise AssertionError("Sidepanel screen is shown")

    def verify_highlight_not_in_netflix_strip(self):
        self.log.info("Verifying that the Netflix strip is not highlighted")
        self.screen.base.press_down()
        self.wait_for_screen_ready(timeout=30000)
        label = self.wtw_labels.LBL_WTW_NETFLIX
        self.screen.refresh()
        cur_item = self.menu_item_option_focus()
        if label in cur_item:
            self.screen.base.press_down()
        self.wait_for_screen_ready()
        self.screen.refresh()
        focus_item = self.menu_item_option_focus()
        assert_that(label, not contains_string(focus_item), f"{focus_item} strip is highligted")

    def verify_netflix_icon_on_wtw_screen(self):
        self.log.info("Verifying netflix icon existence only")
        stripitem = self.screen.get_screen_dump_item('stripitem')
        found = False
        if 'availableOn' in stripitem[0]:
            icon = stripitem[0]['availableOn']['imagename']
            if type(icon) is list:
                assert False, "Different OTT providers are available.Details :Expected only:'{}' but actual were: '{}'"\
                    .format(self.wtw_labels.LBL_WTW_NETFLIX_ICON, icon)
            else:
                if self.wtw_labels.LBL_WTW_NETFLIX_ICON in icon:
                    self.screen.base.press_enter()
                    self.wait_for_screen_ready(timeout=10000)
                    return True
        else:
            assert False, "{} : availableOn is not available in the stripitem".format(stripitem[0])
        assert_that(found, "{} : is not available ".format(stripitem))

    def verify_preview_pane_program_description(self):
        previewpane = self.get_preview_panel()
        if not previewpane:
            assert_that(previewpane, "Preview pane is empty")
        else:
            if not previewpane['title'] or previewpane['title'] is None:
                assert_that(False, "There is no title displayed: {}".format(previewpane['title']))
            if not previewpane['description'] or previewpane['description'] is None:
                assert_that(False, "There is no description displayed: {}".format(previewpane['description']))
        assert True

    def verify_wtw_hero_availability_in_filter(self):
        self.log.info("verifying hero promo availability in filters")
        self.screen.refresh()
        hero = self.wtw_page.verify_hero_promo_wtw()
        if not hero:
            raise AssertionError("WTW hero promo is not available in the filter")
        else:
            self.wtw_page.log.step("WTW hero promo available : {}".format(hero))

    def verify_wtw_hero_not_available_in_filter(self):
        self.log.info("verifying hero promo is not available in filters")
        self.screen.refresh()
        if self.wtw_page.verify_hero_promo_wtw():
            raise AssertionError("WTW hero promo is available in the filter")

    def is_atmospheric_image_present(self):
        screendump = self.screen.get_screen_dump_item()
        image = screendump['previewPane']
        stripitem = screendump['stripitem']
        defaultimage = stripitem[0]['imagename']
        if self.wtw_labels.LBL_DEFAULT_IMAGE in defaultimage:
            self.log.info("Atmospheric image will not be visible")
        else:
            for i in range(len(image)):
                if 'atmosphericImage' in image and image['atmosphericImage'] is not None:
                    self.log.info("Atmosphericimage is visible")
                    break
                elif 'atmosphericImage' not in image:
                    self.log.info("Atmospheric image will not be visible")
                else:
                    raise AssertionError("Atmosphericimage is not visible")

    def verify_hero_promo_ads_left_right_carousel(self):
        arrow_left_right = self.screen.get_screen_dump_item()
        if 'arrow' in arrow_left_right:
            assert_that(self.screen.get_screen_dump_item('arrow'),
                        "Left right arrows present on promo carousel with 1 Ad ")

    def verify_time_info_wtw(self):
        self.log.info("Verifying time info existence in wtw")
        assert_that(self.get_time_info(), "No time info in dump")

    def verify_primary_branding_icon_wtw(self):
        self.log.info("Verifying primary branding icon existence in wtw")
        assert_that(self.get_primary_branding_icon(), "No primary icon in dump")

    def verify_wtw_tiles_and_image_posters(self):
        self.log.info("Verifying wtw tiles and image poster")
        self.wait_for_screen_ready()
        self.screen.refresh()
        for i in range(5):
            image_poster_list = self.get_images_in_focused_strip()
            for i in range(len(image_poster_list)):
                if 'imagename' in image_poster_list[i]:
                    self.screen.base.press_right()
                else:
                    raise AssertionError("Tiles is empty")
            self.screen.base.press_down()
            self.wait_for_screen_ready()

    def verify_screen_components_match_open_api_response(self, feed_list):
        self.log.info("Verifying response of screens api has same UI components that are on the screen.")
        visible_carousels = self.wtw_page.get_carousel_names()
        assert_that(feed_list, has_item(equal_to_ignoring_case(visible_carousels[0])))
