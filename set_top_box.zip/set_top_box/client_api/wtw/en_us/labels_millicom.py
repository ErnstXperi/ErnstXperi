class MillicomWTWLabels:
    pass
