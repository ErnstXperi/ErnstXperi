class WhatToWatchLabels:
    # What to Watch lables
    LBL_WTW_BROWSE_OPTS_HOME = "Home"
    LBL_ON_TV_TODAY = "On TV Today"
    LBL_COLLECTIONS = "Collections"
    LBL_SPORTS = "Sports"
    LBL_MOVIES = "Movies"
    LBL_TV_SERIES = "TV"
    LBL_KIDS = "Kids"
    LBL_BOX_SETS = "Box Sets"

    LBL_WTW_FEED_NAME_SCREENS_ALL = "/screens/all"
    LBL_WTW_FEED_NAME_SCREENS_ON_NOW = "/screens/onNow"
    LBL_WTW_NETFLIX = "Netflix"
    LBL_WTW_NETFLIX_PROVIDER = "Netflix Originals"
    LBL_WTW_NETFLIX_ICON = "hydra_icon_source_Netflix_C0_32x32.png"
    LBL_DEFAULT_IMAGE = 'com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_image_default'

    LBL_ACTIONS_SCREEN = "actions.ActionsScreenView"
    LBL_WTW_INFO_CARD_OVERLAY_VIEW = "overlay.InfoCardOverlayView"
    LBL_WTW_INFO_CARD_OPTIONS = "Options"
    LBL_WTW_INFO_CARDS_BOOKMARK_MOVIE = "Bookmark Movie"
    LBL_WTW_INFO_CARDS_BOOKMARK_EPISODE = "Bookmark Episode"
    LBL_WTW_INFO_CARDS_BOOKMARK_SHOW = "Bookmark Show"
    LBL_WTW_INFO_CARDS_SEE_MORE_INFO = "See More Info"
    LBL_WTW_INFO_CARDS_BOOKMARK_MOVIE_WHISPER = "This movie has been added to My Shows"
    LBL_WTW_INFO_CARDS_BOOKMARK_EPISODE_WHISPER = "This episode has been added to My Shows."
    LBL_WTW_INFO_CARDS_BOOKMARK_SHOW_WHISPER = "This show has been added to My Shows."

    LBL_WHAT_TO_WATCH = "WHAT TO WATCH"
    LBL_WHAT_TO_WATCH_HOME = "WHAT TO WATCH: HOME"
    LBL_WHAT_TO_WATCH_ON_TV_TODAY = "WHAT TO WATCH: ON TV TODAY"
    LBL_WHAT_TO_WATCH_COLLECTIONS = "WHAT TO WATCH: COLLECTIONS"
    LBL_WHAT_TO_WATCH_TV = "WHAT TO WATCH: TV"
    LBL_WHAT_TO_WATCH_MOVIES = "WHAT TO WATCH: MOVIES"
    LBL_WHAT_TO_WATCH_BOX_SETS = "WHAT TO WATCH: BOX SETS"
    LBL_WHAT_TO_WATCH_SPORTS = "WHAT TO WATCH: SPORTS"
    LBL_WHAT_TO_WATCH_KIDS = "WHAT TO WATCH: KIDS"
    LBL_ON_NOW_TV_SHOWS = "On Now TV Shows"
    LBL_TRENDING = "Trending"
    LBL_MODIFY_ONEPASS = "Modify OnePass"
    LBL_HOME_SCREEN_NAME = "HomeMainScreen"
    LBL_ONEPASS_FTUX = "OnePassQuickSelectScreen"
    LBL_HOME_SCREEN_MODE = "home.HomeScreenView"
    LBL_EAS_VIEW = "eam.EamScreenView"
    LBL_GOING_TO_LIVE_TV_OSD = "Going to Live TV"
    LBL_WTW_PRIMARY_SCREEN = "W2WPrimaryScreen"
    LBL_WTW_SIDE_PANEL = "W2WSidePanelScreen"
    LBL_WTW_NOW = 'whattowatchnow'
    LBL_AD_ACTION_UI_NAVIGATE = 'uiNavigateAction'
    LBL_WTW_FREE_MOVIES_AND_TV = 'Free Movies & TV'
    LBL_WTW_NETFLIX_MOVIE = "Netflix Original Movies"
    LBL_PROMO = "DG_tivomax_promo"
    LBL_ADS_GROUP_STAGING = "DG_sol_testads"
    LBL_ADS_ALL_STAGING = "DG_testads"
    LBL_ADS_MASQE = "DG_masqe1"
    LBL_ACTION_SERIES_SCREEN = "actions.series.SeriesScreenView"

    def __init__(self):
        self.LBL_WTW_MENU_LIST = [self.LBL_ON_TV_TODAY, self.LBL_WTW_BROWSE_OPTS_HOME,
                                  self.LBL_COLLECTIONS, self.LBL_SPORTS, self.LBL_MOVIES,
                                  self.LBL_TV_SERIES, self.LBL_KIDS]
