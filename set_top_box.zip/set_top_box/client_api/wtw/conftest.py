import pytest

from set_top_box.client_api.guide.assertions import GuideAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.test_settings import Settings
from tools.logger.logger import Logger
from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.wtw.assertions import WhatToWatchAssertions
from set_top_box.client_api.my_shows.assertions import MyShowsAssertions
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from set_top_box.client_api.apps_and_games.assertions import AppsAndGamesAssertions
from set_top_box.client_api.program_options.assertions import ProgramOptionsAssertions
from set_top_box.client_api.VOD.assertions import VODAssertions
from set_top_box.client_api.service_properties.assertions import ServicePropertiesAssertions

__logger = Logger(__name__)


@pytest.fixture(autouse=True, scope="class")
def setup_what_to_watch(request):
    request.cls.wtw_page = PageFactory("wtw", Settings, request.cls.screen)
    request.cls.wtw_assertions = WhatToWatchAssertions(request.cls.screen)
    request.cls.wtw_assertions.wtw_page = request.cls.wtw_page
    request.cls.wtw_labels = LabelFactory("wtw", Settings)
    request.cls.wtw_page.wtw_labels = request.cls.wtw_labels
    request.cls.wtw_assertions.wtw_labels = request.cls.wtw_labels

    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_assertions = HomeAssertions(request.cls.screen)
    request.cls.home_labels = LabelFactory("home", Settings)
    request.cls.wtw_page.home_labels = request.cls.home_labels
    request.cls.wtw_assertions.home_labels = request.cls.home_labels

    request.cls.my_shows_page = PageFactory("my_shows", Settings, request.cls.screen)
    request.cls.my_shows_assertions = MyShowsAssertions(request.cls.screen)
    request.cls.my_shows_labels = LabelFactory("my_shows", Settings)
    request.cls.my_shows_page.my_shows_labels = request.cls.my_shows_labels

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)
    request.cls.guide_labels = LabelFactory("guide", Settings)

    request.cls.watchvideo_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.watchvideo_assertions = WatchVideoAssertions(request.cls.screen)
    request.cls.watchvideo_labels = request.cls.liveTv_labels = LabelFactory("watchvideo", Settings)

    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)
    request.cls.menu_labels = request.cls.menu_page.menu_labels = LabelFactory("Menu", Settings)

    request.cls.apps_and_games_labels = LabelFactory("apps_and_games", Settings)
    request.cls.apps_and_games_assertions = AppsAndGamesAssertions(request.cls.screen)
    request.cls.apps_and_games_page = PageFactory("apps_and_games", Settings, request.cls.screen)

    request.cls.program_options_assertions = ProgramOptionsAssertions(request.cls.screen)
    request.cls.program_options_page = PageFactory("program_options", Settings, request.cls.screen)
    request.cls.program_options_labels = LabelFactory("program_options", Settings)

    request.cls.vod_assertions = VODAssertions(request.cls.screen)

    request.cls.movie_cdp_page = PageFactory("movie_cdp", Settings, request.cls.screen)

    request.cls.service_properties_assertions = ServicePropertiesAssertions(request.cls.screen)

    request.getfixturevalue('device_reboot_to_imporve_device_perf')
    request.getfixturevalue('clean_ftux_and_sign_in')


@pytest.fixture(autouse=False, scope="function")
def setup_to_check_app(request):
    """
    checks tubitv or plutotv over adb
    """
    result = request.cls.driver.driver._AndroidDriver__adb.is_package_installed('com.tubitv')
    result1 = request.cls.driver.driver._AndroidDriver__adb.is_package_installed('tv.pluto.android')
    if not (result or result1):
        pytest.skip("Device does not contain required app")


@pytest.fixture(autouse=False, scope="function")
def hero_promo_check(request):
    """
    Checks the Hero promo groups are added or not
    """
    request.cls.service_api.get_wtw_hero_promo_ads(request.cls.home_labels.LBL_AD_ACTION_UI_NAVIGATE)
    mandatory = request.cls.service_api.check_groups_enabled(request.cls.wtw_labels.LBL_PROMO)
    if not mandatory:
        pytest.skip("DG group missing, add Ads DG groups: DG_tivomax_promo")
    if Settings.test_environment != "prod":
        optional1 = request.cls.service_api.check_groups_enabled(request.cls.wtw_labels.LBL_ADS_GROUP_STAGING)
        optional2 = request.cls.service_api.check_groups_enabled(request.cls.wtw_labels.LBL_ADS_ALL_STAGING)
        optional3 = request.cls.service_api.check_groups_enabled(request.cls.wtw_labels.LBL_ADS_MASQE)
        if optional1:
            __logger.info("DG_sol_testads added")
        elif optional2:
            __logger.info("DG_testads added")
        elif optional3:
            __logger.info("DG_masqe1 added")
        else:
            pytest.skip("DG group missing, add Ads DG groups: DG_sol_testads or DG_testads or DG_masqe1")
