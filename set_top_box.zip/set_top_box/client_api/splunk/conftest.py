import pytest
import yaml
import time

from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.client_api.splunk.assertions import SplunkAssertions
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.test_settings import Settings
from tools.logger.logger import Logger
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.guide.assertions import GuideAssertions


__log = Logger(__name__)


@pytest.fixture(autouse=True, scope="class")
def setup_splunk(request):
    request.cls.watchvideo_assertions = WatchVideoAssertions(request.cls.screen)
    request.cls.watchvideo_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.watchvideo_labels = LabelFactory("watchvideo", Settings)
    request.cls.watchvideo_assertions.watchvideo_labels = request.cls.watchvideo_labels
    request.cls.watchvideo_page.watchvideo_labels = request.cls.watchvideo_labels

    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_assertions = HomeAssertions(request.cls.screen)
    request.cls.home_labels = request.cls.home_page.home_labels = LabelFactory("home", Settings)

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)
    request.cls.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_page.guide_labels = request.cls.guide_labels

    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)
    request.cls.menu_labels = request.cls.menu_page.menu_labels = LabelFactory("Menu", Settings)
    request.cls.menu_page.menu_labels = request.cls.menu_labels

    request.cls.splunk_page = PageFactory("splunk", Settings, request.cls.screen)
    request.cls.splunk_assertions = SplunkAssertions(request.cls.screen)


qoe_dict = {}


def get_splunk_qoe_dict():
    global qoe_dict
    if not qoe_dict:
        with open(Settings.QOE_YML_FILE) as yfile:
            qoe_dict = yaml.load(yfile, Loader=yaml.FullLoader)
        __log.info("qoe_events_and_attributes.yml file contents ={}".format(qoe_dict))
    return qoe_dict


def get_attributes_from_yml(actual_event_name=None):
    # Read attributes from yml and returned as list
    events = get_splunk_qoe_dict()
    for event, attributes in events.items():
        if event in actual_event_name:
            __log.info("attributes for event-{} = {}".format(event, attributes))
            return attributes


@pytest.fixture(autouse=False, scope="class")
def setup_livetv(request):
    channel = request.cls.service_api.get_random_encrypted_unencrypted_channels(Settings.tsn, transportType="stream",
                                                                                filter_channel=True)
    if not channel:
        pytest.skip("There are no encrypted channels")
    start_time = time.time()
    request.cls.home_page.go_to_guide(request.cls)
    request.cls.guide_page.watch_channel(request.cls, channel[0][0])
    request.cls.watchvideo_assertions.verify_livetv_mode()
    request.cls.watchvideo_assertions.verify_playback_play()
    request.cls.home_page.pause(60)
    request.cls.home_page.back_to_home_short()
    request.cls.home_page.pause(20)
    end_time = time.time()
    min = int((end_time - start_time) / 60) + 5
    events = get_attributes_from_yml(actual_event_name='playbackQoeEvents')
    request.cls.livetv_splunk_result = request.cls.splunk_page.splunk_event_output(event=events,
                                                                                   earliest_time=f"-{min}m")
