import json

from set_top_box.test_settings import Settings
from mind_api.splunk.splunk import Splunk
from tools.logger.logger import Logger
from core_api.stb.assertions import CoreAssertions


class SplunkPage(CoreAssertions):
    log = Logger(__name__)
    splunk = Splunk()

    def splunk_event_output(self, event=None, earliest_time='-24h'):
        query = f"search index=sage logType=operations deviceTsn={Settings.tsn}"
        if event:
            if isinstance(event, list):
                event = ",".join(event)
            query = f"{query} event_name IN ({event})"
        query = f"{query} earliest_time={earliest_time} | rename _raw as Event"
        self.log.info(f"splunk query using for search - {query}")
        response = self.splunk.get_signatures_from_splunk_by_spl_query(query)
        if response:
            response = [json.loads(res['Event']) for res in response]
        self.log.info("results of splunk search - {}".format(response))
        return response

    def get_event_from_response(self, eventName, response):
        for event in response:
            if 'event_name' in event:
                event_name = event['event_name']
                if event_name == eventName:
                    self.log.info(f"Event {event_name} found")
                    return event
        return None
