from set_top_box.client_api.splunk.page import SplunkPage
from tools.logger.logger import Logger


class SplunkAssertions(SplunkPage):
    log = Logger(__name__)

    def verify_splunk_response_not_empty(self, response):
        if len(response) == 0:
            assert False, "Splunk response is empty"

    def verify_events_present_in_splunk_response(self, list_of_events, response):
        """
        list_of_events should be in list.
        """
        for event in list_of_events:
            if self.get_event_from_response(event, response):
                self.log.info(f"{event} is present in Splunk response")
            else:
                assert False, f"{event} not found in Splunk response"

    def verify_attributes_for_the_event_in_splunk_responses(self, event_name, attributes, response):
        event_res = self.get_event_from_response(event_name, response)
        if not event_res:
            assert False, f"Event-{event_name} not found in splunk response"
        self.log.info(f"{event_name} is present in Splunk response, Verifying its attributes")
        for key in attributes:
            self.log.info("key ={}".format(key))
            if key in event_res:
                self.log.info(f"{key} : {event_res[key]} was found in event: {event_name}")
            else:
                assert False, f"Attribute {key} was not found in event: {event_name}"
