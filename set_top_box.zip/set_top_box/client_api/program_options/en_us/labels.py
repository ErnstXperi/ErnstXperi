class ProgramOptionsLabels():
    LBL_INFO_OVERLAY = "overlay.InfoOverlayView"
    LBL_ACTION_SCREEN_VIEW = 'actions.ActionsScreenView'
    LBL_SERIES_SCREEN_VIEW = "actions.series.SeriesScreenView"
    LBL_WATCH_NOW_FROM_LIVE_TV = "Live TV"
    LBL_START_OVER_FROM_BEGINNING = "Start over from beginning"
    LBL_MOVIE = "Movies"
    LBL_ONEPASS_AND_RECORDING_OPTIONS = "OnePass"
    LBL_CREATE_ONEPASS_ONLY = "Create OnePass"
    LBL_CREATE_ONEPASS_WITH_THESE_OPTIONS = "Create OnePass with these options"
    LBL_ONEPASS_OPTIONS = "OnePass Options"
    LBL_TV_SHOW = "TV Shows"
    LBL_ALL_EPISODES = "All Episodes"
    LBL_OTHER_CREDITS = "Other Credits"
    LBL_EXTRAS = "Extras"
    person_screen_strip = [LBL_MOVIE, LBL_TV_SHOW, LBL_OTHER_CREDITS, LBL_EXTRAS]
    LBL_ON_DEMAND = "On Demand"
    LBL_WTW_SOCU_ICON = "http://i.tivo.com/images-static/bravo/providers/hydra_icon_source_socu_50x50.png"
