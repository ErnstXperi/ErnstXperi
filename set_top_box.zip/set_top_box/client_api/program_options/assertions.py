from hamcrest import *
from core_api.stb.assertions import CoreAssertions
from set_top_box.client_api.program_options.en_us.labels import ProgramOptionsLabels


class ProgramOptionsAssertions(CoreAssertions):

    program_options_labels = ProgramOptionsLabels()

    def verify_screen_title(self, title):
        self.log.info(f"Verifying screen title {title}")
        assert_that(self.screen_title(), contains_string(title.upper()))

    def verify_action_view_mode(self, tester=None):
        self.log.info("Verifying action screen view mode")
        self.wait_for_screen_ready("EpisodeScreen", timeout=12000)
        self.verify_view_mode(self.program_options_labels.LBL_ACTION_SCREEN_VIEW)

    def verify_series_screen(self):
        self.log.info("Verifying series screen mode")
        self.screen.refresh()
        self.verify_view_mode(self.program_options_labels.LBL_SERIES_SCREEN_VIEW)

    def verify_ott_app_is_foreground(self, tester, app):
        assert_that(super().verify_ott_app_is_foreground(tester, app))

    def verify_one_pass_created(self):
        assert_that(self.is_in_menu(self.program_options_labels.LBL_ONEPASS_OPTIONS))

    def verify_go_to_episode_screen_icon_focused(self):
        self.log.info("Verifying Focussed icon")
        self.screen.refresh()
        try:
            menu = self.get_menu_item()
            if not isinstance(menu, list):
                menu = [menu, ]
            icon = self.get_focused_item(menu)['focusedicon']['imagename']
        except KeyError as e:
            icon = e
        assert_that(icon, contains_string('hydra_icon_go_to_episode_screen.png'))

    def verify_delete_episode_icon_focused(self):
        self.screen.refresh()
        try:
            menu = self.get_menu_item()
            if not isinstance(menu, list):
                menu = [menu, ]
            icon = self.get_focused_item(menu)['focusedicon']['imagename']
        except KeyError as err:
            icon = err
        assert_that(icon, contains_string('hydra_icon_delete_episode.png'))

    def verify_person_screen_strip(self):
        self.log.step("Verifying person screen strips and its order of display")
        expected = self.program_options_labels.person_screen_strip
        try:
            items = list(map(lambda x: x.get("text"), self.get_menu_item()))
        except Exception:
            # means 1 item in strip - ordered
            return
        i = 0
        while i < len(items) - 1:
            if expected.index(items[i]) >= expected.index(items[i + 1]):
                raise AssertionError(f"{items} not in order, expected {expected}")
            i += 1
        self.log.info("All strips are available and are in correct order")

    def verify_person_screen_title(self, person):
        self.screen.refresh()
        title = person[0][0] + " " + person[0][1]
        self.log.step("Verifying person screen with title as {}".format(title))
        self.verify_screen_title(title)
