from core_api.stb.assertions import CoreAssertions
from set_top_box.client_api.program_options.en_us.labels import ProgramOptionsLabels


class ProgramOptionBase(CoreAssertions):

    labels = ProgramOptionsLabels()

    def run_from_google_play(self):
        self.log.step("Selecting play from Google Play")
        self.select_string_by_substring("Google_Play")
        self.screen.refresh()

    def run_from_on_demand(self):
        self.log.step("Selecting play from On Demand")
        self.select_string_by_substring(self.labels.LBL_ON_DEMAND)
        self.screen.refresh()

    def create_one_pass(self, tester):
        self.log.step("Select OnePass options")
        self.select_menu_by_substring(tester.program_options_labels.LBL_ONEPASS_AND_RECORDING_OPTIONS, confirm=False)
        self.screen.refresh()
        self.log.step("Select create one pass")
        self.select_string_by_substring(tester.program_options_labels.LBL_CREATE_ONEPASS_ONLY)
        if self.is_overlay_shown():
            self.select_menu_by_substring(tester.program_options_labels.LBL_CREATE_ONEPASS_WITH_THESE_OPTIONS)

    def run_from_netflix(self):
        self.log.info("Selecting Netflix shortcut on strip")
        self.select_string_by_substring("Netflix")
        self.screen.refresh()
        self.pause(5)

    def select_play_from_liveTv(self):
        self.log.step("Selecting Live TV shortcut on strip")
        self.select_string_by_substring("Live TV")
        self.screen.refresh()

    def select_play_option(self):
        self.log.step("Selecting Play shortcut on strip")
        self.select_string_by_substring("Play")
        self.screen.refresh()

    def select_play_from_socu(self, socu=labels.LBL_WTW_SOCU_ICON):
        self.log.step("Select play from a socu")
        self.select_strip(socu, matcher_type="in")
        self.screen.refresh()
        if self.is_overlay_shown() and self.get_overlay_mode() == self.labels.LBL_INFO_OVERLAY:
            try:
                self.select_menu(self.labels.LBL_START_OVER_FROM_BEGINNING)
            except Exception as err:
                self.log.info("Seems resolution overlay popup. Err: {}".format(err))
                self.screen.base.press_enter()
                self.screen.refresh()
                if self.is_overlay_shown() and self.get_overlay_mode() == self.labels.LBL_INFO_OVERLAY:
                    self.select_menu(self.labels.LBL_START_OVER_FROM_BEGINNING)
