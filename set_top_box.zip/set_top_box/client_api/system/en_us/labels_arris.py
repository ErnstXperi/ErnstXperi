class SystemLabels:

    # Android Setting lables
    LBL_ACC_AND_SIGN_IN_OPT = "Accounts"
    LBL_NETWORK_AND_INTERNET = "Network & Internet"
