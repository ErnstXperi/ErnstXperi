class SystemLabels:

    # Android Setting lables
    LBL_HYDRA_APP_NAME = "RCN"
