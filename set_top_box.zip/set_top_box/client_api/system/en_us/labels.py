class SystemLabels:

    LANGUAGE_CODES_NAMES = {
        'en-US': 'English (United States)',
        'en-ES': 'Español (España)',
        'es-US': 'Español (Estados Unidos)',
        'fil-PH': 'Filipino',
        'fr-CA': 'Français (Canada)',
        'fr-FR': 'Français (France)'
    }

    # Android Setting lables
    LBL_NETWORK_AND_INTERNET = "Network & Internet"
    LBL_DEVICE_SYS_INFO = "About"
    LBL_SETTINGS_MAIN = "Settings"
    LBL_ACC_AND_SIGN_IN_OPT = "Accounts"
    LBL_NO_ACCOUNTS = "No accounts"
    LBL_ADD_ACCOUNT = "Add account"
    LBL_REMOVE_ACCOUNT = "Remove account"
    LBL_APPS = "Apps"
    LBL_SPECIAL_APP_ACCESS = "Special app access"
    LBL_NOTIFICATION_ACCESS = "Notification access"
    LBL_HYDRA_APP_NAME = "Cableco11"
    LBL_APP_NAME_FOR_MSO = {"cableco3": "Cableco3", "cableco11": "Cableco11", "llacr": "Liberty CAR",
                            "llagd": "Liberty CAR"}
    LBL_CLEAR_DATA = "Clear data"

    # Action confirmation screen
    LBL_OK = "OK"
    LBL_CANCEL = "Cancel"
    LBL_DEVICE_PREFERENCE = "Device Preferences"
    LBL_ABOUT = "About"
    LBL_REBOOT = "Reboot"

    # Android adding new account lables
    LBL_CHOOSE_ACCOUNT_TYPE = "Choose account type"
    LBL_GOOGLE_ACC_TYPE = "Google"
    LBL_SIGN_IN = "Sign In"
    LBL_USE_YOUR_REMOTE = "Use your remote"
    LBL_NEXT_BTN = "Next"

    # Google Assistant labels
    LBL_CONTINUE_BTN = "Continue"
    LBL_YES_BTN = "Yes"

    # Pause time
    LBL_SCREEN_PAUSE_TIME = 5

    # Device Temperature
    TEMP_WARNING = 60
    TEMP_STOP_EXEC = 75

    # screensaver time setting
    LBL_SCREEN_SAVER_TIME = ["5 minutes", "10 minutes", "15 minutes", "30 minutes", "1 hour", "2 hours", "Never"]
