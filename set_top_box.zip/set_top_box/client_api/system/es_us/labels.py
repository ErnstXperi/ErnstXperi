class SystemLabels:

    LANGUAGE_CODES_NAMES = {
        'en-US': 'English (United States)',
        'en-ES': 'Español (España)',
        'es-US': 'Español (Estados Unidos)',
        'fil-PH': 'Filipino',
        'fr-CA': 'Français (Canada)',
        'fr-FR': 'Français (France)'
    }
