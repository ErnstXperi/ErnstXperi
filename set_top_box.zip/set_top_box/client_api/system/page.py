import time
import re
from hamcrest import assert_that, contains_string
from core_api.stb.assertions import CoreAssertions
from set_top_box.client_api.system.en_us.labels import SystemLabels
from set_top_box.test_settings import Settings


class AndroidSystem(CoreAssertions):
    labels = SystemLabels()

    def change_language(self, user_language_code="en-US", user_action="down"):
        """
        :param user_language_code:
        :param user_action up or down
        :return: boolean

        """
        language_dict = self.labels.LANGUAGE_CODES_NAMES
        self.screen.base.driver.launch_language_setting()
        system_locale_code = self.get_system_language_code()

        self.log.info("User searching language {} and system locale {}"
                      .format(language_dict[user_language_code], system_locale_code))

        for i in range(20):

            if self.screen.base.driver.is_exist_by_locator(text=language_dict[user_language_code]):
                self.log.info("change_language - found locator text   {}".format(i))
                self.screen.base.driver.click_by_text(text=language_dict[user_language_code])
                self.screen.base.driver.uiautomator_device.press.center()
                self.screen.base.press_back()
                break

            if "up" == user_action and i == 0:
                self.screen.base.press_back()
                self.log.info("change_language - user navigation up and iteration  {} and system language {}"
                              .format(i, self.get_system_language_code()))
                self.screen.base.driver.snooze(timeout=20)
                self.screen.base.driver.launch_language_setting()

            elif "up" == user_action:
                self.log.info("change_language - user navigation up and iteration  {}".format(i))
                self.screen.base.driver.uiautomator_device.press.up()
            else:
                self.log.info("change_language - user navigation down and iteration  {}".format(i))
                self.screen.base.driver.uiautomator_device.press.down()

        return self.is_language_changed(user_language_code=user_language_code)

    def is_language_changed(self, user_language_code):
        """
        :param user_language_code:
        :return: boolean
        """
        sys_language_code = self.screen.base.driver.get_sys_locale()
        if user_language_code == sys_language_code:
            self.log.info("User language code {} and system language code  {} is matching"
                          .format(user_language_code, sys_language_code))
            return True
        else:
            self.log.info("User language code {} and system language code  {} is not  matching"
                          .format(user_language_code, sys_language_code))
            return False

    def get_system_language_code(self):
        return self.screen.base.driver.get_sys_locale()

    def select_device_settings_menu_item(self, *args):
        """
        Selecting Device Settings mentu item.
        Several items can be selected one by one, just need to provide them as input param separated by comma

        Args:
            *args: list of menus, after selecting an option a new sub screen in
                   Device Settings is opened and next option selected there,
                   e.g "Device Preferences", "About" will open About screen
        """
        self.go_back_to_main_device_settings_screen()
        max_times_go_down = 30  # when option wasn't found, we can try to go to find it
        result = []
        a = str(args).replace("(", "").replace(")", "").replace(", ", "->")
        self.log.info("Opening Device Settings menu: {}".format(a))
        for item in args:
            for i in range(0, max_times_go_down):
                if self.screen.base.is_text_present(item):
                    self.screen.base.select_item_by_text(item)
                    self.pause(1, "Waiting a bit for the next screen to display")
                    result.append(True)
                    break
                else:
                    self.press_down_button()
                if i == max_times_go_down - 1:
                    cur_scr = self.get_device_settings_screen_title()
                    self.log.error(f"Device Settings '{item}' menu item was not found on '{cur_scr}' screen")
                    result.append(False)  # Unsuccessful selection since item wasn't found
        if not all(result):
            cur_scr = self.get_device_settings_screen_title()
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise AssertionError(f"Failed to select {args} option; current screen: {cur_scr}\n\n UI Dump: \n\n{ui_dump}")

    def launch_device_settings_screen(self):
        """
        Opening Device Settings screen
        """
        self.screen.base.launch_device_settings_screen()
        self.pause(3.5, "Waiting a bit for the Device Settings to display")

    def open_system_settings_about(self):
        """
        Opening Device Info Settings screen
        """
        if Settings.is_fire_tv():
            self.screen.base.launch_device_settings_info_screen()
        elif Settings.is_android_tv():
            self.screen.base.launch_device_settings_about_screen()

    def is_google_account_present(self):
        """
        Checking if Google account is present in the Device Settings.
        Main Device Settings screen should be open ("Settings" for Android)

        Returns:
            bool
        """
        self.log.info("Checking if Google account is present")
        self.go_back_to_main_device_settings_screen()
        acc_sign_in_label = self.system_labels.LBL_ACC_AND_SIGN_IN_OPT
        no_accounts_label = self.system_labels.LBL_NO_ACCOUNTS
        text = self.screen.base.driver.uiautomator_device(textStartsWith=acc_sign_in_label).sibling(index=1).text
        is_on = True if no_accounts_label not in text else False
        self.log.debug(f"Google acc check: option label = {acc_sign_in_label}, account text = {text}, is_on = {is_on}")
        return is_on

    def signin_google_account(self, email, password):
        """
        Adding a Google account to Device Settings.

        Args:
            email (str): Google account email
            password (str): password
        """
        self.log.info("Launching adding new Google account screen and adding a Google account")
        self.screen.base.google_signin_screen()
        cur_pkg = self.screen.base.driver.get_info_for_node_item()["packageName"]
        if cur_pkg not in [self.screen.base.driver.device_settings_pkg_main_view_mode,
                           self.screen.base.driver.sign_in_google_acc_pkg_view_mode,
                           self.screen.base.driver.enter_email_pswd_web_form_view_mode]:
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise AssertionError(f"Adding new Google account screen is not displayed, current app is {cur_pkg}"
                                 f"\n\n UI Dump: \n\n{ui_dump}")
        self.go_back_to_main_google_acc_sign_in_screen()
        is_chs_acc_type_scrn = self.screen.base.check_text_availability(self.system_labels.LBL_CHOOSE_ACCOUNT_TYPE)
        if is_chs_acc_type_scrn:
            self.press_ok_button(False)
            self.pause(1, "Waiting for the 'Sign In' button to show")
        sign_in_lbl = self.system_labels.LBL_SIGN_IN
        use_yr_remote_lbl = self.system_labels.LBL_USE_YOUR_REMOTE
        next_btn = self.system_labels.LBL_NEXT_BTN
        # uiautomator click does not work on some boxes
        buttons = {"className": "android.widget.LinearLayout", "clickable": "true"}
        items = self.screen.base.driver.get_uiautomator_element(buttons)
        if items.child(text=sign_in_lbl).exists:
            self.press_ok_button(False)
        else:
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise AssertionError(f"'{sign_in_lbl}' button not found on {cur_pkg} screen\n\n UI Dump: \n\n{ui_dump}")
        # When Choose Account Type screen is shown, Use Your Remote button does not appear, email entering screen is shown
        if not Settings.is_puck():
            self.pause(1, f"Waiting a bit for the '{use_yr_remote_lbl}' button to display")
            items = self.screen.base.driver.get_uiautomator_element(buttons)
            if items.child(text=use_yr_remote_lbl).exists:
                self.press_down_button()
                self.press_ok_button(False)
            else:
                ui_dump = self.screen.base.get_uiautomator_dump()
                raise AssertionError(f"'{use_yr_remote_lbl}' button not found on {cur_pkg} screen\n\n UI Dump: \n\n{ui_dump}")
        self.screen.base.wait_ui_element_appear({"resourceId": "identifierId"}, 25000)
        self.screen.base.type_text(email)
        self.screen.base.press_back_button()  # to make the Next button visible
        self.screen.base.click_by_locator(next_btn)
        self.screen.base.wait_ui_element_appear({"resourceId": "profileIdentifier", "text": email}, 25000)
        if self.screen.base.driver.is_exist_by_locator({"resourceId": "headingText"}):
            heading_text = self.screen.base.driver.get_uiautomator_element({"resourceId": "headingText"}).text
            if heading_text.lower() == sign_in_lbl.lower():
                error = self.screen.base.driver.get_uiautomator_element(
                    {"className": "android.view.View", "index": 1})[2].text
                ui_dump = self.screen.base.get_uiautomator_dump()
                raise AssertionError(f"Email entering failed with '{error}'\n\n UI Dump: \n\n{ui_dump}")
        if self.screen.base.driver.is_exist_by_locator({"resourceId": "profileIdentifier", "text": email}):
            self.screen.base.type_text(password)
            self.screen.base.press_back_button()  # to make the Next button visible
            self.screen.base.click_by_locator(next_btn)
            if self.screen.base.check_text_availability(self.system_labels.LBL_ACC_AND_SIGN_IN_OPT):
                if self.screen.base.driver.is_exist_by_locator({"resourceId": "android.widget.EditText"}):
                    error = self.screen.base.driver.get_uiautomator_element(
                        {"className": "android.view.View", "index": 1})[1].child(className="android.view.View").text
                else:
                    error = self.screen.base.driver.get_uiautomator_element(
                        {"className": "android.view.View", "index": 2}) \
                        .child(className="android.view.View").child(className="android.view.View").text
                    ui_dump = self.screen.base.get_uiautomator_dump()
                raise AssertionError(f"Password entering failed with '{error}'\n\n UI Dump: \n\n{ui_dump}")

    def remove_google_account(self, email, raise_error=True):
        """
        Removing a Google account

        Args:
            raise_error (bool): if fail a test when no Google account to remove
        """
        self.log.info("Launching Device Settings screen and unlink a Google account")
        self.launch_device_settings_screen()
        if self.is_google_account_present():
            self.select_device_settings_menu_item(self.system_labels.LBL_ACC_AND_SIGN_IN_OPT,
                                                  email,
                                                  self.system_labels.LBL_REMOVE_ACCOUNT)
            self.confirm_action_ok_cancel_screen()
        else:
            ui_dump = self.screen.base.get_uiautomator_dump()
            message = f"{email} Google account was not found, nothing to remove\n\n UI Dump: \n\n{ui_dump}"
            if raise_error:
                raise AssertionError(message)
            self.log.warning(message)

    def is_device_settings_option_on(self, option):
        """
        Get option state if it's ON/OFF e.g Wi-Fi, Notification access etc.
        Device Settings screen with option being checked should be already opened

        Args:
            option (str): option name or just text near the switcher

        Returns:
            bool, None if option was not found
        """
        max_times_go_down = 43  # when option wasn't found, we can try to go to find it
        first_time = False
        for i in range(0, max_times_go_down):
            menu_items = self.screen.base.driver.get_uiautomator_element({"className": "android.widget.LinearLayout",
                                                                          "clickable": "true"})
            # When going one item down, we need only last item to check
            # (and one more if an empty item is present) after first entering the loop
            start_point = 0 if not first_time else menu_items.count - 2
            for item in range(start_point, len(menu_items)):
                first_time = True
                child = menu_items[item].child(className="android.widget.LinearLayout")
                sibling = child.sibling(className="android.widget.LinearLayout")
                # Sometimes, empty item is added to the list on the end, let's skip it
                if child.child(className="android.widget.TextView").exists:
                    if child.child(className="android.widget.TextView").text.lower() == option.lower():
                        option_is_on = sibling.child(className="android.widget.Switch").text.lower() == "on"
                        self.log.debug(f"Device Settings '{option}' option's state is {option_is_on}")
                        return True if sibling.child(className="android.widget.Switch").text.lower() == "on" else False
            self.press_down_button()
        cur_scr = self.get_device_settings_screen_title()
        self.log.error(f"Failed to find Device Settings '{item}' option on the '{cur_scr}' screen")
        return None

    def toggle_device_settings_option(self, option, enable=True):
        """
        Switching option ON/OFF (e.g Wi-Fi, Notification access etc.) in the Device Settings.
        Device Settings screen with option being enabled/disabled should be already opened

        Args:
            option (str): option to be swtiched ON/OFF
            enable (bool): if True, enable
                           if False, disalbe
        """
        self.log.info("Switching Device Settings '{}' option to {}".format(option, enable))
        changed = None
        option_state = self.is_device_settings_option_on(option)
        if option_state is not None:
            if option_state and not enable or not option_state and enable:
                menu_items = self.screen.base.driver.get_uiautomator_element({"className": "android.widget.LinearLayout",
                                                                              "clickable": "true"})
                for item in range(0, menu_items.count):
                    child = menu_items[item].child(className="android.widget.LinearLayout")
                    sibling = child.sibling(className="android.widget.LinearLayout")
                    # Sometimes, empty item is added to the list, let's skip it
                    if child.child(className="android.widget.TextView").exists:
                        if child.child(className="android.widget.TextView").text.lower() == option.lower():
                            self.log.debug(f"Device Settings's '{option}' option found, clicking it")
                            changed = sibling.child(className="android.widget.Switch").click()
            self.log.debug(f"Device Settings's '{option}' option already is in {option_state} state, no need to click it")
            changed = True
        if changed is None:
            cur_scr = self.get_device_settings_screen_title()
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise AssertionError(f"Failed to find '{option}' option on the '{cur_scr}' screen\n\n UI Dump: \n\n{ui_dump}")
        elif not changed:
            cur_scr = self.get_device_settings_screen_title()
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise AssertionError(f"Failed to switch '{option}' option to {enable} state on the '{cur_scr}' screen"
                                 f"\n\n UI Dump: \n\n{ui_dump}")

    def get_device_settings_screen_title(self):
        """
        Get Device Settings screen title e.g. Network & Internet or About etc.

        Returns:
            str, Device Settings screen title
        """
        self.log.info("Getting Device Settings screen title")
        title1 = None
        title2 = None
        if self.screen.base.driver.is_exist_by_locator({"resourceId": "com.android.tv.settings:id/decor_title"}):
            # E.g. main Device Seetings screen, Apps etc.
            title1 = self.screen.base.driver.get_text_by_locator({"resourceId": "com.android.tv.settings:id/decor_title"})
        else:
            self.log.warning("Failed to get Device Settings screen title")
            if self.screen.base.driver.is_exist_by_locator({"resourceId": "com.android.packageinstaller:id/decor_title"}):
                # Title in e.g. App permisions screen etc.
                title2 = self.screen.base.driver.get_text_by_locator(
                    {"resourceId": "com.android.packageinstaller:id/decor_title"})
            else:
                self.log.warning("Failed to get Device Settings packageinstaller screen title")
        return title1 or title2

    def go_back_to_main_device_settings_screen(self):
        """
        Going to the main Device Settings screen ("Settings" for Android), something like go_to_home.
        Sometimes, Device Settings may open not in the main screen, e.g. in Notification access,
        so need to set initial screen to proceed with changing params of Device Settings
        """
        self.log.info("Go back to the main Device Settings screen...")
        max_times_go_back = 15
        main_screen = self.labels.LBL_SETTINGS_MAIN
        for i in range(0, max_times_go_back):
            cur_scr = self.get_device_settings_screen_title()
            self.log.debug(f"Main Device Settings screen = {main_screen}, current screen = {cur_scr}")
            if cur_scr != main_screen:
                cur_pkg = self.screen.base.driver.get_info_for_node_item()["packageName"]
                if cur_pkg in [self.screen.base.driver.device_settings_pkg_main_view_mode,
                               self.screen.base.driver.device_settings_pkg_installer_view_mode,
                               self.screen.base.driver.sign_in_google_acc_pkg_view_mode,
                               self.screen.base.driver.enter_email_pswd_web_form_view_mode]:
                    self.screen.base.press_back()
                else:
                    self.log.debug("Device Settings is not on foreground")
                    break
            else:
                self.log.debug(f"Device Settings '{main_screen}' main screen displayed")
                break
        cur_scr = self.get_device_settings_screen_title()
        cur_pkg = self.screen.base.driver.get_info_for_node_item()["packageName"]
        if cur_scr != main_screen:
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise AssertionError(f"Failed to return to the main Device Settings screen; "
                                 f"current Device Settings screen: {cur_scr}, "
                                 f"current app: {cur_pkg}\n\n UI Dump: \n\n{ui_dump}")

    def go_back_to_main_google_acc_sign_in_screen(self):
        """
        Going to the main Google account screen, something like go_to_home.
        Sometimes, main new account adding screen may not be open (e.g. signing in failed
        and email entering screen shown), so need to set initial screen to proceed
        with adding a new Google account
        """
        self.log.info("Go back to the main Sign In new Google account screen...")
        max_times_go_back = 8
        sign_in_exists = False
        choose_acc_type_exists = False
        for i in range(0, max_times_go_back):
            cur_pkg = self.screen.base.driver.get_info_for_node_item()["packageName"]
            if cur_pkg not in [self.screen.base.driver.device_settings_pkg_main_view_mode,
                               self.screen.base.driver.sign_in_google_acc_pkg_view_mode,
                               self.screen.base.driver.enter_email_pswd_web_form_view_mode]:
                ui_dump = self.screen.base.get_uiautomator_dump()
                raise AssertionError(f"No Sign In Google account screen displayed, "
                                     f"current app is {cur_pkg}\n\n UI Dump: \n\n{ui_dump}")
            self.log.debug(f"Current screen view mode = {cur_pkg}")
            choose_acc_type_exists = self.screen.base.check_text_availability(self.system_labels.LBL_CHOOSE_ACCOUNT_TYPE)
            if choose_acc_type_exists:
                # This screen contains different account types to select, Google account is what we need
                break
            sign_in_lbl = self.system_labels.LBL_SIGN_IN
            sign_in_btn = {"className": "android.widget.LinearLayout", "clickable": "true", "index": 0}
            sign_in_exists = self.screen.base.driver.get_uiautomator_element(sign_in_btn).child(text=sign_in_lbl).exists
            if sign_in_exists:
                break
            else:
                self.screen.base.press_back()
                self.pause(1, "Waiting for the previous screen to show")
        if not sign_in_exists and not choose_acc_type_exists:
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise AssertionError(f"Failed to return to the main Sign In new Google account screen; "
                                 f"current screen: {cur_pkg}\n\n UI Dump: \n\n{ui_dump}")

    def confirm_action_ok_cancel_screen(self, is_ok=True):
        """
        The screen with OK and Cancel buttons e.g. when removing a Google account or uninstalling an up etc.
        Action confirmation screen should be open before using this method

        Args:
            is_ok (bool): If True, confirm action, if False, cancel action
        """
        self.log.info(f"Action confirmation screen, is_ok = {is_ok}")
        label = self.system_labels.LBL_OK if is_ok else self.system_labels.LBL_CANCEL
        cur_pkg = self.screen.base.driver.get_info_for_node_item()["packageName"]
        if cur_pkg not in [self.screen.base.driver.device_settings_pkg_main_view_mode,
                           self.screen.base.driver.device_settings_pkg_installer_view_mode]:
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise AssertionError(f"Action confirmation screen is not displayed, current app is {cur_pkg}"
                                 f"\n\n UI Dump: \n\n{ui_dump}")
        # Clicking the confirmation buttons using uiatomator does not work on some boxes
        ok_cancel_btns = {"className": "android.widget.LinearLayout", "clickable": "true"}
        items = self.screen.base.driver.get_uiautomator_element(ok_cancel_btns)
        exists_cancel = items.child(text=self.system_labels.LBL_CANCEL).exists
        exists_ok = items.child(text=self.system_labels.LBL_OK).exists
        if not exists_ok or not exists_cancel:
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise AssertionError("Most likely not Device Settings confirmation screen displayed since no OK or Cancel items"
                                 f"\n\n UI Dump: \n\n{ui_dump}")
        # In some screens Cancel is the 1st button, in others - OK
        ok_cancel_btns["index"] = 0
        is_cancel_first = self.screen.base.driver.get_uiautomator_element(ok_cancel_btns) \
            .child(text=self.system_labels.LBL_CANCEL).exists
        del ok_cancel_btns["index"]
        if is_cancel_first and is_ok or not is_cancel_first and not is_ok:
            self.press_down_button()  # to show highlight over the 1st item
            self.press_down_button()  # highlight needed item
        else:
            self.press_down_button()  # highlight needed item
        # Checking if needed item is highlighted
        ok_cancel_btns["focused"] = "true"
        if self.screen.base.driver.get_uiautomator_element(ok_cancel_btns).child(text=label).exists:
            self.press_ok_button(False)
        else:
            cur_focused = self.screen.base.driver.get_uiautomator_element(ok_cancel_btns) \
                .child(className="android.widget.TextView").text
            del ok_cancel_btns["focused"]
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise Exception(f"Failed to select '{label}' item, currently highlighted - '{cur_focused}'"
                            f"\n\n UI Dump: \n\n{ui_dump}")

    def change_device_name(self, device_name, device_name_key=False):
        """
        Changing device name from android settings
        Returns:

        """
        self.screen.base.driver.device_name_change_settings()
        self.screen.base.driver.is_exist_by_locator(text="Change")
        self.screen.base.driver.uiautomator_device.press.center()
        custom_name = {"resourceId": "com.android.tv.settings:id/guidedactions_item_content", "index": 5}
        for x in range(10):
            self.screen.base.driver.uiautomator_device.press.down()
            if self.screen.base.driver.get_uiautomator_element(custom_name).child(text="Enter custom name…").exists:
                break
        self.screen.base.driver.uiautomator_device.press.center()
        if not device_name_key:
            self.screen.base.type_text(device_name)
        else:
            self.screen.base.driver.press_key(device_name, post_hold_time=500)
        self.screen.base.driver.uiautomator_device.press.enter()
        self.pause(5)  # pausing for device name to get reflected

    def get_device_settings_mac_address(self):
        self.screen.base.launch_device_settings_screen()
        time.sleep(5)
        args = ["Network & Internet", "Network & internet"]
        for item in args:
            if self.screen.base.is_text_present(item):
                self.screen.base.select_item_by_text(item)
                break
        else:
            self.log.info("Device settings does not have network & internet option")
        time.sleep(5)
        self.screen.base.press_down_multiple(10)
        value = self.screen.base.driver.get_uiautomator_element(
            {"className": "android.widget.LinearLayout", "index": 5}) \
            .child(className="android.widget.TextView", index=1).text
        value = value.split('\n')
        self.log.info("Device settings mac address {}".format(value[0]))
        return value[0]

    def validate_device_mac_with_device_settings_mac_address(self):
        self.log.info("Verifying device mac address is same in device settings screen")
        mac = self.screen.base.driver.get_mac_address()
        settings_mac = self.get_device_settings_mac_address()
        assert_that(mac, contains_string(settings_mac), "Device mac address is not same")

    def validate_device_prop_details(self):
        self.log.info("Verifying device prop details")
        device_prop = self.screen.base.driver.get_atv_device_prop()
        assert device_prop, "Device does not have atv properties details"
        result = re.search("^ATV.*", device_prop)
        if result:
            self.log.info("Device prop detail verified")
        else:
            raise AssertionError("Device does not match properties details. Actual value{}".format(device_prop))

    def validate_android_id(self):
        self.log.info("Device android id")
        android_id = self.screen.base.driver.get_android_id()
        assert android_id, "Device does not have android_id"

    def verify_foreground_app_uiautomator(self, package=Settings.app_package, expected=True, raise_error=True):
        """
        Verifying current foreground package.
        When exiting Hydra app using UI elements e.g. serviceCall overaly or Exit app (unmanaged boxes),
        Hydra app may not shown on UI but still recognized as a foreground app in self.screen.base.verify_foreground_app()

        Args:
            package (str): package which is expected to be on foreground
            expected (bool): True - pacakage is on foreground, False - package is not expected to be on foreground
            raise_error (bool): True - raise exception if comparing failed, False - just returning True/False

        Note:
            Be careful, calling uiautomator methods may turn TTS on when doing it while in Screensaver

        Returns:
            bool, if passed package is currently on foreground
        """
        self.log.info(f"Verifying foreground package using uiatomator; package {package}; "
                      f"expected {expected}, raise_error {raise_error}")
        cur_pkg = self.screen.base.driver.get_info_for_node_item()["packageName"]
        if cur_pkg != package and expected or cur_pkg == package and not expected:
            if raise_error:
                raise AssertionError("Verifying foreground package failed."
                                     f"Passed package {package}; actual package {cur_pkg}; expected {expected}")
            else:
                return False
        return True

    def reboot_device_through_UI(self):
        self.log.info("Reboot device through UI")
        if self.screen.base.is_text_present(self.labels.LBL_DEVICE_PREFERENCE):
            self.screen.base.select_item_by_text(self.labels.LBL_DEVICE_PREFERENCE)
            self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
            if int(Settings.os_version) < 10:
                if self.screen.base.is_text_present(self.labels.LBL_ABOUT):
                    self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
                    self.screen.base.select_item_by_text(self.labels.LBL_ABOUT)
                    self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
            else:
                press_down = 0
                reboot_present = 16
                while press_down < reboot_present:
                    self.screen.base.press_down()
                    press_down += 1
            if self.screen.base.is_text_present(self.labels.LBL_REBOOT):
                self.screen.base.select_item_by_text(self.labels.LBL_REBOOT)
                self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
                if self.screen.base.is_text_present(self.labels.LBL_REBOOT):
                    self.screen.base.press_down()
                    self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
                    self.screen.base.press_up()
                    self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
                    self.screen.base.press_enter()
                    self.log.info("Restart through UI and waiting..")
                    self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
                else:
                    raise AssertionError("Unable to select OK")
            else:
                raise AssertionError("Unable to select Restart")
        elif self.screen.base.is_text_present(self.labels.LBL_REBOOT):
            self.screen.base.select_item_by_text(self.labels.LBL_REBOOT)
            self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
            if self.screen.base.is_text_present(self.labels.LBL_REBOOT):
                self.screen.base.press_down()
                self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
                self.screen.base.press_up()
                self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
                self.screen.base.press_enter()
                self.log.info("Restart through UI and waiting.. in elif block")
                self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
            else:
                raise AssertionError("Unable to select Restart")
        else:
            raise AssertionError("launching settings taking time. add delay")

    def go_to_apps_and_select_hydra_app_and_clear_data(self):
        self.log.info("Going to app and select hydra app and clear data..")
        app_name = self.labels.LBL_APP_NAME_FOR_MSO.get(Settings.mso)
        if not app_name:
            raise AssertionError(f"App name is not defined for mso {Settings.mso}")
        if self.screen.base.is_text_present(self.system_labels.LBL_APPS):
            self.screen.base.select_item_by_text(self.system_labels.LBL_APPS)
            self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
            if self.screen.base.is_text_present(app_name):
                self.screen.base.select_item_by_text(app_name)
                self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
                if self.screen.base.is_text_present(self.system_labels.LBL_CLEAR_DATA):
                    self.screen.base.select_item_by_text(self.system_labels.LBL_CLEAR_DATA)
                    self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
                    self.confirm_action_ok_cancel_screen()
                else:
                    raise AssertionError("Clear data option is not present on screen")
            else:
                raise AssertionError(f"unable to select {app_name}")
        else:
            self.log.info("Already in Hydra app screen and clearing data now..")
            if self.screen.base.is_text_present(self.system_labels.LBL_CLEAR_DATA):
                self.screen.base.select_item_by_text(self.system_labels.LBL_CLEAR_DATA)
                self.pause(self.system_labels.LBL_SCREEN_PAUSE_TIME)
                self.confirm_action_ok_cancel_screen()
            else:
                raise AssertionError("Clear data option is not present on screen")

    def validate_temperature(self):
        self.log.info("Getting Device temperature")
        temperature = self.screen.base.driver.get_battery_temperature()
        if temperature <= self.system_labels.TEMP_WARNING:
            self.log.info("Temperature of device is {} which is less than threshold".format(temperature))
            return
        elif self.system_labels.TEMP_WARNING < temperature < self.system_labels.TEMP_STOP_EXEC:
            self.log.warning("Temperature of device is {} which is more than threshold".format(temperature))
        else:
            raise AssertionError(f"Temperature of device is too high '{temperature}'. Stopping execution")

    def launch_global_ads_from_device_settings(self):
        self.screen.base.launch_global_ads_screen()
        ui_dump = self.screen.base.get_uiautomator_dump()
        if 'Reset advertising ID' in ui_dump:
            self.screen.base.driver.click_by_text(text="Delete advertising ID")
            self.press_down_button()
            self.press_down_button()
            self.press_down_button()
            self.screen.base.driver.uiautomator_device.press.center()
            self.screen.base.driver.uiautomator_device.press.center()
            return True
        else:
            self.screen.base.driver.click_by_text(text="Get new advertising ID")
            self.screen.base.driver.click_by_text(text="Confirm")
            return False

    def change_screensaver_time(self, screensaver_time, times=7):
        """
            Changing screensaver timing name from android settings
            Returns:

        """
        self.screen.base.driver.launch_screensaver_settings()
        if not Settings.is_fire_tv():
            for i in range(times):
                if self.screen.base.driver.is_exist_by_locator(text="When to start"):
                    self.screen.base.driver.uiautomator_device.press.center()
                    break
                else:
                    self.screen.base.driver.uiautomator_device.press.down()
        else:
            for i in range(times):
                if self.screen.base.driver.is_exist_by_locator(text="Start Time"):
                    self.screen.base.driver.uiautomator_device.press.center()
                    break
                else:
                    self.screen.base.driver.uiautomator_device.press.down()
        texts = self.system_labels.LBL_SCREEN_SAVER_TIME
        for text in texts:
            if screensaver_time == text:
                self.screen.base.driver.is_exist_by_locator(text=text)
                self.screen.base.driver.uiautomator_device.press.center()
                return True
            else:
                self.screen.base.driver.uiautomator_device.press.down()
        raise self.log.error(f"Failed to find the : '{screensaver_time}' option")
