from hamcrest import assert_that, is_

from set_top_box.client_api.ott_deeplinking.page import DeeplinkingPage


class DeeplinkAssertions(DeeplinkingPage):

    def verify_ott_screen_title(self, screen_title, video_title):
        self.log.info("Verifying screen title and video title of an asset are matching")
        if screen_title.upper() == video_title.upper():
            self.log.info(" {} and {} are matching".format(screen_title.upper(), video_title.upper()))
        else:
            assert f"Expected `{video_title.upper()}` is not on screen text: {screen_title.upper()}"

    def verify_ott_screen_with_package(self, package, app_name):
        self.pause(20)
        self.log.info(f"Verifying {app_name} program screen shown.")
        assert_that(self.screen.base.verify_foreground_app(package), f"{app_name} app didn't start.")

    def verify_gallery_screen(self, tester):
        self.log.info("Verifying Gallery screen")
        self.screen.refresh()
        assert_that(self.view_mode(), is_(tester.vod_labels.LBL_GALLERY_SCREEN_VIEW_MODE))

    def verify_ott_icon_existence(self, icon):
        self.log.step("Nav to show available from OTT")
        available_icon = []
        for i in range(20):
            self.screen.refresh()
            pane = self.get_preview_panel()
            if 'availableOn' in pane:
                ott_icon = self.get_preview_panel()['availableOn']
                ott_icon_list = ott_icon['imagename']
                available_icon.append(ott_icon_list)
                if type(ott_icon_list) is list:
                    for ott in ott_icon_list:
                        if icon in ott:
                            self.log.info("OTT icon exists {}".format(icon))
                            return True
                else:
                    if icon in ott_icon_list:
                        self.log.info("OTT icon exists {}".format(icon))
                        return True
            self.menu_navigate_left_right(0, 1)
        return False

    def verify_hulu_screen(self, tester, package):
        self.log.info(f"Verifying {package} program screen shown.")
        assert_that(self.screen.base.verify_foreground_app(package), f"{package} app didn't start.")
        assert_that(tester.vision_page.verify_av_playback(), "playback of an asset didn't start.")

    def verify_app_provider_in_strip(self, *args):
        """
         *args - it accepts 2 or more arguments , here arguments are provider names and app icon names in png format
        """
        strips = self.strip_list()
        self.log.info("strips displayed {}".format(strips))
        check = any(app in strips for app in args)
        if check is True:
            assert False, " Expected: {0} should not be present in the strip. Actual: {0} is present in the strip" \
                .format(args[0])
        else:
            self.log.info("App is not present in the strip")

    def is_app_content_playback_started(self, timeout=5000, since='now'):
        self.log.info("verifying APP content playback")
        string = self.ott_deeplinking_labels.LBL_APP_PLAYBACK_STATE
        raw_log = self.screen.base.find_str_in_log(string=string, since=since, timeout=timeout)
        if not raw_log:
            self.log.info(f"Unable to find any log with string: '{string}' within {timeout} miliseconds")
            return False
        return True
