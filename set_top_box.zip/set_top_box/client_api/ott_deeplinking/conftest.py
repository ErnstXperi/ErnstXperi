import pytest

from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.my_shows.assertions import MyShowsAssertions
from set_top_box.client_api.text_search.assertions import TextSearchAssertions
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.client_api.ott_deeplinking.assertions import DeeplinkAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.client_api.program_options.assertions import ProgramOptionsAssertions
from set_top_box.client_api.VOD.assertions import VODAssertions
from set_top_box.client_api.apps_and_games.assertions import AppsAndGamesAssertions
from set_top_box.client_api.wtw.assertions import WhatToWatchAssertions
from set_top_box.client_api.guide.assertions import GuideAssertions
from core_api.stb.assertions import CoreAssertions
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from set_top_box.test_settings import Settings
from tools.logger.logger import Logger

__logger = Logger(__name__)


@pytest.fixture(autouse=True, scope="class")
def setup_ott_deeplinking(request):
    """
    Configure steps to be executed before the test cases run
    :param request:
    :return:
    """
    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_assertions = HomeAssertions(request.cls.screen)
    request.cls.home_labels = LabelFactory("home", Settings)

    request.cls.my_shows_labels = LabelFactory("my_shows", Settings)
    request.cls.my_shows_page = PageFactory("my_shows", Settings, request.cls.screen)
    request.cls.my_shows_assertions = MyShowsAssertions(request.cls.screen)

    request.cls.apps_and_games_assertions = AppsAndGamesAssertions(request.cls.screen)
    request.cls.apps_and_games_labels = LabelFactory("apps_and_games", Settings)
    request.cls.apps_and_games_page = PageFactory("apps_and_games", Settings, request.cls.screen)

    request.cls.vod_page = PageFactory("VOD", Settings, request.cls.screen)
    request.cls.vod_labels = request.cls.vod_page.vod_labels = LabelFactory("VOD", Settings)
    request.cls.vod_assertions = VODAssertions(request.cls.screen)

    request.cls.watchvideo_assertions = WatchVideoAssertions(request.cls.screen)
    request.cls.watchvideo_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.watchvideo_labels = LabelFactory("watchvideo", Settings)

    request.cls.wtw_page = PageFactory("wtw", Settings, request.cls.screen)
    request.cls.wtw_labels = LabelFactory("wtw", Settings)
    request.cls.wtw_assertions = WhatToWatchAssertions(request.cls.screen)

    request.cls.text_search_labels = LabelFactory("text_search", Settings)
    request.cls.text_search_page = PageFactory("text_search", Settings, request.cls.screen)
    request.cls.text_search_page.text_search_labels = request.cls.text_search_labels
    request.cls.text_search_assertions = TextSearchAssertions(request.cls.screen)
    request.cls.text_search_assertions.text_search_labels = request.cls.text_search_labels

    request.cls.program_options_page = PageFactory("program_options", Settings, request.cls.screen)
    request.cls.program_options_assertions = ProgramOptionsAssertions(request.cls.screen)
    request.cls.program_options_labels = LabelFactory("program_options", Settings)

    request.cls.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)

    request.cls.core_assertions = CoreAssertions(request.cls.screen)

    request.getfixturevalue('device_reboot_to_imporve_device_perf')
    request.getfixturevalue('clean_ftux_and_sign_in')

    request.cls.menu_labels = LabelFactory("Menu", Settings)
    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)

    request.cls.ott_deeplinking_page = PageFactory("ott_deeplinking", Settings, request.cls.screen)
    request.cls.ott_deeplinking_labels = LabelFactory("ott_deeplinking", Settings)
    request.cls.ott_deeplinking_assertions = DeeplinkAssertions(request.cls.screen)


@pytest.fixture(autouse=False, scope="class")
def enabling_video_providers(request):
    """
    :description:
        enable video providers in Video provider list
    """
    def setup():
        __logger.info("Enable video providers in Video provider list")
        if not Settings.is_fire_tv():
            request.cls.menu_page.go_to_video_providers(request.cls)
            request.cls.menu_page.check_or_uncheck_all_menu_items()
    setup()
