import pytest
import time
from datetime import datetime
import pytz
from core_api.stb.assertions import CoreAssertions
from mind_api.dependency_injection.containers.offer_container import OfferIocContainer
from set_top_box.test_settings import Settings
from set_top_box.conf_constants import HydraBranches
from set_top_box.client_api.my_shows.en_us.labels import MyShowsLabels
from set_top_box.client_api.ott_deeplinking.en_us.labels import DeeplinkingLabels
from set_top_box.client_api.apps_and_games.en_us.labels import AppsAndGamesLabels


class DeeplinkingPage(CoreAssertions):
    my_shows_labels = MyShowsLabels()
    ott_deeplinking_labels = DeeplinkingLabels()
    apps_and_games_labels = AppsAndGamesLabels()

    def trim_year_from_movie_screentitle(self, title):
        self.log.info("movie title {} : ".format(title))
        split_year = title.split("(")
        index = (split_year[0])
        trimed_value = index.strip()
        return trimed_value

    def verify_watch_button(self):
        if self.screen.base.driver.is_exist_by_locator(self.ott_deeplinking_labels.LOC_WATCH_TRAILER) or \
                self.screen.base.driver.is_exist_by_locator(self.ott_deeplinking_labels.LOC_WATCH_HDX) or \
                self.screen.base.driver.is_exist_by_locator(self.ott_deeplinking_labels.LOC_WATCH) or \
                self.screen.base.driver.is_exist_by_locator(self.ott_deeplinking_labels.LOC_WATCH_SD):
            self.screen.base.press_enter()

    def verify_resume_button(self):
        if not self.screen.base.is_exist_by_resource_id(self.ott_deeplinking_labels.LOC_RESUME_BUTTON_DICT):
            self.log.info("Playback of an asset without resume option")
        else:
            self.log.info("Click resume option and check for the playback ")
            self.screen.base.click_by_locator(self.ott_deeplinking_labels.LOC_RESUME_BUTTON)

    def verify_play_trailer_button(self):
        if self.screen.base.driver.is_exist_by_locator(self.ott_deeplinking_labels.LOC_PLAYER_TRAILER_BUTTON):
            self.screen.base.press_enter()

    def replace_character(self, title, ampersand=False):
        trimed_value = self.trim_year_from_movie_screentitle(title)
        new_string = trimed_value.replace("'", "")
        if ampersand:
            title = new_string
            spl_title = title.split(" ")
            new_string = []
            for each in spl_title:
                if "AND" in each:
                    pos = each.index("AND")
                    if pos == 0:
                        try:
                            if each[pos + 3]:
                                new_string.append(each)
                        except Exception:
                            rep = each.replace("AND", "&")
                            new_string.append(rep)
                    else:
                        new_string.append(each)
                else:
                    new_string.append(each)
            my_text = " ".join(new_string)
            self.log.info("Replacement of an ampersand in a title {}".format(my_text))
            return my_text
        return new_string

    def trim_ep_from_series_screentitle(self, title):
        self.log.info("series title {} : ".format(title))
        split_ep = title.split("-")
        index = (split_ep[0])
        trimed_value = index.strip()
        return trimed_value

    def nav_to_more_option(self):
        self.screen.base.press_right()
        self.screen.base.press_enter()
        self.screen.refresh()

    def verify_install_button(self):
        install_lbl = self.ott_deeplinking_labels.LBL_GOOGLE_PLAY_INSTALL_BUTTON
        button = {"className": "android.widget.Button", "clickable": "true"}
        value = self.screen.base.driver.get_uiautomator_element(button)
        if not value.child(text=install_lbl).exists:
            self.screen.base.press_enter()
        else:
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise AssertionError(f"Install button not found '{value}'\n\n UI Dump: \n\n{ui_dump}")

    def verify_and_nav_prime_video_or_membership_in_strip(self, prime_membership, prime_video):
        strips = self.strip_list()
        self.log.info("strips displayed {}".format(strips))
        if prime_membership or prime_video in strips:
            for icon in strips:
                if icon == prime_membership:
                    self.navigate_by_strip(prime_membership)
                    self.log.info("navigated to strip item {}".format(prime_membership))
                if icon == prime_video:
                    self.navigate_by_strip(prime_membership, matcher_type=prime_video)
                    self.log.info("navigated to strip item {}".format(prime_video))
        else:
            assert False, "Expected: {} and {} should be present but Actual : {}".format(prime_video, prime_membership,
                                                                                         strips)

    def select_any_asset(self):
        self.log.info("Selecting random asset.")
        self.screen.base.press_down()
        self.screen.refresh()
        self.screen.base.press_enter()
        time.sleep(5)
        self.screen.refresh()
        self.screen.base.press_enter(5000)

    def verify_screen_title(self, screen_title_after_year_trim):
        title = {"className": "android.widget.TextView", "clickable": "false"}
        value = self.screen.base.driver.get_uiautomator_element(title)
        if not value.child(text=screen_title_after_year_trim).exists:
            self.log.info("Screen Title found : {}".format(screen_title_after_year_trim))
        else:
            ui_dump = self.screen.base.get_uiautomator_dump()
            raise AssertionError(f"Screen title not found '{value}'\n\n UI Dump: \n\n{ui_dump}")

    def select_amazon_image_strip(self):
        self.screen.refresh()
        strip_list = self.strip_list_type("imagename")
        strip = [i for i in strip_list if i]
        self.log.info("strip Image name{}".format(strip))
        found = False
        strip_element = ""
        for image in strip:
            if image == self.my_shows_labels.LBL_AMAZON_PRIME_ICON or image == self.my_shows_labels.LBL_AMAZON_ICON:
                found = True
                strip_element = image
                self.log.info("Found OTT Image name{}".format(image))
                break
        if found:
            self.log.info("selecting strip_item {}".format(strip_element))
            strip = self.strip_list()
            self.log.step(
                f"Got strip from strip_list(): {str(strip)}. Selecting Strip Item '{strip_element}' from the strip.")
            self.navigate_by_strip(strip_element, matcher_type="strict")
            self.select_item(refresh=True)
            self.log.info("strip item {} selected successfully".format(strip_element))
        else:
            pytest.skip("Program does not have OTT content in available list")

    def select_amazon_option(self, *prime_locators):
        strips = self.strip_list()
        for strip in strips:
            if strip in prime_locators:
                self.navigate_by_strip(strip)
                self.log.info("navigated to strip item {}".format(strip))
                self.select_item()
                self.log.info("strip item {} selected successfully".format(strip))
                break
        else:
            assert False, "Expected: {} should be present but Actual : {}".format(prime_locators, strips)

    def search_for_asset_nav_right(self, locator, iter_num=10):
        """Searches the asset till specific locator is found and press enter by navigating right for
        specified iteration"""
        for right in range(iter_num):
            self.screen.base.press_right()
            self.screen.base.press_enter()
            time.sleep(5)
            if self.screen.base.driver.is_exist_by_locator(locator):
                self.screen.base.press_enter()
                break
            else:
                self.screen.base.press_back()
        else:
            assert False, f"{locator} Asset did not find after {iter_num} tries"

    def search_ott_provider_by_ui(self, icon, jumpSeason_option=True):
        """
        This method searches and verifies ott providers on preview pane for episodes
        if jumpSeason is True , verifies the focus on season episodes
        """
        found = True
        i = 0
        while i <= 20 and found:
            try:
                previewPane = self.get_preview_panel()
                preview_image = previewPane["previewImage"]
                self.log.info('previewImage is {}:'.format(preview_image))
                if jumpSeason_option:
                    self.verify_focusOnSeason()
            except Exception:
                self.screen.base.press_down()
                i += 1
            else:
                if type(preview_image) is list:
                    for ott_icon in preview_image:
                        if icon in ott_icon:
                            found = False
                            break
                    else:
                        self.screen.base.press_down()
                        i += 1
                else:
                    if icon in preview_image:
                        found = False
                        break
                    else:
                        self.screen.base.press_down()
                        i += 1
        if found:
            pytest.skip("Test requires {} provider for episodes.".format(icon))

    def search_ott_provider_on_upcoming_by_api(self, tester, provider):
        """
        This method searches and verifies ott providers on preview pane for episodes
        Args:
            tester: object of pytest testcase
            provider: provider text

        """
        time_zone = self.service_api.get_time_zone_with_body_search()
        found = True
        i = 0
        while i <= 20 and found:
            focused_menu_item = self.menu_item_option_focus()
            screen_title = self.screen.get_screen_dump_item('screentitle')
            channel_id = focused_menu_item[3]
            dt_object = tester.my_shows_page.get_show_start_time_on_upcoming_screen(focused_menu_item)
            channel_details_from_mind = tester.my_shows_page.get_channel_by_id(channel_id)
            content_id = ""
            for chan in channel_details_from_mind:
                start_time = datetime.strptime(datetime.fromtimestamp(int(chan.start_time))
                                               .strftime(self.service_api.MIND_DATE_TIME_FORMAT),
                                               self.service_api.MIND_DATE_TIME_FORMAT)
                show_start_time = self.service_api.convert_given_time_to_local_time(start_time,
                                                                                    pytz.timezone(time_zone))
                if chan.title.lower() == screen_title.lower() and show_start_time == dt_object:
                    content_id = chan.content_id
                    break
            show_data = self.service_api.get_preview_offer(content_id, mode="content")
            providers_list = show_data.providers_list
            for prov in providers_list:
                if prov['displayName'] == provider:
                    found = False
                    break
            else:
                self.screen.base.press_down()
                i += 1
        if found:
            pytest.skip("Test requires {} provider for episodes.".format(provider))

    def search_ott_provider(self, tester, icon, jumpSeason_option=True, strip_to_check="", provider=""):
        """
        This method searches and verifies ott providers on preview pane for episodes
        if strip_to_check is Upcoming and HydraBranche>=HydraBranches.STREAMER_1_19 will be
        used search_ott_provider_on_upcoming_by_api function

        :param icon: provider icon
        :param jumpSeason_option: if jumpSeason is True , verifies the focus on season episodes
        :param strip_to_check: strip name, can be Upcoming, All Episodes
        :param tester: object of pytest testcase
        :param provider: provider text name
        """
        if strip_to_check == "Upcoming" and Settings.hydra_branch() >= \
                Settings.hydra_branch(HydraBranches.STREAMER_1_19):
            self.search_ott_provider_on_upcoming_by_api(tester, provider)
        else:
            self.search_ott_provider_by_ui(icon, jumpSeason_option)

    def select_live_and_upcoming(self):
        self.log.step("Selecting live offer from live and upcoming")
        self.screen.base.press_left(time=2000)
        self.screen.get_json()
        if self.is_in_menu(self.ott_deeplinking_labels.LBL_LIVE_AND_UPCOMING):
            self.select_menu(self.ott_deeplinking_labels.LBL_LIVE_AND_UPCOMING)
        elif self.is_in_menu(self.ott_deeplinking_labels.LBL_UPCOMING):
            self.select_menu(self.ott_deeplinking_labels.LBL_UPCOMING)
        else:
            pytest.skip("No Upcoming programs are available hence skipping ")

    def check_trailer_button_exists(self):
        if self.screen.base.driver.is_exist_by_locator(self.ott_deeplinking_labels.LOC_WATCH_TRAILER) or \
                self.screen.base.driver.is_exist_by_locator(self.ott_deeplinking_labels.LOC_WATCH_HDX) or \
                self.screen.base.driver.is_exist_by_locator(self.ott_deeplinking_labels.LOC_WATCH_SD) or \
                self.screen.base.driver.is_exist_by_locator(self.ott_deeplinking_labels.LOC_PLAYER_TRAILER_BUTTON):
            return True
        else:
            return False

    def verify_focusOnSeason(self):
        """
        Verify focus is on season while searching for episodes
        """
        menu_item = self.get_menu_item()
        self.log.info('MenuItem is {}:'.format(menu_item))
        if type(menu_item) is not list:
            menu_item = [menu_item]
        for item in menu_item:
            if item.get("hasfocus") == "true" and item.get("text"):
                episode_name = item.get("text")
                if not episode_name[0][0].isdigit():
                    pass
                else:
                    raise AssertionError(f"Focus is on Jump Season ({episode_name}), but not expected.")

    def nav_to_show_on_wtw_strip(self, show_name, confirm=True, use_preview_panel=False):
        self.log.info(f"seeking for {show_name} in strip")
        counter = 0
        if use_preview_panel:
            current = self.get_preview_panel().get('title', None)
        else:
            current = self.strip_focus()
        if not isinstance(show_name, list):
            target_show_names_list = [show_name]
        else:
            target_show_names_list = show_name
        required_show_highlighted = ""
        if current:
            while True:
                for target_show in target_show_names_list:
                    if isinstance(target_show[0], str) and (target_show[0] in current or current in target_show[0]):
                        self.log.info(f"Show is {target_show[0]}")
                        required_show_highlighted = target_show[0]
                        break
                if required_show_highlighted:
                    break
                self.press_right_button()
                self.pause(2)  # no event for that
                previous = current
                if use_preview_panel:
                    try:
                        current = self.get_preview_panel().get('title', None)
                    except Exception:
                        time.sleep(20)
                        current = self.get_preview_panel().get('title', None)
                else:
                    self.screen.refresh()
                    current = self.strip_focus()
                counter += 1
                if current == previous or counter > 50:
                    pytest.skip(f"{show_name} wasn't found on strip after 50 tries")
        else:
            raise AssertionError("Asset Title not returned")
        if confirm:
            self.press_ok_button()
        return required_show_highlighted

    def return_program_from_service_api(self, feedlist, fallback_program_name, ott=None, fallback_year=None):
        """
        Program is returned from service api or else it will hardcode the program which user has mentioned
        feedlist : list of feednames to be search
        ott : name of the OTT the provider , if ott = None, it will return any provider offer
        eg : Netflix , VUDU etc
        program_name : Offer/program name which need to hardcode
        fallback_year : offer year if any
        year argument is mandatory for movies
        """
        for feed in feedlist:
            program = self.service_api.get_show_available_from_OTT(feedName=feed, OTT=ott,
                                                                   no_partnerIdCount=False)
            program = None
            if program:
                break
        else:
            fallback_program_name_title = fallback_program_name.title()
            if fallback_year:
                self.log.info(" Program not found using service api hence hardcoding it.")
                program = [(fallback_program_name_title, fallback_year)]
            else:
                self.log.info(" Program not found using service api hence hardcoding it.")
                program = [(fallback_program_name_title, " ")]
        return program
