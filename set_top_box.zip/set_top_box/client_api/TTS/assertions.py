import re
import json
from hamcrest.core import assert_that
from hamcrest import has_item, not_none, greater_than, equal_to, has_value, any_of, has_items, contains_string, is_
from tools.logger.logger import Logger
from set_top_box.client_api.TTS.page import TTSPage


class TTSAssertions(TTSPage):
    __logger = Logger(__name__)

    def verify_tts_text(self, tester, expected_text):
        self.log.info("Expected TTS LOG : {}".format(expected_text))
        assert_that(self.pattern_check(expected_text), f"TTS log {expected_text} not found")

    def verify_home_screen_tts(self, tester):
        self.pause(30)  # delay to capture logs
        self.log.step("Verifying Screen title of Home Screen:")
        screen_title = tester.tts_labels.LBL_SCREENTITLE
        self.verify_tts_text(tester, screen_title)
        self.log.info("Screen title validation succeeded")
        self.log.step("Verifying Tip Text of Home Screen:")
        self.verify_tts_text(tester, tester.tts_labels.LBL_HOME_TIP)
        self.log.info("Tip Text validation succeeded")
        self.log.step("Verifying Press Right Option of Home Screen:")
        self.verify_tts_text(tester, tester.tts_labels.LBL_HOME_PRESS_RIGHT)
        self.log.info("Press Right Option Text validation succeeded")

    def pattern_check(self, pattern_list):
        pat = re.compile('.*'.join(map(re.escape, pattern_list)))
        log_list = self.get_log()
        self.log.info("log_list ={}".format(log_list))
        match_found = False
        for line in log_list:
            self.log.info("checking if Line: {} matches  pattern: {} ".format(line, pat))
            if pat.search(line):
                match_found = True
                break
        return match_found

    def verify_one_pass_recording_options_tts(self, tester):
        self.log.step("Selecting OnePass & Recording Options from user preferences")
        self.select_menu(tester.guide_labels.LBL_ONEPASS_AND_RECORDING_OPTIONS)
        self.log.step("Verifying Screen Title of One pass Options")
        self.pause(30)
        screen_title = tester.tts_labels.LBL_SCREENTITLE_ONEPASS
        self.verify_tts_text(tester, screen_title)
        self.log.info("Screen title validation succeeded")
        self.log.step("Verifying other contents in screen")
        self.verify_tts_text(tester, tester.tts_labels.LBL_ONE_PASS_OPTIONS_SCREEN)
        self.log.info("verification succeeded")

    def verify_home_screen_on_demand_tts(self, tester):
        self.log.step("Verifying ONDEMAND option in home screen")
        self.verify_tts_text(tester, tester.tts_labels.LBL_ONDEMAND_OPTIONS)
        self.log.info("verification succeeded of OnDemand Menu")

    def verify_home_screen_menu_items(self, tester):
        self.log.step("Navigating to home screen menu items")
        for item in tester.home_labels.LBL_HOME_MENU_ITEMS:
            self.navigate_by_strip(item)
            self.log.step("Navigated to menu items {}".format(item))
        self.log.step("Verify Home screen menu items")
        for menu in tester.tts_labels.LBL__HOME_MENU_ITEMS:
            menu_list = tester.tts_labels.LBL_HOME_PRESS_RIGHT_FOR_ALL_MENU
            menu_list[0] = menu
            if menu == 'Search':
                menu_list[2] = "press left for other items"
            self.verify_tts_text(tester, menu_list)
            self.log.step("{} is verified successfully".format(menu))

    def verify_program_title_tts(self, tester):
        self.log.step("Verifying show title on socu offer program screen")
        title = self.get_preview_panel()['title']
        self.verify_tts_text(tester, title)

    def verify_socu_offer_tts(self, tester):
        self.log.step("Verifying watch now from SOCU offer")
        self.verify_tts_text(tester, tester.tts_labels.LBL_SOCU_OFFER)

    def verify_recording_options_overlay_tts(self, tester):
        self.pause(30)
        self.log.step("Verifying Recording Options Overlay")
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_RECORDING_OPTIONS_OVERLAY_NAME)
        self.verify_tts_text(tester, tester.tts_labels.LBL_RECORDING_OPTIONS)
        self.log.info("Recording Options Overlay verification succeeded")

    def verify_home_menu_strip_highlight_tts(self, tester):
        self.clear_log()
        self.navigate_by_strip(tester.home_labels.LBL_MENU_SHORTCUT)
        self.verify_tts_text(tester, tester.tts_labels.LBL_HOME_PRESS_RIGHT)

    def verify_display_channel_overlay_tts(self, tester):
        self.log.step("Verifying overlay title")
        channel_title = self.screen.get_screen_dump_item('subtitle')
        overlay_title = tester.tts_labels.LBL_OVERLAYTITLE.copy()
        overlay_title.insert(4, channel_title)
        self.verify_tts_text(tester, overlay_title)
        self.log.info("Overlay title validation succeeded")
        self.log.step("Verifying launch app or watch now")
        watch_or_launch = self.screen.get_screen_dump_item('menuitem')[0]['text']
        self.log.info("watch or launch has {}".format(watch_or_launch))
        label = tester.tts_labels.LBL_LAUNCHAPP_OR_WATCHNOW.copy()
        label.insert(0, watch_or_launch)
        self.verify_tts_text(tester, label)
        self.log.info("Watch now or launch app validation succeeded")
        del overlay_title, label
        self.log.step("Verifying remove favorite channel option")
        self.verify_tts_text(tester, tester.tts_labels.LBL_REMOVE_FAV_CHANNEL)
        self.log.info("validation succeeded")

    def verify_current_pin_tts(self, tester):
        self.log.info("Verifying Current PIN")
        self.pause(10)
        self.verify_tts_text(tester, tester.tts_labels.LBL_CURRENT_PIN)
        tester.tts_page.clear_log()

    def verify_new_pin_tts(self, tester):
        self.log.info("Verifying NEW PIN")
        self.pause(10)
        self.verify_tts_text(tester, tester.tts_labels.LBL_NEW_PIN)
        tester.tts_page.clear_log()

    def verify_confirm_pin_tts(self, tester):
        self.log.info("Verifying CONFIRM PIN")
        self.pause(10)
        self.verify_tts_text(tester, tester.tts_labels.LBL_CONFIRM_PIN)
        tester.tts_page.clear_log()

    def verify_pin_change_notify_tts(self, tester):
        self.log.info("Verifying PIN CHANGE")
        self.pause(10)
        self.verify_tts_text(tester, tester.tts_labels.LBL_PIN_CHANGED)

    def verify_change_pin_tts(self, tester):
        self.log.info("Change the pin")
        self.nav_to_menu(tester.menu_labels.LBL_CHANGE_PIN)
        self.pause(10)
        self.verify_tts_text(tester, tester.tts_labels.LBL_CHANGE_PIN)
        tester.tts_page.clear_log()
        self.wait_for_screen_ready(tester.menu_labels.LBL_CHANGE_PIN)
        self.screen.base.press_enter()

    def verify_tts_favorite_panel(self, tester):
        self.log.step("Verifying favorite panel")
        screen_title = None
        screen_title = tester.tts_labels.LBL_FAVORITE_PANEL.copy()
        self.verify_tts_text(tester, screen_title)
        del screen_title
        self.log.info("Screen title validation succeeded")

    def verify_watch_now_strip(self, tester):
        self.log.step("Verifying watch now strip on socu offer program screen")
        self.verify_tts_text(tester, tester.tts_labels.LBL_WATCH_NOW_STRIP)

    def verify_tts_on_trickplay(self, tester, channel_number, text):
        channel = "Channel: " + str(channel_number)
        callsign = tester.watchvideo_page.get_channel_callsign()
        title_before = tester.watchvideo_page.get_show_title()
        title = tester.my_shows_page.remove_service_symbols(title_before)
        trickplay_3 = ["playing  at"]
        if text is not None:
            text_split = text.split()
            season = text_split[0].replace("S", " ")
            episode = text_split[1].replace("E", " ")
            se_text = "Season" + season + " " + "Episode" + episode
            trickplay_2 = [channel, "weak", callsign, "weak", title, "weak", se_text, "weak"]
        else:
            trickplay_2 = [channel, "weak", callsign, "weak", title, "weak"]
        expected_text = tester.tts_labels.LBL_TRICKPLAY + trickplay_2 + trickplay_3
        self.log.info("verification text is {}".format(expected_text))
        self.verify_tts_text(tester, expected_text)

    def verify_tts_after_pressing_skip_option(self, tester):
        self.log.info("Verifying tts after pressing skip option from onepass quick select screen")
        self.verify_tts_text(tester, tester.tts_labels.LBL_SKIP_OPTION)

    def verify_tts_on_vod_action_screen(self, tester):
        self.screen.refresh()
        current = self.get_focused_item(self.get_menu_item_array())
        watch_now = current.get("text") + " Strip"
        tester.tts_labels.LBL_WATCH_NOW.insert(0, watch_now)
        self.verify_tts_text(tester, tester.tts_labels.LBL_WATCH_NOW)
        title = tester.my_shows_page.get_title_from_pane()[:-7]
        tester.tts_labels.LBL_VOD_SCREEN_TITLE.insert(2, title)
        self.verify_tts_text(tester, tester.tts_labels.LBL_VOD_SCREEN_TITLE)
        preview_pane = self.get_preview_panel()
        genre = preview_pane['genre']
        description = preview_pane['description'][:-3]
        duration = preview_pane['duration']
        tester.tts_labels.LBL_PANE_DESCRIPTION.insert(8, genre)
        tester.tts_labels.LBL_PANE_DESCRIPTION.insert(10, description)
        tester.tts_labels.LBL_PANE_DESCRIPTION.insert(16, duration)
        self.verify_tts_text(tester, tester.tts_labels.LBL_PANE_DESCRIPTION)

    def get_strip_list_items(self):
        strip_item = self.screen.get_screen_dump_item('stripitem')
        text = None
        for i in range(len(strip_item)):
            if 'hasfocus' in strip_item[i]:
                text = strip_item[i]['text']
                break
        return text

    def verify_tts_on_series_name_season_num_and_episode_num(self, tester):
        self.log.info("Verifying tts series name season number and episode number")
        self.screen.refresh()
        title = tester.my_shows_page.get_title_from_pane()
        screen_title = self.screen_title()
        text_split = screen_title.split()
        season = text_split[-2].replace("S", " ")
        episode = text_split[-1].replace("E", " ")
        season_text = "Season" + season
        episode_text = "Episode" + episode
        tester.tts_labels.LBL_ACTION_SCREEN_TITLE.insert(2, title)
        tester.tts_labels.LBL_ACTION_SCREEN_TITLE.insert(4, season_text)
        tester.tts_labels.LBL_ACTION_SCREEN_TITLE.insert(6, episode_text)
        self.verify_tts_text(tester, tester.tts_labels.LBL_ACTION_SCREEN_TITLE)

    def verify_tts_on_watch_now_strip(self, tester):
        self.log.info("Verifying tts on watch now strip")
        current = self.get_focused_item(self.get_menu_item_array())
        watch_now = current.get("text") + " Strip"
        tester.tts_labels.LBL_WATCH_NOW_STRIP_TEXT.insert(0, watch_now)
        self.verify_tts_text(tester, tester.tts_labels.LBL_WATCH_NOW_STRIP_TEXT)

    def verify_tts_on_demand_strip(self, tester):
        self.log.info("Verifying tts on on demand strip")
        screen_title = tester.my_shows_page.get_title_from_pane()
        self.screen.refresh()
        text = self.get_strip_list_items()
        if text is not None:
            text_split = text.split()
            self.log.info("text_split ={}".format(text_split))
            season = text_split[0].replace("S", " ")
            episode = text_split[1].replace("E", " ")
        se_text = "Season" + season + " " + "Episode" + episode
        preview_pane = self.get_preview_panel()
        episodeTitle = preview_pane['episodeTitle']
        text_ep = episodeTitle.split()
        tester.tts_labels.LBL_ON_DEMAND_EPISODES_STRIP.insert(2, screen_title)
        tester.tts_labels.LBL_ON_DEMAND_EPISODES_STRIP.insert(4, se_text)
        tester.tts_labels.LBL_ON_DEMAND_EPISODES_STRIP.insert(6, text_ep[2])
        self.verify_tts_text(tester, tester.tts_labels.LBL_ON_DEMAND_EPISODES_STRIP)

    def verify_tts_episode_action_screen(self, tester):
        """
        Announcing: <Screen title>+ SHORT_PAUSE + <program title> + SHORT_PAUSE + <watch now strip <title on
        display>+ MEDIUM_PAUSE + <read preview pane info>
        """
        self.log.info("Verifying tts on episode action")
        self.verify_tts_on_series_name_season_num_and_episode_num(tester)
        self.verify_tts_on_watch_now_strip(tester)
        preview_pane = self.get_preview_panel()
        description = preview_pane['description']
        entitlementStatus = preview_pane['entitlementStatus']
        genre = preview_pane['genre']
        parentalControlRating = preview_pane['parentalControlRating']
        tester.tts_labels.LBL_PROGRAM_SCREEN_PANE_DESCRIPTION.insert(3, entitlementStatus)
        tester.tts_labels.LBL_PROGRAM_SCREEN_PANE_DESCRIPTION.insert(6, "rated" + " " + parentalControlRating)
        tester.tts_labels.LBL_PROGRAM_SCREEN_PANE_DESCRIPTION.insert(8, genre)
        tester.tts_labels.LBL_PROGRAM_SCREEN_PANE_DESCRIPTION.insert(10, description)
        self.verify_tts_text(tester, tester.tts_labels.LBL_PROGRAM_SCREEN_PANE_DESCRIPTION)

    def verify_tts_on_demand_episode_strip(self, tester):
        """
         Announcing: "On Demand Episodes strip" + SHORT_PAUSE +<series_name><Season # Episode#><episode title>
         + SHORT_PAUSE + Available on <content provider logo> + MEDIUM_PAUSE
         + Press RIGHT for other items + Press REPLAY for all items + <preview data>
        """
        self.log.info("Verifying tts on on demand strip from episodic asset")
        self.verify_tts_on_demand_strip(tester)
        preview_pane = self.get_preview_panel()
        description = preview_pane['description']
        entitlementStatus = preview_pane['entitlementStatus']
        tester.tts_labels.LBL_EPISODE_PANE_DESCRIPTION.insert(3, entitlementStatus)
        tester.tts_labels.LBL_EPISODE_PANE_DESCRIPTION.insert(6, description)
        self.pause(10)
        self.verify_tts_text(tester, tester.tts_labels.LBL_EPISODE_PANE_DESCRIPTION)

    def verify_tts_may_also_like_biaxial_strip(self, tester):
        self.log.info("Verifying tts on may also like biaxial strip for movies or non episodic shows")
        self.verify_tts_text(tester, tester.tts_labels.LBL_MAY_ALSO_LIKE_STRIP)
