import os
from tools.logger.logger import Logger
from core_api.stb.assertions import CoreAssertions
from set_top_box.test_settings import Settings


class TTSPage(CoreAssertions):
    __logger = Logger(__name__)
    __tts_log = []
    __stop = False

    def start_collect_tts_logs(self):
        self.log.info("started collecting tts logs ")
        log = False
        while not self.get_stop():
            log = self.wait_for_tts_text(suppress_log=True)
            self.collect_log(log)

    def set_stop(self, stop):
        self.__stop = stop

    def get_stop(self):
        return self.__stop

    def get_log(self):
        return self.__tts_log

    def collect_log(self, log):
        if isinstance(log, str) and log not in self.__tts_log:
            self.__tts_log.append(log)

    def clear_log(self):
        self.log.info("Clearing the TTS log")
        self.__tts_log.clear()

    def get_expected_text_fav_panel_channel_detail(self, tts_label):
        channel_detail = None
        self.screen.refresh()
        channel_info = self.strip_focus()
        if isinstance(channel_info, list):
            channel_detail = tts_label
            tts_label.clear()
            channel_detail.insert(0, channel_info[0])
            channel_detail.insert(2, 'channel ' + channel_info[1].split()[1])
        else:
            self.log.info("Program detail could not be retrieved")
        return channel_detail

    def highlight_and_verify_trickplay_left_side_icons(self, tester):
        self.log.info("Navigating trickplay left side icons")
        self.screen.base.press_left()
        self.screen.refresh()
        tester.tts_assertions.verify_tts_text(tester, tester.tts_labels.LBL_TTS_REWIND)
        self.log.info("Verify Rewind successfull.")
        self.screen.base.press_left()
        self.screen.refresh()
        tester.tts_assertions.verify_tts_text(tester, tester.tts_labels.LBL_TTS_JUMP_BACK)
        self.log.info("Verify Jump back successfull.")
        self.screen.base.press_left()
        self.screen.refresh()
        tester.tts_assertions.verify_tts_text(tester, tester.tts_labels.LBL_TTS_START_OVER)
        self.log.info("Verify start over successfull.")

    def highlight_and_verify_trickplay_right_side_icons(self, tester):
        self.log.info("Navigating trickplay right side icons")
        self.screen.base.press_right()
        tester.tts_assertions.verify_tts_text(tester, tester.tts_labels.LBL_TTS_FAST_FORWARD)
        self.log.info("Verify LBL_TTS_FAST_FORWARD successfull.")
        self.screen.base.press_right()
        tester.tts_assertions.verify_tts_text(tester, tester.tts_labels.LBL_TTS_JUMP_FORWARD)
        self.log.info("Verify LBL_TTS_JUMP_FORWARD successfull.")
        self.screen.base.press_right()
        tester.tts_assertions.verify_tts_text(tester, tester.tts_labels.LBL_TTS_GO_TO_END)
        self.log.info("Verify LBL_TTS_GO_TO_END successfull.")
        self.screen.base.press_right()
        tester.tts_assertions.verify_tts_text(tester, tester.tts_labels.LBL_TTS_GO_TO_LIVE_TV)
        self.log.info("Verify LBL_TTS_GO_TO_LIVE_TV successfull.")
        self.screen.base.press_right()
        tester.tts_assertions.verify_tts_text(tester, tester.tts_labels.LBL_TTS_INFO_BANNER)
        self.log.info("Verify LBL_TTS_INFO_BANNER successfull.")
        self.screen.base.press_right()
        tester.tts_assertions.verify_tts_text(tester, tester.tts_labels.LBL_TTS_ONE_LINE_GUIDE)
        self.log.info("Verify LBL_TTS_ONE_LINE_GUID successfull.")

    def get_pause_label(self, tester):
        pause_label = tester.tts_labels.LBL_TTS_PAUSE.copy()
        self.screen.refresh()
        dump = self.screen.get_screen_dump_item()
        currently_recording = 'paused at '
        record = dump['recordingTrickplay']
        recording = currently_recording + record.get('currentPosition') + ' of ' + record.get('recordingDuration')
        bannertip = dump['bannerTip']
        title = dump['title']
        call_sign = dump['call-sign']
        channel_no = dump['channel-number']
        channel_no = 'Channel: ' + channel_no
        pause_label.insert(6, channel_no)
        pause_label.insert(8, call_sign)
        pause_label.insert(10, title)
        pause_label.insert(12, bannertip)
        pause_label.insert(14, recording)
        self.log.info(f" pause lable after insert {pause_label}")
        return pause_label

    def get_play_label(self, tester):
        play_label = tester.tts_labels.LBL_TTS_PLAY.copy()
        self.screen.refresh()
        dump = self.screen.get_screen_dump_item()
        currently_recording = 'playing recording at '
        record = dump['recordingTrickplay']
        recording = currently_recording + record.get('currentPosition') + ' of ' + record.get('recordingDuration')
        bannertip = dump['bannerTip']
        title = dump['title']
        call_sign = dump['call-sign']
        channel_no = dump['channel-number']
        channel_no = 'Channel: ' + channel_no
        play_label.insert(6, channel_no)
        play_label.insert(8, call_sign)
        play_label.insert(10, title)
        play_label.insert(12, bannertip)
        play_label.insert(14, recording)
        self.log.info(f" Play lable after insert {play_label}")
        return play_label

    def verify_pause(self, tester):
        self.log.info("Verifying play pause")
        pause_label = self.get_pause_label(tester)
        tester.tts_assertions.verify_tts_text(tester, pause_label)

    def verify_play(self, tester):
        self.log.info("pressing play button")
        play_label = self.get_play_label(tester)
        tester.tts_assertions.verify_tts_text(tester, play_label)
