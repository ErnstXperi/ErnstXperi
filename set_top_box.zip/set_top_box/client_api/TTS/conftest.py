import threading

import pytest

from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.client_api.my_shows.assertions import MyShowsAssertions
from set_top_box.client_api.apps_and_games.assertions import AppsAndGamesAssertions
from set_top_box.client_api.guide.assertions import GuideAssertions
from set_top_box.client_api.program_options.assertions import ProgramOptionsAssertions
from set_top_box.test_settings import Settings
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from tools.logger.logger import Logger
from set_top_box.client_api.TTS.assertions import TTSAssertions


__logger = Logger(__name__)


@pytest.fixture(autouse=True, scope="class")
def setup_tts(request):
    """
    Configure steps to be executed before the test cases run
    :param request:
    :return:
    """
    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_labels = request.cls.home_page.home_labels = LabelFactory("home", Settings)
    request.cls.home_assertions = HomeAssertions(request.cls.screen)
    request.cls.home_assertions.home_labels = request.cls.home_labels

    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)
    request.cls.menu_labels = request.cls.menu_page.menu_labels = LabelFactory("Menu", Settings)

    request.cls.my_shows_labels = LabelFactory("my_shows", Settings)
    request.cls.my_shows_page = PageFactory("my_shows", Settings, request.cls.screen)
    request.cls.my_shows_assertions = MyShowsAssertions(request.cls.screen)

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)

    request.cls.text_search_labels = LabelFactory("text_search", Settings)
    request.cls.text_search_page = PageFactory("text_search", Settings, request.cls.screen)
    request.cls.text_search_page.text_search_labels = request.cls.text_search_labels

    request.cls.programoption_assertions = ProgramOptionsAssertions(request.cls.screen)
    request.cls.vod_labels = LabelFactory("VOD", Settings)
    request.cls.vod_page = PageFactory("VOD", Settings, request.cls.screen)

    request.cls.watch_video_page = request.cls.watchvideo_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.watchvideo_labels = request.cls.liveTv_labels = LabelFactory("watchvideo", Settings)
    request.cls.watchvideo_assertions = WatchVideoAssertions(request.cls.screen)

    request.cls.apps_and_games_page = PageFactory("apps_and_games", Settings, request.cls.screen)
    request.cls.apps_and_games_assertions = AppsAndGamesAssertions(request.cls.screen)
    request.cls.apps_and_games_labels = LabelFactory("apps_and_games", Settings)

    request.cls.live_tv_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.live_tv_assertions = WatchVideoAssertions(request.cls.screen)
    request.cls.live_tv_labels = request.cls.liveTv_labels = LabelFactory("watchvideo", Settings)

    request.cls.text_search_page = PageFactory("text_search", Settings, request.cls.screen)
    request.cls.text_search_page.text_search_labels = request.cls.text_search_labels

    request.cls.tts_page = PageFactory("TTS", Settings, request.cls.screen)

    request.cls.tts_labels = LabelFactory("TTS", Settings)
    request.cls.tts_assertions = TTSAssertions(request.cls.screen)

    request.getfixturevalue('device_reboot_to_imporve_device_perf')
    request.getfixturevalue('clean_ftux_and_sign_in')
    request.getfixturevalue('disable_parental_controls')


@pytest.fixture(autouse=False, scope="function")
def start_tts_log(request):
    request.cls.screen.base.TTS_on_off(tts=True)
    request.cls.tts_page.set_stop(False)
    thread = threading.Thread(target=request.cls.tts_page.start_collect_tts_logs)
    thread.daemon = True
    thread.start()


@pytest.fixture(autouse=False, scope="function")
def stop_tts_log(request):
    def tear_down():
        request.cls.screen.base.TTS_on_off()
        request.cls.tts_page.set_stop(True)
    request.addfinalizer(tear_down)
