
class CablecoTTSLabels:
    LBL_SOCU_AVAILABLE = "available on Cableco SOCU"
    LBL_SOCU_OFFER = [LBL_SOCU_AVAILABLE, 'medium', 'press right for other actions']
