class TTSLabels(object):
    LBL_HOME = "HOME"
    LBL_SCREENTITLE = ['Screen title', 'weak', LBL_HOME]
    LBL_HOME_TIP = ['weak', 'Tip: Press BACK to return to video']
    LBL_HOME_PRESS_RIGHT = ['medium', 'press right for other items', 'medium', 'Press DOWN for predictions strip']
    LBL_HOME_PRESS_RIGHT_FOR_ALL_MENU = ['Menu', 'medium', 'press right for other items', 'medium',
                                         'Press DOWN for predictions strip']
    LBL_ONE_PASS_OPTIONS_SCREEN = ['Choose the default options that will be used when you set up a new recording or OnePass. ',
                                   'medium', 'Include: Recordings and Streaming Videos', 'weak',
                                   'press right for next setting press down for other items', 'weak',
                                   'Choose what kind of episodes to include.']
    LBL_ONDEMAND_OPTIONS = ['On Demand', 'medium', 'press right for other items', 'medium',
                            'Press DOWN for predictions strip']
    LBL__HOME_MENU_ITEMS = ['Menu', 'Watch TV', 'My Shows', 'What to Watch', 'Guide', 'Apps and Games', 'On Demand',
                            'Search']
    LBL_ONE_PASS = "OnePass and Recording Options"
    LBL_SCREENTITLE_ONEPASS = ['Screen title', 'weak', LBL_ONE_PASS]
    LBL_SOCU_AVAILABLE = "available on Cableco SOCU"
    LBL_SOCU_OFFER = [LBL_SOCU_AVAILABLE, 'medium', 'press right for other actions']
    LBL_RECORDING_OPTIONS = ['Record just this episode', 'medium', '  press down for other items', 'medium']
    LBL_OVERLAYTITLE = ['overlay title', 'weak', 'Channel Options', 'weak', 'weak']
    LBL_LAUNCHAPP_OR_WATCHNOW = ['medium', 'press down for other items', 'medium']
    LBL_REMOVE_FAV_CHANNEL = ['Remove from Favorite Channels', 'medium', 'press up for other items', 'medium']
    LBL_CHANGE_PIN = ['Change PIN', 'medium', 'press down for other items']
    LBL_CURRENT_PIN = ['Current PIN', 'weak', 'Number box 1 of 4', 'medium', 'Press a number key on the remote',
                       'weak', 'Please enter your current 4-digit Parental Controls PIN.']
    LBL_NEW_PIN = ['New PIN', 'weak', 'Number box 1 of 4', 'medium', 'Press a number key on the remote',
                   'weak', 'Please enter your new 4-digit Parental Controls PIN.']
    LBL_CONFIRM_PIN = ['Confirm PIN', 'weak', 'Number box 1 of 4', 'medium', 'Press a number key on the remote',
                       'weak', 'Please enter your new PIN again.']
    LBL_PIN_CHANGED = ['Notification', 'weak', 'Your PIN has been successfully changed.']
    LBL_CHANNEL_INFO = ['weak', 'medium']
    LBL_FAVORITE_PANEL = ['overlay title', 'weak', 'Favorites', 'weak']
    LBL_PRESS_RIGHT_FOR_OTHER_FAVORITE_CHANNEL = ['Press right for other favorite channels']
    LBL_PRESS_LEFT_FOR_OTHER_FAVORITE_CHANNEL = ['Press left for other favorite channels']
    LBL_WATCH_NOW_STRIP = "Watch Now Strip"
    LBL_TRICKPLAY = ['Pause', 'medium', ' for other items', 'medium',
                     'press DOWN for Continue Watching and Favorites overlays', 'weak']
    LBL_LIVE = ['medium', 'Going to Live TV.']
    LBL_TTS_REWIND = ['Rewind', 'medium', 'press left or right for other items', 'medium',
                      'press DOWN for Continue Watching and Favorites overlays']
    LBL_TTS_JUMP_BACK = ['Jump back', 'medium', 'press left or right for other items', 'medium',
                         'press DOWN for Continue Watching and Favorites overlays']
    LBL_TTS_START_OVER = ['Start Over', 'medium', 'press right for other items', 'medium',
                          'press DOWN for Continue Watching and Favorites overlays']
    LBL_TTS_FAST_FORWARD = ['Fast-forward', 'medium', 'press left or right for other items', 'medium',
                            'press DOWN for Continue Watching and Favorites overlays']
    LBL_TTS_JUMP_FORWARD = ['Jump forward', 'medium', 'press left or right for other items', 'medium',
                            'press DOWN for Continue Watching and Favorites overlays']
    LBL_TTS_GO_TO_END = ['Go to End', 'medium', 'press left or right for other items', 'medium',
                         'press DOWN for Continue Watching and Favorites overlays']
    LBL_TTS_GO_TO_LIVE_TV = ['Go to Live TV', 'medium', 'press left or right for other items', 'medium',
                             'press DOWN for Continue Watching and Favorites overlays']
    LBL_TTS_INFO_BANNER = ['Info Banner', 'medium', 'press left or right for other items', 'medium',
                           'press DOWN for Continue Watching and Favorites overlays']
    LBL_TTS_ONE_LINE_GUIDE = ['One Line Guide', 'medium', 'press left for other items', 'medium',
                              'press DOWN for Continue Watching and Favorites overlays']
    LBL_TTS_PAUSE = ['Play', 'medium', 'press left or right for other items', 'medium',
                     'press DOWN for Continue Watching and Favorites overlays', 'weak', 'weak', 'weak', 'weak', 'weak', 'weak']
    LBL_TTS_PLAY = ['Pause', 'medium', 'press left or right for other items', 'medium',
                    'press DOWN for Continue Watching and Favorites overlays', 'weak', 'weak', 'weak', 'weak', 'weak', 'weak']
    LBL_SKIP_OPTION = ['Notification', 'weak', 'You can repeat first-time setup by going to Menu ', 'weak',
                       'SYSTEM and ACCOUNT', 'weak', 'Help', 'weak', 'Quick Tour.']
    LBL_WATCH_NOW = ["weak", "available on"]
    LBL_VOD_SCREEN_TITLE = ['Screen title', 'weak', 'weak']
    LBL_PANE_DESCRIPTION = ['medium', 'medium', 'weak', '', 'medium', 'weak', '', 'weak', 'weak', 'weak', '', 'weak',
                            'duration', 'weak', 'weak', '']
    LBL_ON_DEMAND_EPISODES_STRIP = ['On Demand Episodes Strip ', 'weak', 'weak', 'weak', 'weak', 'streaming', 'weak',
                                    'available on', 'weak', 'EXP On Demand', 'medium',
                                    'press right for other items, press replay for all items']
    LBL_EPISODE_PANE_DESCRIPTION = ['medium', 'medium', 'weak', 'medium', 'weak', 'weak']
    LBL_ACTION_SCREEN_TITLE = ['Screen title', 'weak', 'weak', 'weak', 'weak']
    LBL_PROGRAM_SCREEN_PANE_DESCRIPTION = ['medium', 'medium', 'weak', 'medium', 'weak', 'weak', 'weak']
    LBL_WATCH_NOW_STRIP_TEXT = ["weak", "available on"]
    LBL_MAY_ALSO_LIKE_STRIP = "May Also Like Strip"
