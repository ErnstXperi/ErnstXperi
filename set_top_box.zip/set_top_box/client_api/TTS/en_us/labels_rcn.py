
class RCNTTSLabels:
    LBL_SOCU_AVAILABLE = "available on RCN Restart/Catchup"
    LBL_SOCU_OFFER = [LBL_SOCU_AVAILABLE, 'medium', 'press right for other actions']
