
class TDSTTSLabels:
    LBL_SOCU_AVAILABLE = "available on Start Over"
    LBL_SOCU_OFFER = [LBL_SOCU_AVAILABLE, 'medium', 'press right for other actions']
