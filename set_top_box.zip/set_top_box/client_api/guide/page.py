"""
Created on Sept 7, 2017

@author: tboroffice
"""

import datetime
from urllib import parse
import time
import re
import sys
import inspect

import pytest

from core_api.stb.assertions import CoreAssertions
from core_api.stb.base import UINavigationException
from set_top_box.client_api.guide.en_us.labels import GuideLabels
from set_top_box.test_settings import Settings
from tools.logger.logger import Logger
from set_top_box.conf_constants import HydraBranches
from mind_api.middle_mind import field


class GuidePage(CoreAssertions):
    guide_labels = GuideLabels()
    log = Logger(__name__)
    STRIP_AM_PM_FROM_TIME = "%a%p%m"
    EXM_SCREEN_NAME = "GridGuide"
    SCRN_DMP_HTEXT = "#text"

    def return_guide_row_focus(self, screen_dump):
        """
        Method to get focused guide row

        Args:
            screen_dump: list, use self.return_guide() for getting input value for this param

        Returns:
            dict, focused guide row
        """
        for row in screen_dump:
            for tab in row[u'grid-row']:
                # Usually, tab = None means that Guide Cell does not have text or icon, or highlighter,
                # it can be in case when the program takes 9 or less minutes in 30 minutes tab (e.g. ends)
                if tab and u"hasfocus" in tab.keys():
                    return row[u'grid-row']

    def get_focused_guide_row_tab(self, guide_row_xml_part):
        """
        Method to get focused guide row tab (guide cell)

        Args:
            guide_row_xml_part: list,

        Returns:
            dict, focused guide cell
        """
        rows = guide_row_xml_part
        lenval = len(rows)
        for row in rows:
            # Check if only 1 grid row available in guide
            if lenval > 1:
                row_value = row[u'grid-row']
            else:
                row_value = rows[u'grid-row']
            row_value = list(filter(None, row_value))
            for tab in row_value:
                # Usually, tab = None means that Guide Cell does not have text or icon, or highlighter,
                # it can be in case when the program takes 9 or less minutes in 30 minutes tab (e.g. ends)
                if tab and u"hasfocus" in tab.keys():
                    return tab
        else:
            raise LookupError("Unable to find focused guide tab. Dump: {}".format(guide_row_xml_part))

    def get_images_in_focused_guide_row_cell(self, grid_row_dump):
        """
        method to get all images in a focused grid row cell
        Args:
            grid_row_dump: grid row dump section

        Returns:
            list
        """
        focused_cell = self.get_focused_guide_row_tab(grid_row_dump)
        list_of_images = []
        if type(focused_cell) is dict and "imagename" in focused_cell.keys():
            list_of_images = focused_cell["imagename"]
            if type(list_of_images) is not list:
                list_of_images = [list_of_images]
        return list_of_images

    def return_guide(self, screen_dump={}, retry=3):
        """
        Method to extract list of guide grid rows. Data will be verified:
            * number of rows has to be more then 5
            * each row has to contain 'grid-row' key
            * on of rows has to be focused
        :param screen_dump: raw screen dump
        :param retry: number of retires
        :return: list, grid rows
        """
        if screen_dump == {}:
            screen_dump = self.screen.get_json()
        for itr in range(retry + 1):
            guide_grid = self.get_menu_item(screen_dump)
            grid_len = len(guide_grid)
            all_rows_consistent = all(row and 'grid-row' in row for row in guide_grid)
            grid_has_focus = 'hasfocus' in f'{guide_grid}'
            if grid_len and all_rows_consistent and grid_has_focus:
                self.log.debug("Guide grid verified")
                break
            else:
                self.log.debug("Failure occurred while checking for attributes in screendump. Hence retrying... \n"
                               "grid_len={}; all_rows_consistent={}; grid_has_focus={}".format(grid_len,
                                                                                               all_rows_consistent,
                                                                                               grid_has_focus))
                self.pause(0.5)
                screen_dump = self.screen.get_json()
        else:
            guide_grid = []
            self.log.error("Unable to get GUIDE data. \n"
                           "ScreenDump: {}".format(screen_dump))
            # TODO: seems raise error is needed
        return guide_grid

    def return_channel_list(self, screen_dump=[]):
        channel_list = []
        for row in screen_dump:
            for tab in row[u'grid-row']:
                if 'channelnumber' in tab:
                    channel_list.append(tab['channelnumber'])
                    break
        self.log.info('channel list: {}'.format(channel_list))
        return channel_list

    def get_to_channel_tab(self, tester=None, screen_dump={}, move_to_channel_tab=True, is_olg=False):
        """
        Navigates to Channel column in the same row.
        Applicable to Past and In-Progress Guide / One Line Guide
        """
        channel_item = {}
        selected_tab_index = 0 if is_olg else 1
        if is_olg:
            self.screen.get_json()
            self.log.info("Getting to the Channel Cell in One Line Guide")
            if not self.ui_element_exists("oneLineGuideHeaderInfo"):
                raise AssertionError("One Line Guide is not shown")
            # One Line Guide is shown
            row_focus = self.get_strip_list()
            if type(row_focus) is dict:
                row_focus = [row_focus]
            # When Fail Open OLG, tiles may not be visible for a bit, so menuitem won't be found,
            # but we are on OLG, so can move to channel cell
            dump = self.screen.get_screen_dump_item()
            channels = dump.get("menuitem") if dump.get("menuitem") is not None else []
            for chan in channels:
                if chan.get("highlighted-row") == "true":
                    channel_item = chan
                    break
            row_focus.append(channel_item)
            for tab in row_focus:
                if tab is not None and tab.get("hasfocus") == "true":
                    selected_tab_index = row_focus.index(tab)
                    break
        else:
            self.log.info("Getting to the Channel Cell in Grid Guide")
            # Grid Guide is displayed
            self.wait_for_guide_next_page()
            guide = self.return_guide(screen_dump)
            row_focus = self.return_guide_row_focus(guide)
            tab_focus = self.get_focused_guide_row_tab(guide)
            selected_tab_index = row_focus.index(tab_focus)
            for tab in row_focus:
                if 'channelnumber' in tab:
                    channel_item = tab
                    break
        if not channel_item:
            return None
        if move_to_channel_tab:
            index = len(row_focus) if self.screen.get_screen_dump_item("isPastGuide") == "true" else 0
            if is_olg:
                # In OLG, the first tile has index 0, so let's add one more step to get to channel cell
                selected_tab_index += 1
            self.menu_navigate_left_right(selected_tab_index, index)
        if not is_olg:
            # Waiting for this event is needed for Grid Guide only
            self.wait_for_guide_next_page()
        return channel_item

    def validate_channel_tab(self, tester, channel_list_confirm, screen_dump={}):
        content = self.get_foucsed_content()
        count = 0
        if "text" in content.keys() and content['text'] not in channel_list_confirm:
            while True:
                self.screen.refresh()
                guide = self.return_guide(screen_dump)
                row_focus_confirm = \
                    tester.guide_assertions.verify_guide_row_focus(screen_dump=guide)
                tab_focus_confirm = \
                    tester.guide_assertions.verify_guide_row_tab_focus(screen_dump=guide)
                selected_tab_index_confirm = row_focus_confirm.index(tab_focus_confirm)

                channel_list = []
                for tab in row_focus_confirm:
                    if 'channelnumber' in tab:
                        channel_list = tab
                        self.log.info(" Channel Tab found. Breaking!! ")
                        break
                if channel_list:
                    channel_index = row_focus_confirm.index(channel_list)
                if (selected_tab_index_confirm - channel_index) != 0:
                    self.menu_navigate_left_right(selected_tab_index_confirm, channel_index)
                    self.log.info(" Moving to index {} ".format(selected_tab_index_confirm - channel_index))
                    count += 10
                    if count > 10:
                        self.log.info(" Max retries reached {} ".format(count))
                        break
                elif (selected_tab_index_confirm - channel_index) == 0:
                    break
        elif "channelnumber" in content.keys() and content['channelnumber'] \
                in channel_list_confirm:
            self.log.info(" Channel Tab selected fine! ")

    def get_foucsed_content(self):
        self.screen.refresh()
        menu = self.screen.get_screen_dump_item('menuitem')
        if isinstance(menu, list):
            for item in menu:
                for content in item['grid-row']:
                    if content and "hasfocus" in content.keys() and content["hasfocus"] == "true":
                        self.log.info(f"Content was {content}")
                        return content
        else:
            self.log.info(" Not valid screen, returning None!! ")
            return None

    def channel_number_highlight_in_guide(self, tester, channel_number):
        self.log.info(f"Selecting and starting {channel_number} playback if found")
        self.enter_channel_number(channel_number)
        channel_found = self.get_highlighted_channel_number_in_one_line_guide()
        self.log.info(f"Available channel is {channel_found}")
        if channel_found == channel_number:
            self.select_and_watch_program(tester, text="live")
            self.wait_for_screen_ready(tester.watchvideo_labels.LBL_LIVETV_SCREEN)
            return True
        else:
            return False

    def wait_and_check_next_item_in_row(self):
        """
        Wait for current show to finish in guide and move to next item
        """
        dumptime, guidetime, guidetime_to_mins = self.get_current_time_in_mins()
        showtime = self.get_program_start_and_end_time()
        showtime_end_mins = self.convert_time_to_sec(showtime[1][0])
        time_pm_am = re.findall(r"(\d{1,2}\:\d+\S)(am|pm)+", dumptime)
        self.calculate_diff_and_wait_for_show_to_finish(showtime, guidetime, guidetime_to_mins, showtime_end_mins, time_pm_am,
                                                        max_diff=15, right=False)
        self.press_right_button(refresh=False)
        row = self.get_foucsed_content()
        if 'textcolor' in row.keys():
            return row['textcolor']
        else:
            raise AssertionError('text color key is not available for focussed menuitem: {}'.format(row))

    def choose_show_by_name(self, show_name):
        """
        Navigating to show name by horizontal greed,
        highlighter should setted properly before use, ie by entering channel number
        @param show_name: Show to be searched
        @type show_name: string
        """
        for i in range(6):
            grid = self.get_foucsed_content()
            if grid and grid.get("text"):
                show_title = self.convert_special_chars(grid.get("text"))
                if show_title.lower() in show_name.lower() or show_name.lower() in show_title.lower():
                    self.wait_for_header_rendering()
                    self.press_ok_button(refresh=False)
                    return
                self.log.info("Found show: {} not matched searched: {} continue".format(show_title, show_name))
            self.log.info("Grid empty continue")
            self.press_right_button()
            self.wait_for_screen_ready()
        pytest.skip("Show wasn't found skipping")

    def wait_for_guide_next_page(self):
        """
        method to wait for GuideScreen content (grid's values) ready
        Screen done will be verified too
        """
        self.log.info("Wait for guide next page to load")
        state = self.wait_for_screen_ready()
        self.log.info("Guide List Model Log Found: {}".format(state))
        if state:
            # if screen ready there is no sense to wait more  - update screen dump without wait
            self.screen.get_json()
        else:
            # dump screen with one more wait for screen ready
            self.screen.refresh()

    def navigate_to_channel(self, tester, channel_number):
        self.log.info("Navigating to channel number :{}".format(channel_number))
        self.wait_for_screen_ready(self.guide_labels.LBL_GUIDE_SCREEN)
        channel_tab = self.get_to_channel_tab(tester, move_to_channel_tab=False)
        self.go_to_show(tester, channel_tab['channelnumber'], channel_number)
        return True

    def go_to_show(self, tester, current, go_to):
        list = tester.service_api.get_current_guide_line_up()
        current = list.index(current)
        go_to = list.index(go_to)
        straight_index = current - go_to
        reverse_index = None
        if current > go_to:
            part_to_end = len(list) - current
            part_from_start = go_to
            reverse_index = -(part_to_end + part_from_start)
        elif current < go_to:
            part_to_end = len(list) - go_to
            part_from_start = current
            reverse_index = part_to_end + part_from_start
        else:
            reverse_index = 0
        if abs(straight_index) <= abs(reverse_index):
            self.move_up_down(straight_index)
        else:
            self.move_up_down(reverse_index)

    def navigate_to_channel_from_one_line_guide(self, channel):
        in_focus_channel = None
        channel_list = []  # channel list to add all channels to prevent infinite cycle
        searching = True  # key to search
        self.log.info(f"Scrolling OneLineGuide to the channel {channel} ")
        while searching:  # cycle until search == True
            currently_visible_channels = []  # list to search channel in current page
            self.screen.refresh()  # update screen dump
            channels = self.get_menu_item()  # get channels in screen dump
            for channel_info in channels:  # get all channels on current page
                currently_visible_channels.append(channel_info.get('text', {})[0])
                if channel_info.get('highlighted-row') or channel_info.get('hasfocus'):
                    in_focus_channel = channel_info.get('text', {})[0]
            for ch in currently_visible_channels:  # add all channel to channel_list
                if ch not in channel_list:
                    channel_list.append(ch)
                else:
                    # if the channel is in the channel_list, the search for all channels is complete
                    searching = False
            channel_list.pop()
            channel_list.pop()
            if (channel in currently_visible_channels) and (in_focus_channel in currently_visible_channels):
                if in_focus_channel != channel:
                    # If "in_focus_channel" > "channel" -> steps "down", else steps "up"
                    steps = currently_visible_channels.index(channel) - currently_visible_channels.index(
                        in_focus_channel)
                    self.log.info(
                        f"The channel {in_focus_channel} on focus now. "
                        f"Searching channel is {channel}. It takes {steps} steps to focus.")
                    self.navigate_by_XY(steps, "Y")
                else:
                    self.log.info(f"The channel {channel} is on focus.")
                    searching = False

            elif channel not in channel_list and searching:
                self.log.debug("Scrolling to the next channel.")
                self.navigate_by_XY(len(currently_visible_channels) - 2, "Y")
            else:
                raise LookupError(f'Channel {channel} didn`t found in device`s channel list.')
        return True

    def navigate_to_channel_from_guide_grid(self, channel):
        channel_list = []  # channel list to add all channels to prevent infinite cycle
        # Sometimes, it takes longer to shows guide rows, so we'll wait a bit
        retries_empty_guide_rows = 1
        searching = True  # key to search
        self.log.info(f"Scrolling to the channel {channel} ")
        while searching:  # cycle until search == True
            in_focus_channel = None
            currently_visible_channels = []  # list to search channel in current page
            self.screen.refresh()  # update screen dump
            channels = self.get_menu_item()  # get channels in screen dump
            for item in channels:  # get all channels on current page
                # When gridRow are not yet filled with data, they shown as None in the screen dump
                channel_details = item.get('grid-row', [{}]) if item and "grid-row" in item else None
                if channel_details:
                    retries_empty_guide_rows = 1
                    currently_visible_channels.append(channel_details[0].get('channelnumber'))
                elif not channel_details and retries_empty_guide_rows >= 5:
                    raise AssertionError("Empty Guide Rows detected: {}".format(self.screen.get_screen_dump_item()))
                else:
                    self.pause(3, f"Waiting till guide rows are shown...; retry #{retries_empty_guide_rows}")
                    retries_empty_guide_rows += 1
                    break  # got grid rows empty, waiting till them are displayed
                # get current in focus channel
                if in_focus_channel is None:
                    in_focus_channel = self.get_focussed_channel_number_in_grid(channel_details)
            if retries_empty_guide_rows > 1:
                # Got grid rows empty, waiting till them are displayed
                continue
            for ch in currently_visible_channels:  # add all channel to channel_list
                if ch not in channel_list:
                    channel_list.append(ch)
                else:
                    # if the channel is in the channel_list, the search for all channels is complete
                    self.log.debug(f"Channel found in the list, searching stopped; ch = {ch}; channel_list = {channel_list}")
                    searching = False
            channel_list.pop()  # delete last channel from the list
            if channel in currently_visible_channels:
                if in_focus_channel != channel:
                    # If "in_focus_channel" > "channel" -> steps "down", else steps "up"
                    steps = currently_visible_channels.index(channel) - currently_visible_channels.index(
                        in_focus_channel)
                    self.log.info(
                        f"The channel {in_focus_channel} on focus now. "
                        f"Searching channel is {channel}. It takes {steps} steps to focus.")
                    self.navigate_by_XY(steps, "Y")
                else:
                    self.log.info(f"The channel {channel} is on focus.")
                    searching = False
            elif channel not in channel_list and searching:
                self.log.debug("Scrolling to the next page of the channel.")
                self.go_to_bottom_cell_in_guide()
                self.pause(5)
                self.screen.base.press_down()
                self.wait_for_guide_next_page()
                continue
            else:
                raise LookupError(f'Channel {channel} didn`t found in device`s channel list.')

    def focus_on_channel_airing_now_program(self, tester, channel_number):
        if self.navigate_to_channel(tester, channel_number=channel_number):
            self.screen.base.press_right(time=3000)
            return True
        else:
            return False

    def get_grid_focus_details(self, screen_dump={}):
        screen_data = screen_dump if screen_dump else self.screen.get_json()
        program_info = {}
        screen_xml_dict = screen_data['xml']
        guide = self.return_guide(screen_dump=screen_data)
        row_focus = self.return_guide_row_focus(screen_dump=guide)
        guide_cell_icons = []
        for grid_item in row_focus:
            if 'hasfocus' in grid_item.keys():
                if 'text' in grid_item.keys():
                    program_info['program_name_in_cell'] = grid_item['text']
                if 'imagename' in grid_item.keys():
                    guide_cell_icons.append(grid_item['imagename'])
                if 'channellogo' in grid_item.keys():
                    guide_cell_icons.append(grid_item['channellogo'])
                if 'formaticon' in grid_item.keys():
                    guide_cell_icons.append(grid_item['formaticon'])
                if 'notrecordableicon' in grid_item.keys():
                    guide_cell_icons.append(grid_item['notrecordableicon'])
        if guide_cell_icons:
            program_info['guide_cell_icons'] = guide_cell_icons
        program_info['grid_header_title'] = screen_xml_dict['program']['text']
        program_info['description'] = screen_xml_dict['description']['text']
        if 'showtime' in screen_xml_dict.keys():
            program_info['time_slot'] = screen_xml_dict['showtime']['text']
        program_info['channel_number'] = row_focus[0].get('channelnumber')
        program_info['channel_name'] = row_focus[0].get('channelcallsign')
        program_info['channel_logo'] = row_focus[0].get('channellogo')
        program_info['current_time'] = screen_xml_dict.get('timeinfo')
        if 'source-icons' in screen_xml_dict.keys():
            program_info['source_icons'] = screen_xml_dict['source-icons']
        if 'imagename' in screen_xml_dict['program'].keys():
            program_info['grid_header_icons'] = screen_xml_dict['program']['imagename']
        program_info['current_date'] = screen_xml_dict['date']['text']
        return program_info

    def watch_channel(self, tester, channel_number):
        self.log.info("Selecting and starting channel playback")
        channel_found = self.enter_channel_number(channel_number)
        self.wait_for_guide_next_page()
        focused_item = self.get_live_program_name(tester)
        self.log.info("Selecting to play {}".format(focused_item))
        if channel_found:
            self.select_and_watch_program(tester, text="live")
            self.wait_for_screen_ready(tester.watchvideo_labels.LBL_LIVETV_SCREEN)
            return True
        else:
            return False

    def get_guide_time_window(self, screen_dump={}):
        "gets the list of times that demarcate the current grid window"
        guide_screen = {}
        if screen_dump == {}:
            guide_screen = self.screen.get_json()
        else:
            guide_screen = screen_dump
        time_list = guide_screen['xml']['time']
        return time_list

    def get_guide_date(self, screen_dump={}):
        "gets the date of the current grid program window"
        guide_screen = {}
        if screen_dump == {}:
            guide_screen = self.screen.get_json()
        else:
            guide_screen = screen_dump

        current_date = guide_screen['xml']['date']['text']
        return current_date

    def is_guide_current(self, screen_dump={}, date_time=None):
        """
        :description:
            Checks if clock current time is within the 1st Grid Guide Time Cell
        :params:
            screen_dump - json
            date_time - datetime
        :return:
            boolean
        """
        self.log.info("Verifying current time is within live program time")
        grid_time_snapshot = self.get_grid_time_snapshot(guide_screen=screen_dump)
        current_date_time = None
        if date_time is not None:
            current_date_time = date_time
        else:
            current_date_time = grid_time_snapshot['current_date_time']
        composite_window_list = grid_time_snapshot['current_window']
        self.log.info("Current date_time:{} ".format(current_date_time))
        self.log.info("composites: {}".format(composite_window_list))
        if current_date_time >= composite_window_list[0]:
            if current_date_time < composite_window_list[1]:
                return True
        else:
            return False

    def is_guide_past(self, screen_dump={}):
        """
        :description:
            Checks if clock current time is greater than the 4th Grid Guide Time Cell
        :params:
            screen_dump - json
        :return:
            boolean
        """
        grid_time_snapshot = self.get_grid_time_snapshot(guide_screen=screen_dump)
        current_date_time = grid_time_snapshot['current_date_time']
        composite_window_list = grid_time_snapshot['current_window']
        if current_date_time > composite_window_list[3]:
            return True
        else:
            return False

    def is_guide_future(self, screen_dump={}):
        """
        :description:
            Checks if clock current time is less than the 1st Grid Guide Time Cell
        :params:
            screen_dump - json
        :return:
            boolean
        """
        self.log.info("comparing current time against future time")
        grid_time_snapshot = self.get_grid_time_snapshot(guide_screen=screen_dump)
        current_date_time = grid_time_snapshot['current_date_time']
        composite_window_list = grid_time_snapshot['current_window']
        if current_date_time < composite_window_list[0]:
            return True
        else:
            return False

    def get_curr_guide_time(self, screen_dump=None):
        """
        Get date and time of the clock in the Grid Guide Header

        Args:
            tester (TestGuideScreen): an instance of the test class

        Returns:
            datetime
        """
        screen = screen_dump or self.screen.get_json()
        time_dict = self.get_grid_time_snapshot(guide_screen=screen)
        cur_time = time_dict['current_date_time']
        return cur_time

    def get_screen_guide_time(self, tester, guide_screen={}):
        """
        Get date and time of the 1st time cell in the Grid Guide

        Args:
            tester (TestGuideScreen): an instance of the test class

        Returns:
            datetime
        """
        screen = guide_screen if guide_screen else self.screen.get_json()
        tester.guide_assertions.verify_date_info_in_guide(screen)
        time_dict = self.get_grid_time_snapshot(guide_screen=screen)
        cur_time = time_dict['current_window'][0]
        self.log.info(f"Current time in Guide {cur_time}")
        return cur_time

    def move_days_forward(self, tester, days=1, retry=1000):
        self.log.step("Checking Guide data availability of next {} days".format(days))
        self.wait_for_screen_ready()
        curr_date = self.get_screen_guide_time(tester)  # time of the 1st time cell
        time_delta = datetime.timedelta(days=days)
        destination_date = curr_date + time_delta
        number_pages_to_date = int((destination_date - curr_date).days * 24 / 2)  # number of pages to destination date
        for step in range(number_pages_to_date):
            self.screen.base.press_right(time=400)
        trycount = 0
        while curr_date != destination_date and retry > trycount:
            curr_date = self.get_screen_guide_time(tester)
            # the 4th time cell of the last Grid Guide page ends at the same time
            # as the 1st time cell of initial one at Guide entering
            time_delta = datetime.timedelta(minutes=120)
            curr_date = curr_date + time_delta
            if curr_date == destination_date:
                break
            elif curr_date > destination_date:
                self.log.info("Reached destination future Guide data")
                break
            else:
                self.screen.base.press_right(time=500)
            trycount += 1
        self.log.info("Future data found at the trycount {}. ".format(trycount))
        tester.guide_assertions.verify_date_greater_or_equal(curr_date, destination_date)

    def move_days_backward(self, tester, days=1, retry=100):
        self.log.step("Checking Guide data availability of previous {} days".format(days))
        self.wait_for_screen_ready()
        curr_date = self.get_screen_guide_time(tester)  # time of the 1st time cell
        time_delta = (datetime.timedelta(days=days) * -1)
        destination_date = curr_date + time_delta
        trycount = 0
        while curr_date > destination_date:
            for i in range(retry):
                if Settings.is_apple_tv() or Settings.is_devhost():
                    self.screen.base.press_left(time=500)
                else:
                    self.screen.base.press_guide_prev()
            curr_date = self.get_screen_guide_time(tester)
            if trycount > retry:
                break
            trycount += 1
        tester.guide_assertions.verify_date_less_or_equal(curr_date, destination_date)

    def get_grid_time_snapshot(self, guide_screen):
        time_window = self.get_guide_time_cell_list_in_datetime_grid_guide(screen_dump=guide_screen)
        if time_window[1].hour == 0:
            time_window[1] = time_window[1] + datetime.timedelta(days=1)
            time_window[2] = time_window[2] + datetime.timedelta(days=1)
            time_window[3] = time_window[3] + datetime.timedelta(days=1)
        composite_window_list = [time_window[0], time_window[1], time_window[2], time_window[3]]
        current_date_time = self.get_clock_time_info_datetime()
        time_dict = {
            'current_date_time': current_date_time,
            'current_window': composite_window_list
        }
        return time_dict

    def get_guide_date_cell_in_datetime_grid_guide(self, screen_dump={}):
        """
        :description:
            Get date from the Grid Guide screen (date in the channel column caption)
            This date represents currently displayed Grid Guide time window (past, now, future)
        :params:
        :return:
            datetime, class instance (the time is zeroed since it does not have it)
        """
        box_date = self.get_date_today()
        date_str = self.get_guide_date(screen_dump=screen_dump)
        date_converted = self.convert_tivo_date(date_str)
        # Making appropriate year
        if box_date.month == 1 and date_converted.month == 12:
            date_converted = date_converted.replace(year=box_date.year - 1)
        elif box_date.month == 12 and date_converted.month == 1:
            date_converted = date_converted.replace(year=box_date.year + 1)
        else:
            date_converted = date_converted.replace(year=box_date.year)
        return date_converted

    def get_guide_time_cell_list_in_datetime_grid_guide(self, screen_dump={}):
        """
        :description:
            Get Grid Guide column time list (the time in the comlum headers)
            This date represents currently displayed Grid Guide time window (past, now, future)
        :params:
        :return:
            list of datetime items
        """
        time_line = []
        time_line_list = self.get_guide_time_window(screen_dump=screen_dump)
        grid_guide_date = self.get_guide_date_cell_in_datetime_grid_guide(screen_dump)
        # Making appropriate year, month, day
        for item in time_line_list:
            item_parsed = self.convert_tivo_time(item)
            time_line.append(self.create_composite_date_time(grid_guide_date, item_parsed.time()))
        return time_line

    def select_and_watch_program(self, tester, text='', socu=False, resume=False, open_rec_overlay=True):
        """
        Args:
            tester (TestClass): test class instance
            text (str): ??? it looks like this param is not used
            socu (bool): True - staring SOCU playback, False - starting Live TV
            resume (bool): True - starting a program from the paused point,
                           False - starting a program from beginning
            open_rec_overlay (bool): True, making long key press to bring up the Record Overlay
                                     False, no long key press since Record Overlay is shown
        """
        if socu:
            if open_rec_overlay:
                self.screen.base.long_press_enter()
                self.wait_for_screen_ready("RecordOverlay")
            self.screen.refresh()
            if self.is_overlay_shown():
                self.log.step("Watch SOCU from Guide: Record overlay")
                self.select_menu(self.get_watch_now_catchup_name(tester))
            elif self.screen.get_screen_dump_item('viewMode') == tester.watchvideo_labels.LBL_LIVETV_VIEWMODE:
                tester.watchvideo_assertions.verify_error_overlay_not_shown()
                self.log.step("Watch SOCU from live TV: Info banner")
                tester.watchvideo_page.show_info_banner()
                self.select_strip(tester.watchvideo_labels.LBL_START_OVER)
            else:
                raise AssertionError("Record Overlay or watchvideo live screen not displayed")
            try:
                self.wait_for_screen_ready(tester.guide_labels.LBL_RESUME_OVERLAY)
                screen = self.screen.get_json()['xml']
                if "overlayMode" in screen.keys():
                    if resume:
                        self.select_menu(self.guide_labels.LBL_RESUME_PLAYING)
                    else:
                        self.select_menu(self.guide_labels.LBL_STARTOVER)
            except Exception:
                self.log.info("Overlay is not shown, video is already playing.")
        else:
            if open_rec_overlay:
                self.screen.base.press_enter()
                self.pause(5)
            self.screen.refresh()
            if self.is_overlay_shown():
                self.log.step("Watch Live from Guide: Record overlay")
                if self.is_in_menu(self.guide_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE):
                    self.select_menu(self.guide_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE)
                elif self.is_in_menu(self.guide_labels.LBL_WATCH_NOW_RECORD_OVERLAY):
                    self.log.info("Watch Now overlay is displayed")
                    self.select_menu(self.guide_labels.LBL_WATCH_NOW_RECORD_OVERLAY)
                    if self.is_overlay_shown():
                        self.screen.refresh()
                        if self.is_in_menu(self.guide_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE):
                            self.log.info("Selecting watch live from Watch Now overlay")
                            self.select_menu(self.guide_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE)
            else:
                self.log.info("Record overlay is not displayed")
                self.screen.refresh()

    def select_and_record_program(self, tester):
        self.log.step("Raise overlay for highligted program and select recording")
        self.press_info_or_long_press_enter()
        self.wait_for_screen_ready("RecordOverlay")
        self.screen.refresh()
        if self.is_overlay_shown():
            self.log.step("Record program from Record overlay")
            self.select_menu_by_substring(tester.guide_labels.LBL_RECORD)
        elif self.screen.get_screen_dump_item('viewMode') == tester.watchvideo_labels.LBL_LIVETV_VIEWMODE:
            self.log.step("Record program from Info banner")
            tester.watchvideo_page.show_info_banner()
            self.select_strip(tester.guide_labels.LBL_RECORD_STRING)
        else:
            raise AssertionError("Record Overlay or watchvideo live screen not displayed")
        self.wait_for_screen_ready(tester.guide_labels.LBL_RECORD_OVERLAY, 15000)
        self.screen.refresh()
        if self.is_overlay_title():
            self.select_menu_by_substring(tester.guide_labels.LBL_RECORD)
            tester.home_assertions.verify_whisper(self.guide_labels.LBL_RECORD_SCHEDULED, False)

    def select_and_cancel_program_recording(self, tester, long_press=False):
        self.log.step("Launching Record overlay and cancelling a recording")
        if long_press:
            self.log.info("Doing a long press")
            self.screen.refresh()
            self.press_info_or_long_press_enter()
            self.wait_for_screen_ready(self.guide_labels.LBL_RECORD_OVERLAY, timeout=30000)
            self.screen.refresh()
            if not self.is_overlay_shown():
                # condition for KeyEventServer where is no info button
                self.log.info("Overlay not displayed")
                self.screen.base.long_press_enter()
                self.wait_for_screen_ready(self.guide_labels.LBL_RECORDING_OPTIONS_OVERLAY, timeout=20000)
            if self.screen.get_screen_dump_item('viewMode') == tester.watchvideo_labels.LBL_LIVETV_VIEWMODE:
                self.log.info("Delete recording from Info banner")
                tester.watchvideo_page.show_info_banner()
                self.select_strip(tester.watchvideo_labels.LBL_STOP_RECORDING)
                self.wait_for_screen_ready()
                self.screen.refresh()
                self.select_menu_by_substring('delete')
                return
        else:
            self.screen.refresh()
            self.screen.base.press_enter(time=1000)
        self.screen.refresh()
        tester.guide_assertions.verify_menu_has_option('Modify')
        self.verify_menu_has_focus()
        self.select_menu_by_substring('Modify')
        self.pause(3)
        self.screen.refresh()
        tester.guide_assertions.verify_menu_has_option('Cancel')
        self.verify_menu_has_focus()
        self.select_menu_by_substring('Cancel')
        self.pause(3)
        self.screen.refresh()
        tester.guide_assertions.verify_menu_has_option('delete')
        self.verify_menu_has_focus()
        self.select_menu_by_substring('delete')

    def select_and_get_more_info(self, tester):
        self.screen.base.long_press_enter(time=1000)
        self.wait_for_screen_ready(self.guide_labels.LBL_RECORDING_OPTIONS_OVERLAY)
        self.screen.refresh()
        tester.guide_assertions.verify_menu_has_option('More')
        self.verify_menu_has_focus()
        self.select_menu_by_substring('More')
        self.pause(3)
        self.screen.refresh()

    def one_line_guide_options(self, tester):
        self.screen.base.press_enter(time=300)
        self.screen.base.press_up()
        self.pause(0.5)
        self.screen.refresh()
        tester.watchvideo_assertions.verify_one_line_guide()
        self.screen.base.press_right()
        self.screen.base.press_enter(time=300)
        self.pause(0.5)
        self.screen.refresh()
        tester.guide_assertions.verify_one_line_guide_menu_options()

    def select_and_goto_one_line_guide(self, tester):
        self.screen.base.press_enter(time=300)
        self.screen.base.press_up()
        self.pause(5)
        self.screen.refresh()
        tester.watchvideo_assertions.verify_one_line_guide()

    def goto_one_line_guide_from_live(self, tester, channel=None, confirm=True):
        """
        Method to invoke online guide widget and assert titles exist. If channel defined the before checking
        the channel will be tuned
        :param tester: instance(self) of suite entities
        :param channel: int/str, of particular channel required to tune. If none default channel will be verified
        """
        self.log.step("Launching one line guide from live tv")
        self.open_olg()
        tester.watchvideo_assertions.verify_one_line_guide()
        if channel is not None:
            self.log.info("Navigate to channel {}. ".format(channel))
            self.enter_channel_number(channel, confirm=confirm, olg=True)  # contains 15s delay
            if confirm:
                self.log.info("Open the one line guide")
                # wait reopen olg as it hided by timeout
                self.wait_for_onelineguide("false")
                self.open_olg()
        self.screen.get_json()  # using this as oneline interactive widget

    def exit_one_line_guide(self):
        self.log.info("Pressing BACK to exit One Line Guide")
        self.screen.base.press_back()

    def select_and_bookmark(self, tester):
        self.log.step("select and bookmark")
        self.screen.base.long_press_enter(time=1000)
        self.screen.refresh()
        tester.guide_assertions.verify_menu_has_option('Bookmark')
        show_name = self.get_overlay_title()
        self.verify_menu_has_focus()
        self.select_menu_by_substring('Bookmark')
        self.pause(3)
        self.screen.refresh()
        return show_name

    def select_menu_items(self, menu):
        if not self.is_menu_focus():
            loop_attempts = 0
            while not self.is_menu_focus():
                self.screen.base.press_up()
                self.screen.refresh()
                loop_attempts += 1
                if loop_attempts > 10:
                    break
        self.select_menu(menu)
        self.screen.refresh()

    def select_menu_items_no_refresh(self, menu):
        if not self.is_menu_focus():
            loop_attempts = 0
            while not self.is_menu_focus():
                self.screen.base.press_up()
                self.screen.refresh()
                loop_attempts += 1
                if loop_attempts > 10:
                    break
        self.select_menu(menu)

    def switch_channel_option(self, option):
        self.log.step(f"Changing to {option}")
        item_status = True
        for i in range(5):
            self.menu_navigate_left_right(1, 0)
            self.wait_for_screen_ready()
            self.screen.refresh()
            if self.channel_tab_focus_check():
                item_status = False
                break
        if item_status:
            raise AssertionError("Focus is not on channel tab")
        self.select_item()
        self.wait_for_screen_ready("ChannelOptionsOverlay")
        self.screen.refresh()
        self.nav_to_menu(self.guide_labels.LBL_CHANNELS_WATCH_NOW_OVERLAY)
        self.wait_for_screen_ready()
        self.screen.refresh()
        menu_item = self.menu_list()
        index = menu_item.index(self.guide_labels.LBL_CHANNELS_WATCH_NOW_OVERLAY)
        if index is None:
            raise AssertionError("{} not available in overlay".format(self.guide_labels.LBL_CHANNELS_WATCH_NOW_OVERLAY))
        option_item = self.screen.get_screen_dump_item('menuitem')[index]['optionItem']
        self.log.info("option item: {}".format(option_item))
        if option_item is not None:
            for item in option_item:
                if 'hasfocus' in item:
                    if item['text'] != option:
                        self.log.info("changing from {} to {}".format(item['text'], option))
                        self.menu_navigate_left_right(0, 1)
                        self.select_item()
                    else:
                        self.log.info("selected option is already set to {}".format(item['text']))
                        break
        else:
            raise AssertionError("Option Item were empty {}:".format(option_item))
        self.wait_for_screen_ready()
        self.screen.refresh()

    def go_up_down_channels_on_guide(self, num_of_times):
        self.log.step("Navigating UP/DOWN in guide")
        timestamp_start = datetime.datetime.now().timestamp()
        Settings.test_window_start = timestamp_start * 1000
        self.screen.base.press_up()
        for i in range(num_of_times):
            self.screen.base.press_up()
        for i in range(num_of_times):
            self.screen.base.press_down()
        timestamp_end = datetime.datetime.now().timestamp()
        Settings.test_window_end = timestamp_end * 1000

    def fast_forward_show(self, tester, speed):
        self.log.info(f"Fast forwarding playback to {speed} speed")
        for i in range(speed):
            self.screen.base.press_fast_forward()
        self.screen.refresh()
        tester.guide_assertions.verify_fast_forward(speed)

    def rewind_show(self, tester, speed):
        self.log.info(f"Rewind playback to {speed} speed")
        for i in range(speed):
            self.screen.base.press_rewind()
        self.screen.refresh()
        tester.guide_assertions.verify_rewind(speed)

    def pause_show(self, tester):
        self.log.info("Pausing video playback")
        self.screen.base.press_playpause()
        tester.guide_assertions.verify_pause()

    def check_content_playback(self, tester, refresh=True, tplus=False):
        overlay = False
        self.wait_for_LiveTVPlayback("PLAYING")
        if refresh:
            self.screen.refresh()
            if not self.is_overlay_shown():
                count = 5
                while count > 0 and not tplus:
                    tester.watchvideo_page.show_trickplay_if_not_visible()
                    self.screen.refresh()
                    dump = self.screen.get_screen_dump_item('trick-play')
                    replay_time = self.convert_time_to_sec(dump['replay-size'])
                    if replay_time > 0:
                        count = -2
                        break
                    self.pause(3)
                    count -= 1
                self.log.info("Checking playback started or not")
                if count != -2 and not tplus:
                    self.log.info("Failed to playback content")
                    return False, overlay
            else:
                self.log.info("Failed to playback content. overlay observed")
                overlay = True
                return False, overlay
        self.log.info("content playback successful")
        return True, overlay

    def find_channel_with_audio_option(self, tester):
        self.log.info("Looking for a channel with multiple Audio Tracks")
        tester.home_page.back_to_home_short()
        tester.home_assertions.verify_menu_item_available(tester.home_labels.LBL_GUIDE_SHORTCUT)
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_GUIDE_SHORTCUT)
        tries = 15
        while tries > 0:
            self.screen.base.press_down()
            self.get_live_program_name(self)
            self.screen.base.press_enter()
            tester.guide_assertions.verify_live_playback()
            self.open_full_info_banner(tester)
            self.screen.refresh()
            if self.is_strip_list():
                if self.is_in_strip("Change Audio Track"):
                    self.log.info("Got a channel with Audio track")
                    self.select_strip("Change Audio Track")
                    break
            self.screen.base.press_back()
            if not self.wait_for_screen_ready("GridGuide"):
                self.screen.base.press_back()
            tries -= 1
        if tries == 0:
            pytest.fail("Unable to find a channel with audio track option")

    def open_full_info_banner(self, tester):
        self.screen.base.press_info()
        platforms_not_supported = ['firetv']
        if Settings.platform.lower() in platforms_not_supported:
            tester.watchvideo_page.wait_for_trickplay_bar_dismiss(Settings.trickplay_bar_timeout_in_pause_mode)
            tester.watchvideo_assertions.verify_trickplay_bar_not_shown()
            self.press_down_button()

    def change_audio(self, tester):
        self.log.step("Modifying audio track")
        self.open_full_info_banner(tester)
        self.screen.refresh()
        if not self.is_in_strip("Change Audio Track"):
            self.find_channel_with_audio_option(tester)
        else:
            self.log.info("Got a channel with Audio track")
            self.select_strip("Change Audio Track")
        self.screen.refresh()
        audio_options = self.menu_list()
        audio_options.append(audio_options.pop(audio_options.index(audio_options[0])))
        self.screen.base.press_back()
        for option in audio_options:
            self.log.info("Modifying Audio track option to {}".format(option))
            self.open_full_info_banner(tester)
            self.pause(2)
            self.screen.refresh()
            self.select_strip("Change Audio Track")
            self.screen.refresh()
            self.select_menu(option)
            self.pause(2)
            self.open_full_info_banner(tester)
            self.pause(2)
            self.screen.refresh()
            self.select_strip("Change Audio Track")
            self.screen.refresh()
            tester.guide_assertions.verify_audio_option_selected(option)
            self.screen.base.press_back()

    def get_show_from_guide(self):
        self.screen.refresh()
        menuitem = self.screen.get_screen_dump_item('menuitem')
        return menuitem[0]['grid-row'][1]['text']

    def get_show_from_trickplay(self):
        self.log.info("Getting program name")
        self.pause(1)
        self.screen.refresh()
        self.pause(2)
        title = self.screen.get_screen_dump_item('title')
        return title

    def find_show_with_bookmark_option(self, tester):
        tester.home_page.back_to_home_short()
        tester.home_assertions.verify_menu_item_available(tester.home_labels.LBL_GUIDE_SHORTCUT)
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_GUIDE_SHORTCUT)
        self.wait_for_screen_ready(self.guide_labels.LBL_GUIDE_SCREEN)
        tries = 15
        content = None
        while (tries > 0):
            self.screen.base.press_down()
            self.screen.refresh()
            self.get_live_program_name(self)
            self.screen.base.press_enter()
            self.wait_for_screen_ready()
            content = self.get_show_from_trickplay()
            self.screen.base.press_info(time=2000)
            self.screen.refresh()
            if not self.is_strip_list():
                continue
            if self.is_in_strip("Bookmark", matcher_type="in"):
                self.select_string_by_substring("Bookmark")
                self.pause(1)
                break
            self.screen.base.press_back()
            self.wait_for_screen_ready()
            if self.screen.get_screen_dump_item('viewMode') == tester.watchvideo_labels.LBL_LIVETV_VIEWMODE:
                self.screen.base.press_back()
            tries -= 1
        return content

    def bookmark_content(self, tester):
        content = None
        content = self.get_show_from_trickplay()
        self.screen.base.press_info()
        self.screen.base.press_right(time=300)
        self.screen.refresh()
        if self.is_in_strip("Bookmark", matcher_type="in"):
            self.select_string_by_substring("Bookmark")
            self.pause(2)
        else:
            content = self.find_show_with_bookmark_option(tester)
        return content

    def get_watch_now_catchup_name(self, tester, inprogress=True):
        self.screen.refresh()
        focused_image_item = self.image_focus()
        if isinstance(focused_image_item, list):
            watch_now_catchup_name = self.guide_labels.LBL_WATCH_NOW_RECORD_OVERLAY
        else:
            if inprogress:
                if Settings.hydra_branch() < Settings.hydra_branch(HydraBranches.STREAMER_1_7):
                    watch_now_catchup_name = tester.menu_labels.LBL_WATCH_NOW_FROM_SOCU
                else:
                    watch_now_catchup_name = self.get_catchup_startover_text(tester)[1]
            else:
                if Settings.hydra_branch() < Settings.hydra_branch(HydraBranches.STREAMER_1_7):
                    watch_now_catchup_name = tester.menu_labels.LBL_WATCH_NOW_FROM_SOCU
                else:
                    watch_now_catchup_name = self.get_catchup_startover_text(tester)[0]
        self.log.info("Selecting {} ".format(watch_now_catchup_name))
        return watch_now_catchup_name

    def get_focussed_grid_item(self, tester=None):
        """
        The method is reciving focused program. if GridGuide element is not avaialable a few retries with
        screen refreshes will be performed
        Args:
            tester: trash parameter

        Returns:
            str, name of focused program
        """
        self.log.info("Getting focussed program name")
        guide = self.return_guide()
        tab_focus = self.get_focused_guide_row_tab(guide)
        focused_item = tab_focus['text'] if "text" in tab_focus else self.screen.get_screen_dump_item('program', 'text')
        self.log.info("The focused program is: {}".format(focused_item))
        return focused_item

    def press_info_or_long_press_enter(self, refresh=False):
        self.log.info("Pressing info button/long press enter based on device type")
        if Settings.is_managed():
            self.screen.base.press_info()
        else:
            self.screen.base.long_press_enter()
        if refresh:
            self.screen.refresh()

    def create_live_recording(self, start_rec=None, stop_rec=None):
        self.log.step("Creating live recording")
        record_status = None
        record_status = self.check_cell_recordable_or_not()
        if record_status:
            self.press_info_or_long_press_enter(refresh=True)
            if not self.is_overlay_shown():
                # condition for KeyEventServer where is no info button
                self.log.info("Overlay not displayed")
                self.screen.base.long_press_enter()
                self.wait_for_screen_ready(self.guide_labels.LBL_RECORDING_OPTIONS_OVERLAY, timeout=20000)
                self.screen.refresh()
                if not self.is_overlay_shown():
                    self.log.info("Overlay not displayed, retrying to launch Record overlay")
                    self.screen.base.long_press_enter()
                    self.wait_for_screen_ready(self.guide_labels.LBL_RECORDING_OPTIONS_OVERLAY, timeout=20000)
                    self.screen.refresh()
            modifyrecording = self.guide_labels.LBL_MODIFY_RECORDING
            menulist = self.menu_list()
            liststr = ' '.join([str(elem) for elem in menulist])
            if not self.is_overlay_shown():
                # check record overlay is shown before navigation if not then there is no sense to continue testing
                mode = overlay_title = ""
                try:
                    mode = self.view_mode()
                    overlay_title = self.get_overlay_title()
                except KeyError:
                    pass
                raise LookupError("Record overlay is not visible. Current mode: {}, overlay:{}".format(mode, overlay_title))
            if modifyrecording in liststr:
                self.log.info("Recording is already scheduled and list in myshows")
                self.nav_to_menu_by_substring(modifyrecording)
            else:
                self.log.info("schedule live recording")
                try:
                    self.select_menu_by_substring(self.guide_labels.LBL_RECORD)
                except LookupError as e:
                    self.log.error(e)
                    raise UINavigationException(
                        "Seeking option: {} not found in overlay's option: {}".format(self.guide_labels.LBL_RECORD,
                                                                                      self.get_menu_item()))
                self.wait_for_screen_ready(self.guide_labels.LBL_RECORD_OVERLAY)
                self.screen.refresh()
                if self.is_overlay_shown():
                    if start_rec:
                        self.nav_to_menu_by_substring(self.guide_labels.LBL_START_RECORDING_MENU)
                        self.log.info("On start recording padding.")
                        self.nav_to_item_option_horizontally(start_rec)
                    if stop_rec:
                        self.nav_to_menu_by_substring(self.guide_labels.LBL_STOP_RECORDING_MENU)
                        self.log.info("On stop recording padding.")
                        self.nav_to_item_option_horizontally(stop_rec)
                    if not Settings.is_apple_tv():
                        self.nav_to_top_of_list()
                        self.screen.refresh()
                    self.select_menu_by_substring(self.guide_labels.LBL_RECORD)
                    self.log.info("Recording Scheduled successfully")
                    return record_status
        else:
            self.log.error("Program does not seem to be recordable.")
            return record_status

    def guide_streaming_channel_number(self, tester=None, filter_channel=False, is_preview_offer_needed=False,
                                       use_cached_grid_row=False):
        """
        Args:
            filter_channel (bool): True - only channels with working playback are taken, False - any
            use_cached_grid_row (bool): True - using cached get_grid_row_search() response, False - making request
            is_preview_offer_needed (bool): True - making /v1/preview/offer request to get additional specific data,
                                            False - no /v1/preview/offer request;
                                            this param is needed for OpenAPI;

        Returns:
            str, channel_number
        """
        self.log.step("picking recordable channel from guide")
        channel_details = self.api.get_restrictedcapability_channels_details(
            Settings.tsn, filter_channel=filter_channel, filter_ndvr=True, is_preview_offer_needed=is_preview_offer_needed,
            use_cached_grid_row=use_cached_grid_row)
        channel_number = self.tivo_guide_nonrestricted_channel_no(channel_details)
        return channel_number

    def guide_encrypted_streaming_channel_number(self, tester=None, is_preview_offer_needed=False, use_cached_grid_row=False):
        """
        Args:
            use_cached_grid_row (bool): True - using cached get_grid_row_search() response, False - making request
            is_preview_offer_needed (bool): True - making /v1/preview/offer request to get additional specific data,
                                            False - no /v1/preview/offer request;
                                            this param is needed for OpenAPI;

        Returns:
            str, channel_number
        """
        channel_details = self.api.get_encrypted_restrictedcapability_channels_details(
            is_preview_offer_needed=is_preview_offer_needed, use_cached_grid_row=use_cached_grid_row)
        channel_number = self.tivo_guide_nonrestricted_channel_no(channel_details)
        return channel_number

    def tivo_guide_nonrestricted_channel_no(self, channel_details):
        """
        will take channel_details array and returns a non restricted channel number
        :param channel_details: api output of grid_row_search from which channel details need to be extracted
        :return: a non restricted channel number
        """
        if len(channel_details) > 1:
            del channel_details[0]  # temporary deletion until the non restricted channel API is fixed
        self.log.info("channel_details are: {}".format(channel_details))
        non_restricted_channel = None
        for channels in channel_details:
            if not channels['restricted'] and not channels['live_offer_restricted']:
                non_restricted_channel = channels['number']
                break
        if non_restricted_channel is not None:
            self.log.info("Channel number with no streaming restrictions: {}".format(non_restricted_channel))
            return non_restricted_channel
        else:
            assert False, "No non restricted channel found in channel details"

    def delete_one_pass_on_record_overlay(self, tester):
        self.screen.base.press_info()
        self.wait_for_screen_ready(self.guide_labels.LBL_RECORD_OVERLAY)
        self.screen.refresh()
        if not self.is_overlay_shown():
            # condition for KeyEventServer where is no info button
            self.log.info("Overlay not displayed, trying to launch record overlay via long press enter")
            self.screen.base.long_press_enter()
            self.wait_for_screen_ready(self.guide_labels.LBL_RECORD_OVERLAY)
            self.screen.refresh()
        if self.is_overlay_shown():
            self.log.step("Delete onepass from Record overlay")
            self.select_menu_by_substring(tester.guide_labels.LBL_MODIFY)
        elif self.screen.get_screen_dump_item('viewMode') == tester.watchvideo_labels.LBL_LIVETV_VIEWMODE:
            self.log.step("Delete onepass from Info banner")
            tester.watchvideo_page.show_info_banner()
            self.select_strip(tester.guide_labels.LBL_MODIFY_ONEPASS)
        else:
            raise AssertionError("Record Overlay or watchvideo live screen not displayed")
        self.screen.refresh()
        for label in [tester.guide_labels.LBL_CANCEL, tester.guide_labels.LBL_YES_CANCEL]:
            self.select_menu_by_substring(label)
            self.is_screen_rendered()
            self.screen.refresh()

    def create_one_pass_on_record_overlay(self, tester, streaming_only=False, reruns=False, record_everything=False,
                                          record_only=False, new_only=False):

        def _fun(substring):
            self.is_screen_rendered()
            self.screen.refresh()
            self.select_menu_by_substring(substring)
            self.pause(2)
        self.press_info_or_long_press_enter(refresh=False)
        self.wait_for_screen_ready(self.guide_labels.LBL_RECORD_OVERLAY, timeout=13000)
        self.screen.refresh()
        if "Options" in self.menu_list():  # select Options
            self.screen.base.press_enter()
            self.screen.refresh()
        if not self.is_overlay_shown():
            # condition for KeyEventServer where is no info button
            self.log.info("Overlay not displayed, trying to launch record overlay via long press enter")
            self.screen.base.long_press_enter()
            self.wait_for_screen_ready(self.guide_labels.LBL_RECORD_OVERLAY, timeout=20000)
            self.screen.refresh()
            if not self.is_overlay_shown():
                self.log.info("Overlay not displayed, retrying to launch Record overlay")
                self.screen.base.long_press_enter()
                self.wait_for_screen_ready(self.guide_labels.LBL_RECORD_OVERLAY, timeout=20000)
        if self.is_overlay_shown():
            self.log.step("Create onepass from Record overlay")
            show_name = self.get_overlay_title()
            self.log.info("Show onepassed - {}".format(show_name))
            menulist = self.menu_list()
            liststr = ' '.join([str(elem) for elem in menulist])
            if tester.guide_labels.LBL_CREATE in liststr:
                self.select_menu_by_substring(tester.guide_labels.LBL_CREATE)
            elif tester.guide_labels.LBL_MODIFY in liststr:
                self.select_menu_by_substring(f"{tester.guide_labels.LBL_MODIFY} {tester.guide_labels.LBL_ONE_PASS}")
                _fun(tester.guide_labels.LBL_USE_THESE_OPTIONS)
                tester.guide_assertions.verify_whisper_shown(self.guide_labels.LBL_ONEPASS_WHISPER_UPDATE_TEXT)
                return show_name
            else:
                raise AssertionError("Create/Modify OnePass Option is unavailable on Record Overlay")
        elif self.screen.get_screen_dump_item('viewMode') == tester.watchvideo_labels.LBL_LIVETV_VIEWMODE:
            show_name = self.screen.get_screen_dump_item('title')
            self.log.step("Create onepass from Info banner")
            tester.watchvideo_page.show_info_banner()
            self.select_strip(tester.watchvideo_labels.LBL_CREATE_ONEPASS)
        else:
            raise AssertionError("Record Overlay or watchvideo live screen not displayed")
        if record_everything:
            if Settings.is_ndvr_applicable():
                self.nav_to_menu(tester.guide_labels.LBL_RECORD_MENU)
                tester.menu_page.nav_to_item_option(tester.guide_labels.LBL_EVERYTHING)
        if streaming_only:
            self.nav_to_menu(tester.guide_labels.LBL_INCLUDE_MENU)
            tester.menu_page.nav_to_item_option(tester.guide_labels.LBL_STREAMING_VIDEO_ONLY)
        if record_only:
            self.nav_to_menu(tester.guide_labels.LBL_INCLUDE_MENU)
            tester.menu_page.nav_to_item_option(tester.guide_labels.LBL_RECORDINGS_ONLY)
        if new_only:
            self.nav_to_menu(tester.guide_labels.LBL_RECORD_MENU)
            tester.menu_page.nav_to_item_option(tester.guide_labels.LBL_NEW_ONLY)
        elif reruns:
            self.nav_to_menu(tester.guide_labels.LBL_RECORD_MENU)
            tester.menu_page.nav_to_item_option(tester.guide_labels.LBL_NEW_AND_RERUNS)
        _fun(tester.home_labels.LBL_CREATE_ONEPASS_WITH_THESE_OPTIONS)
        tester.guide_assertions.verify_whisper_shown(self.guide_labels.LBL_ONEPASS_WHISPER_TEXT)
        return show_name

    def open_record_overlay(self, using_info_button=False):
        self.log.step("Pop up Record Overlay")

        def show_record_overlay(press_info):
            if press_info:
                self.press_info_button(refresh=True)
            else:
                self.press_long_ok(refresh=True)
            self.wait_for_screen_ready(self.guide_labels.LBL_RECORD_OVERLAY, timeout=20000)

        show_record_overlay(using_info_button)
        if self.view_mode() == self.guide_labels.LBL_LIVE_TV_VIEW_MODE:
            self.screen.base.press_record()
            self.screen.refresh()
            state = self.wait_for_screen_ready(self.guide_labels.LBL_RECORD_OVERLAY, 20000)
            # Check record overlay is displayed before doing further navigations
            if not state:
                raise LookupError("Record overlay is not visible.")
        if not self.is_overlay_shown():
            self.log.warning("Record overlay wasn't displayed, trying again...")
            if Settings.is_managed():
                self.screen.base.press_info()
            else:
                self.screen.base.long_press_enter()
            self.wait_for_screen_ready(self.guide_labels.LBL_RECORDING_OPTIONS_OVERLAY, timeout=20000)
            self.screen.refresh()
        if not self.is_overlay_shown():
            raise AssertionError("Record Overlay wasn't shown, seems "
                                 f"{'long press OK button' if not using_info_button else 'info button'} not firing")

    def get_live_cache(self):
        trickplay = (self.screen.get_screen_dump_item('trick-play'))
        self.log.info("current cache size is {}".format(trickplay['replay-size']))
        return trickplay['replay-size']

    def build_cache(self, duration):
        cache_size = self.get_live_cache()
        self.log.info("cache_size: {}".format(cache_size))
        actual_duration = self.convert_time_to_sec(cache_size)
        self.log.info("actual cache size: {}".format(actual_duration))
        wait_time = int(duration - actual_duration)
        if wait_time > 0:
            self.log.info("Building cache for {}".format(wait_time))
            self.pause(wait_time)
        else:
            self.log.info("Enough cache is available")

    def get_current_recordable_show(self):
        loop_count = 0
        while loop_count <= 10:
            self.screen.base.press_enter(time=4000)
            self.screen.refresh()
            menu = self.menu_list()
            if self.guide_labels.LBL_PROGRAM_OPTIONS_RECORD_EPISODE in menu:
                self.screen.base.press_back()
                break
            elif len(menu) > 0:
                self.screen.base.press_back()
                self.screen.base.press_down()
            else:
                self.screen.base.press_down()
            loop_count += 1

        if loop_count > 10:
            assert False, "No recordable show found"

    def record_show(self):
        self.screen.base.press_enter(time=4000)
        self.screen.refresh()
        menu = self.menu_list()
        if self.guide_labels.LBL_PROGRAM_OPTIONS_RECORD_EPISODE in menu:
            show_name = self.screen.get_screen_dump_item('overlayTitle')
            self.select_menu_items(self.guide_labels.LBL_PROGRAM_OPTIONS_RECORD_EPISODE)
            self.select_menu_items(self.guide_labels.LBL_PROGRAM_OPTIONS_RECORD_EPISODE_WITH_THESE_OPTIONS)
            return show_name
        else:
            assert False, "Non recordable show"

    def select_cancel_recording(self, tester):
        self.log.info("Canceling the recording through the Record Overlay")
        self.menu_navigate_left_right(0, 3)
        self.wait_for_screen_ready("GuideListModel")
        self.screen.base.press_enter()
        self.wait_for_screen_ready("RecordOverlay")
        self.screen.refresh()
        if self.is_menu_list():
            menu_item_list = self.menu_list()
            record_menu_item = any(tester.guide_labels.LBL_RECORD in menu for menu in menu_item_list)
            modify_menu_item = any(tester.guide_labels.LBL_MODIFY_RECORDING in menu for menu in menu_item_list)
            self.log.info(f"record menu: {record_menu_item} :: modify recording menu :: {modify_menu_item}")
            if record_menu_item:
                # Schedule the recording
                self.select_validation_recording(tester)
                self.screen.refresh()
                # If Storage Limit overlay displayed - select OK
                if self.is_overlay_shown():
                    overlay_title = self.get_overlay_title()
                    if overlay_title is not None and tester.guide_labels.LBL_OVERLAY_STORAGE_LIMIT_TITLE in overlay_title:
                        self.select_menu(tester.guide_labels.LBL_OVERLAY_STORAGE_LIMIT_OK)
                # Check if recording was scheduled
                self.wait_for_screen_ready("GridGuide")
                self.screen.base.press_enter()
                self.wait_for_screen_ready("RecordOverlay")
                tester.guide_assertions.verify_is_modify_recording_record_overlay_item(tester)
                # Delete the recording
                self.select_validation_delete(tester)
                # Check if recording deleted
                self.wait_for_screen_ready("GridGuide")
                self.screen.base.press_enter()
                self.wait_for_screen_ready("RecordOverlay")
                tester.guide_assertions.verify_no_modify_recording_record_overlay_item(tester)
            elif modify_menu_item:
                # Delete the recording
                self.select_validation_delete(tester)
                # Check if recording deleted
                self.wait_for_screen_ready("GridGuide")
                self.screen.base.press_enter()
                self.wait_for_screen_ready("RecordOverlay")
                tester.guide_assertions.verify_no_modify_recording_record_overlay_item(tester)
            else:
                pytest.skip("Neither 'Record this episode/movie' nor 'Modify recording ($channel_data)' was found in the"
                            "Record Overlay")
        else:
            raise AssertionError("Channel item not found")

    def select_validation_delete(self, tester):
        self.log.info("Deleting the recording through the Record Overlay")
        self.screen.refresh()
        self.select_menu_by_substring(tester.guide_labels.LBL_MODIFY_RECORDING)
        self.wait_for_screen_ready("RecordingOptionsOverlay")
        self.screen.refresh()
        tester.guide_assertions.verify_menu_has_option(tester.guide_labels.LBL_CANCEL)
        self.select_menu_by_substring(tester.guide_labels.LBL_CANCEL)
        self.wait_for_screen_ready("CancelRecordingOverlay")
        self.screen.refresh()
        tester.guide_assertions.verify_menu_has_option(tester.guide_labels.LBL_CANCEL_REC_CONFIRMATION)
        self.select_menu_by_substring(tester.guide_labels.LBL_CANCEL_REC_CONFIRMATION)

    def select_validation_recording(self, tester):
        self.log.info("Scheduling a recording through the Record Overlay")
        self.screen.refresh()
        self.select_menu_by_substring(tester.guide_labels.LBL_RECORD)
        self.wait_for_screen_ready("RecordingOptionsOverlay")
        self.screen.refresh()
        tester.guide_assertions.verify_menu_has_option(tester.guide_labels.LBL_RECORD)
        self.select_menu_by_substring(tester.guide_labels.LBL_RECORD)

    def get_live_program_name_no_retries(self, tester, guide_time_to_mins, show_time_end_to_mins, diff=5):
        """
        Get live program name without retries.

        Args:
            tester (TestClass): test class instance
            guide_time_to_mins (int): show_time_end_to_mins
            show_time_end_to_mins (int): show_time_end_to_mins
            diff (int): wait time in minutes for show to end when it ends in less minutes than passed ones

        Returns:
            str, program name shown on a Guide Cell
        """
        self.log.info(f"Getting program name from Guide Cell; guide_time_to_mins {guide_time_to_mins}; "
                      f"show_time_end_to_mins {show_time_end_to_mins}; diff {diff}")
        focused_offer = None
        self.log.debug(f"show_time_end_to_mins = {show_time_end_to_mins}; guide_time_to_mins = {guide_time_to_mins}")
        if show_time_end_to_mins >= guide_time_to_mins:
            diff_time = show_time_end_to_mins - guide_time_to_mins
            self.log.info("Diff between Showtime and Current time is {}".format(diff_time))
            if diff_time <= diff:
                self.log.info("Sleeping as either the program is ending in another {} min".format(diff_time))
                self.pause(diff_time * 60)
                self.press_right_button()
            focused_offer = self.get_focussed_grid_item(tester)
        return focused_offer

    def get_live_program_name(self, tester, diff=5, raise_error_if_no_text=True):
        """
        Get live program name with retries. There may be more than 1 program in the current time frame
        and this method helps to locate live show among others.

        Args:
            tester (TestClass): test class instance
            diff (int): wait time in minutes for show to end when it ends in less minutes than passed ones
            raise_error_if_no_text (bool): True - raise error if program has no text over Guide Cell
                                           False - no failures when show does not have text on Guide Cell
                                           Note: if program duration <= 9 minutes in the current time frame,
                                                 then there won't be any text on the Guide Cell

        Returns:
            str, program name shown on a Guide Cell
        """
        self.log.step("Checking focussed program is live or not")
        limit = 0
        focused_offer = None
        error = ""
        while limit < 10:
            showtime = self.get_program_start_and_end_time()
            if showtime is None:
                raise TypeError("Failed to get program airing time from dump even after multiple retries:{}".format(showtime))
            dumptime = self.screen.get_screen_dump_item('timeinfo')
            guidetime = dumptime.strip(self.STRIP_AM_PM_FROM_TIME)
            guidetime_to_mins = self.convert_time_to_sec(guidetime)
            showtime_end_to_mins = self.convert_time_to_sec(showtime[1][0])
            showtime_start_to_mins = self.convert_time_to_sec(showtime[0][0])
            time_pm_am = re.findall(r"(\d{1,2}\:\d+\S)(am|pm)+", dumptime)
            self.log.info("guide time info breakdown: {}".format(time_pm_am))
            if showtime_start_to_mins == showtime_end_to_mins:
                # this means 24h show and it always live
                focused_offer = self.get_focussed_grid_item(tester)
                self.log.info("Found 24h show(live): '{}'".format(focused_offer))
                break
            # This part goes to shows that are less then 24 hours
            if showtime[1][1] != time_pm_am[0][1]:
                self.log.info("Time transition from {} to {}.adding 720 mins".format(showtime[1][1], time_pm_am[0][1]))
                # if there is time transition between am-pm/pm-am then adds 720 mins to show end time.
                showtime_end_to_mins += 720
            guidetime, guidetime_to_mins, showtime_end_to_mins = \
                self._update_guide_and_show_time(guidetime, guidetime_to_mins, showtime_end_to_mins)
            if showtime_end_to_mins >= guidetime_to_mins:
                focused_offer = self.get_live_program_name_no_retries(tester, guidetime_to_mins, showtime_end_to_mins, diff)
                break
            self.log.info("Scroll right. We are expecting live show later")
            self.press_right_button()
            self.wait_for_guide_next_page()
            limit += 1
        if focused_offer is None and raise_error_if_no_text:
            # Sometimes we need to merely highlight an in progress program. If show duration is less than 9 minutes
            # in the current time frame then the program won't have any text on the Guide Cell
            details = "After {} retries cant get focused program. Details: '{}'".format(limit, error)
            raise LookupError(details).with_traceback(sys.exc_info()[2])
        self.log.info("Offer returned: {}".format(focused_offer))
        focused_offer = self.convert_special_chars(focused_offer)
        return focused_offer

    def get_program_start_and_end_time(self, attempts=4):
        self.log.info("Getting program start and end time")
        showtime = None
        if self.is_overlay_shown():
            self.press_back_button()
        try:
            limit = 0
            while limit < attempts:
                self.screen.refresh()
                screen = self.screen.screen_dump['xml']
                if 'showtime' in screen.keys():
                    program_time = self.screen.get_screen_dump_item('showtime', 'text')
                    showtime = re.findall(r"(\d{1,2}\:\d+\S)(am|pm)+", program_time)
                    self.log.info("showtime is {}".format(showtime))
                    return showtime
                else:
                    condition = 'viewMode' in screen.keys() and screen['viewMode'] != self.guide_labels.LBL_VIEW_MODE
                    if limit != attempts - 1 and condition:
                        self.log.info("On {} screen. Pressing back to return to guide screen".format(screen['viewMode']))
                        self.press_back_button()
                        self.wait_for_screen_ready(self.guide_labels.LBL_GUIDE_SCREEN)
                    if limit == attempts - 1 and condition:
                        self.log.info("Navigating to guide again before attempting last time: {}".format(screen['viewMode']))
                        self.home_page.go_to_guide(self)
                    self.log.info("Showtime was not available in screendump. Retrying....")
                    self.pause((limit * 7) / 10)
                limit += 1
        except Exception as KeyError:
            self.log.error("Could not find {} in screendump".format(KeyError))
        return showtime

    def check_channel_availability(self, tester, channels, jmp_channel=None):
        self.log.step("checking if any of the jump channel is available in Guide from jump channel list")
        channel_list = tester.api.get_channel_search(omit=False)
        num_list = []
        channel_numbers = []
        for channel in channel_list:
            if channel.channel_number:
                num_list.append(channel.channel_number)
        for key in channels.keys():
            if key in num_list:
                channel_number = key
                channel_name = channels.get(key)
                self.log.info("Selected Jump channel is {}: {}".format(channel_number, channel_name))
                channel_numbers.append(channel_number)
        if not channel_numbers:
            pytest.skip(f"Guide do not have any of the jump channels from {channels} list of jump channels retrieved")
        elif jmp_channel:
            ch_num = []
            for ch_no in channel_numbers:
                jump_ch_name = channels.get(ch_no, None)
                if jump_ch_name is not None:
                    for vod in jmp_channel:
                        if vod.lower() in jump_ch_name.lower():
                            ch_num.append(ch_no)
            return ch_num
        else:
            return channel_numbers

    def verify_channel(self, tester, channel_number):
        self.log.info("Verifiying Channel number {}".format(channel_number))
        tester.home_page.back_to_home_short()
        tester.home_assertions.verify_menu_item_available(tester.home_labels.LBL_GUIDE_SHORTCUT)
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_GUIDE_SHORTCUT)
        self.watch_channel(tester, channel_number)
        tester.vod_assertions.verify_view_mode(tester.guide_labels.LBL_LIVE_TV_VIEW_MODE, dump=False)

    def press_enter(self, tester):
        self.screen.base.press_enter()
        self.screen.refresh()
        if 'overlayTitle' in self.screen.screen_dump['xml'].keys():
            if (tester.guide_assertions.verify_hdmiconnection_overlay(self.guide_labels.LBL_HDMI_OVERLAY)):
                self.screen.base.press_enter()

    def select_verify_modify_recording(self, tester):
        self.pause(2)
        self.wait_for_screen_ready(tester.guide_labels.LBL_RECORD_OVERLAY)
        self.screen.refresh()
        if self.is_menu_list():
            if self.is_in_menu(self.guide_labels.LBL_MODIFY):
                self.select_menu_by_substring(self.guide_labels.LBL_MODIFY)
                self.pause(2)
                self.screen.refresh()
                self.select_overlay_stripitem(self.guide_labels.LBL_KEEP_UNTIL_MENU)
                self.validate_modify_record_overlay(tester, self.guide_labels.LBL_KEEP_UNTIL)
                self.select_overlay_stripitem(self.guide_labels.LBL_START_RECORDING_MENU)
                if "b-hydra-streamer-1-7" in Settings.branch.lower():
                    self.validate_modify_record_overlay(tester, self.guide_labels.LBL_START_RECORDING)
                else:
                    self.validate_modify_record_overlay(tester, self.guide_labels.LBL_STARTRECORDING)
                self.select_overlay_stripitem(self.guide_labels.LBL_STOP_RECORDING_MENU)
                if "b-hydra-streamer-1-7" in Settings.branch.lower():
                    self.validate_modify_record_overlay(tester, self.guide_labels.LBL_STOP_RECORDING)
                else:
                    self.validate_modify_record_overlay(tester, self.guide_labels.LBL_STOPRECORDING)
            else:
                raise AssertionError("Modify menu for recording not found")
        else:
            raise AssertionError("Channel item not found")
        record_menu = self.get_record_menu_item()
        self.select_menu_items(record_menu)
        self.pause(2)

    def get_record_menu_item(self):
        self.log.info("Record menu item")
        menu_item = self.menu_list()
        if self.guide_labels.LBL_PROGRAM_OPTIONS_RECORD_EPISODE_WITH_THESE_OPTIONS in menu_item:
            return self.guide_labels.LBL_PROGRAM_OPTIONS_RECORD_EPISODE_WITH_THESE_OPTIONS
        elif self.guide_labels.LBL_PROGRAM_OPTIONS_RECORD_SHOW_WITH_THESE_OPTIONS in menu_item:
            return self.guide_labels.LBL_PROGRAM_OPTIONS_RECORD_SHOW_WITH_THESE_OPTIONS

    def select_overlay_stripitem(self, menu_item):
        self.log.info("Locating and selecting menu {}".format(menu_item))
        menu_focus = self.menu_focus()
        menu = self.menu_list()
        current_focus_index = menu.index(menu_focus) if menu_focus else 0
        menu_item_index = menu.index(menu_item)
        index_diff = current_focus_index - menu_item_index
        if (index_diff > 0):
            for i in range(index_diff):
                self.screen.base.press_up()
        else:
            index_diff = index_diff * -1
            for i in range(index_diff):
                self.screen.base.press_down()

    def validate_modify_record_overlay(self, tester, validation_label_list):
        self.screen.refresh()
        current_label = self.menu_item_option_focus()
        if current_label in validation_label_list:
            for label in validation_label_list:
                if current_label != label:
                    tester.menu_page.nav_to_item_option(label)
                    self.pause(2)
        else:
            raise AssertionError("The Label details on the overlay is not identical to the ones to be verified with")
        self.screen.refresh()

    def get_the_recording_icon_details(self):
        self.log.info("Getting recording icon from dump")
        screen_data = self.screen.get_json()
        screen_xml = screen_data['xml']
        if 'recording-icon' in screen_xml.keys():
            recordingicon_info = {}
            recordingicon_info['recordingicon_images'] = screen_xml['recording-icon']
            return recordingicon_info
        else:
            raise AssertionError('recording icon not shown after waiting for 30 sec.')

    def validate_explicit_recording_icon(self, tester, icon_image_list):
        if self.guide_labels.LBL_EXPLICIT_RECORD_ICON not in icon_image_list:
            tester.guide_assertions.explicit_recordingicon_assertion()
        else:
            self.log.info("Single explicit icon validation success!")

    def tab_refresh_explicit_recording_icon(self, retry=3, icon_validation=True):
        """
        The referesh movement has been put for a device bug(the explicit
        label icon is not reflected as soon as the recording is scheduled )to be fixed
        :return:
        """
        self.log.info("refreshing tab focus to display record icon in guide  header")
        found = False
        for i in range(retry):
            self.pause(30)  # Added delay as stated in the product bug BZSTREAM-6255 to wait for 30sec
            self.menu_navigate_left_right(0, 1)
            self.pause(5)
            self.menu_navigate_left_right(1, 0)
            self.wait_for_screen_ready()
            self.screen.refresh()
            if icon_validation:
                screen_xml = self.screen.screen_dump['xml']
                if 'recording-icon' in screen_xml.keys():
                    found = True
                    break
            else:
                self.log.info("Recording icon validation not required")
                found = True
                break
        if found:
            self.log.info("Recording icon shown")
        else:
            raise AssertionError('recording icon not shown after waiting for 30 sec with retry attempts.')

    def select_validate_onepass(self, tester):
        self.log.step("Launch and validate one pass options")
        self.screen.base.press_enter()
        self.screen.refresh()
        self.menu_navigate_left_right(1, 0)
        self.pause(2)
        self.screen.refresh()
        tester.guide_assertions.verify_menu_has_option(tester.vod_labels.LBL_ONEPASS_OPTIONS)
        self.select_menu_by_substring(tester.vod_labels.LBL_ONEPASS_OPTIONS)
        self.pause(2)
        self.screen.refresh()
        tester.guide_assertions.verify_menu_has_option(self.guide_labels.LBL_CANCEL)
        self.select_menu_by_substring(self.guide_labels.LBL_CANCEL)
        self.pause(2)
        self.wait_for_screen_ready(self.guide_labels.LBL_CANCEL_ONEPASS_OVERLAY)
        self.screen.refresh()
        self.select_menu_by_substring(self.guide_labels.LBL_YES_CANCEL)
        tester.guide_assertions.verify_whisper_shown(self.guide_labels.LBL_CANCEL_ONEPASS_WHISPER)

    def get_trickplay_non_restricted_socu_channel(self, tester, filter_channel=False):
        self.log.info("Get trickplay non restricted SOCU channel")
        socu_chn_wo_restrict = []
        socu_channel_num = []
        channels = tester.api.get_channels_with_no_socu_trickplay_restriction()
        socu_channels = self.get_all_socu_channels_from_guide(tester)
        for channel in socu_channels:
            socu_channel_num.append(channel['channel_number'])
        for channel in channels:
            if channel['number'] in socu_channel_num:
                socu_chn_wo_restrict.append(channel['number'])
        if len(socu_chn_wo_restrict) == 0:
            pytest.skip("All the socu channels have socu trickplay restrictions enabled")
        else:
            if filter_channel:
                socu_chn_wo_restrict = tester.api.filter_good_channels(socu_chn_wo_restrict, filter_channel)
                if socu_chn_wo_restrict is None and len(socu_chn_wo_restrict) < 0:
                    pytest.fail(f"None of the channels from list:{socu_chn_wo_restrict} is playable")
            self.log.info("unrestricted socu channels: {}".format(socu_chn_wo_restrict))
            return socu_chn_wo_restrict

    def get_all_socu_channels_from_guide(self, tester):
        socu_channels = []
        grid_row_list = tester.api.get_grid_row_search()
        for row in grid_row_list:
            if row['offers']:
                first_offer = row['offers'][0]
                socu_channel_list = {}
                if first_offer.is_catchup or first_offer.is_startover:
                    socu_channel_list['channel_number'] = row['channel_item'].channel_number
                    socu_channel_list['stationId'] = row['channel_item'].station_id
                    socu_channels.append(socu_channel_list)
        self.log.info("Socu channels list: {}".format(socu_channels))
        return socu_channels

    def playback_and_verify_trickplay_action(self, tester, rewind=False, forward=False, pause=False,
                                             playpause=False, speed=1, socu=True):
        self.log.step("Checking trickplay actions")
        if socu:
            self.select_and_watch_program(tester, socu=True)
        tester.guide_assertions.verify_live_playback()
        self.wait_for_screen_ready(self.guide_labels.LBL_SOCU_PLAYBACK_SCREEN)
        if forward:
            self.log.info(f"Checking fast forward trickplay action with speed {speed}")
            self.fast_forward_show(tester, speed)
            self.screen.base.press_playpause()
        elif rewind:
            self.log.info(f"Checking rewind trickplay action with speed {speed}")
            self.rewind_show(tester, speed)
            self.screen.base.press_playpause()
        elif pause:
            self.log.info("Checking pause trickplay action ")
            self.screen.base.press_playpause()
        elif playpause:
            self.log.info("Checking play trickplay action ")
            self.pause_show(tester)
            self.screen.refresh()
            if not self.get_trickplay_visible():
                self.screen.base.press_playpause()
            self.screen.base.press_playpause()
            tester.guide_assertions.verify_play_normal()

    def select_and_validate_program_screen_strips(self, tester, strip_order):
        self.log.step("Getting strip list")
        self.open_record_overlay()
        self.select_menu(tester.menu_page.get_more_info_name(tester))
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_EPISODE_SCREEN)
        self.screen.refresh()
        menu = self.menu_list()
        strip_order = self.check_menu_availability(menu, strip_order)
        tester.guide_assertions.verify_strip_order(strip_order, menu)

    def check_menu_availability(self, menu, strips):
        pop_array = []
        for item in strips:
            self.log.info("checking item{}".format(item))
            if item not in menu:
                pop_array.append(item)

        if pop_array:
            strips = [item for item in strips if item not in pop_array]
        else:
            self.log.info("No items removed")

        return strips

    def go_to_live_tv(self, tester):
        self.log.info("Navigate to live tv")
        tester.home_page.back_to_home_short()
        tester.home_assertions.verify_menu_item_available(tester.home_labels.LBL_LIVETV_SHORTCUT)
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_LIVETV_SHORTCUT)
        status = self.wait_for_screen_ready('TvWatchLive')
        if not status:
            self.log.info("Tune to channel")
            self.open_olg()
            self.screen.base.press_enter()

    def get_highlighted_channel_number_in_one_line_guide(self, refresh=True):
        self.log.info("get highlighted channel number")
        if refresh:
            self.screen.get_json()  # to avoid 8 second wating before making a screen dump
        channel_list = self.screen.get_screen_dump_item('menuitem')
        for channel in channel_list:
            if channel:
                if 'highlighted-row' in channel.keys():
                    if channel['highlighted-row'] == "true":
                        return channel['text'][0]
        self.log.info("highlighted channel number not found")
        return False

    def goto_episode_screen(self, tester):
        self.log.step("Launching Episode screen")
        self.screen.base.long_press_enter()
        self.wait_for_screen_ready(tester.guide_labels.LBL_RECORD_OVERLAY)
        self.screen.refresh()
        self.select_menu(tester.menu_page.get_more_info_name(tester))
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_EPISODE_SCREEN)

    def get_strip_items_title(self, tester):
        self.log.step("Getting strip items title")
        self.screen.base.press_right()
        title_list = []
        for i in range(12):
            self.screen.refresh()
            strip_items = self.screen.get_screen_dump_item('stripitem')
            st = strip_items[self.return_strip_focus_index()]
            if st.__contains__('hasfocus') and st.__contains__('text') and tester.vod_labels.LBL_VIEW_ALL in st['text']\
                    and st['hasfocus']:
                break
            else:
                title = self.get_preview_panel()['title']
                title_list.append(title)
                self.screen.base.press_right()
        self.log.info(f"Strip titles list: {title_list}")
        return title_list

    def move_or_select_view_all_in_biaxial_screen_strip(self, tester, strip, select_view_all=False):
        self.log.step(f"Moving to strip {strip}")
        self.screen.refresh()
        menu_list = self.menu_list()
        if strip in menu_list:
            self.nav_to_menu(strip)
            self.screen.refresh()
            for i in range(20):
                strip_items = self.get_strip_array()
                text_index, index_diff, left = self.find_focussed_and_required_text_index_in_strip(strip_items)
                if strip_items[text_index].get('text') is not None\
                        and tester.vod_labels.LBL_VIEW_ALL in strip_items[text_index]['text'] \
                        and strip_items[text_index].get('hasfocus') == 'true':
                    self.log.info("Reached 'VIEW ALL' tile")
                    if select_view_all:
                        self.log.info("Selecting View All option to launch list view")
                        self.screen.base.press_enter()
                        self.wait_for_screen_ready()
                        self.screen.refresh()
                    return
                else:
                    for j in range(index_diff):
                        if left:
                            self.screen.base.press_left()
                        else:
                            self.screen.base.press_right()
                    self.screen.refresh()
            self.log.error("could not reach 'VIEW ALL' tile even after {} attempts".format(i))
            assert False
        else:
            self.log.error("{} is not available".format(strip))
            assert False

    def select_verify_onepass_overlay_menu_item(self, tester):
        self.log.step("Launching OnePass Options overlay")
        self.pause(2)
        self.select_menu_by_substring(tester.guide_labels.LBL_CREATE)
        self.screen.refresh()
        self.wait_for_screen_ready(tester.guide_labels.LBL_ONEPASS_OPTIONS_OVERLAY)
        if self.is_menu_list():
            self.select_overlay_stripitem(self.guide_labels.LBL_START_FROM_MENU)
            self.select_overlay_stripitem(self.guide_labels.LBL_RENT_OR_BUY_MENU)
            self.select_overlay_stripitem(self.guide_labels.LBL_RECORD_MENU)
            self.select_overlay_stripitem(self.guide_labels.LBL_CHANNEL_MENU)
            self.select_overlay_stripitem(self.guide_labels.LBL_KEEP_AT_MOST_MENU)
            self.select_overlay_stripitem(self.guide_labels.LBL_KEEP_UNTIL_MENU)
            self.select_overlay_stripitem(self.guide_labels.LBL_START_RECORDING_MENU)
            self.select_overlay_stripitem(self.guide_labels.LBL_STOP_RECORDING_MENU)
        else:
            raise AssertionError("Channel item not found")

    def modify_onepass_option_values(self, tester, label):
        self.log.info("modifying one pass option to {}".format(label))
        self.screen.refresh()
        current_label = self.menu_item_option_focus()
        if current_label != label:
            tester.menu_page.nav_to_item_option(label)
            self.pause(2)
        else:
            raise AssertionError("The Label details on the overlay is not identical to modify.")

    def return_focused_guide_row_index(self):
        self.log.info("get focused guide row index")
        guide = self.return_guide()
        focused_index = 0
        for item in guide:
            for row in item['grid-row']:
                if 'hasfocus' in row.keys() and row['hasfocus'] == 'true':
                    return focused_index
            focused_index += 1

    def go_to_bottom_cell_in_guide(self):
        self.log.info("go to bottom cell in guide")
        focused_index = self.return_focused_guide_row_index()
        self.move_up_down(focused_index - 7)

    def get_date_of_show(self, items):
        if isinstance(items, dict):
            date_of_show = items.get('text')[0]
        elif isinstance(items, list):
            date_of_show = items[0]['text'][0]
        return date_of_show

    def get_time_of_show(self, items):
        if isinstance(items, dict):
            time_of_show = items.get('text')[1]
        elif isinstance(items, list):
            time_of_show = items[0]['text'][1]
        return time_of_show

    def get_title_of_show(self, items):
        if isinstance(items, dict):
            title_of_show = items.get('text')[2]
        elif isinstance(items, list):
            title_of_show = items[0]['text'][2]
        return title_of_show

    def channel_number(self, items):
        if isinstance(items, dict):
            channel_number = items.get('text')[3]
        elif isinstance(items, list):
            channel_number = items[0]['text'][3]
        return channel_number

    def icon_check(self, icon, screen_image, expected=True):
        """
        Can be used in areas below and others where icons are shown (and also some others):
            - Guide Cells
            - Guide Header preview (icons near title)
            - One Line Guide tile icons

        Args:
            icon (str): icon name e.g. hydra_icon_status_new.png;
                        if None - checking if there's no any icon
            screen_image (list): list of icons
            expected (bool): True - checking if icon is displayed, False - checking if there's no icon;
                             if icon param is None, then 'expected' param is forcely set to False

        Returns:
            bool, if icon is shown on UI
        """
        icon_check_status = False
        result = False
        if icon:
            icon_check_status = any(icon in string for string in screen_image) if type(screen_image) is list \
                else icon in screen_image
            if expected and icon_check_status or not expected and not icon_check_status:
                result = True
        else:
            result = not screen_image
        return result

    def get_socu_header_icon(self, tester):
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_18):
            socu_header_icon = field.socu_partner_id[Settings.mso] + "/partnerSourceLogo"
            return socu_header_icon
        elif Settings.hydra_branch() <= Settings.hydra_branch(HydraBranches.STREAMER_1_17):
            return tester.guide_labels.LBL_SOCU_SOURCE_ICON_HEADER

    def get_icon_name_for_passed_type(self, tester, icon_type):
        """
        Args:
            icon_type (str): one of (new, ppv, socu_guide_header, socu_guide_cell, non_recordable)

        Notes:
            socu_guide_header is applicable to Guide Header and One Line Guide preview

        Returns:
            str, icon name e.g. hydra_icon_status_new.png
        """
        if icon_type is None:
            return None
        elif icon_type == "new":
            return self.guide_labels.LBL_NEW_ICON
        elif icon_type == "ppv":
            return self.guide_labels.LBL_PPV_ICON
        elif icon_type == "socu_guide_header":
            return self.get_socu_header_icon(tester)
        elif icon_type == "socu_guide_cell":
            return self.guide_labels.LBL_CATCHUP_ICON
        elif icon_type == "non_recordable":
            return self.guide_labels.LBL_NON_RECORDABLE_CELL_ICON
        else:
            raise ValueError(f"{icon_type} type is not supported yet")

    def find_and_nav_to_guide_ad_using_gui(self,
                                           tester,
                                           action_type=None,
                                           screen_name=None,
                                           link_to_top_of_screen=False,
                                           is_carousel=False,
                                           feed_name="/promotions/guideHeader",
                                           streamer_only=False,
                                           need_deeplink=False,
                                           is_filter=False,
                                           is_subscribed=True,
                                           is_tivo_plus=False,
                                           is_app=False,
                                           is_installed=True,
                                           is_top_lvl=False):
        """
        find and navigate to the ad with current action type and returns the ad

        :param action_type: guide ads kernel action type
        :param screen_name: is a part of AD's URI that contained in Kernel
        :param bool link_to_top_of_screen:
                                True: find ADs with URI ended exactly with screen name
        :param bool is_carousel:
                                True: using regexp to find ADs with URI that contains &carousel=
        :param bool is_subscribed:
                                True: to get ADs with subscribed channels.
                                False: to get ADs with unsubscribed channels.
        :param bool is_tivo_plus:
                                True: get ads with tivo+ channels.
        :param bool is_app:
                                True: filter out ads by installed/uninstalled apps
        :param bool is_installed:
                                True: to get ADs with installed apps
                                False: to get ADs with uninstalled apps
        :param bool is_top_lvl:
                                True: to get ADs leading to TOP LVL APP
        :param feed_name: search ads by feed names:
            /promotions/guideFooter
            /promotions/guideHeader
            /promotions/guideBanner
        :param streamer_only: get ad for streamers only
        :param need_deeplink: uri must contain a deeplink
        :param bool is_filter:
                                True: to use the filter method
                                False: to don't use the filter method

        :return: AD obj
        """
        self.log.info("go to grid guide, action_type = {}".format(action_type))
        filtered_guide_ads_list = []
        guide_ads_list = tester.service_api.get_ads_list(action_type,
                                                         screen_name,
                                                         link_to_top_of_screen,
                                                         feed_name,
                                                         streamer_only,
                                                         need_deeplink)
        if not guide_ads_list:
            pytest.skip("Guide ADs with parameters: \n"
                        "action type: {} \n"
                        "screen name: {} \n"
                        "feed name: {} \n"
                        "link to top of screen: {} \n"
                        "streamer only: {} \n"
                        "need deep link: {} \n"
                        "filter 'is carousel': {} \n"
                        "is subscribed channel: {} \n"
                        "are NOT found in API response".format(action_type, screen_name, feed_name,
                                                               link_to_top_of_screen, streamer_only,
                                                               need_deeplink, is_carousel, is_subscribed))
        # Link to the top of the screen can't be filtered because there are no parameters to filter by
        if is_filter:
            if action_type == 'liveTvUiAction':
                filtered_guide_ads_list = tester.service_api.filter_out_live_tv_ads_list(guide_ads_list,
                                                                                         is_subscribed,
                                                                                         is_tivo_plus)
            elif not is_app and action_type == 'uiNavigateAction':
                filtered_guide_ads_list = tester.service_api.filter_out_ui_navigation_ads_list(tester,
                                                                                               guide_ads_list,
                                                                                               is_carousel)
            elif is_app and action_type == 'uiNavigateAction':
                filtered_guide_ads_list = self.filter_out_ads_by_installed_uninstalled_apps(guide_ads_list,
                                                                                            is_installed)
                if is_top_lvl:
                    filtered_guide_ads_list = self.filter_out_ads_by_top_lvl_app(filtered_guide_ads_list)

                if not filtered_guide_ads_list:
                    pytest.skip("After filtering we got no ADs with installed={} apps\n"
                                "Full list of ADs we got from API:\n {}".format(is_installed, guide_ads_list))
        else:
            filtered_guide_ads_list = guide_ads_list

        if 'guideFooter' in feed_name:
            return self.navigate_to_and_get_guide_footer(filtered_guide_ads_list)

        elif 'guideHeader' in feed_name:
            return self.navigate_to_and_get_guide_header(tester, filtered_guide_ads_list)

        elif 'guideBanner' in feed_name:
            return self.navigate_to_and_get_guide_banner(filtered_guide_ads_list)

        else:
            pytest.skip("Navigation to unknown AD's type does not provided")

    def filter_out_ads_by_top_lvl_app(self, ads_list):
        """
        method to filter ads list by top level app
        :param: ads_list
        :return: filtered_ads_list
        """
        filtered_ads_list = []
        for ad in ads_list:
            if 'kernel' in ad.keys() and 'uri' in ad['kernel'].keys():
                if 'deeplink=' not in ad['kernel']['uri']:
                    filtered_ads_list.append(ad)
        return filtered_ads_list

    def filter_out_ads_by_installed_uninstalled_apps(self, ads_list, is_installed=True):
        """
        method to filter ads list by apps - installed/uninstalled
        :param: ads_list
        :return: filtered_ads_list
        """
        filtered_ads_list = []
        for ad in ads_list:
            if 'kernel' in ad.keys() and 'uri' in ad['kernel'].keys():
                app_name = re.search(r'\w+\.\w+\.\w+', ad['kernel']['uri'])[0]
                installed = self.is_app_installed(app_name)
                if is_installed and installed:
                    filtered_ads_list.append(ad)
                elif not is_installed and not installed:
                    filtered_ads_list.append(ad)
        return filtered_ads_list

    def navigate_to_and_get_guide_footer(self, filtered_guide_ads_list):
        """
        Find and navigate to program in guide channel list that will match to guide footer from list
        :param filtered_guide_ads_list: list of footer ads
        :return: guide footer
        """
        for i in range(100):
            guide_footer_ad, guide_footer_ad_row_index = self.get_guide_ad_row(filtered_guide_ads_list)
            # guide_footer_row can be 0 so verifying is not None
            if guide_footer_ad and guide_footer_ad_row_index is not None:
                # if index is 8 then test will navigate to Guide Banner need +1 row down
                if guide_footer_ad_row_index == 8:
                    self.vertical_nav_to_guide_row_by_index(guide_footer_ad_row_index + 1, 'Y')
                    return guide_footer_ad
                else:
                    self.vertical_nav_to_guide_row_by_index(guide_footer_ad_row_index, 'Y')
                    return guide_footer_ad
            else:
                self.screen.base.press_channel_down()
        else:
            raise LookupError("Guide footers are not found in grid guide program list. \n "
                              "Footers: \n {}".format(filtered_guide_ads_list))

    def navigate_to_and_get_guide_header(self, tester, filtered_guide_ads_list):
        """
        Find and navigate to program in guide channel list that will match to guide header from list
        :param tester:
        :param filtered_guide_ads_list: list of header ads
        :return: guide header
        """
        self.go_to_last_channel(tester)
        for i in range(25):
            self.screen.refresh()
            guide_header_ad = self.get_ad_matches_to_program(filtered_guide_ads_list)
            if guide_header_ad:
                return guide_header_ad
            self.screen.base.press_down()
            self.wait_for_screen_ready(self.guide_labels.LBL_GUIDE_SCREEN)
        raise LookupError("Guide headers are not found in grid guide program list. \n "
                          "Headers: \n {}".format(filtered_guide_ads_list))

    def go_to_last_channel(self, tester):
        channels_list = []
        channels = tester.api.get_channel_search(is_received=None, includeUnavailableChannels=True)
        for channel in channels:
            channels_list.append(channel.channel_number)
        self.log.info("List of all channels: {}".format(channels_list))
        self.enter_channel_number(channels_list[-1])

    def navigate_to_and_get_guide_banner(self, filtered_guide_ads_list):
        """
        Find and navigate to program in guide channel list that will match to guide banner from list
        :param filtered_guide_ads_list: list of banners ads
        :return: guide banner
        """
        self.go_to_bottom_cell_in_guide()
        self.pause(5)
        self.screen.base.press_down()
        for i in range(20):
            self.wait_for_screen_ready(self.guide_labels.LBL_GUIDE_SCREEN)
            self.screen.refresh()
            guide_banner_ad = self.get_ad_matches_to_program(filtered_guide_ads_list)
            if guide_banner_ad:
                return guide_banner_ad
            self.screen.base.press_channel_up()
            self.wait_for_guide_next_page()
        raise LookupError("Guide banners are not found in grid guide program list. \n "
                          "Banners: \n {}".format(filtered_guide_ads_list))

    def get_ad_matches_to_program(self, ads_list):
        """
        method can be used in guide. Search a program that will match to expected ad
        :params: guide ads list
        :return: guide ad that will match to a program
        """
        ad_matching_to_cur_program = None
        cur_program = self.get_program()
        if cur_program and 'text' in cur_program.keys():
            for ad in ads_list:
                if 'details' in ad.keys() and 'caption' in ad['details'].keys():
                    if cur_program['text'] == ad['details']['caption']:
                        ad_matching_to_cur_program = ad
                else:
                    self.log.warning("AD has no 'details' or 'caption' keys:\n {}".format(ad))
        else:
            self.log.warning("get_program() returned no program or program without 'text' key"
                             "Program: {}\n"
                             "Dump:\n {}".format(cur_program, self.screen.screen_dump['xml']))
        return ad_matching_to_cur_program

    def vertical_nav_to_guide_row_by_index(self, row_index, axis):
        """
        method can be used in guide to navigate to row by index
        """
        self.log.info("go to bottom cell in guide")
        focused_index = self.return_focused_guide_row_index()
        self.navigate_by_XY(row_index - focused_index, axis)

    def get_guide_ad_row(self, guide_ad_list):
        """
        method can be used in guide to find an index of row of expected guide_ad
        :return: guide_ad obj and index of row where this ad is
        """
        self.screen.refresh()
        self.wait_for_screen_ready(self.guide_labels.LBL_GUIDE_SCREEN)
        menu_item_list = self.get_menu_item()
        try:
            for index_of_row in range(len(menu_item_list)):
                for guide_ad in guide_ad_list:
                    if 'channelcallsign' in menu_item_list[index_of_row]['grid-row'][0].keys() and \
                            menu_item_list[index_of_row]['grid-row'][0]['channelcallsign'] == guide_ad['details']['caption']:
                        return guide_ad, index_of_row
        except (KeyError, TypeError):
            self.log.info("There is no Key or expected Type in \n"
                          "menu_item_list: {}, guide_ad_list: {}".format(menu_item_list, guide_ad_list))
        return None, None

    def wait_for_header_rendering(self):
        self.log.step("Wait for header rendering")
        self.pause(3)  # hardcod as no event for it

    def wait_and_watch_until_end_of_program(self, tester):
        self.log.info("Verify playback behavior when watched until the end.")
        self.pause(15)
        self.screen.refresh()
        trickplay = self.screen.get_screen_dump_item('trick-play')
        currentTime = self.convert_time_to_sec(trickplay['current-pos'])
        endTime = self.convert_time_to_sec(trickplay['replay-size'])
        wait_time = int(endTime - currentTime) - 20
        if wait_time > 0:
            self.pause(wait_time)
        self.screen.refresh()
        tester.guide_assertions.verify_play_normal()

    def convert_duration(self, time_duration: int):
        """
        if show time duration more than 720 seconds (from 12:00 to 12:59) need to convert
        @param time_duration:
        @return:
        """
        if time_duration > 720:
            self.log.info("Time was {}. Setting back to 0 + minutes in time".format(time_duration))
            time_duration -= 720
        return time_duration

    def wait_and_watch_until_end_of_program_livetv(self, tester):
        """
        Watch LiveTV program duration to the end.
        @param tester:
        @return:
        """
        self.log.info("Verify playback behavior when watched until the end.")
        self.screen.refresh()
        trickplay = self.screen.get_screen_dump_item('trick-play')
        current_time = self.convert_time_to_sec(trickplay['current-position'])
        end_time = self.convert_time_to_sec(trickplay['end-time'])
        # if show end_time or current_time duration more than 720 seconds (from 12:00 to 12:59) need to convert
        current_time = self.convert_duration(current_time)
        end_time = self.convert_duration(end_time)
        # get wait_time in seconds
        wait_time = int(end_time - current_time) * 60
        self.log.info(f"Wait time is {wait_time} seconds.")
        if wait_time > 0:
            self.pause(wait_time)
        self.screen.refresh()
        tester.guide_assertions.verify_play_normal()

    def verify_episode_panel_and_playback_of_upcoming_episode(self, tester):
        self.screen.refresh()
        show = True
        try:
            nextshow = self.screen.get_screen_dump_item('up-next')
            show = True
        except KeyError:
            show = False
        if show:
            self.log.info('Up next show {} displayed in the end of the current program streaming'.format(nextshow))
            self.pause(100)
            tester.guide_assertions.verify_channel_title(tester, nextshow)
            tester.guide_assertions.verify_play_normal()

    def nav_to_show_available_from_OTT(self, tester):
        self.log.step("nav to show available from OTT")
        for i in range(20):
            self.screen.refresh()
            screen_dump = self.screen.screen_dump['xml']
            if 'source-icons' in screen_dump.keys() and 'imagename' in screen_dump['source-icons'].keys():
                for OTT_ICON in tester.home_labels.LBL_WTW_ICON_LIST_OTT:
                    if OTT_ICON in screen_dump['source-icons']['imagename']:
                        return True
            self.menu_navigate_left_right(0, 1)
        return False

    def nav_to_show_not_available_from_OTT(self, tester):
        self.log.step("nav to show not available from OTT")
        for i in range(20):
            self.screen.refresh()
            screen_dump = self.screen.screen_dump['xml']
            if 'source-icons' not in screen_dump.keys() or 'imagename' not in screen_dump['source-icons'].keys():
                return True
            else:
                for OTT_ICON in tester.home_labels.LBL_WTW_ICON_LIST_OTT:
                    if OTT_ICON not in screen_dump['source-icons']['imagename']:
                        return True
            self.menu_navigate_left_right(0, 1)
        return False

    def go_to_recorded_program_in_guide(self, tester, program_name, channel_number, future=False):
        self.log.step("Navgating to program in guide that was scheduled for recording")
        tester.home_page.go_to_guide(tester)
        self.enter_channel_number(channel_number)
        if not future:
            self.log.info("Checking in future guide data")
            self.pause(50)  # extra wait for the show to complete.
            self.menu_navigate_left_right(2, 0)
            focused_item = self.get_focussed_grid_item(tester)
            self.screen.refresh()
            if focused_item == program_name:
                self.log.info(f"Program found: {program_name}")
                return True
            else:
                self.log.info(f"Program not found: {program_name}")
                return False
        else:
            self.log.info("Checking in current guide screen data")
            for i in range(3):
                self.screen.base.press_right()
                focused_item = self.get_focussed_grid_item(tester)
                self.screen.refresh()
                if focused_item == program_name:
                    self.log.info(f"Program found: {program_name}")
                    return True

    def watch_past_scou_program_from_replay_and_myshow(self, tester):
        self.log.step("Playback SOCU offer from recording/myshows")
        self.open_record_overlay()
        if not self.is_overlay_shown():
            self.log.info("Overlay not displayed")
            self.screen.base.long_press_enter()
            self.wait_for_screen_ready()
            self.screen.refresh()
        watchnowfrommyshow = self.guide_labels.LBL_WATCH_NOW_FROM_MY_SHOWS
        menulist = self.menu_list()
        liststr = ' '.join([str(elem) for elem in menulist])
        if not self.is_overlay_shown():
            # check record overlay is shown before navigation if not then there is no sense to continue testing
            mode = overlay_title = ""
            try:
                mode = self.view_mode()
                overlay_title = self.get_overlay_title()
            except KeyError:
                pass
            raise LookupError("Record overlay is not visible. Current mode: {}, overlay:{}".format(mode, overlay_title))
        if watchnowfrommyshow not in liststr:
            self.log.info("Watch now from myshows option is not list")
            self.select_menu(tester.guide_labels.LBL_WATCH_NOW_RECORD_OVERLAY)
            if not self.is_overlay_shown():
                # check playback overlay is shown before navigation if not then there is no sense to continue testing
                mode = overlay_title = ""
                try:
                    mode = self.view_mode()
                    overlay_title = self.get_overlay_title()
                except KeyError:
                    pass
                raise LookupError("Playback overlay is not visible. Current mode: {}, overlay:{}".format(mode, overlay_title))
            self.select_menu(tester.guide_labels.LBL_WATCH_NOW_FROM_MY_SHOWS)
            tester.guide_assertions.verify_play_normal()
        else:
            self.select_menu(tester.guide_labels.LBL_WATCH_NOW_FROM_MY_SHOWS)
            tester.guide_assertions.verify_play_normal()

    def watch_now_from(self, tester, source):
        self.open_record_overlay()
        self.select_menu_by_substring(source)
        if self.is_overlay_shown():
            self.select_menu_by_substring(tester.guide_labels.LBL_STARTOVER)
        else:
            self.log.info("Startover overlay wasn't show. Video is already playing.")

    def navigate_and_verify_socu_icon_on_prediction_bar(self, tester):
        tester.home_page.goto_prediction()
        tester.home_assertions.verify_highlighter_on_prediction_strip()
        self.screen.refresh()
        i = 0
        striplist = self.screen.screen_dump['xml']['stripitem']
        while i <= 10:
            icon = self.guide_labels.LBL_RECORD_OVERLAY_CATCHUP_ICON
            if 'availableOn' in striplist[1].keys():
                image = striplist[1]['availableOn']['imagename']
                if isinstance(image, list):
                    value = ' '.join([str(elem) for elem in image])
                else:
                    value = striplist[1]['availableOn']['imagename']
                if 'hasfocus' in striplist[1] and icon in value:
                    self.log.info("Socu icon available in prediction bar")
                    break
            self.screen.base.press_right()
            self.pause(3)
            self.screen.refresh()
            striplist = self.screen.screen_dump['xml']['stripitem']
            i += 1
        return

    def launch_action_screen_using_GA(self, collectionId):
        self.log.step("Launching program screen using GA")
        self.launch_program_screen_using_GA(collectionId)

    def start_live_playback_from_action_screen(self, tester):
        self.log.step("Starting Live Playback")
        self.nav_to_menu(tester.vod_labels.LBL_WATCH_NOW)
        self.select_strip(tester.home_labels.LBL_LIVE_TV)

    def start_live_tv_playback(self, tester):
        """
        Start LiveTV playback from already highlighted program
        """
        self.screen.base.press_enter()
        self.wait_for_screen_ready(tester.liveTv_labels.LBL_LIVETV_SCREEN)

    def get_trickplay_current_position_in_sec(self, refresh=True):
        self.log.info("To get the trickplay current position in seconds")
        if refresh:
            self.screen.refresh()
        trickplay = self.screen.get_screen_dump_item('trick-play')
        current_time = self.convert_time_to_sec(trickplay['current-pos'])
        return current_time

    def add_channel_to_favorites(self, channel):
        self.log.step(f"Adding '{channel}' to favorite channels.")
        self.enter_channel_number(channel)
        self.press_left_button()
        self.press_ok_button()
        self.select_menu(self.guide_labels.LBL_ADD_TO_FAVORITE_CHANNELS)
        self.wait_for_screen_ready()
        self.press_right_button()

    def launch_app_from_guide(self, number):
        self.log.step(f"Launching '{number}'channels.")
        self.enter_channel_number(number)
        self.wait_for_screen_ready()
        channel_tab = self.get_to_channel_tab(self, move_to_channel_tab=True)
        self.validate_channel_tab(self, channel_tab)
        self.press_ok_button()
        self.select_menu(self.guide_labels.LBL_LAUNCH_APP)

    def remove_channel_from_favorites(self, tester, channel):
        self.log.step(f"removing '{channel}' from favorite channels.")
        self.enter_channel_number(channel)
        self.press_left_button()
        self.press_ok_button()
        if self.is_in_menu(tester.watchvideo_labels.LBL_REMOVE_FROM_FAVORITE_CHANNELS):
            self.select_menu(tester.watchvideo_labels.LBL_REMOVE_FROM_FAVORITE_CHANNELS)
        else:
            # do nothing
            self.screen.base.press_back()
        self.wait_for_screen_ready()
        self.press_right_button()

    def return_channel_bits_of_channels(self, channellist):
        """
        Method to get the channebits for responding channel in dict format:
        :param channellist : list of channels
        :return: dict with key as channel number and value as corresponding channelbits
        """
        db = "/db/NpkDb.sqlite"
        channelbitsdict = {}
        for channelnumber in channellist:
            query = f"select channelbits from cschannel where majornumber = {channelnumber} and channelsourceid = '6';"
            channelbits = self.screen.base.driver.sqlite_query(db, query)
            if channelbits is None:
                self.log.warning(f"Channelbits for {channelnumber} channel was not found ")
            else:
                channelbitsdict.update({channelnumber: channelbits[0]})
        self.log.info(f"channelnumber with corresponding channelbits {channelbitsdict}")
        return channelbitsdict

    def return_ip_preferred_channels(self, channelbitsdict):
        """
         Method to get the list of channels that preferred IP:
              * 29th bit denotes the preference
              * 29th bit = 1 then IP preference
         :param: dict with channelnumber as key and channelbits as value
         :return: channel list which prefered IP
         """
        ippreferred_channellist = []
        for channelnumber, channelbits in channelbitsdict.items():
            channelbits = str(bin(int(channelbits)).replace("0b", ""))
            if (len(channelbits) >= 29) and (channelbits[len(channelbits) - 29] == '1'):
                ippreferred_channellist.append(int(channelnumber))
        if not ippreferred_channellist:
            self.log.info("No channels with IP preference")
            return ippreferred_channellist
        else:
            self.log.info(f"Channel list with IP preference {ippreferred_channellist}")
            return ippreferred_channellist

    def return_qam_preferred_channels(self, channelbitsdict):
        """
         Method to get the list of channels that preferred QAM:
              * 29th bit denotes the preference
              * 29th bit = 0 then QAM preference
         :param: dict with channelnumber as key and channelbits as value
         :return: channel list which preferenced QAM
         """
        qampreferred_channellist = []
        for channelnumber, channelbits in channelbitsdict.items():
            channelbits = str(bin(int(channelbits)).replace("0b", ""))
            if (len(channelbits) >= 29) and (channelbits[len(channelbits) - 29] == '0'):
                qampreferred_channellist.append(int(channelnumber))
        if not qampreferred_channellist:
            self.log.info("No channels with QAM preference")
            return qampreferred_channellist
        else:
            self.log.info(f"Channel list with QAM preference {qampreferred_channellist}")
            return qampreferred_channellist

    def return_channel_with_no_preference(self, channelbitsdict):
        """
         Method to get the list of channels that preferred None:
              * if the channelbits lenght is less then 29 then None
         :param: dict with channelnumber as key and channelbits as value
         :return: channel list which preferenced None
         """
        no_preference_channellist = []
        for channelnumber, channelbits in channelbitsdict.items():
            channelbits = str(bin(int(channelbits)).replace("0b", ""))
            if (len(channelbits) < 29):
                no_preference_channellist.append(int(channelnumber))
        if not no_preference_channellist:
            self.log.info("No channels with none preference")
            return no_preference_channellist
        else:
            self.log.info(f"Channel list with none preference {no_preference_channellist}")
            return no_preference_channellist

    def return_channel_with_same_stationid_lcn(self):
        """
          Method to get the list of channels which has same station id and same LCN
          :param: None
          :return: List of channels
          """
        db = "/db/NpkDb.sqlite"
        query = "SELECT majornumber FROM cschannel where majornumber IN \
        (select majorNumber from CsChannel group by majorNumber HAVING COUNT(majorNumber) > 2) \
        GROUP BY majornumber, stationid HAVING COUNT(*) > 1;"
        channellist = self.screen.base.driver.sqlite_query(db, query)
        if channellist is None:
            self.log.info("No channel with same station id and LCN")
            return channellist
        else:
            self.log.info(f"Channel list with with same station id and lcn {channellist}")
            return channellist

    def check_for_overlay_watchnow_or_watchlive(self):
        if self.is_overlay_shown():
            self.screen.refresh()
            menu = self.screen.get_screen_dump_item('menuitem')
            if menu[0].get('text') == self.guide_labels.LBL_CHANNEL_OPTIONS_WATCH_NOW:
                self.select_menu_by_substring(self.guide_labels.LBL_CHANNEL_OPTIONS_WATCH_NOW)
            elif menu[0].get('text') == self.guide_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE:
                self.select_menu_by_substring(self.guide_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE)

    def is_message_shown_on_record_overlay(self, message):
        """
        If a message is shown on the Record overlay
        e.g. "This show is not available to record" or "Unable to get purchase info for this PPV show"
        These messages are located above the options and below the show info

        Args:
            message (str): IPPPV message on the Record overlay

        Retunrs:
            bool
        """
        self.log.info("Is message shown on the Record overlay")
        is_present = False
        rec_overlay_message = None
        try:
            rec_overlay_message = self.screen.get_screen_dump_item('overlaynonrecordable', 'text')
        except Exception:
            pass
        if type(rec_overlay_message) is str:
            if message in rec_overlay_message:
                is_present = True
        elif type(rec_overlay_message) is list:
            for item in rec_overlay_message:
                if message in item:
                    is_present = True
                    break
        return is_present

    def is_ipppv_option_shown_in_record_overlay(self, option_label):
        """
        If an IPPPV option is shown on the Record overlay

        Args:
            option_label (str): IPPPV option label

        Returns:
            bool
        """
        self.log.info("Is IPPPV option shown in the Record overlay")
        is_found = False
        menu_list = self.menu_list()
        for item in menu_list:
            if option_label in item:
                is_found = True
                break
        return is_found

    def open_record_overlay_for_future_show(self, record_overaly_name_in_dump):
        """
        Opening the Record overlay for a future show
        In Progress or Future Guide should be dispalayed

        Args:
            record_overaly_name_in_dump (str): Record Overlay's system name in screen dump
        """
        self.log.info("Opening Record overlay in the Future Guide")
        self.screen.base.press_right()
        self.screen.base.press_enter()
        self.wait_for_screen_ready(record_overaly_name_in_dump, 5000)
        self.verify_overlay_shown()

    def get_catchup_startover_text(self, tester):
        value = tester.api.get_catchup_and_startover_name()
        if value is None:
            value = tester.api.get_catchup_and_startover_name_partnerInfoSearch()
        if value is not None:
            self.log.info("Getting startover and catchup name from service API")
            start_over = tester.menu_labels.LBL_STRING_CATCHUP_STARTOVER_NOW + "{}".format(value[1])
            catch_up = tester.menu_labels.LBL_STRING_CATCHUP_STARTOVER_NOW + "{}".format(value[0])
        else:
            self.log.info("Getting startover and catchup name from default labels")
            start_over = tester.menu_labels.LBL_DEFAULT_WATCH_NOW_FROM_STARTOVER
            catch_up = tester.menu_labels.LBL_DEFAULT_WATCH_NOW_FROM_CATCHUP
        return (catch_up, start_over)

    def check_playback_on_device(self, tester, channel_num, tplus=False):
        self.screen.refresh()
        mode = self.view_mode() != tester.liveTv_labels.LBL_LIVETV_VIEWMODE
        if mode:
            tester.home_page.go_to_guide(tester)
        self.enter_channel_number(channel_num)
        if mode and not tplus:
            self.get_live_program_name(tester)
            self.select_and_watch_program(tester)
        if tplus:
            if mode:
                self.get_live_program_name(tester)
                self.wait_for_screen_ready()
                self.press_ok_button(refresh=False)
            if tester.watchvideo_page.is_tivo_plus_eula_overlay_shown():
                self.wait_for_screen_ready("TiVoPlusAcceptanceOverlay")
                tester.watchvideo_assertions.verify_tivo_plus_eula_overlay_is_shown()
                self.select_menu_by_substring(tester.liveTv_labels.LBL_ACCEPT)
                tester.watchvideo_assertions.verify_tivo_plus_eula_osd_is_not_shown()
        return self.get_playback_status_and_result(tester, channel_num, tplus=tplus)

    def get_playback_status_and_result(self, tester, channel_num, tplus=False):
        status = None
        result = None
        osd = None
        status, overlay = self.check_content_playback(tester, tplus=tplus)
        if status:
            self.log.info(f"channel {channel_num}:{status}. checking playback for 30 secs")
            self.pause(30)
            self.screen.refresh()
            if self.is_overlay_shown():
                self.log.info("Overlay displayed")
                overlay = True
                return self.get_error_overlay_details(overlay)
            try:
                osd = self.osd_text()
                if osd is not None:
                    self.log.info("Stuck in OSD: {}".format(osd))
                    status = False
                    return status, osd
            except Exception:
                self.log.info("Playback successful")
            self.log.info(f"Overlay was not observed, Channel - {channel_num} is streaming without any issues")
            return status, result
        else:
            self.log.info("Failed to playback the content")
            return self.get_error_overlay_details(overlay)

    def playback_status_check_on_device(self, tester, clist, url_check=True, tplus=False):
        if url_check:
            url, state = self.health_api.live_tv_url_health_check(clist)
        else:
            url = None
            state = 'OK'
        self.log.step(f"channel details being tested: {clist}")
        if 'OK' in state:
            if clist[3]:
                status, result = self.check_playback_on_device(tester, clist[0], tplus=tplus)
            return status, result, state, url
        else:
            self.log.error(f"Looks like the channel tuning url has some issue: {state}")
            result = state + " URL Issue"
            return False, result, state, url

    def tune_to_tivo_plus_channel(self, tester, channel=None):
        """
        Tunes to TiVo+ channel from Guide screen and accepts user agreement if user agreement overlay is shown
        """
        if channel:
            self.enter_channel_number(channel, confirm=True)
        self.press_ok_button()
        self.pause(2)
        if tester.home_page.verify_onscreen_trickplay_overlay():
            self.press_ok_button()
        if tester.watchvideo_page.is_tivo_plus_eula_overlay_shown():
            self.select_menu(tester.liveTv_labels.LBL_ACCEPT)

    def get_streamable_adult_content(self, tester):
        """
        Will get the list of streamable adult channels
        """
        streamable_channel_list = []
        streamable_channel_details = tester.api.get_restrictedcapability_channels_details(Settings.tsn,
                                                                                          channel_payload_count=100)
        if not streamable_channel_details:
            pytest.skip("could not find streamable channel list")
        for channel in streamable_channel_details:
            streamable_channel_list.append(channel['number'])
        self.log.info("streamable_channel_list: {}".format(streamable_channel_list))
        adult_channel = tester.api.get_live_adult_channels()
        self.log.info("adult channels: {}".format(adult_channel))
        streamable_adult_channel_list = list(set(adult_channel) & set(streamable_channel_list))
        return streamable_adult_channel_list

    def get_streamable_rating_content(self, tester):
        """
        Will get the list of streamable rating channels
        """
        streamable_channel_list = []
        streamable_channel_details = tester.api.get_restrictedcapability_channels_details(Settings.tsn,
                                                                                          filter_channel=True)
        if not streamable_channel_details:
            pytest.skip("could not find streamable channel list")
        for channel in streamable_channel_details:
            streamable_channel_list.append(channel['number'])
        self.log.info("streamable_channel_list: {}".format(streamable_channel_list))
        rating_channels = tester.api.get_live_tv_rating_channels()
        self.log.info("rating channels: {}".format(rating_channels))
        streamable_rating_channel_list = list(set(rating_channels) & set(streamable_channel_list))
        self.log.info("streamable rating channels: {}".format(streamable_rating_channel_list))
        return streamable_rating_channel_list

    def start_socu_playback(self, tester, channel_num, st=False, cu=False, vt=False):
        self.log.step("Checking SOCU playback of channel: {}".format(channel_num))
        self.log.info("StartOver enabled/disabled: {}".format(st))
        self.log.info("Catchup enabled/disabled: {}".format(cu))
        st_program = None
        cu_program = None
        st_result = None
        cu_result = None
        st_status = None
        cu_status = None
        tester.home_page.go_to_guide(tester)
        self.enter_channel_number(channel_num)
        if st:
            st_program = self.get_live_program_name(tester)
            tester.guide_assertions.press_select_verify_record_overlay(tester, long_press=True)
            tester.guide_assertions.press_select_verify_watch_screen(tester, st_program, playback_check=False)
            st_status, st_result = self.get_playback_status_and_result(tester, channel_num)
            if vt:
                tester.vision_page.verify_av_playback(status=st_status, result=st_result)
        else:
            self.log.info("Startover is not enabled on device for channel: {}".format(channel_num))
            st_status = "Startover Disabled"
            st_result = "Startover Disabled"
        if cu:
            tester.home_page.go_to_guide(tester)
            self.enter_channel_number(channel_num)
            self.wait_for_screen_ready()
            self.menu_navigate_left_right(3, 0)
            self.wait_for_screen_ready()
            cu_program = self.get_focussed_grid_item(tester)
            tester.guide_assertions.press_select_verify_record_overlay(tester, inprogress=False)
            tester.guide_assertions.press_select_verify_watch_screen(tester, cu_program, playback_check=False)
            cu_status, cu_result = self.get_playback_status_and_result(tester, channel_num)
            if vt:
                tester.vision_page.verify_av_playback(status=cu_status, result=cu_result)
        else:
            self.log.info("CatchUp is not enabled on device for channel: {}".format(channel_num))
            cu_status = "CatchUp Disabled"
            cu_result = "CatchUp Disabled"
        self.log.info("SOCU playback status: {} {} {} {} {} {}".format(st_program, st_status, st_result, cu_program,
                                                                       cu_status, cu_result))
        return st_program, st_status, st_result, cu_program, cu_status, cu_result

    def get_error_overlay_details(self, overlay=False):
        status = False
        if overlay:
            dump = self.screen.get_screen_dump_item()
            result = dump['overlayTitleText'] + ' - ' + dump['overlayTitle']
            self.log.info(f"result: {result}")
            self.screen.base.press_enter()
            self.wait_for_screen_ready()
            return status, result
        else:
            result = "AV is not yet loaded. Trickplay replay-size is 0"
            return status, result

    def get_encrypted_socu_channel(self, tester, filter_socu=False):
        """
        Get encrypted socu channel from guide
        """
        encrypted_channel = []
        channel = tester.service_api.get_random_encrypted_unencrypted_channels(Settings.tsn, socu=True,
                                                                               encrypted=True, filter_channel=True)
        socu_channels = self.get_all_socu_channels_from_guide(tester)
        socu_ch = [channel.get('channel_number') for channel in socu_channels]
        if filter_socu:
            good_channels = tester.api.filter_channels(socu_ch, socu_ch, filter_socu=True)
            if len(good_channels) > 0:
                self.log.info("Working SOCU encryped channels available: {}".format(good_channels))
                socu_ch = good_channels
        for c in channel:
            if c[0] in socu_ch:
                self.log.info("Encrypted socu channel found")
                encrypted_channel.append(c)
        if len(encrypted_channel) <= 0:
            pytest.skip("Device doesnot have any encrypted socu channel")
        return encrypted_channel

    def get_channellogo_from_guide(self, tester, refresh=False):
        if refresh:
            self.screen.refresh()
        grid_details = self.get_grid_focus_details()
        channel_logo = grid_details['channel_logo']
        return channel_logo

    def get_channelname_from_guide(self, tester, refresh=False):
        if refresh:
            self.screen.refresh()
        channel_name_detail = self.screen.get_screen_dump_item('description')['text']
        if channel_name_detail.isalpha():
            channel_name = channel_name_detail
        else:
            for char in channel_name_detail:
                if char.isalpha():
                    continue
                else:
                    index = channel_name_detail.index(char)
                    channel_name = channel_name_detail[:index]
                    break
        return channel_name

    def get_channels_list_mode(self):
        self.screen.refresh()
        result = str(self.screen.get_screen_dump_item('tiptext'))
        mode = ''
        if self.guide_labels.LBL_FAVORITE_CHANNELS_TIP_TEXT in result:
            mode = self.guide_labels.LBL_FAVORITE_CHANNELS_TIP_TEXT
        elif self.guide_labels.LBL_ALL_CHANNELS_TIP_TEXT in result:
            mode = self.guide_labels.LBL_ALL_CHANNELS_TIP_TEXT
        if not mode:
            raise LookupError('Unable to get channel list mode.')
        else:
            return mode

    def get_screen_title(self, refresh=False):
        if refresh:
            self.screen.refresh()
        screentitle = self.screen.get_screen_dump_item("screentitle")
        return screentitle

    def get_channel_logo_status(self, tester):
        self.log.info("Going to guide")
        tester.home_page.go_to_guide(tester)
        self.wait_for_screen_ready(screen_name="GuideListModel")
        self.log.info("Looking for channel logo")
        self.screen.refresh()
        channel_details = self.get_grid_focus_details()
        if channel_details['channel_logo'] is None:
            self.log.info(
                "Channel logo is absent for channel №"
                f"{channel_details['channel_number']} {channel_details['channel_name']}")
            return False
        else:
            self.log.info(
                "Channel logo is displayed for channel №"
                f"{channel_details['channel_number']} {channel_details['channel_name']}")
            return True

    def get_channel_call_sign(self):
        channel_name = None
        self.screen.refresh()
        screendump = self.screen.get_screen_dump_item('menuitem')
        row_focus = self.return_guide_row_focus(screendump)
        self.log.step("Dump is {}".format(screendump))
        self.log.step("focus {}".format(row_focus))
        for item in row_focus:
            if 'channelcallsign' in item.keys():
                channel_name = item['channelcallsign']
        self.log.step("Channel name is {}".format(channel_name))
        return channel_name

    def find_focussed_and_required_text_index_in_strip(self, strip_list, expected="VIEW ALL"):
        left = None
        text_index = None
        focus_index = None
        index_diff = None
        if strip_list is None:
            self.screen.refresh()
            strip_list = self.get_strip_array()
        for item in strip_list:
            if item is not None:
                if item.get('text') is not None and expected in item.get('text'):
                    text_index = strip_list.index(item)
                    self.log.info("text_index: {}".format(text_index))
                if item.get('hasfocus') is not None and item.get('hasfocus') == 'true':
                    focus_index = strip_list.index(item)
                    self.log.info("focus_index: {}".format(focus_index))
        if text_index is None:
            self.log.info("{} is not available in {}".format(expected, strip_list))
            text_index = 0
            left = True
        if text_index < focus_index:
            index_diff = focus_index - text_index
            left = True
        elif text_index > focus_index:
            index_diff = text_index - focus_index
        elif text_index == focus_index:
            self.log.info("Focus is already on {}".format(expected))
            index_diff = 0
        self.log.info("index_diff: {}, left: {}".format(index_diff, left))
        return text_index, index_diff, left

    def highlight_first_cell(self):
        self.wait_for_guide_next_page()
        guide = self.return_guide()
        row_focus = self.return_guide_row_focus(guide)
        tab_focus = self.get_focused_guide_row_tab(guide)
        selected_tab_index = row_focus.index(tab_focus)
        self.menu_navigate_left_right(selected_tab_index, 1)

    def wait_for_24_hours(self):
        self.log.info("Waiting for 24 hours")
        self.pause(24 * 60 * 60)

    def get_upcoming_episode(self, tester):
        self.log.step("Navigating to Upcoming episodes in series screen")
        self.screen.base.press_enter()
        self.wait_for_screen_ready()
        self.screen.refresh()
        self.menu_navigate_left_right(1, 0)
        self.pause(2)
        self.screen.refresh()
        content = tester.my_shows_page.get_menu_item_for_upcoming_program(tester)
        self.select_menu(content)
        self.menu_navigate_left_right(0, 1)
        self.screen.refresh()
        menulist = self.get_menu_item()
        for show in menulist:
            self.screen.refresh()
            icon = tester.my_shows_labels.LBL_LIVE_ICON
            if icon in show['imagename']:
                self.screen.base.press_down()
                self.screen.refresh()
            else:
                self.log.info(f"Next Show is {show}")
                break
        return show['text']

    def get_show_time(self):
        show_time = (self.screen.get_screen_dump_item()['show-time'])
        showtime = re.findall(r"(\d{1,2}\:\d+\S)(am|pm)+", show_time)
        self.log.info(f"Show time is {showtime}")
        return showtime

    def get_next_show_time_in_mins(self, showtime):
        showtime_end_to_mins = self.convert_time_to_sec(showtime[1][0])
        self.log.info(f"showtime_end_to_mins {showtime_end_to_mins} and showtime {showtime[1][0]}")
        return showtime_end_to_mins

    def get_current_time_in_mins(self):
        dumptime = self.screen.get_screen_dump_item('timeinfo')
        self.log.info(f"dump time is {dumptime}")
        guidetime = dumptime.strip(self.STRIP_AM_PM_FROM_TIME)
        self.log.info(f"guidetime is {guidetime}")
        guidetime_to_mins = self.convert_time_to_sec(guidetime)
        self.log.info(f"guidetime_to_mins is {guidetime_to_mins}")
        return dumptime, guidetime, guidetime_to_mins

    def _update_guide_and_show_time(self, guidetime, guidetime_to_mins, showtime_end_to_mins):
        if guidetime_to_mins >= 720:
            if showtime_end_to_mins >= 720:
                showtime_end_to_mins = showtime_end_to_mins - 720 if showtime_end_to_mins > guidetime_to_mins \
                    else showtime_end_to_mins % 12
            self.log.info("Time was {}. Setting back to 0 + minutes in time".format(guidetime))
            guidetime_to_mins = guidetime_to_mins - 720
            self.log.info("guide time & show endtime after setting back {}-{}"
                          "".format(guidetime_to_mins, showtime_end_to_mins))
        return guidetime, guidetime_to_mins, showtime_end_to_mins

    def calculate_diff_and_wait_for_show_to_finish(self, showtime, guidetime, guidetime_to_mins,
                                                   showtime_end_to_mins, time_pm_am, **kwargs):
        """
        Calculating diff and waiting for current show to finish
        """
        self.log.info("Calculating diff and waiting for current show to finish")
        max_diff = kwargs.get('max_diff', 5)
        right_press = kwargs.get('right', True)
        if not showtime[1][1] == time_pm_am[0][1]:
            self.log.info("Time transition from {} to {}. adding 720 mins".format(showtime[1][1], time_pm_am[0][1]))
            # if there is time transition between am-pm/pm-am then adds 720 mins to show end time.
            showtime_end_to_mins += 720
        self.log.info(f"showtime_end_to_mins after transition {showtime_end_to_mins}")
        guidetime, guidetime_to_mins, showtime_end_to_mins = \
            self._update_guide_and_show_time(guidetime, guidetime_to_mins, showtime_end_to_mins)
        if showtime_end_to_mins >= guidetime_to_mins:
            diff_time = showtime_end_to_mins - guidetime_to_mins
            self.log.info("Diff between Showtime and Current time is {}".format(diff_time))
            if diff_time <= max_diff:
                self.log.info("Sleeping as either the program is ending in another {} min".format(diff_time))
                self.pause(diff_time * 60)
                if right_press:
                    self.screen.base.press_right()
            else:
                if showtime_end_to_mins >= 720:
                    time_to_wait = showtime_end_to_mins - 720 - guidetime_to_mins
                    self.log.info(f"showtime_end_to_mins == 720 and time_to_wait {time_to_wait}")
                    self.pause(time_to_wait * 60)
                else:
                    self.log.info("In the else block Diff between Showtime and Current time is {}".format(diff_time))
                    self.pause(diff_time * 60)

    def wait_for_current_show_to_finish(self):
        """
        Make sure script is on live tv
        """
        self.screen.refresh()
        showtime = self.get_show_time()
        dumptime, guidetime, guidetime_to_mins = self.get_current_time_in_mins()
        showtime_end_to_mins = self.get_next_show_time_in_mins(showtime)
        time_pm_am = re.findall(r"(\d{1,2}\:\d+\S)(am|pm)+", dumptime)
        self.log.info("guide time info breakdown: {}".format(time_pm_am))
        self.calculate_diff_and_wait_for_show_to_finish(showtime, guidetime, guidetime_to_mins, showtime_end_to_mins,
                                                        time_pm_am)

    def get_current_date_and_time(self):
        starttime = (self.screen.get_screen_dump_item()['start-time'])
        self.log.info(f"Start time is at {starttime}")
        current_time = re.findall(r"(\d+/\d+/\d+) (\d{1,2}\:\d+\S)(am|pm)+", starttime)
        self.log.info(f"current_time before {current_time}")
        modified_current_time = current_time[0][1] + current_time[0][2]
        self.log.info(f"modified_current_time after modification {modified_current_time}")
        current_date = re.findall(r'(\d+/\d+){1,2}', starttime)
        self.log.info(f"current_date before {current_date}")
        modified_current_date = current_date[0]
        self.log.info(f"modified_current_date after modification {modified_current_date}")
        return modified_current_date, modified_current_time

    def wait_for_upcoming_episode_to_air(self, tester, program, date, start_time, channel_number):
        self.log.step(f"waiting for next episode of {program} which is on {date} {start_time} on {channel_number}")
        while True:
            tester.home_page.goto_live_tv(channel_number)
            tester.home_page.wait_for_screen_ready()
            tester.watchvideo_assertions.verify_view_mode(tester.liveTv_labels.LBL_LIVETV_VIEWMODE)
            tester.watchvideo_page.wait_for_LiveTVPlayback(status="PLAYING")
            self.screen.refresh()
            self.wait_for_current_show_to_finish()
            tester.home_page.goto_live_tv(channel_number)
            tester.home_page.wait_for_screen_ready()
            tester.watchvideo_assertions.verify_view_mode(tester.liveTv_labels.LBL_LIVETV_VIEWMODE)
            tester.watchvideo_page.wait_for_LiveTVPlayback(status="PLAYING")
            self.screen.refresh()
            current_date, current_time = self.get_current_date_and_time()
            self.log.info(f"In short {current_time} {start_time} and {current_date} {date}")
            if current_date == date and current_time == start_time:
                break
            elif current_date > date:
                break

    def channel_tab_focus_check(self):
        self.log.info("Verify that the channel cell is highlighted")
        status = False
        guide = self.return_guide()
        tab_focus = self.get_focused_guide_row_tab(guide_row_xml_part=guide)
        if 'channelnumber' in tab_focus and 'hasfocus' in tab_focus:
            status = tab_focus.get('channelnumber')
        return status

    def press_up_down_and_verify_guide_data(self, tester, up=False, down=False):
        self.log.step("Verifying guide data")
        if up:
            tester.watchvideo_page.press_up_multiple_times(no_of_times=4)
            self.wait_for_screen_ready("GuideListModel")
        if down:
            tester.watchvideo_page.press_down_multiple_times(no_of_times=4)
            self.wait_for_screen_ready("GuideListModel")
        holes1 = tester.guide_assertions.detect_holes_in_guide(tester)
        self.log.step("press up down holes {}".format(holes1))
        return holes1

    def verify_past_future_guide_data(self, tester, future=False, past=False, days=1):
        self.log.step("Verifying future/past guide data")
        number_of_days = []
        days += 1
        holes2 = 0
        while True:
            self.screen.refresh()
            screen_dump = self.screen.get_screen_dump_item()
            day_with_date = screen_dump['date'].get('text', None)
            if day_with_date is None:
                raise AssertionError("Day and date is not available.")
            if day_with_date not in number_of_days:
                number_of_days.append(day_with_date)
            if past:
                tester.watchvideo_page.press_left_multiple_times(no_of_times=6)
                self.wait_for_screen_ready("GuideListModel")
            if future:
                tester.watchvideo_page.press_right_multiple_times(no_of_times=5)
                self.wait_for_screen_ready("GuideListModel")
            holes = tester.guide_assertions.detect_holes_in_guide(tester)
            holes2 += holes
            if len(number_of_days) >= days:
                break
        self.log.step("Total holes found {}".format(holes2))
        return holes2

    def get_epgLookBackHours(self, tester):
        self.log.info("Getting pin from branding ui")
        branding_value = {}
        try:
            branding_value = tester.api.branding_ui()
        except Exception:
            self.log.info("Error retrieving epgLookBackHours from branding ui")
        if branding_value.epg_hours:
            # get password published in branding bundle
            Epg_Past_Number_of_Hours = branding_value.epg_hours
        else:
            # Past EPG Days will be 3 i.e 72 hours by default if we have not published it in branding bundle
            Epg_Past_Number_of_Hours = self.guide_labels.LBL_EPG_PAST_NUMBER_OF_HOURS
        Epg_Past_Number_of_Days = int(Epg_Past_Number_of_Hours // 24)
        return Epg_Past_Number_of_Days

    def check_if_series(self):
        screen_dump = self.screen.get_screen_dump_item('description')
        text = screen_dump['text']
        self.log.info("text is {}".format(text))
        if text[0] != "S":
            final_text = None
        else:
            final_text = text
        self.log.info("Final text {}".format(final_text))
        return final_text

    def get_jump_channel_number(self, channels=None, app=None):
        for key, value in channels.items():
            if app.lower() == value.lower():
                return key
        return None

    def launch_netflix_from_guide(self, tester):
        self.log.info("Launching netflix from guide")
        self.nav_to_menu(tester.watchvideo_labels.LBL_WATCH_NOW)
        self.screen.base.long_press_enter()
        tester.guide_assertions.verify_record_overlay(tester)
        self.screen.refresh()
        self.select_menu(tester.menu_labels.LBL_NETFLIX)
        self.press_ok_button()

    def timestamp_test_start(self):
        timestamp_start = datetime.datetime.utcnow().timestamp()
        self.log.debug("timestamp_start is {}".format(timestamp_start))
        Settings.test_window_start = timestamp_start * 1000

    def timestamp_test_end(self):
        timestamp_end = datetime.datetime.utcnow().timestamp()
        self.log.debug("timestamp_end is {}".format(timestamp_end))
        Settings.test_window_end = timestamp_end * 1000

    def get_channel_format(self):
        self.screen.refresh()
        screendump = self.screen.get_screen_dump_item('menuitem')
        row_focus = self.return_guide_row_focus(screendump)
        self.log.debug("Dump is {}, focus {}".format(screendump, row_focus))
        for item in row_focus:
            if 'formaticon' in item.keys():
                channel_format_icon = item['formaticon']
        self.log.info("Channel name is {}".format(channel_format_icon))
        return channel_format_icon

    def get_image_detail_from_branding_bundle_response(self, item=None, item_value=None):
        image_name = []
        value = self.service_api.branding_ui()
        if not value:
            pytest.skip("Failed to get Ui branding bundle response: {}".format(value))
        if 'image' in value.dict_item and item and item_value:
            for image in value.branding_image:
                if item in image and item_value in image[item]:
                    image_name.append(image[item])
            if not image_name:
                pytest.skip("{} not found in list :{}".format(item, value.branding_image))
            self.log.info("image name found: {}".format(image_name))
            return image_name
        self.log.info("No item or item_value not found or not defined. returning complete response")
        return value

    def check_cell_recordable_or_not(self):
        """
        check if the cell highlighted is recordable or not
        """
        recordable = True
        if self.view_mode() == self.guide_labels.LBL_VIEW_MODE:
            row_dump = self.return_guide()
            image_list = self.get_images_in_focused_guide_row_cell(row_dump)
            if image_list:
                for image in image_list:
                    if self.guide_labels.LBL_NON_RECORDABLE_CELL_ICON in image:
                        recordable = False
                        break
            else:
                self.log.info("Focused row did not have any images: {}".format(image_list))
        return recordable

    def get_focussed_channel_number_in_grid(self, grid_details):
        """
        returns channel number having focus
        """
        self.log.info(f"Getting focused channel number in grid; grid_details = {grid_details}")
        in_focus_channel = None
        if grid_details:
            for item in grid_details:
                # If a guide cell (item) is not highlighted and is too short to show any icon or text,
                # it becomes None in the screen dump. Knowing that, we can just skip it.
                if item and item.get('hasfocus'):
                    in_focus_channel = grid_details[0].get('channelnumber')
                    break
        return in_focus_channel

    def get_webkit_group_name(self, name, group_names):
        grp_list = []
        for grp in group_names:
            if name.lower() in grp.get('groupName').lower():
                grp_list.append(grp.get('groupName'))
        if len(grp_list) > 1:
            webkit_list = [grp for grp in grp_list if 'webkit' in grp][0]
            self.log.info(f"Webkit name after filter: {webkit_list}")
            return webkit_list
        return grp_list[0]

    def check_package(self, exp_package=Settings.PLUTO_TV_PACKAGE_NAME):
        """
        return package_match status
        """
        status = True
        package = None
        package = self.screen.base.get_foreground_package()
        if package != exp_package:
            self.log.error("Package expected: {} but was Actual: {}".format(exp_package, package))
            status = False
        return status, package

    def add_random_channel_to_favorite(self, tester, count=1):
        """
        Adds some random channel to favorites
        """
        tester.home_page.back_to_home_short()
        tester.menu_page.go_to_user_preferences(tester)
        tester.menu_page.select_menu_items(tester.guide_labels.LBL_FAVORITE_CHANNELS)
        for x in range(count):
            # count is num of channels to be added
            index = tester.menu_page.find_first_unchecked(tester.menu_labels.LBL_UNCHECKED)
            if index >= 0:
                tester.menu_page.menu_navigate_up_down(0, index)
                tester.menu_page.select_item()

    def get_fav_channels(self, tester):
        """
        Gets all the channels marked as favorite
        """
        fav_list = []
        checked = tester.guide_labels.LBL_CHECKED
        tester.menu_page.go_to_user_preferences(tester)
        tester.menu_page.go_to_favorite_channels()
        self.screen.refresh()
        menu = (self.screen.get_screen_dump_item('menuitem'))
        for item in menu:
            if (checked in item['imagename']) or (checked in item['imagename'][0]):
                fav_list.append(item['text'][0])
        return fav_list

    def remove_all_fav_channels_thro_ui(self, tester, fav_list):
        """
        Removes all channels from Favorites
        params: Total Channel numbers in list to be removed from Favorite
        """
        tester.home_page.go_to_guide(tester)
        tester.guide_page.wait_for_screen_ready()
        tester.guide_assertions.verify_guide_screen(tester)
        tester.guide_page.switch_channel_option(tester.guide_labels.LBL_FAVORITES_OPTION)
        for no_of_ch in range(len(fav_list)):
            self.select_remove_from_fav(tester)

    def select_remove_from_fav(self, tester):
        """
        Use only when in Fav screen and channel cell highlighted
        Navigates and selects remove from fav channel
        """
        self.log.step("Navigating and selecting remove from Favorites")
        self.wait_for_screen_ready()
        self.select_item()
        self.wait_for_screen_ready(tester.guide_labels.LBL_CHANNEL_OPT_OVERLAY)
        self.screen.refresh()
        self.nav_to_menu(tester.watchvideo_labels.LBL_REMOVE_FROM_FAVORITE_CHANNELS)
        self.wait_for_screen_ready()
        self.select_item()

    def get_first_aired_or_genre_from_combined_str(self, string, mode="first_aired"):
        """
        Gettng separate value for First Aired or Genre from string with combined value.
        Applicable to Guide Header preview, Record Overlay preview.

        Args:
            string (str): Cartoon, First aired: 10/16/2021 (in Guide Header preview);
                          Spanish. First aired: 4/4/2022 (in Record Overlay preview)
            mode (str): one of (first_aired, genre)

        Returns:
            str, First aired date
        """
        # Separator between genres and first aired date in Guide Header preview is a ',';
        # for Record Overlay preview: '.'
        if string and string.find(".") > 0:
            return string[string.find(".") + 2:] if mode == "first_aired" else string[0:string.find(".")]
        elif string and string.find(",") > 0:
            return string[string.rfind(",") + 2:] if mode == "first_aired" else string[0:string.rfind(",")]
        elif string and string.find(",") < 0 and string.find(".") < 0:
            return string
        else:
            return None

    def get_first_aired_attributes_genre_from_guide_header(self, mode="first_aired"):
        """
        Args:
            mode (str): one of (first_aired, show_attributes, genre)

        Returns:
            str, if mode == first_aired: First aired: 4/4/2022
                 if mode == show_attributes: (CC, R, HD)
                 if mode == genre: Spanish, Cartoon
        """
        if "genreAndFirstAiringAndAttributes" in self.screen.get_screen_dump_item():
            if self.SCRN_DMP_HTEXT in self.screen.get_screen_dump_item("genreAndFirstAiringAndAttributes") and \
               mode == "show_attributes":
                text = self.screen.get_screen_dump_item("genreAndFirstAiringAndAttributes", self.SCRN_DMP_HTEXT)
                return text
            if "font" in self.screen.get_screen_dump_item("genreAndFirstAiringAndAttributes"):
                if self.SCRN_DMP_HTEXT in self.screen.get_screen_dump_item("genreAndFirstAiringAndAttributes", "font"):
                    text = self.screen.get_screen_dump_item("genreAndFirstAiringAndAttributes", "font", self.SCRN_DMP_HTEXT)
                    return self.get_first_aired_or_genre_from_combined_str(text, mode)
        return None

    def find_channel_and_highlight_program_in_guide(self, tester, is_olg, channel_show_offer=None, **params):
        """
        Selects particular program in Guide/One Line Guide. It's expected that Guide screen is already opened.
        What this method does in detail:
            1. Goes to Guide/One Line Guide
            2. Finds a channel using OpenAPI methods
            3. Highlights a program cell

        Notes:
            It's better to have count = None in kwargs to have ability to implement further search by /v1/preview/offer
            after making /v1/guideRows

        Args:
            tester (TestClass): test class instance e.g. TestGuideScreen
            is_olg (bool): True - highlighting channel in One Line Guide, False - in Guide
            channel_show_offer (list): in format [[channelNumber, GuideCell, Channel, [steps, left/right], PreviewOffer]];
                                       this method will not make API call if this param is passed

        Kwargs:
            params: parameters for OpenAPI API methods

        Returns:
            list, [[channelNumber, GuideCell, Channel, [steps, left/right], PreviewOffer]]
                  steps + left/right shows how many steps and where needed to be done to highlight a cell in Guide;
                  Note: Tip for Guide - get to Channel Cell before pressing Left/Right using steps from this item
        """
        self.log.info("Finding channel and highlighting a program cell in Guide")
        if not channel_show_offer:
            if "count" not in params:
                params["count"] = None
            channel_show = self.service_api.get_random_channel_from_guide_rows(**params)
            params["count"] = 1
            channel_show_offer = self.service_api.get_random_filtered_channels_by_preview_offer(channel_show, **params)
        if is_olg:
            tester.home_page.goto_live_tv(channel_show_offer[0][0], confirm=True)
            tester.watchvideo_assertions.verify_video_playback_started()
            self.open_olg(refresh=False)
        else:
            tester.home_page.go_to_guide(tester)
            self.enter_channel_number(channel_show_offer[0][0], confirm=False)
        self.get_to_channel_tab(is_olg=is_olg)
        # We need to go to needed Program Cell from Channel Cell
        press_number = channel_show_offer[0][3][0]
        left_right = channel_show_offer[0][3][1]
        while press_number > 0:
            if left_right == "right":
                self.press_right_button(refresh=False)
            else:
                self.press_left_button(refresh=False)
            press_number -= 1
        return channel_show_offer

    def get_ppv_rental_channel(self, tester):
        channel_list = tester.api.get_channels_list()
        if tester.guide_labels.LBL_IPPPV_CHANNEL in channel_list:
            return tester.guide_labels.LBL_IPPPV_CHANNEL
        else:
            return None

    def press_enter_multiple_times(self, no_of_times):
        self.log.info(f"Pressing Enter {no_of_times} times")
        for _ in range(no_of_times):
            self.screen.base.press_enter()

    def remove_all_fav_channels_in_guide(self, tester):
        """
        Removes channels from Favorites shown in guide
        Maximum 20 guide screen
        """
        tester.home_page.go_to_guide(tester)
        tester.guide_page.wait_for_screen_ready(tester.guide_labels.LBL_GUIDE_SCREEN)
        tester.guide_assertions.verify_guide_screen(tester)
        tester.guide_page.switch_channel_option(tester.guide_labels.LBL_FAVORITES_OPTION)
        for i in range(20):
            if not tester.guide_page.is_menu_list():
                self.log.info("No channels in favorites,Changing to all channels ")
                tester.guide_page.press_ok_button()
                break
            else:
                channel_list = self.screen.get_screen_dump_item('menuitem')
                for channel in range(len(channel_list)):
                    self.select_remove_from_fav(tester)
                    self.wait_for_screen_ready(tester.guide_labels.LBL_GUIDE_SCREEN)

    def press_channel_up_or_down_multiple_times(self, action='up', no_of_times=1):
        if action.lower() == 'up':
            for _ in range(no_of_times):
                self.screen.base.press_channel_up()
        else:
            for _ in range(no_of_times):
                self.screen.base.press_channel_down()

    def move_highlight_to_a_cell(self, steps_left_right):
        """
        Moving highlight from a Channel Cell to a Program Cell in one row (Past/In Progress/Future Guide & OLG).

        Args:
            steps_left_right (list): in format [steps, left/right]
        """
        self.log.info(f"Moving highlight to a Program Cell from a Channel Cell; steps_left_right {steps_left_right}")
        steps = steps_left_right[0]
        is_right = True if steps_left_right[1] == "right" else False
        while steps > 0:
            if is_right:
                self.press_right_button(refresh=False)
            else:
                self.press_left_button(refresh=False)
            steps -= 1
        if not self.ui_element_exists("oneLineGuideTile"):
            # Waiting for this event is needed for Grid Guide only
            self.wait_for_guide_next_page()

    def get_olg_channel_call_sign_of_highlighted_row(self):
        """
        Get call sign of a highlighted row in One Line Guide
        """
        menu_item = self.screen.get_screen_dump_item('menuitem')
        menu_list = menu_item if type(menu_item) is list else [menu_item]
        row_ch_call_sign = None
        for item in menu_list:
            if "highlighted-row" in item:
                row_ch_call_sign = item['text'][1]
                break
        return row_ch_call_sign

    def get_olg_channel_number_of_highlighted_row(self):
        """
        Get channel number of a highlighted row in One Line Guide
        """
        menu_item = self.screen.get_screen_dump_item('menuitem')
        menu_list = menu_item if type(menu_item) is list else [menu_item]
        row_ch_num = None
        for item in menu_list:
            if "highlighted-row" in item:
                row_ch_num = item['text'][0]
                break
        return row_ch_num

    def get_olg_tile_subtitle(self):
        """
        Get tile subtitle in the One Line Guide
        """
        tile_subtitle = None
        strip_item = self.screen.get_screen_dump_item().get('stripitem')
        if strip_item is not None:
            strip_list = strip_item if type(strip_item) is list else [strip_item]
            for item in strip_list:
                if "hasfocus" in item:
                    tile_subtitle = item.get('tile-subtitle')
                    break
        tile_subtitle = tile_subtitle if tile_subtitle is not None else "%NONE%"
        return tile_subtitle

    def waiting_fail_open(self, is_wait_fail_open=True, is_olg=False):
        """
        Method for waiting for Fail Open Guide/Fail Open One Line Guide
        Note:
            Disconnected Guide service whisper is shown,
            one tile in a row is shown with title 'Select to watch $channel_call_sign' (OLG) and
            all grid rows shows Select to watch $channel_call_sign instead of program names (Grid Guide)

        Args:
            is_wait_fail_open (bool): True - waiting when Grid Guide Cell/One Line Guide tile shows Select to watch title
                                      False - waiting for Fail Open Guide/OLG whisper to be shown
            is_olg (bool): True - checking fail open in OLG, False - checking fail open in Grid Guide
        """
        self.log.info(f"Wating for Fail Open {'One Line Guide' if is_olg else 'Guide'}")
        # Product Defect
        # timeout happens later than expected: https://jira.xperi.com/browse/CLOUD-5377
        # Whisper may not appear in this case (intermittent), affects also older versions.
        # Also OLG tiles may not show Select to watch text quickly.
        number_of_attemps = 10
        expected_whi_txt = self.guide_labels.LBL_WHISPER_OLG_DISCONNECTED_GUIDE_SERVICE
        for attempt in range(number_of_attemps):
            self.screen.get_json()
            if is_olg and "oneLineGuideHeaderInfo" not in self.screen.get_screen_dump_item():
                # OLG got hidden due to inactivity time, let's bring it up
                self.open_olg(refresh=False, wait_olg_event=False, wait_olg_content=False)
            if is_wait_fail_open:
                title = "%NONE%"
                try:
                    title = self.get_olg_tile_subtitle() if is_olg else self.get_focussed_grid_item(self)
                except Exception:
                    pass
                if self.guide_labels.LBL_DS_PROGRAM_CELL in title:
                    # Select to watch text is shown on a tile in OLG
                    break
                self.pause(8)
            elif self.verify_whisper(expected_whi_txt, visible=True, raise_error=False):
                # The Fail Open Guide/One Line Guide whisper is present in the screen dump
                break
            elif attempt == number_of_attemps - 1 or self.wait_for_whisper_text(expected_whi_txt):
                self.screen.get_json()
                break

    def channel_change(self, button="channel up"):
        if button == "channel up":
            self.screen.base.press_channel_up()
        else:
            self.screen.base.press_channel_down()
        self.wait_for_channel_change()

    def create_recording_using_ui(self, tester, channel):
        tester.home_page.go_to_guide(tester)
        tester.home_page.wait_for_screen_ready(self.guide_labels.LBL_GUIDE_SCREEN)
        tester.guide_assertions.verify_guide_screen(tester)
        self.enter_channel_number(channel)
        show = self.get_live_program_name(tester)
        if self.create_live_recording():
            return show
        else:
            return False

    def get_channels_with_recordable_live_offer(self):
        """
            Method return channel number with recordable live channel offer
            Return: channel_number (str)
        """
        if not Settings.is_ndvr_applicable():
            pytest.skip("NDVR is not enabled")
        channels_list = []
        channels = self.service_api.get_recordable_channels_list()
        guide_rows = self.service_api.get_guide_rows(channel_list=channels)
        for guide_row in guide_rows:
            for offer in guide_rows[guide_row]:
                offer_start_time = datetime.datetime.strptime(datetime.datetime.fromtimestamp(offer.start_time)
                                                              .strftime(self.service_api.MIND_DATE_TIME_FORMAT),
                                                              self.service_api.MIND_DATE_TIME_FORMAT)

                offer_end_time = datetime.datetime.\
                    strptime(datetime.datetime.fromtimestamp(offer.start_time + offer.duration).
                             strftime(self.service_api.MIND_DATE_TIME_FORMAT), self.service_api.MIND_DATE_TIME_FORMAT)

                local_time = datetime.datetime.now()
                if offer_start_time < local_time < offer_end_time:
                    actions = self.service_api.get_actions_offer(offer.offer_id, groups="scheduleRecording")
                    if actions:
                        if actions.kernel['actionId'] == 'recordThisEpisode' or \
                                actions.kernel['actionId'] == 'recordThisShow':
                            channels_list.append(guide_row)
                    else:
                        continue
        if not channels_list:
            raise LookupError('There are no recordable live offer in channels.')
        return channels_list

    def start_recording_playback_from_record_overlay(self, tester):
        self.log.step("Starting Recording Playback from Guide")
        self.screen.refresh()
        self.press_info_or_long_press_enter()
        self.wait_for_screen_ready(self.guide_labels.LBL_RECORD_OVERLAY, timeout=30000)
        self.nav_to_menu(tester.guide_labels.LBL_WATCH_NOW_FROM)
        self.select_item(refresh=False)
        self.wait_for_screen_ready(self.guide_labels.LBL_RECORDING_PLAYBACK_SCREEN)

    def watch_now_from_catch_up_highlighted_show(self, tester):
        self.log.step("Starting Recording Playback from Guide")
        self.press_info_or_long_press_enter()
        self.wait_for_screen_ready(self.guide_labels.LBL_RECORDING_OPTIONS_OVERLAY, timeout=20000)
        self.nav_to_menu(tester.menu_labels.LBL_WATCH_NOW_FROM_SOCU)
        self.select_item(refresh=False)
