import re
import json
import os

import pytest
from hamcrest import assert_that, is_, greater_than, not_none, none, has_items, contains_string, equal_to, \
    equal_to_ignoring_case, greater_than_or_equal_to, less_than_or_equal_to, is_in

from set_top_box.client_api.guide.page import GuidePage
from set_top_box.client_api.guide.en_us.labels import GuideLabels
from set_top_box.test_settings import Settings
from tools.logger.logger import Logger
from set_top_box.conf_constants import HydraBranches


class GuideAssertions(GuidePage):
    log = Logger(__name__)

    def verify_guide_screen(self, tester, screen_dump={}):
        self.log.step("Verifying Guide Screen")
        self.wait_for_screen_ready("GuideListModel")
        if screen_dump == {}:
            screen_dump = self.screen.get_json()
        if screen_dump['xml']['viewMode'] != self.guide_labels.LBL_VIEW_MODE:
            raise AssertionError('Guide Screen not Loaded!')
        if 'time' not in screen_dump['xml'].keys():
            raise AssertionError('Guide time window is not present')
        if screen_dump['xml']['time'] is None or None in screen_dump['xml']['time']:
            raise AssertionError('Guide time window is not present')

        if 'timeinfo' not in screen_dump['xml'].keys():
            raise AssertionError('Guide current time not present')
        if len(screen_dump['xml']['time']) < 2:
            raise AssertionError('Guide time window is unexpectedly small')
        guide = self.return_guide(screen_dump=screen_dump)
        self.verify_guide_row_focus(screen_dump=guide)
        self.verify_guide_row_tab_focus(screen_dump=guide)
        for row in guide:
            row[u'grid-row'] = list(filter(None, row[u'grid-row']))
            for item in row['grid-row']:
                if 'text' in item and item['text'] == 'Title not available':
                    raise AssertionError('Guide missing airing data: %s in \n%s' % (str(item), str(guide)))
        self.log.info("Guide Screen loaded completely without any issues")

    def detect_holes_in_guide(self, tester, screen_dump={}):
        self.log.step("Detecting holes in Guide Screen")
        holes = 0
        self.wait_for_screen_ready("GuideListModel")
        if screen_dump == {}:
            screen_dump = self.screen.get_json()
        if screen_dump['xml']['viewMode'] != self.guide_labels.LBL_VIEW_MODE:
            raise AssertionError('Guide Screen not Loaded!')
        if 'time' not in screen_dump['xml'].keys():
            raise AssertionError('Guide time window is not present')
        if screen_dump['xml']['time'] is None or None in screen_dump['xml']['time']:
            raise AssertionError('Guide time window is not present')

        if 'timeinfo' not in screen_dump['xml'].keys():
            raise AssertionError('Guide current time not present')
        if len(screen_dump['xml']['time']) < 2:
            raise AssertionError('Guide time window is unexpectedly small')
        guide = self.return_guide(screen_dump=screen_dump)
        self.verify_guide_row_focus(screen_dump=guide)
        self.verify_guide_row_tab_focus(screen_dump=guide)
        for row in guide:
            row[u'grid-row'] = list(filter(None, row[u'grid-row']))
            for item in row['grid-row']:
                if 'text' in item and item['text'] == 'Title not available':
                    holes += 1
                elif 'text' not in item:
                    if item.get('channelnumber'):
                        continue
                    else:
                        self.log.info("this tile doesn't have text {}".format(item))
                        holes += 1
        self.log.info("current grid row holes {}".format(holes))
        return holes

    def verify_guide_holes(self, holes1, holes2, holes3):
        self.log.step("Calculating guide holes")
        total_holes = holes1 + holes2 + holes3
        if total_holes > 0:
            raise AssertionError('Total holes found: {}'.format(total_holes))

    def verify_guide_row_focus(self, screen_dump=[]):
        if len(screen_dump) < 1:
            raise AssertionError('Empty guide grid data')
        for row in screen_dump:
            if 'grid-row' not in row.keys():
                raise AssertionError('Guide grid missing required grid row keys')
        try:
            guide_row_focus = self.return_guide_row_focus(screen_dump=screen_dump)
        except Exception:
            raise AssertionError('Grid failed to load in time')
        if len(guide_row_focus) < 1:
            raise AssertionError('Empty guide grid row data')
        return guide_row_focus

    def verify_guide_row_tab_focus(self, screen_dump=[]):
        if len(screen_dump) < 1:
            raise ValueError('Empty guide grid data received: {}'.format(screen_dump))
        try:
            tab_focus = self.get_focused_guide_row_tab(guide_row_xml_part=screen_dump)
        except LookupError as err:
            raise AssertionError('Grid failed to load in time. Err: {}'.format(err))
        assert_that(tab_focus, "There is no focused guide row tab on the screen. DUMP: {}".format(screen_dump))

    def verify_channel_found(self, nav_result):
        assert nav_result, 'Channel could not be found'

    def verify_watch_channel(self, tester, channel_number, nav_result=None):
        if nav_result is not None:
            self.verify_channel_found(nav_result=nav_result)
        watch_channel = self.watch_channel(tester, channel_number)
        assert watch_channel, f'Channel {channel_number} could not be found'

    def verify_focus_on_channel_airing_now_program(self, tester, channel_number):
        self.log.step("Verifying Focus on currently airing program  or not")
        if not self.focus_on_channel_airing_now_program(tester, channel_number):
            raise AssertionError('Channel %s could not be found' % channel_number)

    def verify_menu_has_option(self, option_text):
        self.log.info(f"Verifying {option_text} existence")
        self.verify_menu_list(option_text, mode="none_item_presence")
        menu_list = self.menu_list()
        option_found = False
        for item in menu_list:
            if option_text in item:
                self.log.info(f"{option_text} found")
                option_found = True
        if not option_found:
            raise AssertionError('Menu option %s is not available' % option_text)

    def verify_menu_has_watch_option(self, option_text):
        self.pause(5)
        screen_dump = self.screen.get_json()
        menuitem = screen_dump['xml']['menuitem']
        option_found = False
        for item in menuitem:
            if option_text in item['text'] and self.guide_labels.LBL_WATCH_NOW_FROM not in item['text']:
                if item['text'] == self.guide_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE:
                    self.select_menu(self.guide_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE)
                    option_found = True
                else:
                    self.select_menu(self.guide_labels.LBL_CHANNEL_OPTIONS_WATCH_NOW)
                    self.screen.base.press_enter(time=3000)
                    option_found = True
        if not option_found:
            raise AssertionError(f"Menu item '{option_text}' not found")

    def press_select_and_verify_overlay(self):
        self.screen.base.press_enter(time=500)
        screendump = self.screen.get_json()
        for item in self.guide_labels.LBL_RECORD_OVERLAY_MENU_ITEM:
            for options in screendump['xml']['menuitem']:
                if item == options['text']:
                    break
            else:
                raise AssertionError(f"Menu item '{item}' not found")

    def verify_channel_option(self, option):
        self.log.step("Verifying guide tip text for channels")
        tiptext = (self.screen.get_screen_dump_item('tiptext'))
        found = False
        for item in tiptext:
            for value in item['option']:
                if value['text'] == option:
                    found = True
                    break
            if found:
                break
        if not found:
            raise AssertionError(f"Channel option '{option}' not found")

    def verify_channel_title(self, tester, title):
        self.log.info(f"Verifying Channel title: {title}")
        tester.watchvideo_assertions.wait_for_LiveTVPlayback("PLAYING")
        limit = 5
        for retry in range(limit):
            self.screen.refresh()
            self.pause(retry)
            if self.view_mode() == tester.watchvideo_labels.LBL_LIVETV_VIEWMODE:
                break
            elif self.get_ui_error():
                raise LookupError("Expected livetv but on the screen error: {}".format(self.get_ui_error()))
            else:
                # TODO: error log verification is needed
                pass

        screentitle = self.screen.get_screen_dump_item('title')
        assert_that(screentitle, title, "Screen title doesn't match")
        self.log.info("Screen title successfully validated")

    def verify_one_line_guide_menu_options(self):
        assert_that(self.is_menu_list(), True)

    def verify_favorite_show_in_guide(self):
        self.log.info("Verify favorite show in guide")
        menuitem = (self.screen.get_screen_dump_item('menuitem'))
        assert_that(len(menuitem), greater_than(0))

    def verify_play_normal(self):
        # Once audio/video check is implemented, unexpected overlays need to be handled[Eg. DRM Error]
        self.log.step("Verifying trickplay playback status")
        self.screen.refresh()
        self.verify_error_overlay_not_shown()  # handling playback error overlays e.g. DRM etc.
        trickplay = (self.screen.get_screen_dump_item('trick-play'))
        assert_that(trickplay['play-status'], equal_to('playNormal'))

    def verify_fast_forward(self, speed):
        forward_str = "playForward" + str(speed)
        trickplay = (self.screen.get_screen_dump_item('trick-play'))
        assert_that(trickplay['play-status'], forward_str)

    def verify_rewind(self, speed):
        rewind_str = "playRewind" + str(speed)
        trickplay = (self.screen.get_screen_dump_item('trick-play'))
        assert_that(trickplay['play-status'], rewind_str)

    def verify_pause(self):
        trickplay = (self.screen.get_screen_dump_item('trick-play'))
        assert_that(trickplay['play-status'], 'playPause')

    def verify_date_is_equal(self, curr_date, destination_date):
        self.log.info("Verifying if current date is equal to destination one; current: {}, destination: {}"
                      .format(curr_date, destination_date))
        assert_that(curr_date, equal_to(destination_date))

    def verify_date_greater_or_equal(self, curr_date, destination_date):
        self.log.info(
            "Verifying if current date is greater than or equal to destination one; current: {}, destination: {}"
            .format(curr_date, destination_date))
        assert_that(curr_date, greater_than_or_equal_to(destination_date))

    def verify_date_less_or_equal(self, curr_date, destination_date):
        self.log.info("Verifying if current date is less than or equal to destination one; current: {}, destination: {}"
                      .format(curr_date, destination_date))
        assert_that(curr_date, less_than_or_equal_to(destination_date))

    def verify_audio_option_selected(self, option):
        self.log.step("Verifying whether audio option {} was modified or not".format(option))
        assert_that(self.menu_list()[0], option)

    def verify_info_bar(self):
        assert_that(self.is_strip_list())
        assert_that(self.is_in_strip("info"))

    def verify_option_in_strip(self, option):
        assert_that(self.is_in_strip(option))

    def verify_date_info_in_guide(self, screen):
        found = False
        for item in screen['xml']:
            if 'date' in item:
                found = True
        assert_that(found, True)

    def verify_key_in_screen(self, key):
        screen = self.screen.screen_dump['xml']
        found = False
        for item in screen:
            if item == key:
                found = True
                break
        assert_that(found, True)

    def verify_watch_now_from_catchup_name(self, tester, retries=3, inprogress=True, socu_on=True):
        """
        Method to verify current focused item is "Watch now..." and exact label

        Args:
            tester (TestClass): test entity with all objects
            retries (int): number of retries to get focused item
            inprogress (bool): if a highlighted Guide Cell is an in progress show
            socu_on (bool): if True, checks if catchup label is located in the Record Overlay as a separate option
                            if False, checks if catchup label is NOT in the Record Overlay as a separate option
                            (it's available in Watch now option when SOCU feature is off)
        """
        self.log.info("Verifying catchup name in record overlay")
        for step in range(retries):
            focused_item = self.menu_focus()
            if isinstance(focused_item, str):
                self.log.info("Focused item is : {}".format(focused_item))
                break
            else:
                self.log.debug("Unable to get focused item. One more try. Response: '{}'".format(focused_item))
                self.screen.refresh()
        else:
            raise ValueError("Unable to detect focused item. Cur dump: '{}'".format(self.screen.get_screen_dump_item()))
        # When SOCU feature is OFF, catchup/startover show is available in Watch now option;
        # If SOCU feature is ON, then catchup/startover is the 1st option in the Record Overlay (with SOCU icon on the right)
        expected_item = self.get_watch_now_catchup_name(tester, inprogress) if socu_on \
            else self.guide_labels.LBL_WATCH_NOW_RECORD_OVERLAY
        assert_that(focused_item == expected_item,
                    'Expected focus "{}", but actual "{}"'.format(expected_item, focused_item))

    def verify_watch_now_from_catchup_icon(self):
        self.log.info("Checking if Catchup menu is available or not")
        self.screen.refresh()
        focused_image_item = self.image_focus()
        found = False
        if isinstance(focused_image_item, list):
            for image in focused_image_item:
                if self.guide_labels.LBL_RECORD_OVERLAY_CATCHUP_ICON in image:
                    self.log.info("Catch Up option Found")
                    found = True
                    break
        else:
            if self.guide_labels.LBL_RECORD_OVERLAY_CATCHUP_ICON in focused_image_item:
                self.log.info("Catch Up option Found")
                found = True
        assert_that(found, True)

    def press_select_verify_record_overlay(self, tester, long_press=False, inprogress=True, socu_on=True):
        """
        Args:
            tester (TestClass): test class instance
            long_press (bool): if long key press should be done
            inprogress (bool): if a highlighted Guide Cell is an in progress show
            socu_on (bool): if True, checks if catchup label is located in the Record Overlay as a separate option
                            if False, checks if catchup label is NOT in the Record Overlay as a separate option
                            (it's available in Watch now option when SOCU feature is off)
        """
        self.log.step("Select highlighted item and verify record overlay; \n"
                      f"long_press {long_press}, inprogress {inprogress}, socu_on {socu_on}")
        if long_press:
            self.screen.base.long_press_enter()
        else:
            self.screen.base.press_enter()
        self.wait_for_screen_ready(self.guide_labels.LBL_RECORD_OVERLAY)
        self.verify_watch_now_from_catchup_name(tester, 3, inprogress, socu_on)

    def press_select_verify_watch_screen(self, tester, focused_item, playback_check=True):
        self.log.step("Selecting '{}' SOCU playback from Record Overlay and verifying playback".format(focused_item))
        focused_image_item = self.image_focus()
        if isinstance(focused_image_item, list):
            self.log.step("Selecting watch now if SOCU is also available from OTT")
            self.press_ok_button(refresh=False)
        self.pause(3)
        self.press_ok_button(refresh=True)
        max_retries = 3
        while max_retries > 0:
            max_retries -= 1
            state = self.wait_for_screen_ready(self.guide_labels.LBL_RESUME_OVERLAY)
            if state:
                try:
                    self.log.info("selecting Resume or start over from beginning")
                    self.select_item()
                except Exception:
                    raise AssertionError('Unable to playback the SOCU offer from Guide')
            state = self.wait_for_screen_ready(self.guide_labels.LBL_SOCU_PLAYBACK_SCREEN)
            if not state:
                """
                state = self.wait_for_screen_ready(self.guide_labels.LBL_TRY_AGAIN_SCREEN)
                if not state:
                    self.log.info("Trying again...")
                else:
                    self.screen.get_json()
                    raise AssertionError('Unexpected Overlay : TryAgainLaterOverlay')
                """
                if playback_check:
                    tester.watchvideo_assertions.verify_error_overlay_not_shown()
            else:
                self.log.info("SOCU Playback : VALIDATION SUCCEEDED")
                break
        if playback_check:
            self.verify_channel_title(tester, focused_item)
            tester.watchvideo_assertions.verify_playback_play()

    def press_select_verify_playback(self, stay_tick_play_bar=True, stay_ipppv_osd=True, stay_playback=True):
        """
        Args:
            stay_tick_play_bar (bool): True - trick play bar continues displaying if it's shown,
                                       False - wait till trick play bar dismissing
            stay_ipppv_osd (bool): True - IPPPV OSD (applicable to IPPPV channels) stays displayed,
                                   False - press Back to dismiss IPPPV OSD
            stay_playback (bool): True - staying in playback, False - pressing Back to return to previous screen;
                                  NOTE: stay_ipppv_osd should be False to leave playback
        """
        self.log.info("Pressing OK and verifying playback")
        self.press_ok_button(refresh=False)
        self.verify_play_normal()
        if not stay_tick_play_bar and self.screen.get_screen_dump_item('trick-play',
                                                                       'trick-play-bar-visible') == "true":
            self.wait_for_infobanner("dismissed")  # waiting trick play bar dismissing
        if not stay_ipppv_osd and "osdtext" in self.screen.get_screen_dump_item() and \
                self.watchvideo_labels.LBL_IPPPV_PAY_PER_VIEW in self.screen.get_screen_dump_item('osdtext'):
            # After pressing Back on IPPPV OSD, you get to Live TV playback
            self.press_back_button(refresh=False)
        if not stay_playback and not stay_ipppv_osd:
            self.press_back_button(refresh=False)

    def press_info_verify_closed_captioning_off(self):
        self.screen.base.press_info(time=300)
        self.screen.refresh()
        self.verify_cc("OFF")

    def verify_guide_title(self):
        self.log.step("Verifying current title is GUIDE")
        if self.screen_title() != self.guide_labels.LBL_SCREENTITLE:
            self.log.info("Title was not Guide, trying to wait")
            self.wait_for_screen_ready()
            self.screen.refresh()
        assert_that(self.screen_title(), is_("GUIDE"))

    def verify_year_in_title(self, converse=False):
        self.log.step("Checking year in title")
        matcher = none if converse else not_none
        assert_that(self.screen.screen_dump['xml'].get('endingText', None), matcher())

    def verify_bookmark_and_moreInfo_available(self, tester):
        self.log.step("Checking availablility of More Info and Bookmark this movie menus in list")
        assert_that(self.menu_list(), has_items(tester.menu_page.get_more_info_name(tester), "Bookmark this movie"))

    def verify_show_name_present(self, show):
        show = self.convert_special_chars(show)
        self.log.step(f"Verifying {show} availability in list")
        self.screen.refresh()
        shows = self.menu_list()
        for i in range(len(shows)):
            item = self.convert_special_chars(shows[i])
            if item.lower() in show.lower():
                break
        else:
            assert False, f"'{show}' not found. Available shows: {shows}"

    def verify_in_current_guide(self, screen_dump=None):
        if not screen_dump:
            screen_dump = self.screen.get_json()
        assert_that(self.is_guide_current(screen_dump), "Displayed Grid Guide is not current")

    def verify_guide_start_interval(self, screen_dump=None, date_time=None):
        """
        Verify that grid time interval starts with specified time
        """
        if not screen_dump:
            screen_dump = self.screen.get_json()
        assert_that(self.is_guide_current(screen_dump, date_time=date_time),
                    "Displayed Grid Guide interval does not contain {} ".format(date_time))

    def verify_in_past_guide(self, screen_dump=None):
        screen_dump = screen_dump or self.screen.get_json()
        assert_that(self.is_guide_past(screen_dump), "Displayed Grid Guide is not in the past")

    def verify_in_current_or_future_guide(self, screen_dump={}):
        if not screen_dump:
            screen_dump = self.screen.get_json()
        assert_that((self.is_guide_future(screen_dump) or self.is_guide_current(screen_dump)),
                    "Displayed Grid Guide is not in the current or future guide")

    def verify_transition_past_guide_and_back(self):

        def __fun(action, verify):
            for _ in range(5):
                action()
            self.pause(5)
            self.screen.refresh()
            verify()

        __fun(self.screen.base.press_left, self.verify_in_past_guide)
        __fun(self.screen.base.press_right, self.verify_in_current_or_future_guide)

    def verify_show_title_available(self):
        self.log.step("Verifying if focussed item title is 'title not available' or not")
        if self.get_foucsed_content()['text'] == self.guide_labels.LBL_TITLE_NOT_AVAILABLE:
            pytest.skip("Unable to play this channel")

    def verify_channel_text_color(self, text_color):
        self.log.step("Verifying channel text color")
        self.pause(3)
        row = self.get_foucsed_content()
        current_color = row["textcolor"] if 'textcolor' in row.keys() else self.wait_and_check_next_item_in_row()
        assert_that(current_color, contains_string(text_color))

    def press_select_verify_channel_not_subscribed_overlay(self):
        self.log.step("Verifying Channel not subscribed overaly launch")
        self.screen.base.press_enter(time=1000)
        self.screen.refresh()
        overlay_title = self.get_overlay_title(raise_error=False)
        assert_that(overlay_title, contains_string(self.guide_labels.CHANNEL_NOT_SUBSCRIBED))

    def verify_jump_channel_launch(self, app_name=None, enter=True):
        self.log.info("checking if app was launched or not")
        if not app_name:
            app_name = Settings.app_package
        expected_screens = ["NotHydra",
                            *self.guide_labels.ON_DEMAND_SCREENS.values(),
                            *self.guide_labels.THIRD_PARTY_APP_PACKAGES.values()
                            ]
        check_details = ""
        if Settings.is_apple_tv() and enter:
            screen_name = self.get_screen_name(timeout=30000)
            self.log.info("screen_name ={}".format(screen_name))
            if not screen_name == "VodBrowseMainScreen":
                self.log.info("Press Enter to launch app on apple tv")
                self.screen.base.press_enter()
            self.wait_for_screen_ready()
        if not self.screen.base.verify_foreground_app(app_name):
            screentitle = self.screen.base.get_foreground_package()
        else:
            try:
                self.screen.refresh()
                screentitle = self.get_screen_name(timeout=30000)
            except Exception as err:
                check_details += "********* \n {} \n".format(err)
                screentitle = self.screen.base.get_foreground_package()
        assert_that(screentitle,
                    is_in(expected_screens),
                    "Verification of jump channel failed. DETAILS: {}".format(check_details))

    def verify_hdmiconnection_overlay(self, option):
        hdmioverlay = self.screen.get_screen_dump_item('overlayTitle')
        return hdmioverlay == option

    def verify_fast_forward_1(self, tester):
        self.screen.base.press_fast_forward()
        self.pause(5)
        tester.vod_assertions.verify_press_forward_trick_play(tester.vod_labels.LBL_FWDX1)

    def explicit_recordingicon_assertion(self):
        raise AssertionError("Single explicit icon validation Failed!")

    def verify_text_image_from_screen(self, option_text, image_name=None):
        """
        The function would validate if the screen captures the option_text and an image(optional)
        :param option_text: Text to be validated form the screen
        :param image_name: Image to be validated from the screen
        :return:
        """
        self.log.step(f"Verifying availability of option text:{option_text}  and image:{image_name}")
        self.pause(2)
        screen_dump = self.screen.get_json()
        menuitem = screen_dump['xml']['menuitem']
        fallback_img = self.guide_labels.LBL_SOCU_FALLBAC_IMG
        for item in menuitem:
            if option_text in item.get('text'):
                if image_name:
                    if image_name not in item.get('imagename'):
                        if fallback_img not in item.get('imagename'):
                            raise AssertionError("Image item {} not found".format(image_name))
                    self.log.info("Image name validated for option {}. ".format(item['imagename']))
                self.log.info("Item text validated for option {}".format(item['text']))
                return
        raise AssertionError('{} not in dump'.format(option_text))

    def verify_catchup_socu_icon_on_search_screen(self):
        self.log.info("Verifying SOCU icon existence")
        imagename = self.get_preview_panel()['availableOn']['imagename']
        found = False
        if isinstance(imagename, list):
            for item in imagename:
                if self.guide_labels.LBL_RECORD_OVERLAY_CATCHUP_ICON in item:
                    self.log.info("SOCU icon exists")
                    found = True
                    break
        if isinstance(imagename, str):
            if self.guide_labels.LBL_RECORD_OVERLAY_CATCHUP_ICON in imagename:
                self.log.info("SOCU icon exists")
                found = True
        assert_that(found)

    def verify_show_title(self, show_title, mode="record_overlay"):
        """
        Verifying show title on Guide Header preview, Program Screen preview, Record Overlay preview,
        Already Recording Overlay Preview
        highlighted Guide Cell, One Line Guide preview.

        Args:
            show_title (str): program title
            mode (str): one of (guide_header, record_overlay, already_recording_overlay,
            program_screen, guide_cell, olg_preview)
        """
        self.log.info(f"Verifying show title '{show_title}'; mode {mode}")
        screen_dump = self.screen.get_json()
        show_title_no_sys_symbols = self.remove_service_symbols(show_title)
        program_name = None
        if mode == "guide_header":
            program_name = self.remove_service_symbols(self.screen.get_screen_dump_item("program", "text"))
        elif mode == "record_overlay":
            program_name = self.remove_service_symbols(self.screen.get_screen_dump_item("overlayTitle"))
        elif mode == "already_recording_overlay":
            program_name = self.remove_service_symbols(self.screen.get_screen_dump_item("subtitle"))
        elif mode == "program_screen":
            program_name = self.remove_service_symbols(self.screen.get_screen_dump_item("previewPane", "title"))
        elif mode == "guide_cell":
            program_name = self.remove_service_symbols(
                self.get_grid_focus_details(screen_dump)["program_name_in_cell"])
        elif mode == "olg_preview":
            program_name = self.remove_service_symbols(self.screen.get_screen_dump_item("oneLineGuideTile", "title"))
        else:
            raise ValueError(f"Not supported mode - {mode}")
        is_contained = True if show_title_no_sys_symbols in program_name else False
        assert_that(is_contained,
                    f"Show title does not match; current: {program_name}; expected: {show_title_no_sys_symbols}; "
                    f"screen_dump:\n\n{screen_dump}")

    def verify_program_subtitle(self, show_subtitle, mode="record_overlay"):
        """
        Verifying show subtitle on Guide Header preview, Program Screen preview, Record Overlay preview,
        One Line Guide preview.
        Subtitle may be present for series, episode, special content types.

        Args:
            show_subtitle (str): program subtitle
            mode (str): one of (guide_header, record_overlay, program_screen, olg_preview)
        """
        self.log.info(f"Verifying show subtitle '{show_subtitle}'; mode {mode}")
        screen_dump = self.screen.get_json()
        show_subtitle_no_sys_symbols = self.remove_service_symbols(show_subtitle)
        program_subtitle = None
        is_contained = False
        if mode == "guide_header":
            program_subtitle = self.remove_service_symbols(self.screen.get_screen_dump_item("description",
                                                                                            "text"))
        elif mode == "record_overlay":
            program_subtitle = self.remove_service_symbols(self.screen.get_screen_dump_item("overlayTitleText"))
        elif mode == "program_screen":
            program_subtitle = self.remove_service_symbols(self.screen.get_screen_dump_item("previewPane",
                                                                                            "episodeTitle"))
        elif mode == "olg_preview":
            program_subtitle = self.remove_service_symbols(
                self.screen.get_screen_dump_item("oneLineGuideTile", "title"))
        else:
            raise ValueError(f"Not supported mode - {mode}")
        is_contained = True if show_subtitle_no_sys_symbols in program_subtitle else False
        assert_that(is_contained,
                    f"Program subtitle does not match; on UI: {program_subtitle}; "
                    f"expected: {show_subtitle_no_sys_symbols}; screen_dump:\n\n{screen_dump}")

    def verify_program_description(self, show_description, mode="record_overlay"):
        """
        Verifying show description on Guide Header preview, Program Screen preview, Record Overlay preview,
        One Line Guide preview.

        Args:
            show_description (str): program description
            mode (str): one of (guide_header, record_overlay, program_screen, olg_preview, info_card)
        """
        self.log.info(f"Verifying show description '{show_description}'; mode {mode}")
        screen_dump = self.screen.get_json()
        show_description_no_sys_symbols = self.remove_service_symbols(show_description)
        program_description = None
        is_contained = False
        if mode == "guide_header":
            program_description = self.remove_service_symbols(self.screen.get_screen_dump_item("description",
                                                                                               "text"))
        elif mode == "record_overlay":
            program_description = self.remove_service_symbols(self.screen.get_screen_dump_item("bodytext"))
        elif mode in ("program_screen", "olg_preview"):
            program_description = self.remove_service_symbols(self.screen.get_screen_dump_item("previewPane",
                                                                                               "description"))
        elif mode in ("info_card"):
            program_description = self.remove_service_symbols(self.screen.get_screen_dump_item("previewText"))
        else:
            raise ValueError(f"Not supported mode - {mode}")
        is_contained = True if show_description_no_sys_symbols in program_description else False
        assert_that(is_contained,
                    f"Program descrition does not match; on UI: {program_description}; "
                    f"expected: {show_description_no_sys_symbols}; screen_dump:\n\n{screen_dump}")

    def verify_program_category(self, show_categories, mode="record_overlay"):
        """
        Verifying show categories on Guide Header preview, Program Screen preview, Record Overlay preview.

        Args:
            show_categories (str): program categories
            mode (str): one of (guide_header, record_overlay, program_screen)
        """
        self.log.info(f"Verifying show genres '{show_categories}'; mode {mode}")
        screen_dump = self.screen.get_json()
        program_categories = None
        is_contained = False
        if mode == "guide_header":
            program_categories = self.get_first_aired_attributes_genre_from_guide_header("genre")
        elif mode == "record_overlay":
            program_categories = self.get_first_aired_or_genre_from_combined_str(
                self.remove_service_symbols(self.screen.get_screen_dump_item("genreAndFirstAiring")), "genre")
        elif mode == "program_screen":
            program_categories = self.remove_service_symbols(self.screen.get_screen_dump_item("previewPane",
                                                                                              "genre"))
        else:
            raise ValueError(f"Not supported mode - {mode}")
        is_contained = True if show_categories in program_categories else False
        assert_that(is_contained,
                    f"Program categories does not match; on UI: {program_categories}; "
                    f"expected: {show_categories}; screen_dump:\n\n{screen_dump}")

    def verify_program_first_aired(self, show_first_aired, mode="record_overlay"):
        """
        Verifying show first aired date on Guide Header preview, Program Screen preview, Record Overlay preview.
        First aired may be present for series, episode, special content types.

        Args:
            show_first_aired (str): program first aired date, format: 9/25/2022
            mode (str): one of (guide_header, record_overlay, program_screen)
        """
        self.log.info(f"Verifying show first aired date '{show_first_aired}'; mode {mode}")
        screen_dump = self.screen.get_json()
        program_first_aired = None
        # Removing excess 0's to match format
        show_first_aired = show_first_aired.replace(" 0", "").replace("/0", "/")
        show_first_aired = show_first_aired[1:] if show_first_aired[0] == "0" else show_first_aired
        is_contained = False
        if mode == "guide_header":
            program_first_aired = self.get_first_aired_attributes_genre_from_guide_header("first_aired")
        elif mode == "record_overlay":
            program_first_aired = self.get_first_aired_or_genre_from_combined_str(
                self.remove_service_symbols(self.screen.get_screen_dump_item("genreAndFirstAiring")), "first_aired")
        elif mode == "program_screen":
            program_first_aired = self.remove_service_symbols(self.screen.get_screen_dump_item("previewPane", "aired"))
            # Preparing date format for Program Screen, the year should be contain only 2 last numbers
            if len(show_first_aired[show_first_aired.rfind("/") + 1:]) > 2:
                show_first_aired = show_first_aired.replace("/19", "/").replace("/20", "/")
        else:
            raise ValueError(f"Not supported mode - {mode}")
        is_contained = True if show_first_aired in program_first_aired else False
        assert_that(is_contained,
                    f"Program first aired date does not match; on UI: {program_first_aired}; "
                    f"expected: {show_first_aired}; screen_dump:\n\n{screen_dump}")

    def verify_program_start_end_date(self, show_start_end_date, mode="record_overlay"):
        """
        Verifying show start and end date on Guide Header preview, Program Screen preview, Record Overlay preview,
        One Line Guide preview.

        Args:
            show_start_end_date (str): program start and end date, in format: Sun 9/9 4:01pm - 1:05am;
                                       for One Line Guide format is 8:00pm - 8:30pm
            mode (str): one of (guide_header, record_overlay, program_screen, olg_preview)
        """
        self.log.info(f"Verifying show start and end date '{show_start_end_date}'; mode {mode}")
        screen_dump = self.screen.get_json()
        program_start_end_date = None
        # Removing excess 0's to match format
        show_start_end_date = show_start_end_date.replace(" 0", "").replace("/0", "")
        is_contained = False
        if mode == "guide_header":
            program_start_end_date = self.screen.get_screen_dump_item("showtime", "text")
        elif mode == "record_overlay":
            program_start_end_date = self.screen.get_screen_dump_item("airingDate")
        elif mode == "program_screen":
            program_start_end_date = self.remove_service_symbols(self.screen.get_screen_dump_item("previewPane",
                                                                                                  "airingDate"))
        elif mode == "olg_preview":
            program_start_end_date = self.remove_service_symbols(self.screen.get_screen_dump_item("show-time"))
        else:
            raise ValueError(f"Not supported mode - {mode}")
        is_contained = True if show_start_end_date.lower() in program_start_end_date.lower() else False
        assert_that(is_contained,
                    f"Program start and end date does not match; on UI: {program_start_end_date}; "
                    f"expected: {show_start_end_date}; screen_dump:\n\n{screen_dump}")

    def verify_program_tv_rating(self, show_tv_rating, mode="record_overlay"):
        """
        Verifying show TV rating on Guide Header preview, Program Screen preview, Record Overlay preview.

        Args:
            show_tv_rating (str): program TV rating e.g. TV-G
            mode (str): one of (guide_header, record_overlay, program_screen)
        """
        self.log.info(f"Verifying show TV rating '{show_tv_rating}'; mode {mode}")
        screen_dump = self.screen.get_json()
        program_tv_rating = None
        is_contained = False
        if mode == "guide_header":
            program_tv_rating = self.screen.get_screen_dump_item("rating", "text")
        elif mode == "record_overlay":
            program_tv_rating = self.screen.get_screen_dump_item("rating")
        elif mode == "program_screen":
            program_tv_rating = self.remove_service_symbols(self.screen.get_screen_dump_item("previewPane",
                                                                                             "parentalControlRating"))
        else:
            raise ValueError(f"Not supported mode - {mode}")
        is_contained = True if show_tv_rating in program_tv_rating else False
        assert_that(is_contained,
                    f"Program TV rating does not match; on UI: {program_tv_rating}; expected: {show_tv_rating}; "
                    f"screen_dump:\n\n{screen_dump}")

    def verify_program_not_available_to_record(self, was_recorded=False, is_copyright=False, expected=True):
        """
        Verifying show not available to record label on Guide Header preview, Record Overlay preview.

        Args:
            was_recorded (bool): True - show was previously recorded, False - otherwise
            is_copyright (booL): True - not allowed to record due to copyright restriction, False - otherwise
            expected (bool): True - not allowed to record label should be shown, False - otherwise
        """
        self.log.info(f"Verifying program not available to record label; expected {expected}")
        screen_dump = self.screen.get_json()
        expected_label = None
        if expected:
            expected_label = self.guide_labels.LBL_NOT_AVAILABLE_TO_WATCH_OR_RECORD if was_recorded else \
                self.guide_labels.LBL_NOT_AVAILABLE_TO_RECORD
        if is_copyright:
            expected_label = self.guide_labels.LBL_STATUS_MESSAGE_NDVR_OFFER_RESTRICTION
        overlaynonrecordable = self.screen.get_screen_dump_item("overlaynonrecordable")
        icon_list = overlaynonrecordable.get("imagename", [])
        icon_check = self.icon_check(self.guide_labels.LBL_NON_RECORDABLE_ICON, icon_list, expected)
        assert_that(icon_check, f"{self.guide_labels.LBL_NON_RECORDABLE_ICON} icon is "
                                f"{'SHOWN' if expected else 'NOT displayed'} on Record Overlay; "
                                f"screen dump: \n\n{screen_dump}")
        actual_label = overlaynonrecordable.get("text", [])
        label_check = expected_label in actual_label if expected else not actual_label
        assert_that(label_check,
                    f"Actual non-recordable label on Record Overlay: {actual_label}; expected: {expected}; "
                    f"{'expected label text: ' + expected_label + '; ' if expected else ''}"
                    f"screen dump: \n\n{screen_dump}")

    def verify_program_attributes(self, show_attributes, mode="record_overlay"):
        """
        Verifying show attributes on Guide Header preview, Program Screen preview, Record Overlay preview,
        One Line Guide preview.

        Args:
            show_attributes (str): program attributes e.g. R, SD, HD, SAP etc.
            mode (str): one of (guide_header, record_overlay, program_screen, olg_preview)
        """
        self.log.info(f"Verifying show attributes '{show_attributes}'; mode {mode}")
        screen_dump = self.screen.get_json()
        program_attributes = None
        is_contained = False
        if mode == "guide_header":
            description = self.screen.get_screen_dump_item("description", "text")
            search1 = re.search(r".*(\(.*\))", description)
            program_attributes = search1.group(1) if search1 is not None else None
        elif mode == "record_overlay":
            program_attributes = self.screen.get_screen_dump_item("bodytext")
        elif mode in ("program_screen", "olg_preview"):
            program_attributes = self.remove_service_symbols(self.screen.get_screen_dump_item("previewPane",
                                                                                              "videoDescription"))
        else:
            raise ValueError(f"Not supported mode - {mode}")
        is_contained = True if program_attributes and show_attributes.lower() in program_attributes.lower() else False
        assert_that(is_contained,
                    f"Program attributes does not match; on UI: {program_attributes}; expected: {show_attributes}; "
                    f"screen_dump:\n\n{screen_dump}")

    def verify_program_star_rating(self, show_star_rating):
        """
        Verifying movie star rating on Guide Header preview, Program Screen preview, Record Overlay preview,
        One Line Guide preview.

        Args:
            show_star_rating (float): program star rating 0-4
        """
        self.log.info(f"Verifying movie star rating '{show_star_rating}'")
        screen_dump = self.screen.get_json()
        program_star_rating_list = self.screen.get_screen_dump_item("starrating", "imagename")
        half = full = 0
        for image in program_star_rating_list:
            if self.guide_labels.LBL_ICON_START_RATING_HALF in image:
                half += 0.5
            elif self.guide_labels.LBL_ICON_START_RATING_FULL in image:
                full += 1
        start_rating = full + half if program_star_rating_list else None
        is_contained = True if start_rating == show_star_rating else False
        assert_that(is_contained,
                    f"Program star rating does not match; actual: {start_rating}; expected: {show_star_rating}; "
                    f"screen_dump:\n\n{screen_dump}")

    def verify_program_subtitle_icon_record_overlay(self, show_subtitle_icon):
        """
        Verifying subtitle icon on Record Overlay preview e.g. NEW icon

        Args:
            show_subtitle_icon (str): subtitle icon name
        """
        self.log.info(f"Verifying show subtitle icon '{show_subtitle_icon}'")
        screen_dump = self.screen.get_json()
        program_subtitle_icon = self.screen.get_screen_dump_item("subtitle-icon")
        is_contained = True if show_subtitle_icon in program_subtitle_icon else False
        assert_that(is_contained,
                    f"Program subtitle icon does not match; on UI: {program_subtitle_icon}; "
                    f"expected: {show_subtitle_icon}; screen_dump:\n\n{screen_dump}")

    def verify_available_sources(self, source_icon_list=[], expected=True):
        """
        Verifying if icons of available sources are shown in Guide Header preview

        Args:
            source_icon_list (list): list of available source icons to test;
                                     If None or empty, checking if any icon is shown (also consider expected variable)
            expected (bool): True - source icons should be shown, False - otherwise
        """
        self.log.info(f"Verifying source icons '{source_icon_list}', expected {expected}")
        screen_dump = self.screen.get_json()
        current_source_icons = self.screen.get_screen_dump_item("source-icons", "imagename") if \
            "source-icons" in self.screen.get_screen_dump_item() else []
        # Let's convert from dict to list if there's the only one source icon for further handling list type
        current_source_icons = [current_source_icons["imagename"]] if type(current_source_icons) is dict \
            else current_source_icons
        is_contained_list = []
        for icon_passed in source_icon_list:
            was_found = False
            for icon_ui in current_source_icons:
                if icon_passed in icon_ui:
                    was_found = True
                    break
            if was_found and expected or not was_found and not expected:
                is_contained_list.append(True)
            else:
                is_contained_list.append(False)
        if not source_icon_list:
            if current_source_icons and expected or not current_source_icons and not expected:
                is_contained_list.append(True)
            else:
                is_contained_list.append(False)
        assert_that(all(is_contained_list),
                    f"Source icons does not match; on UI: {current_source_icons}; "
                    f"icons to check: {source_icon_list if source_icon_list else 'any icon'}; expected {expected}; "
                    f"screen_dump:\n\n{screen_dump}")

    def verify_channel_of_highlighted_program_cell(self, channel_number, screen_dump={}):
        """
        :description:
            Verify channel number of highlighted program cell
            Grid Guide Screen
        :params:
            channel_number
        :return:
        """
        self.log.info(f"Verifying channel number for highlighted program cell; expected channel = {channel_number}")
        result = True
        if not screen_dump:
            screen_dump = self.screen.get_json()
        grid_details = self.get_grid_focus_details(screen_dump)
        channel_number_screen = grid_details["channel_number"]
        if channel_number_screen != channel_number:
            result = False
        assert_that(result, "Channel number is not correct; on UI: {}, passed: {}"
                    .format(channel_number_screen, channel_number))

    def verify_channel_name_of_highlighted_program_cell(self, channel_name, screen_dump={}):
        """
        :description:
            Verify channel name of highlighted program cell
            Grid Guide Screen
        :params:
            channel_name
        :return:
        """
        self.log.info(f"Verifying channel name for highlighted program cell; expected channel name = {channel_name}")
        result = True
        if not screen_dump:
            screen_dump = self.screen.get_json()
        grid_details = self.get_grid_focus_details(screen_dump)
        channel_number_screen = grid_details["channel_name"]
        if channel_number_screen != channel_name:
            result = False
        assert_that(result, "Channel name is not correct; on UI: {}, passed: {}"
                    .format(channel_number_screen, channel_name))

    def verify_socu_icon_in_guide_header(self, tester, title):
        self.log.step("Verifying socu icon and show title in guide header")
        self.wait_for_guide_next_page()
        self.wait_for_header_rendering()
        self.screen.refresh()
        source_icon = self.screen.get_screen_dump_item('source-icons', 'imagename')
        program_name = self.remove_service_symbols(self.screen.get_screen_dump_item('program', 'text'))
        title = self.remove_service_symbols(title)
        if isinstance(source_icon, list):
            source_icon = " ".join(source_icon)
        socu_header_icon = self.get_socu_header_icon(tester)
        self.log.info(f"socu_header_icon: {socu_header_icon}")
        assert_that(socu_header_icon in source_icon,
                    f"Expect {socu_header_icon} got {source_icon}")
        assert_that(program_name, equal_to_ignoring_case(title), f"Expect {program_name} got {title}")

    def verify_socu_onlineguide(self, image_name, refresh=True):
        self.log.step("Verify socu icon in OLG")
        self.pause(2)
        if refresh:
            self.screen.get_json()
        menuitem = self.screen.get_screen_dump_item('oneLineGuideTile')

        def _check_image(menuitem, image_name):
            if isinstance(menuitem['imagename'], list):
                for eachitem in menuitem['imagename']:
                    if image_name in eachitem:
                        return True
                else:
                    return False
            elif isinstance(menuitem['imagename'], str):
                if image_name in menuitem['imagename']:
                    return True
                else:
                    return False

        if menuitem:
            image_check = _check_image(menuitem, image_name)
            if not image_check:
                self.log.info("image {} not found. checking image {}".format(image_name,
                                                                             self.guide_labels.LBL_SOCU_FALLBAC_IMG))
                if not _check_image(menuitem, self.guide_labels.LBL_SOCU_FALLBAC_IMG):
                    raise AssertionError("Socu images {}, {} not found".format(image_name,
                                                                               self.guide_labels.LBL_SOCU_FALLBAC_IMG))
        else:
            self.log.info("One line guide is not ready")

    def press_select_verify_resume_overlay(self):
        self.screen.base.long_press_enter()
        self.wait_for_screen_ready()
        self.verify_resume_playing_option()

    def verify_resume_playing_option(self):
        focused_item = self.menu_focus()
        found = False
        if (focused_item == self.guide_labels.LBL_RESUME_PLAYING):
            found = True
        assert_that(found, True)

    def verify_partial_watched_show(self, current_pos1, current_pos2):
        current_position1_sec = self.convert_time_to_sec(current_pos1)
        current_position2_sec = self.convert_time_to_sec(current_pos2)
        assert_that(current_position1_sec, current_position2_sec)

    def verify_default_channel_is_highlighted(self, tester, channel_number):
        self.log.info("Verify default channel position.")
        self.screen.refresh()
        guide = tester.guide_page.return_guide()
        channel_list = tester.guide_page.return_channel_list(guide)
        grid_focused = tester.guide_page.get_grid_focus_details()
        assert_that(grid_focused['channel_number'], contains_string(channel_number), 'Incorrect channel highlighted')
        assert_that(channel_list[0], contains_string(channel_number), 'Incorrect position of a highlighted channel')

    def verify_watch_live_option_on_record_overlay(self, tester):
        found = False
        self.pause(2)
        self.screen.refresh()
        menu_list = self.menu_list()
        watchoptions = [self.guide_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE,
                        self.guide_labels.LBL_CHANNEL_OPTIONS_WATCH_NOW, tester.menu_labels.LBL_WATCH_NOW_FROM_SOCU]
        for item in menu_list:
            if item in watchoptions:
                found = True
        assert_that(found)

    def verify_more_info_option_on_record_overlay(self, tester):
        self.log.info("Asserting for more info option in record overlay")
        menu_list = self.menu_list()
        for item in menu_list:
            if item == tester.menu_page.get_more_info_name(tester):
                return
        raise AssertionError("More info option not found in dump")

    def verify_watch_now_option_on_record_overlay(self):
        self.log.info("Asserting for watch now option in record overlay")
        menu_list = self.menu_list()
        for item in menu_list:
            if item == self.guide_labels.LBL_CHANNEL_OPTIONS_WATCH_NOW:
                return
        raise AssertionError("Watch now option not found in dump")

    def verify_ipppv_feature_is_on_or_off_in_record_overlay(self, expected=True):
        """
        Verifying that there is IPPPV option in the Record overlay
        Args:
            expected (bool): expected feature state on/off
        """
        option_label = self.guide_labels.LBL_RENT_AND_WATCH_NOW_IPPPV
        ipppv_message = self.guide_labels.LBL_UNABLE_TO_GET_PURCHASE_INFO_FOR_PPV_PROGRAM
        self.log.info("Verifying if IPPPV feature is on/off on Record overlay; "
                      f"option_label '{option_label}', ipppv_message '{ipppv_message}', expected {expected}")
        is_ipppv_option_found = self.is_ipppv_option_shown_in_record_overlay(option_label)
        # Warning message is shown on the Record overlay for the programs that were unable to get PPV info
        # Since it also means that IPPPV feature is on, need to check if this message is displayed
        is_ipppv_message = self.is_message_shown_on_record_overlay(ipppv_message)
        current_feature_state = is_ipppv_option_found or is_ipppv_message
        result = False
        if current_feature_state and expected or not current_feature_state and not expected:
            result = True
        screen_dump = self.screen.get_screen_dump_item()
        assert_that(result,
                    "Record Overlay: IPPPV feature is currently {}; expected - {}; screen dump: \n{}"
                    "".format(current_feature_state, expected, screen_dump))

    def verify_non_recordable_label_in_record_overlay(self, message_type, expected=True):
        """
        Verifying that there is or isn't non recordable label on the Record overlay
        Args:
            message_type (str): one of (copyright_restriction, no_watch_or_record, no_record, not_allowed)
            expected (bool): True - checking if message_type is shown on Record Overlay, False - isn't shown
                             Note: if message_type is None, then True - checking if any nDVR label is shown,
                                   False - no any nDVR label on Record Overlay
        """
        copyright_restriction = self.guide_labels.LBL_STATUS_MESSAGE_NDVR_OFFER_RESTRICTION
        no_watch_or_record = self.guide_labels.LBL_NOT_AVAILABLE_TO_WATCH_OR_RECORD
        no_record = self.guide_labels.LBL_NOT_AVAILABLE_TO_RECORD
        not_allowed = self.guide_labels.LBL_STATUS_MESSAGE_NDVR_CHANNEL_RESTRICTION
        msg_list = [copyright_restriction, no_watch_or_record, no_record, not_allowed]
        label_to_check = None
        if message_type == "copyright_restriction":
            label_to_check = copyright_restriction
        elif message_type == "no_watch_or_record":
            label_to_check = no_watch_or_record
        elif message_type == "no_record":
            label_to_check = no_record
        elif message_type == "not_allowed":
            label_to_check = not_allowed
        elif message_type is None:
            label_to_check = "any"
        else:
            raise ValueError(f"Unsupported {message_type} message type")
        self.log.info("Verifying if nDVR message is shown on Record overlay; "
                      f"label to check '{label_to_check}', expected {expected}")
        if label_to_check == "any":
            is_ndvr_message_shown = self.is_message_shown_on_record_overlay(label_to_check)
        else:
            result = []
            for msg in msg_list:
                result.append(self.is_message_shown_on_record_overlay(msg))
            is_ndvr_message_shown = any(result)
        result = False
        if is_ndvr_message_shown and expected or not is_ndvr_message_shown and not expected:
            result = True
        screen_dump = self.screen.get_screen_dump_item()
        assert_that(result,
                    "Record Overlay: nDVR message '{}' is currently {}; expected - {}; screen dump: \n{}"
                    "".format(label_to_check, is_ndvr_message_shown, expected, screen_dump))

    def cancel_one_pass_and_verify(self, tester):
        self.log.step("Cancel one pass and verify")
        tester.guide_page.select_menu(tester.my_shows_labels.LBL_ONE_PASS_OPTIONS)
        self.wait_for_screen_ready()
        self.screen.refresh()
        self.select_menu_by_substring(tester.guide_labels.LBL_CANCEL)
        self.wait_for_screen_ready()
        self.screen.refresh()
        self.select_menu_by_substring(tester.guide_labels.LBL_YES_CANCEL)
        tester.home_assertions.verify_whisper(tester.home_labels.LBL_ONEPASS_WHISPER_CANCEL, False)

    def verify_live_playback(self):
        self.log.step("Verifying Live Playback Status")
        playback = self.wait_for_LiveTVPlayback("PLAYING")
        screen_msg = ""
        if not playback:
            self.screen.get_json()
            try:
                screen_msg = self.get_ui_error()
            except KeyError:
                screen_msg = self.screen.screen_dump
        assert_that(playback, "Failed to playback Live TV!. current screen is {}".format(screen_msg))

    def verify_strip_order(self, expected, actual):
        self.log.info("Verifying strip order")
        for i in range(len(actual)):
            if actual[i] != expected[i]:
                raise AssertionError(f"Not in order. expected: {expected[i]} Actual: {actual[i]}")

    def verify_recording_now_icon(self):
        self.log.info("Verify recording now icon")
        wait_time = 35
        icon_found = False
        while wait_time > 0:
            screen = self.screen.get_json()['xml']
            if 'recording-icon' in screen.keys():
                icon_found = True
                break
            wait_time -= 1
        if not icon_found:
            raise AssertionError('Recording icon not shown.')
        assert_that(screen['recording-icon']['imagename'],
                    contains_string(self.guide_labels.LBL_RECORDING_NOW_ICON),
                    "Invalid icon was shown")

    def verify_onepass_icon(self):
        self.log.info("Verify onepass now icon")
        self.tab_refresh_explicit_recording_icon()
        screen = self.screen.get_json()['xml']
        if 'recording-icon' in screen.keys():
            assert_that(screen['recording-icon']['imagename'], contains_string(self.guide_labels.LBL_ONEPASS_ICON),
                        "Invalid icon was shown")
        else:
            raise AssertionError('Onepass icon not shown.')

    def verify_empty_favorite_channels_list_in_guide(self):
        self.log.info("Verifying that Favorite Channels list is empty.")
        screen = self.screen.get_json()['xml']
        assert_that(screen['text'][0], contains_string(self.guide_labels.LBL_EMPTY_FAVORITE_CHANNELS_TEXT))

    def verify_highlighted_channel_in_one_line_guide(self, channel_number):
        self.log.info("Verify highlighted channel")
        highlighted_channel = self.get_highlighted_channel_number_in_one_line_guide()
        assert_that(highlighted_channel, equal_to(channel_number), "Invalid channel number")

    def verify_highligted_and_next_highlighted_channel_in_one_line_guide(self, channel_number, next_channel_number,
                                                                         up=True):
        """
        Verifying highlighted and next highlighted channel number in One Line Guide

        Args:
            channel_number (int): channel number in currently highlighted row
            next_channel_number (int): channel number in the next row
            up (bool): True - pressing UP after checking currently highlighted channel, False - pressing DOWN
        """
        self.log.info("Verify highlighted channel")
        self.pause(2)
        highlighted_channel = self.get_highlighted_channel_number_in_one_line_guide(refresh=True)
        assert_that(highlighted_channel, equal_to(channel_number), "Invalid channel number")
        if up:
            self.press_up_button(refresh=False)
        else:
            self.press_down_button(refresh=False)
        self.log.info("Verify next highlighted channel")
        next_highlighted_channel = self.get_highlighted_channel_number_in_one_line_guide(refresh=True)
        assert_that(next_highlighted_channel, equal_to(next_channel_number), "Invalid channel number")

    def verify_no_modify_recording_record_overlay_item(self, tester):
        """
        :description:
            Verify that there's no Modify recording menu item in the Record Overlay
            Record Overlay should be open before using the method
        :params:
            tester - instance of a test class
        :return:
        """
        self.log.info("Verify that there's no Modify recording menu item in the Record Overlay")
        self.screen.refresh()
        menu_items = self.menu_list()
        is_not_shown = True
        for item in menu_items:
            if item is not None and tester.guide_labels.LBL_MODIFY_RECORDING in item:
                is_not_shown = False
                break
        assert_that(is_not_shown, "'Modify recording' menu item is shown")

    def verify_is_modify_recording_record_overlay_item(self, tester):
        """
        :description:
            Verify that Modify recording menu item is shown in the Record Overlay
            Record Overlay should be open before using the method
        :params:
            tester - instance of a test class
        :return:
        """
        self.log.info("Verify that Modify recording menu item is shown in the Record Overlay")
        self.screen.refresh()
        menu_items = self.menu_list()
        is_shown = False
        for item in menu_items:
            if item is not None and tester.guide_labels.LBL_MODIFY_RECORDING in item:
                is_shown = True
                break
        assert_that(is_shown, "There's no 'Modify recording' menu item")

    def verify_gallery_screen_and_tiles_order(self, tester, titles, program, strip):
        self.log.info("Verifying Gallery screen")
        self.screen.refresh()
        gallerytitle = strip + ': ' + program
        assert_that(self.view_mode(), is_(tester.vod_labels.LBL_GALLERY_SCREEN_VIEW_MODE))
        assert_that(gallerytitle.upper(), self.screen.get_screen_dump_item('screentitle'))
        assert_that(self.screen.get_screen_dump_item('columnCount'), 3)
        for item in titles:
            title = self.get_preview_panel()['title']
            if item != title:
                assert False
            else:
                self.screen.base.press_right()

    def verify_guide_banner_is_focused(self):
        self.log.info("Verify guide banner is focused")
        self.screen.refresh()
        try:
            banner = self.screen.get_screen_dump_item('GuideBanner')
            if banner is None:
                pytest.skip("Test requires guide banner but banner was not found")
        except KeyError:
            pytest.skip("Test requires guide banner but banner was not found")
        try:
            guide_banner_focus = self.screen.get_screen_dump_item('GuideBanner', 'hasfocus')
        except (KeyError, TypeError):
            guide_banner_focus = False
        if not guide_banner_focus:
            raise AssertionError('guide banner is not focused')

    def verify_guide_cell_icons_on_highlighted_row(self, tester, icon=None, expected=True, screen_dump={}):
        """
        Verifying icon presence/absence on the highlighted Guide Cell.

        Args:
            icon (str): one of (new, ppv, socu_guide_cell, non_recordable),
                        if set, checking only one icon; if None - checking if there's no any icon
            expected (bool): True - checking if icon is displayed, False - checking if there's no icon;
                             if icon param is None, then 'expected' param is forcely set to False
        """
        expected = expected if icon else False
        info_text = f"{icon.upper()} icon" if icon else "if icon is absent"
        self.log.info(f"Verifying {info_text} on Guide Cells; expected {expected}")
        icon_to_find = self.get_icon_name_for_passed_type(tester, icon)
        screen_dump = self.screen.get_json() if not screen_dump else screen_dump
        guide = self.return_guide(screen_dump=screen_dump)
        cell_images = self.get_images_in_focused_guide_row_cell(guide)
        result = self.icon_check(icon_to_find, cell_images, expected)
        shown_icons = f"; shown icons {cell_images}" if not icon else ""
        assert_that(result, f"{icon_to_find + ' icon' if icon else 'some icon(s)'} "
                            f"{'is NOT displayed' if expected else 'is SHOWN'}; expected {expected}"
                            f"{shown_icons}; screen_dump: \n\n{screen_dump}")

    def verify_icon_olg_highilighted_tile(self, tester, icon=None, expected=True, screen_dump={}):
        """
        One Line Guide is expected to be open before calling this method.
        Verifying icon presence/absence on the highlighted OLG tile.

        Args:
            icon (str): one of (new, ppv, socu_guide_header, non_recordable),
                        if set, checking only one icon; if None - checking if there's no any icon
            expected (bool): True - checking if icon is displayed, False - checking if there's no icon;
                             if icon param is None, then 'expected' param is forcely set to False
        """
        expected = expected if icon else False
        info_text = f"{icon.upper()} icon" if icon else "that icon is not present"
        self.log.info(f"Verifying {info_text} on OLG tile; expected {expected}")
        icon_to_find = self.get_icon_name_for_passed_type(tester, icon)
        screen_dump = self.screen.get_json() if not screen_dump else screen_dump
        # Getting images under the OLG tile
        olg_tile = self.screen.get_screen_dump_item("oneLineGuideTile")
        # Let's also get images from the OLG tile itself
        strip_list = self.get_strip_list()
        focused_list_images = []
        for strip in strip_list:
            if strip and strip.get("hasfocus") and strip.get("imagename"):
                if type(strip.get("imagename")) is list:
                    focused_list_images.extend(strip.get("imagename"))
                else:
                    focused_list_images.append(strip.get("imagename"))
        icons_olg_tile = self.screen.get_screen_dump_item("oneLineGuideTile", "imagename") \
            if "imagename" in olg_tile else []
        icons_olg_tile = [icons_olg_tile] if type(icons_olg_tile) is str else icons_olg_tile
        icons_olg_tile.extend(focused_list_images)
        result = self.icon_check(icon_to_find, icons_olg_tile, expected)
        shown_icons = f"; shown icons {icons_olg_tile}" if not icon else ""
        assert_that(result, f"{icon_to_find + ' icon' if icon else 'some icon(s)'} "
                            f"{'is not displayed' if expected else 'is shown'}; expected {expected}"
                            f"{shown_icons}; screen_dump: \n\n{screen_dump}")

    def verify_guide_header_title_icons(self, tester, icon=None, expected=True, screen_dump={}):
        """
        Verifying icon presence/absence on Guide Header preview near title.
        E.g. PPV, NEW, non-recordable and some others

        Args:
            icon (str): one of (new, ppv, socu_guide_header, non_recordable),
                        if set, checking only one icon; if None - checking if there's no any icon
            expected (bool): True - checking if icon is displayed, False - checking if there's no icon;
                             if icon param is None, then 'expected' param is forcely set to False
        """
        expected = expected if icon else False
        info_text = f"{icon.upper()} icon" if icon else "there's no any icon"
        self.log.info(f"Verifying {info_text} on near Guide Header title; expected {expected}")
        icon_to_find = self.get_icon_name_for_passed_type(tester, icon)
        screen_dump = self.screen.get_json() if not screen_dump else screen_dump
        guide_header_prog_data = self.screen.get_screen_dump_item("program")
        icons_guide_header_title = guide_header_prog_data.get(
            "imagename") if "imagename" in guide_header_prog_data else []
        non_recordable = self.screen.get_screen_dump_item("nonrecordablechanneltip", "imagename") if \
            "nonrecordablechanneltip" in self.screen.get_screen_dump_item() else {}
        non_recordable_icon = non_recordable.get("imagename") if "imagename" in non_recordable else None
        if non_recordable_icon:
            icons_guide_header_title.append(non_recordable_icon)
        result = self.icon_check(icon_to_find, icons_guide_header_title, expected)
        shown_icons = f"; shown icons {icons_guide_header_title}" if not icon else ""
        assert_that(result, f"{icon_to_find + ' icon' if icon else 'some icon(s)'} "
                            f"{'is NOT displayed' if expected else 'is SHOWN'}; expected {expected}"
                            f"{shown_icons}; screen_dump: \n\n{screen_dump}")

    def validate_time(self, time):
        time_exist_status = bool(re.match('^ *(1[0-2]|[1-9]):[0-5][0-9] *(a|p|A|P)(m|M) *$', time))
        self.log.info('time_exist_status is:{}'.format(time_exist_status))
        assert_that(time_exist_status, 'True')

    def validate_date(self, date):
        date_existence_status = bool(re.findall(r"[\d]{1,2}/[\d]{1,2}", date))
        self.log.info('date_existence_status is:{}'.format(date_existence_status))
        assert_that(date_existence_status, 'True')

    def validate_channel_number(self, channelno):
        channel_num_exist_status = bool(re.match('([0-9]+)', channelno))
        self.log.info('channel existence status is:{}'.format(channel_num_exist_status))
        assert_that(channel_num_exist_status, 'True')

    def validate_hd_sd_icons(self, icon):
        if isinstance(icon, str):
            icon = list(icon)
        hd_icon_check = self.icon_check(self.guide_labels.LBL_HD_ICON, icon)
        sd_icon_check = self.icon_check(self.guide_labels.LBL_SD_ICON, icon)
        if hd_icon_check:
            self.log.info('HD icon found')
        elif sd_icon_check:
            self.log.info('SD icon found')
        else:
            assert False, "HD or SD icon not present for the program"

    def press_select_and_verify_wtw_screen(self):
        self.log.info("Press select and verify wtw screen")
        self.screen.base.press_enter()
        self.wait_for_screen_ready()
        self.screen.refresh()
        view_mode = self.view_mode()
        assert_that(view_mode, equal_to(self.guide_labels.LBL_WTW_SCREEN_VIEW))

    def ppv_overlay_confirm(self):
        self.log.info("Checking PPV Upsell Overlay")
        ppv_overlay_text = self.screen.get_screen_dump_item('osdtext')
        assert_that(self.guide_labels.LBL_PPV_UPSELL_OVERLAY in ppv_overlay_text)

    def press_select_and_verify_app_running(self, guide_banner):
        """
        :description:
            Presses the select and verifies that the correct application has started
        :params:
            guide_banner - guide banner
        :return:
        """
        self.log.info("Press select and verify app running")
        self.screen.base.press_enter(time=100)
        self.pause(5)
        app_name = re.search(r'\w+\.\w+\.\w+', guide_banner['kernel']['uri'])[0]
        self.log.info("APP NAME from AD's info: {}".format(app_name))
        assert_that(self.screen.base.verify_foreground_app(app_name))

    def verify_catchup_socu_icon_on_program_screen(self, lbl=None):
        self.log.step("Verifying catchup icon in SOCU on program screen")
        imagename = self.get_preview_panel()['previewImage']
        found = False
        icon = lbl if lbl is not None else self.guide_labels.LBL_RECORD_OVERLAY_CATCHUP_ICON
        if isinstance(imagename, list):
            for image in imagename:
                if icon in image:
                    found = True
                    break
        else:
            if icon in imagename:
                found = True
        assert_that(found, "socu icon is not displayed as expected {} - {}".format(imagename, icon))

    def verify_catchup_icon(self, tester):
        self.log.step("Verifying catchup icon in SOCU playback screen")
        self.screen.refresh()
        catchupicon = self.screen.get_screen_dump_item('catchup-icon')
        if catchupicon:
            if tester.menu_labels.LBL_CATCH_UP_ICON not in catchupicon:
                if tester.menu_labels.LBL_SOCU_SOURCE_ICON not in catchupicon:
                    raise AssertionError("Image item {} not found".format(catchupicon))
        else:
            raise AssertionError('Catchup icon not shown.')

    def verify_tuned_channel_is_subscribed_or_not_subscribed(self, tester, channel, start_channel, key=None, count=1):
        self.log.info("Check the tuned channel number as expected channel")
        self.enter_channel_number(start_channel)
        self.wait_for_channel_change()
        if tester.watchvideo_page.get_confirm_jump_channel_overlay_visibility():
            self.select_menu_by_substring(tester.watchvideo_labels.LBL_NEXT_CHANNEL)
        elif start_channel != self.screen.get_screen_dump_item('channel-number'):
            raise AssertionError("Entered Wrong channel number")
        tester.watchvideo_assertions.verify_error_overlay_not_shown()
        if start_channel < channel:
            if key == 'fastforward':
                tester.watchvideo_page.navigate_to_start_of_video()
                self.verify_fast_forward_1(tester)
            elif key == 'rewind':
                self.screen.base.press_rewind()
                self.pause(5)
                self.verify_rewind(1)
            elif key == 'pause':
                self.screen.base.press_playpause()
            for i in range(count):
                tester.guide_page.channel_change(button="channel up")
            if self.osd_shown():
                self.log.info("Highlited unentitled channel")
                return
            if tester.watchvideo_page.get_confirm_jump_channel_overlay_visibility():
                self.select_menu_by_substring(tester.watchvideo_labels.LBL_NEXT_CHANNEL)
                return
            if self.is_overlay_shown():
                overlay_title = self.get_overlay_title()
                if overlay_title is not None and tester.watchvideo_labels.LBL_SUBSCRIPTION_REQUIRED in overlay_title:
                    self.log.info("Into unsubscripted channel")
                    return
            tester.watchvideo_assertions.verify_error_overlay_not_shown()
            self.screen.refresh()
            channel_number = self.screen.get_screen_dump_item('channel-number')
            if channel_number >= channel:
                self.verify_play_normal()
            else:
                raise AssertionError(
                    'Channel Up did not move the channel from "{}" to channel "{}" Actual Channel "{}"'.format(
                        start_channel, channel, channel_number))
        elif start_channel > channel:
            if key == 'fastforward':
                tester.watchvideo_page.navigate_to_start_of_video()
                self.verify_fast_forward_1(tester)
            elif key == 'rewind':
                self.screen.base.press_rewind()
                self.pause(5)
                self.verify_rewind(1)
            elif key == 'pause':
                self.screen.base.press_playpause()
            for i in range(count):
                tester.guide_page.channel_change(button="channel down")
            if self.osd_shown():
                self.log.info("Highlited unentitled channel")
                return
            if tester.watchvideo_page.get_confirm_jump_channel_overlay_visibility():
                self.select_menu_by_substring(tester.watchvideo_labels.LBL_NEXT_CHANNEL)
                return
            if self.is_overlay_shown():
                overlay_title = self.get_overlay_title()
                if overlay_title is not None and tester.watchvideo_labels.LBL_SUBSCRIPTION_REQUIRED in overlay_title:
                    self.log.info("Into unsubscripted channel")
                    return
            tester.watchvideo_assertions.verify_error_overlay_not_shown()
            self.screen.refresh()
            channel_number = self.screen.get_screen_dump_item('channel-number')
            if channel_number <= channel:
                self.verify_play_normal()
            else:
                raise AssertionError(
                    'Channel Down did not move the channel from "{}" to channel "{}" Actual Channel "{}"'.format(
                        start_channel, channel, channel_number))

    def channel_index_value_from_channel_list(self, channel_list, channel):
        x = 0
        for i in channel_list:
            if i == channel:
                break
            else:
                x = x + 1
        return x

    def verify_channel_up_or_down_behaviour_in_one_line_guide(self, tester, channel, channel_up=False):
        self.log.info("Verify channel up/down from one line guide")
        self.open_olg()
        self.enter_channel_number(channel)
        self.log.info("Reopen the one line guide")
        # wait reopen olg as it hided by timeout
        self.wait_for_onelineguide("false")
        self.open_olg()
        self.screen.base.press_left()
        if channel_up:
            self.screen.base.press_channel_up()
            self.wait_for_screen_ready()
            self.log.info("Verify highlighted channel")
            highlighted_channel = self.get_highlighted_channel_number_in_one_line_guide()
            if not highlighted_channel or highlighted_channel < channel:
                raise AssertionError('Channel up is not moved to the Previous channel from OLG')
        else:
            self.screen.base.press_channel_down()
            self.wait_for_screen_ready()
            self.log.info("Verify highlighted channel")
            highlighted_channel = self.get_highlighted_channel_number_in_one_line_guide()
            if not highlighted_channel or highlighted_channel > channel:
                raise AssertionError('Channel down is not moved to the Next channel from OLG')

    def verify_upcoming_menu_episode_screen(self, channel):
        self.log.step("Checking availability of Upcoming or Upcoming airings strip")
        menulist = self.menu_list()
        if self.guide_labels.LBL_UPCOMING_AIRINGS in menulist:
            return self.guide_labels.LBL_UPCOMING_AIRINGS, self.guide_labels.LBL_UPCOMING_AIRINGS_LIST_SCREEN
        elif self.guide_labels.LBL_UPCOMING in menulist:
            return self.guide_labels.LBL_UPCOMING, self.guide_labels.LBL_UPCOMING_EPISODES_LIST_SCREEN
        else:
            assert False, "Neither upcoming nor upcoming airings are present for the program"

    def verify_ip_prefered_channels_after_merge_policy(self, ipchannellist):
        """
        Method to verify after merge policy, IP channels are according to the preference set in channelbits
        :param ipchannellist : list of channel that should be ip according to preference
        """
        for ipchannelnumber in ipchannellist:
            db = "/db/UclDb.sqlite"
            query = f"select * from UclChannel where sourceType=5 and majornumber={ipchannelnumber};"
            query_result = self.screen.base.driver.sqlite_query(db, query)
            if query_result is None:
                raise AssertionError(f'{ipchannelnumber} is QAM and not according to preference')
            else:
                self.log.info(f'{ipchannelnumber} is IP and its according to preference')

    def verify_qam_prefered_channels_after_merge_policy(self, qamchannellist):
        """
        Method to verify after merge policy, QAM channels are according to the preference set in channelbits
        :param qamchannellist : list of channel that should be ip according to preference
        """
        for qamchannelnumber in qamchannellist:
            db = "/db/UclDb.sqlite"
            query = f"select * from UclChannel where sourceType=5 and majornumber={qamchannelnumber};"
            query_result = self.screen.base.driver.sqlite_query(db, query)
            if query_result is None:
                self.log.info(f'{qamchannelnumber} is QAM and its according to preference')
            else:
                raise AssertionError(f'{qamchannelnumber} is IP and not according to preference')

    def verify_guide_header_ads_block(self, tester):
        """
        The method goes to the guide header ads block and verify position of Guide Header within Guide channel list.
        """
        guide_header_list = tester.service_api.get_ads_list()
        if not guide_header_list:
            pytest.skip("Guide banner is not found")
        self.go_to_last_channel(tester)
        guide = self.return_guide()
        guide_row_focus = self.return_guide_row_focus(guide)
        last_channel = guide_row_focus[0]['channelnumber']
        del guide[0]
        count = int(len(guide_header_list) / 8) + 1
        for i in range(count):
            for row in guide:
                if 'guidepromotion' not in row['grid-row'][0].keys():
                    if row['grid-row'][0]['channelnumber'] < last_channel:
                        return
                    else:
                        raise AssertionError("Looks like we navigated NOT to the last channel"
                                             "The next channel is larger than the previous"
                                             "We should be on a last channel in grid to go down "
                                             "and verify guide headers")
            self.screen.base.press_channel_down()
            self.wait_for_guide_next_page()
            guide = self.return_guide()
        raise AssertionError("Channel not found")

    def press_select_verify_ppv_info_overlay(self):
        self.log.step("Verify PPV Info Overlay")
        self.screen.base.press_info()
        self.screen.refresh()
        overlay_mode = self.screen.get_screen_dump_item('overlayMode')
        assert_that(overlay_mode, contains_string(self.guide_labels.LBL_INFO_OVERLAY))

    def press_select_verify_confirm_purchase_overlay(self):
        self.log.step("Verify PPV Purchase Overlay")
        self.screen.base.press_enter()
        self.screen.refresh()
        overlay_title = self.get_overlay_title()
        assert_that(overlay_title, contains_string(self.guide_labels.LBL_PURCHASE_CONFIRM_OVERLAY_TITLE))

    def press_select_verify_ppv_purchase_confirm_overlay(self):
        self.log.step("Verify PPV Purchase Confirm Overlay")
        self.select_menu_by_substring(self.guide_labels.LBL_RENT_FOR)
        self.screen.refresh()
        overlay_title = self.get_overlay_title()
        assert_that(overlay_title, contains_string(self.guide_labels.LBL_PURCHASED_CONFIRMED_TITLE))
        self.screen.base.press_enter()

    def verify_confirm_purchase_overlay_dismiss(self):
        self.log.step("Verify PPV  Confirm Purchase Overlay can be dismissed")
        self.select_menu_by_substring(self.guide_labels.LBL_NO)
        assert_that(self.screen_title(), is_(self.guide_labels.LBL_SCREENTITLE),
                    "Did not  go to Guide screen.")

    def verify_rewind_skip_speed(self, speed):
        self.log.step("Verifying trickplay playback skip speed with rewind mode")
        current_time = self.get_trickplay_current_position_in_sec(self)
        self.log.info("current_time dump value{}".format(current_time))
        if speed == 1:
            waittime = 30
            delay = waittime * 3
            self.pause(waittime)
        elif speed == 2:
            waittime = 20
            delay = waittime * 18
            self.pause(waittime)
        elif speed == 3:
            waittime = 10
            delay = waittime * 60
            self.pause(waittime)
        else:
            self.log.info("Rewind speed is not defined correctly")
        trickplay_dump_time = self.get_trickplay_current_position_in_sec()
        trickplay_expected = current_time - delay - waittime
        self.log.info("Trickplay dump time value{}".format(trickplay_dump_time))
        self.log.info("Trickplay time expected value{}".format(trickplay_expected))
        if trickplay_dump_time in range(trickplay_expected + 30, trickplay_expected - 60):
            self.log.info("Trickplay rewind skip speed validation succeed")
            return
        else:
            assert_that(False, "Failed to validate Trickplay rewind skip speed")

    def verify_forward_skip_speed(self, speed):
        self.log.step("Verifying trickplay playback skip speed with forward mode")
        current_time = self.get_trickplay_current_position_in_sec()
        self.log.info("current_time dump value{}".format(current_time))
        if speed == 1:
            waittime = 30
            delay = waittime * 3
            self.pause(waittime)
        elif speed == 2:
            waittime = 20
            delay = waittime * 18
            self.pause(waittime)
        elif speed == 3:
            waittime = 10
            delay = waittime * 60
            self.pause(waittime)
        else:
            self.log.info("Forward speed is not defined correctly")
        trickplay_dump_time = self.get_trickplay_current_position_in_sec()
        trickplay_expected = current_time + delay + waittime
        self.log.debug("Trickplay dump time value{}, Trickplay time expected value{}".format(trickplay_dump_time,
                                                                                             trickplay_expected))
        if trickplay_dump_time in range(trickplay_expected - 30, trickplay_expected + 60):
            self.log.info("Trickplay forward skip speed validation succeed")
        else:
            raise AssertionError("Failed to validate Trickplay forward skip speed")

    def verify_channel_playback_status(self, status, result, url=None):
        self.log.info("status and result after check: {} - {}".format(status, result))
        assert_that(status, is_(True), f"{result} - Issue obsered on playback of channel. \n {url}")

    def verify_channel_store_response(self, response):
        assert_that(response, is_(True), "Failed to store channel details")

    def verify_default_channel(self, default_channel, tuned_channel):
        assert_that(default_channel, equal_to(tuned_channel), "channel not same actual: '{}', expected: '{}'"
                    .format(tuned_channel, default_channel))

    def verify_audioonly_channel_is_non_recordable(self, audioonlychannelnumber, nonrecordable_channels):
        if nonrecordable_channels:
            if audioonlychannelnumber[0] in nonrecordable_channels:
                self.log.info("Audio only channel is non recordable")
            else:
                raise AssertionError(
                    "Recording is not supported on audio only channel but it is in recordable channel list")
        else:
            raise AssertionError(
                "No Non-recordable channel, Audio only channel is present so non-recordable channel should be there")

    def verify_download_error(self):
        self.log.info("Checking Download  Overlay")
        self.pause(10)
        self.screen.get_json()
        download_overlay_title = self.get_overlay_title()
        assert_that(self.guide_labels.LBL_DOWNLOAD_OVERLAY_TITLE in download_overlay_title)

    def guide_adult_content_is_hidden(self):
        self.log.step("Verifying Title Hidden tile on Favorite Strip")
        self.screen.refresh()
        menuitem = self.screen.screen_dump['xml']['menuitem']
        found = False
        for item in menuitem:
            for value in item['grid-row']:
                if "text" in value.keys() and value['text'] == "Title Hidden":
                    found = True
                    break
            if found:
                break
        if not found:
            raise AssertionError("{} is not displayed.".format("Title Hidden"))

    def verify_socu_playback_status(self, st_pgm, st_status, st_result, cu_pgm, cu_status, cu_result):
        if not isinstance(st_status, str):
            assert_that(st_status, is_(True), f"{st_result} - Issue obsered during startover of program {st_pgm}")
        if not isinstance(cu_status, str):
            assert_that(cu_status, is_(True),
                        f"{cu_result} - Issue obsered during playback of catchup program {cu_pgm}")

    def verify_channel_not_subscribed_osdtext(self, tester):
        self.log.step("Verifying Channel not subscribed OSD text.")
        self.screen.refresh()
        osdtext = self.screen.get_screen_dump_item('osdtext')
        if tester.watchvideo_labels.LBL_CHANNEL_NOT_SUBSCRIBED_OSD_TEXT not in osdtext:
            raise AssertionError("Unable to verify the Unsubscription OSD text")

    def verify_channel_number_in_guide(self, actual_channel_number, refresh=False):
        if refresh:
            self.screen.refresh()
        grid_details = self.get_grid_focus_details()
        self.log.info("Grid details {}".format(grid_details))
        expected_channel_number = grid_details['channel_number']
        assert_that(actual_channel_number, equal_to_ignoring_case(expected_channel_number), "Not as expected")

    def verify_channels_list_mode(self, mode):
        assert_that(self.get_channels_list_mode(), is_(mode))

    def get_channel_index_value_difference_between_channels(self, channel_list, channel1, channel2):
        x = 0
        for i in channel_list:
            if i == channel1:
                break
            else:
                x = x + 1
        y = 0
        for i in channel_list:
            if i == channel2:
                break
            else:
                y = y + 1
        if x < y:
            index = y - x
        else:
            index = x - y
        return index

    def verify_channel_cell_is_highlighted(self):
        self.log.info("Verify that the channel cell is highlighted")
        self.screen.refresh()
        guide = self.return_guide()
        tab_focus = self.get_focused_guide_row_tab(guide_row_xml_part=guide)
        assert_that(tab_focus.get('channelnumber', False),
                    "Channel cell is not highlighted. guid dump: {}".format(guide))

    def verify_thuuz_ratings(self, visible=True):
        self.log.info("Verifying Thuuz Ratings")
        self.wait_for_screen_ready()
        self.screen.refresh()
        screen_dump = self.screen.get_screen_dump_item()
        if visible:
            if screen_dump.get('thuuz-rating', None) is None:
                raise AssertionError("Thuuz Rating is not visible")
        else:
            if screen_dump.get('thuuz-rating', None) is not None:
                raise AssertionError("Thuuz rating is visible")

    def verify_critic_ratings(self, visible=True):
        self.log.info("Verifying Critic Ratings")
        self.wait_for_screen_ready()
        self.screen.refresh()
        previewpane = self.screen.get_screen_dump_item('previewPane')
        if visible:
            if previewpane.get('criticRating', None) is None:
                raise AssertionError("Critic Rating is not visible")
        else:
            if previewpane.get('criticRating', None) is not None:
                raise AssertionError("Critic Rating is visible on Action Page")

    def verify_channellist_based_on_device_mode(self, device_mode):
        db = "/db/UclDb.sqlite"
        query_channelcount = "select count(*) from UclChannel;"
        query_ip_channelcount = "select count(*) from UclChannel where sourceType=5;"
        query_qam_directune_channelcount = "select count(*) from UclChannel where sourceType=2;"
        query_channenid_UclChannel_st2 = "select channelId from UclChannel where sourceType=2;"
        query_channenid_UclDirectTuneNetworkInfo = "select channelId from UclDirectTuneNetworkInfo;"
        channelcount = self.screen.base.driver.sqlite_query(db, query_channelcount)
        ip_channelcount = self.screen.base.driver.sqlite_query(db, query_ip_channelcount)
        qam_directune_channelcount = self.screen.base.driver.sqlite_query(db, query_qam_directune_channelcount)
        channelid_UclChannel_st2 = self.screen.base.driver.sqlite_query(db, query_channenid_UclChannel_st2)
        channenid_UclDirectTuneNetworkInfo = self.screen.base.driver.sqlite_query(
            db, query_channenid_UclDirectTuneNetworkInfo)
        if device_mode == "IP-STB":
            if channelid_UclChannel_st2 == channenid_UclDirectTuneNetworkInfo:
                self.log.info("All channels are either IP or direct tune")
                if int(channelcount[0]) == int(ip_channelcount[0]) + int(qam_directune_channelcount[0]):
                    self.log.info("All Channel count is equal to IP and Direct tune channel")
                else:
                    raise AssertionError(
                        "Channel type apart from IP and direct tune is present in IP only mode which is wrong")
            else:
                raise AssertionError("IP only mode has QAM channels also which is wrong")
        elif device_mode == "HD-STB":
            if channelid_UclChannel_st2 != channenid_UclDirectTuneNetworkInfo:
                if int(ip_channelcount[0]) != 0:
                    self.log.info("Hybrid/Zapper mode has both IP and QAM channels")
                else:
                    raise AssertionError("No ip channels present in hybrid/zapper mode")
            else:
                raise AssertionError("No QAM channel present in hybrid/zapper mode")
        else:
            pytest.skip("Mini mode channel list depends on its DVR device mode so skipping the test")

    def verify_no_record_button_on_guide_info_banner_for_nDVR_restricted_offer(self):
        menuitem = (self.screen.get_screen_dump_item('menuitem'))
        menu_options = []
        for item in menuitem:
            menu_options.append(item.get('text'))
        if self.guide_labels.LBL_PROGRAM_OPTIONS_RECORD_EPISODE in menu_options \
                or self.guide_labels.LBL_RECORD_THIS_MOVIE_INFOCARD in menu_options \
                or self.guide_labels.LBL_RECORD_THIS_SHOW in menu_options:
            raise AssertionError("Record option is available in guide info banner for nDVR restricted offer")
        else:
            assert True, "No record option available in guide info banner for nDVR restricted offer"

    def verify_status_message_in_upcoming_airing_for_nDVR_restricted_offer_in_content_screen(self):
        try:
            preview_pane = self.get_preview_panel()
        except KeyError:
            preview_pane = None
        if preview_pane and 'recordingType' in preview_pane and \
                preview_pane.get('recordingType') == self.guide_labels.LBL_STATUS_MESSAGE_NDVR_OFFER_RESTRICTION and \
                preview_pane.get('recordingIcon') == \
                self.guide_labels.LBL_COMMON_IMAGE_PATH + self.guide_labels.LBL_NON_RECORDABLE_CELL_ICON:
            assert True, "status message shown in " \
                         "upcoming airing for nDVR restricted offer in content screen with proper non-recordable icon"
        else:
            raise AssertionError(
                "No status message shown in upcoming airing for nDVR restricted offer in content screen")

    def verify_status_message_in_guide_info_banner_for_nDVR_restricted_offer(self):
        screen_dump = self.screen.get_json()
        overlaynonrecordable = None
        if 'overlaynonrecordable' in screen_dump['xml']:
            overlaynonrecordable = screen_dump['xml']['overlaynonrecordable']
        if overlaynonrecordable and overlaynonrecordable.get('text') == \
                self.guide_labels.LBL_STATUS_MESSAGE_NDVR_OFFER_RESTRICTION and \
                overlaynonrecordable.get('imagename') == \
                self.guide_labels.LBL_COMMON_IMAGE_PATH + self.guide_labels.LBL_NON_RECORDABLE_ICON:
            assert True, "Status message shown in guide info card for nDVR restricted offer"
        else:
            raise AssertionError("No status message shown in guide info card for nDVR restricted offer")

    def verify_disconnected_program_name(self, ds_program_cell_content):
        """
        :description:
            Verify that real PGD is replaced with "Select to watch <channel>" when service is down.
        :params:
            ds_program_cell_content - program cells content when service is down.
        :return:
        """
        self.log.info("Verifying DS program cell content")
        self.waiting_fail_open()
        program = self.get_focussed_grid_item()
        assert_that(program, contains_string(ds_program_cell_content), 'Program cell content is not "Select to watch "')

    def verify_past_guide_blocked(self, expected=True):
        """
        Args:
            expected (bool): True - checking if transtion to Past Guide is blocked,
                             False - checking if it's possible to go to the Past Guide
        """
        self.log.info(f"Verifying scrolling to the Past Guide is {'blocked' if expected else 'possible'}")
        self.press_left_button(refresh=False)
        self.verify_channel_cell_is_highlighted()
        self.press_left_button(refresh=False, repeat_count=5)
        is_cur_guide = self.is_guide_current()
        result = False
        if is_cur_guide and expected or not is_cur_guide and not expected:
            result = True
        err_msg = "Transitions to Past Guide are not blocked" if expected else "No possibility to go to the Past Guide"
        assert_that(result, err_msg)

    def verify_future_guide_blocked(self, expected=True):
        """
        Args:
            expected (bool): True - checking if transtion to Future Guide is blocked,
                             False - checking if it's possible to go to the Future Guide
        """
        self.log.info(f"Verifying scrolling to the Future Guide is {'blocked' if expected else 'possible'}")
        self.press_right_button(refresh=False, repeat_count=5)
        is_cur_guide = self.is_guide_current()
        result = False
        if is_cur_guide and expected or not is_cur_guide and not expected:
            result = True
        err_msg = "Transitions to Future Guide are not blocked" if expected else "No possibility to go to the Future Guide"
        assert_that(result, err_msg)

    def verify_status_message_in_guide_info_banner_for_nDVR_restricted_channel(self):
        screen_dump = self.screen.get_json()
        overlaynonrecordable = None
        if 'overlaynonrecordable' in screen_dump['xml']:
            overlaynonrecordable = screen_dump['xml']['overlaynonrecordable']
        if overlaynonrecordable and overlaynonrecordable.get('text') == \
                self.guide_labels.LBL_STATUS_MESSAGE_NDVR_CHANNEL_RESTRICTION and \
                overlaynonrecordable.get('imagename') == \
                self.guide_labels.LBL_COMMON_IMAGE_PATH + self.guide_labels.LBL_NON_RECORDABLE_ICON:
            assert True, "Status message shown in guide info card for nDVR restricted channel offer"
        else:
            raise AssertionError("No status message shown in guide info card for nDVR restricted channel offer")

    def verify_record_overlay(self, tester):
        self.screen.refresh()
        overlay_mode = self.screen.get_screen_dump_item('overlayMode')
        assert_that(overlay_mode, contains_string(self.guide_labels.LBL_INFO_OVERLAY))

    def verify_guide_all_channel_option(self, tester):
        tester.home_page.go_to_guide(tester)
        tester.guide_page.wait_for_screen_ready("GridGuide")
        tester.guide_assertions.verify_guide_title()
        if tester.guide_page.get_channels_list_mode() != 'all channels':
            if not tester.guide_page.is_menu_list():
                tester.guide_page.press_ok_button()
            else:
                tester.guide_page.switch_channel_option("All")
        self.pause(5)
        tester.guide_assertions.verify_channels_list_mode('all channels')

    def validate_uhd_icons(self, icon):
        if isinstance(icon, str):
            icon = list(icon)
        uhd_icon_check = self.icon_check(self.guide_labels.LBL_UHD_ICON, icon)
        if uhd_icon_check:
            self.log.info('UHD icon found')
        else:
            assert False, "UHD icon not present for the program"

    def verify_uhd_icon_in_guide_cell(self):
        self.log.step("Verifying UHD icon is displayed in Guide ")
        self.wait_for_screen_ready()
        self.screen.get_json()
        assert self.guide_labels.LBL_UHD_ICON in self.get_channel_format(), "There is no UHD Icon for the 4K channel"

    def verify_bookmark_present(self, bookmark):
        self.log.info("Verifying Bookmark option present in screen")
        found = False
        self.verify_menu_list(bookmark, mode="none_item_presence")
        menu_list = self.menu_list()
        for item in menu_list:
            if bookmark in item:
                self.log.info(f"{bookmark} option found")
                found = True
        return found

    def verify_new_live_icon(self, items):
        if isinstance(items, dict):
            self.validate_hd_sd_icons(items.get('imagename'))
            new_icon_check = self.icon_check(self.guide_labels.LBL_NEW_ICON, items.get('imagename'))
            live_icon_check = self.icon_check(self.guide_labels.LBL_LIVE_ICON, items.get('imagename'))
        else:
            self.log.info('items:{}'.format(items[0]['imagename']))
            self.validate_hd_sd_icons(items[0]['imagename'])
            new_icon_check = self.icon_check(self.guide_labels.LBL_NEW_ICON, items[0]['imagename'])
            live_icon_check = self.icon_check(self.guide_labels.LBL_LIVE_ICON, items[0]['imagename'])
        if new_icon_check:
            self.log.info('New icon found')
        if live_icon_check:
            self.log.info('Live icon found')

    def verify_upcoming_airings_screen(self, tester):
        self.log.info("Verifyig Upcoming Airings screen view")
        self.screen.refresh()
        items = self.screen.get_screen_dump_item('menuitem')
        date_of_show = self.get_date_of_show(items)
        time_of_show = self.get_time_of_show(items)
        title_of_show = self.get_title_of_show(items)
        channel_number = self.channel_number(items)
        if isinstance(items, dict):
            if len(items.get('text')) > 4:
                series_episode = items.get('text')[4]
                tester.home_assertions.validate_seriesname(series_episode)
        else:
            if len(items[0]['text']) > 4:
                series_episode = items[0]['text'][4]
                tester.home_assertions.validate_seriesname(series_episode)
        self.verify_new_live_icon(items)
        tester.home_assertions.validate_episodetitle(title_of_show)
        self.validate_time(time_of_show)
        self.validate_date(date_of_show)
        self.validate_channel_number(channel_number)

    def verify_show_in_guide(self, show):
        found = False
        tries = 0
        while tries < 10:
            self.pause(1)
            self.screen.refresh()
            menu = (self.screen.get_screen_dump_item('menuitem'))
            for item in menu:
                for content in item['grid-row']:
                    if 'text' in content and (content['text'] in show or show in content['text']):
                        found = True
                        break
            if found:
                break
            press_down_number = 8
            while press_down_number > 0:
                self.screen.base.press_down()
                press_down_number -= 1
            tries += 1
        if not found:
            raise AssertionError(f"Show item '{show}' not found")

    def smart_verify_guide_service_down_whisper(self, is_olg=False):
        """
        Smart verification if Guide service down whisper is shown. This whipser is shown for about 5 seconds.

        Args:
            is_olg (bool): True - checking fail open in OLG, False - checking fail open in Grid Guide
        """
        info_msg = "One Line Guide" if is_olg else "Grid Guide"
        self.log.info(f"Smart verification of disconnected Guide service whisper in {info_msg}")
        self.waiting_fail_open(is_wait_fail_open=False, is_olg=is_olg)
        raise_error = False if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_18) else True
        self.verify_whisper(self.guide_labels.LBL_WHISPER_OLG_DISCONNECTED_GUIDE_SERVICE,
                            visible=True, raise_error=raise_error)

    def verify_olg_tile_count(self, expected_count=1):
        """
        Verifying One Line Guide tile count.

        Args:
            expected_count (int): expected tile count
        """
        self.log.info(f"Verifying if tiles count is {expected_count} in a row in OLG")
        strip_list = self.get_strip_array()
        tile_cnt = len(strip_list)
        assert_that(tile_cnt, equal_to(expected_count), f"{expected_count} tiles in the row expected; current count: "
                                                        f"{tile_cnt}")

    def verify_olg_tiles_with_disconnected_service(self, tile_text, expected_count=1, up_times=1, is_disconnect=False):
        """
        Verifying One Line Guide tiles in a row:
         - Tile count
         - Tile subtitle

        Args:
            tile_text (str): text located in the bottom of the tile (call sign is added automatically if is_disconnect=False)
            expected_count (int): expected tile count
            up_times (int): times to scroll up in the One Line Guide
            is_disconnect (bool): True - service is disconnected, False - service connected;
                                  if there's no connection to service, channel call sign is added to tile bottom text
                                  or channel number if call sign is not present, such behavior available since Hydra v1.15
        """
        self.log.info(f"Verifying OLG tile; tile_text '{tile_text}', expected_count {expected_count}, "
                      f"up_times {up_times}, is_disconnect {is_disconnect}")
        for i in range(up_times):
            self.waiting_fail_open(is_olg=True)
            self.verify_olg_tile_count(expected_count)
            row_ch_num = self.get_olg_channel_number_of_highlighted_row()
            row_ch_call_sign = self.get_olg_channel_call_sign_of_highlighted_row()
            suffix = row_ch_call_sign if row_ch_call_sign else row_ch_num
            check_text = tile_text if not is_disconnect else tile_text + " " + suffix
            check_text = tile_text  # workaround due to a defect
            self.verify_olg_tile_subtitle(check_text)
            self.press_up_button(refresh=False)

    def verify_olg_tile_subtitle(self, tile_text):
        """
        Verfiying tile subtitle text (usually, it's located in the bottom of a highlighted tile) in One Line Guide.
        Usually, it's a show name for episodic programs and some others.

        Args:
            tile_text (str): text located in the bottom of the tile
        """
        self.log.info(f"Verifying if '{tile_text}' subtitle is shown on a tile in OLG")
        tile_subtitle_actual = self.get_olg_tile_subtitle()
        assert_that(tile_subtitle_actual, contains_string(tile_text),
                    "OneLineGuide's tile subtitle text does not match; "
                    f"expected: {tile_text}, actual: {tile_subtitle_actual}")

    def verify_ppv_purchase_confirmed_overlay_purchase_pin(self):
        self.log.step("Verify PPV Purchase Confirmed Overlay")
        self.screen.refresh()
        overlay_title = self.get_overlay_title()
        assert_that(overlay_title, contains_string(self.guide_labels.LBL_PURCHASED_CONFIRMED_TITLE))

    def verify_channel_not_present(self, channel_number, screen_dump={}):
        """
        :description:
            Verify channel not available in guide
            Grid Guide Screen
        :params:
            channel_number
        :return:
        """
        self.log.info(f"Verifying channel number not present in guide; expected channel = {channel_number}")
        result = True
        if not screen_dump:
            screen_dump = self.screen.get_json()
        grid_details = self.get_grid_focus_details(screen_dump)
        channel_number_screen = grid_details["channel_number"]
        if channel_number_screen != channel_number:
            self.log.info(f" highlighted channel is {channel_number_screen}, channel number {channel_number} "
                          f"not found in Guide")
        else:
            assert_that(result, "Channel still present in Guide: {}, passed: {}".format(channel_number_screen,
                                                                                        channel_number))

    def verify_action_kernel_type(self, offer_id, mode='offer', expected_action_kernel_type=''):
        """
        Verifying Action Kernel Type from v1/action/offer or content or series.

        Args:
            offer_id (str): offer or content or series id
            mode (str): may be offer or content or series id
            expected_action_kernel_type (str): expected action_kernel_type
        """
        actual_action_kernel_type = self.service_api.get_actions_offer(offer_id, mode).kernel['actionKernelType']
        assert_that(actual_action_kernel_type, expected_action_kernel_type, 'Action Kernel Type is not correct')

    def verify_guide_focussed_cell_when_service_blocked_and_unblocked(self, blocked=False):
        focussed_text = self.get_focussed_grid_item()
        self.log.info("grid details: {}".format(focussed_text))
        if not blocked and self.guide_labels.LBL_SELECT_WATCH_CHANNEL in focussed_text:
            raise AssertionError("Guide service not blocked.Still failed to load guide data in cell:{}".format(focussed_text))
        try:
            if blocked and self.guide_labels.LBL_SELECT_WATCH_CHANNEL not in focussed_text:
                raise AssertionError("Failed to block guide service. Focussed cell text: {}".format(focussed_text))
        except AssertionError:
            pytest_current_test = os.getenv("PYTEST_CURRENT_TEST", "cd_temp_loc").split(":")[-1]
            tc_name = re.sub(r'(?u)[^-\w.]', '', pytest_current_test)
            since_str = 'TEST_CASE_START: ' + tc_name
            if blocked and not self.screen.base.find_str_in_log(self.guide_labels.LBL_ISSUE_GUIDE, since=since_str):
                raise AssertionError("Failed to get {} in adb logs as well. Guide service failed to block: {}"
                                     .format(self.guide_labels.LBL_ISSUE_GUIDE, since_str))
