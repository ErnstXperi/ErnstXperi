class CBTGuideLabels():
    LBL_RECORD_OVERLAY_CATCHUP_ICON = LBL_SOCU_SOURCE_ICON_HEADER = "altav2_fioptics_image_socu_branding_live_tv"
