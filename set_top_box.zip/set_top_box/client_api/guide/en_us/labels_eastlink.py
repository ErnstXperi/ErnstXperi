class EastlinkGuideLabels():
    LBL_EPG_PAST_NUMBER_OF_HOURS = 30
    LBL_RECORD_OVERLAY_CATCHUP_ICON = "eastlink_icon_source_socu"
    LBL_SOCU_SOURCE_ICON_HEADER = "eastlink_icon_source_socu"
