import pytest

from set_top_box.client_api.service_properties.assertions import ServicePropertiesAssertions
from tools.logger.logger import Logger
from set_top_box.test_settings import Settings


__logger = Logger(__name__)


@pytest.fixture(autouse=True, scope="class")
def setup_service_properties(request):
    """
    Configure steps to be executed before the test cases run
    :param request:
    :return:
    """
    request.cls.service_properties_assertions = ServicePropertiesAssertions(request.cls.screen)
