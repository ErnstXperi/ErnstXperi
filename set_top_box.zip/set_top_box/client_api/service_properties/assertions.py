import re
import os
import yaml

import pytest
from hamcrest.core import assert_that
from hamcrest import equal_to

from tools.logger.logger import Logger
from core_api.stb.assertions import CoreAssertions


class ServicePropertiesAssertions(CoreAssertions):
    __logger = Logger(__name__)

    def verify_wanipaddress_is_found_in_logs(self, ipaddress):
        raw_log = self.screen.base.find_str_in_log(string=ipaddress)
        if raw_log:
            self.log.step("wanipaddress found")
        else:
            raw_log = self.screen.base.find_str_in_log(string="onMyWanIpAddressGetResponse")
            self.log.info("raw_log is: {}".format(raw_log))
            if raw_log is None:
                raw_log = self.screen.base.find_str_in_log(string="IPAddressRequest")
                self.log.info("raw_log is: {}".format(raw_log))
            ipaddress_adb = raw_log[1]
            self.log.info("ipaddress_adb is: {}".format(ipaddress_adb))
            if ipaddress_adb:
                self.log.info("wanipaddress is present in adb logs and is not none.")
            else:
                raise AssertionError("wanipaddress is not found in adb logs")

    def verify_usage_of_open_api(self):
        open_api_log = self.screen.base.find_str_in_log(string="/v1/uiActions/feedItems/")
        if open_api_log:
            self.log.info("OpenApi is being used here.")
        else:
            raise AssertionError("Morpheus API is called. Open API is not used here.")
