from hamcrest import *
from core_api.stb.assertions import CoreAssertions
from set_top_box.client_api.text_search.page import TextSearchBase
from set_top_box.client_api.text_search.en_us.labels import TextSearchLabels
from set_top_box.shared_context import ExecutionContext


class TextSearchAssertions(TextSearchBase):
    text_search_labels = TextSearchLabels()

    def verify_search_text_entry(self, search_text):
        assert_that(self.get_text_search_value(), equal_to(search_text + "_"))

    def verify_search_result(self, result):
        '''
        Apppend first 10 search result and search item in that
        :param result:
        :return:
        '''
        search_list = []
        list_length = len(self.text_search_result_list())
        article_list = ['The ', 'An ', 'A ']
        for article in article_list:
            if result[0:len(article)] == article:
                result = result[(len(article) + 1):len(result)]
                result.strip()
                break
        self.log.info("Searching {} in Search Result List".format(result))
        limit = list_length if list_length <= 10 else 10
        raw_list = self.text_search_result_list()
        for i in range(0, limit):
            if raw_list[i]:
                search_list.append(raw_list[i].replace("&lt;/font&gt;", '').replace('&lt;font color="#009FDE"&gt;', '')
                                   .replace('Ã±', 'n').replace('Ãº', 'u').replace('Ã³', 'o').replace('Ã­', 'i')
                                   .replace('Ã©', 'e').replace('Ã¼', 'u').replace('Ã¡', 'a').replace('ñ', 'n')
                                   .replace('&', 'AND'))

        assert_that(search_list, has_item(contains_string(result)))

    def verify_search_screen_title(self):
        self.log.info('Verifying search screen title')
        self.verify_screen_title("SEARCH")

    def verify_person_titlescreen(self, person):
        self.log.step(f"Verifying person screen title for {person}")
        self.screen.refresh()
        assert_that(self.screen.get_screen_dump_item('screentitle'), equal_to_ignoring_case(person))

    def verify_ott_icon(self):
        self.log.step("Verifying OTT icon existence")
        self.screen.refresh()
        assert_that(self.get_preview_panel()['availableOn'])

    def verify_movie_screen(self, tester):
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_MOVIE_SCREEN, 15000)
        self.verify_view_mode(tester.my_shows_labels.LBL_ACTION_SCREEN_VIEW)

    def verify_record_overlay(self, tester):
        state = self.wait_for_screen_ready(tester.guide_labels.LBL_RECORDING_OPTIONS_OVERLAY, 30000)
        assert_that(state)

    def verify_explicit_recording_from_search(self, tester, program, menu_option):
        if menu_option is tester.guide_labels.LBL_LIVE_AND_UPCOMING:
            self.log.step("Verifying availability of recording in My Shows")
            tester.home_page.go_to_my_shows(tester)
            self.menu_navigate_left_right(1, 0)
            self.screen.refresh()
            self.select_menu(tester.my_shows_labels.LBL_SERIES_RECORDINGS)
            self.screen.refresh()
            menu = self.menu_list()
            if isinstance(menu[0], str):
                try:
                    item = eval(menu[0])[0]
                except SyntaxError:
                    item = menu[0]
            else:
                item = menu[0][0]
        else:
            self.log.step("Verifying availability of recording in ToDo List")
            tester.home_page.back_to_home_short()
            tester.home_page.select_menu_shortcut(tester.home_labels.LBL_MENU_SHORTCUT)
            self.nav_to_top_of_list()
            tester.menu_page.go_to_to_do_list(tester)
            self.screen.refresh()
            menu = self.menu_list()
            item = menu[0]
        if program != item:
            raise AssertionError("Program not available in list. Expected: {}, Actual: {}".format(program, item))

    def verify_preview_pane(self):
        self.log.info("Verifying existence of preview title and description")
        pane = self.get_preview_panel()
        if pane['title'] and pane['description']:
            assert True
        else:
            assert False

    def verify_program_availablity_under_myshows_folder(self, tester, program, folder):
        # this api might require a modification after the bug fix https://jira.tivo.com/browse/PARTDEFECT-1057
        self.screen.refresh()
        menulist = self.menu_list()
        self.log.info(f"menulist for folder {folder}: {menulist}")
        for menu in menulist:
            if folder == tester.my_shows_labels.LBL_MY_SHOWS_STREAMING_MOVIES:
                preview = self.get_preview_panel()
                if 'releaseYear' in preview:
                    title = preview['title'] + " " + preview['releaseYear']
                else:
                    title = preview['title']
            else:
                title = menu
            self.log.info(f"comparing {program.upper()} to {title.upper()}")
            if program.upper() == title.upper():
                self.log.info(f"{program} found under {folder} folder")
                return
            if self.view_mode() != tester.vod_labels.LBL_EPISODE_SCREEN_VIEW_MODE:
                self.screen.base.press_right()
            else:
                self.screen.base.press_down()
            self.screen.refresh()
        raise AssertionError("Bookmarked Movie {} is not listed under {}".format(program, folder))

    def verify_empty_search_result_on_search_screen(self):
        self.log.step("Verifying Empty Search result on Search screen.")
        menu_text = self.screen.get_screen_dump_item('menuitem', 'text')
        assert_that(menu_text, contains_string(self.text_search_labels.LBL_EMPTY_SEARCH_MESSAGE))

    def verify_foreground_app_or_google_play(self, expected_foreground_app_package_name):
        self.log.step(f"Verifying if foreground app is {expected_foreground_app_package_name} or google play")
        # wait for transition to another foreground app to happen
        self.pause(5)
        app_on_foreground_found = self.screen.base.verify_foreground_app(expected_foreground_app_package_name)
        google_play_on_foreground_found = self.screen.base.verify_foreground_app(
            self.text_search_labels.GOOGLE_PLAY_PACKAGE_NAME)
        # sometimes instead of com.android.vending ActivityManager shows com.android.vending.inlinedetails
        gp_id_foreground_found = self.screen.base.verify_foreground_app(
            self.text_search_labels.GOOGLE_PLAY_PACKAGE_NAME_INLINE_DETAILS)
        gp_inline_pack = self.text_search_labels.GOOGLE_PLAY_PACKAGE_NAME_INLINE_DETAILS
        self.log.info(
            f"Is {expected_foreground_app_package_name} foreground: {app_on_foreground_found}")
        self.log.info(
            f"Is {self.text_search_labels.GOOGLE_PLAY_PACKAGE_NAME} foreground: {google_play_on_foreground_found}")
        self.log.info(
            f"Is {gp_inline_pack} foreground: {gp_id_foreground_found}")
        if not (app_on_foreground_found or google_play_on_foreground_found or gp_id_foreground_found):
            raise AssertionError(f"Neither Play Market nor App {expected_foreground_app_package_name} was found on foreground")

    def press_select_and_verify_app_is_not_hydra(self, tester, enter=True):
        self.log.step("Press select and verifying that the background app is not Hydra")
        if enter:
            self.screen.base.press_enter(time=5000)
        self.wait_for_screen_ready()
        app_package = tester.api.settings.app_package
        foreground_app = self.screen.base.get_foreground_package()
        if app_package == foreground_app:
            raise AssertionError("Neither OTT App was found on foreground. Foreground app is {}".format(foreground_app))

    def verify_ui_and_open_api_response_match_for_may_also_like(self):
        ui_response = self.screen.get_screen_dump_item()
        open_api_response = ExecutionContext.mind_if.\
            open_api.may_also_like_open_api_collection_search("Movie", "Doomsday", "Danny's Doomsday")
        list_titles_open_api_may_also_like = []
        if not ui_response:
            raise AssertionError("Failed to get {} Open API response".format(ui_response))
        title_ui_may_also_like = self.get_preview_panel()["title"]
        if not open_api_response:
            raise AssertionError("Failed to get {} Open API response".format(open_api_response))
        for may_also_like_open_api_response in open_api_response.feed_items:
            if may_also_like_open_api_response["feedItemType"] == self.text_search_labels.LBL_MOVIE_FEED_ITEM_TYPE:
                list_titles_open_api_may_also_like.append(may_also_like_open_api_response["title"])
        assert_that(title_ui_may_also_like, is_in(list_titles_open_api_may_also_like))
