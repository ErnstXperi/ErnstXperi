class TextSearchLabels:
    LBL_EMPTY_SEARCH_MESSAGE = "There are no matching shows, movies, videos, or people."
    LBL_PERSON_SCREEN = "PersonScreen"
    LBL_EPISODE_SCREEN = "EpisodeScreen"
    LBL_IC_MORE_INFO_OPTION = "See More Info"
    LBL_WATCH_NOW = "Watch Now"
    LBL_IC_OPTIONS_OPT = "Options"
    LBL_SEARCH_SCREEN_VIEW_NAME = 'search.SearchScreenView'
    GOOGLE_PLAY_PACKAGE_NAME = "com.android.vending"
    # sometimes instead of com.android.vending ActivityManager shows com.android.vending.inlinedetails
    GOOGLE_PLAY_PACKAGE_NAME_INLINE_DETAILS = "com.android.vending.inlinedetails"
    LBL_SEARCH_TEXT_STRING = "MUSIC CHOICE"
    LBL_EXPECTED_SEARCH_STRING = "Music Choice Hip-Hop Classics"
    LBL_MOVIE_FEED_ITEM_TYPE = "Movie"
