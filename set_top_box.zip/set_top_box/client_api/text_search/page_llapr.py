from core_api.stb.assertions import CoreAssertions
from test_settings import Settings
from tools.logger.logger import Logger
import os
from set_top_box.client_api.text_search.page import TextSearchBase as DefaultSearchPg
import time


class LLATextSearchPage(DefaultSearchPg):
    __logger = Logger(__name__)

    def input_search_text(self, search_text):
        self.log.info("Entering Search text override :{}".format(search_text))
        self.screen.base.press_clear()
        self.screen.base.type_text(search_text)
        time.sleep(5)
        self.screen.refresh()
