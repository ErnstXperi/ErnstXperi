import time
import re

import pytest

from core_api.stb.assertions import CoreAssertions
from set_top_box.client_api.text_search.en_us.labels import TextSearchLabels
from set_top_box.test_settings import Settings
from set_top_box.client_api.home.en_us.labels import HomeLabels
from set_top_box.conf_constants import HydraBranchVersion, HydraBranches


class TextSearchBase(CoreAssertions):
    text_search_labels = TextSearchLabels()
    home_labels = HomeLabels()
    year_template = re.compile(r" \(\d{4}\)")
    clean_template = re.compile(r"&lt.*?&gt;")

    def input_search_text(self, search_text):
        search_text = self.replace_spanish_chars(search_text)
        self.log.info("Entering Search text: {}".format(search_text))
        self.clear_search_text()
        self.input_text_search(search_text)
        time.sleep(5)
        self.screen.refresh()

    def replace_spanish_chars(self, search_text):
        """
        api to replace english chars to spanish chars
        NOTE: please do not change the order of chars in list
        """
        spanish_chars = ["Á", "É", "Í", "Ñ", "Ó", "Ú", "Ü", "á", "é", "í", "ñ", "ó", "ú", "ü"]
        english_chars = ["A", "E", "I", "N", "O", "U", "U", "a", "e", "i", "n", "o", "u", "u"]
        for i in range(len(spanish_chars)):
            search_text = re.sub(spanish_chars[i], english_chars[i], search_text)
        return search_text

    def delete_reenter(self):
        self.delete_last_character()
        self.screen.refresh()
        self.input_text_search("N")
        time.sleep(5)
        self.screen.refresh()

    def is_textpad_focus(self, text_grid=[]):
        focus = False
        if not text_grid:
            text_grid = self.return_text_grid()
        for letter_dict in text_grid:
            if 'hasfocus' in letter_dict.keys():
                focus = True
        return focus

    def move_focus_to_textpad(self):
        if not self.is_textpad_focus():
            self.log.info("TextPad not focused, moving focus")
            self.menu_navigate_left_right(5, 0)
        self.screen.get_json()

    def return_textpad_focus(self, text_grid=[]):
        focused = False
        focused_letter = {}
        if text_grid == []:
            text_grid = self.return_text_grid()
        focused = self.is_textpad_focus(text_grid=text_grid)
        if focused:
            for letter_dict in text_grid:
                if 'hasfocus' in letter_dict.keys():
                    focused_letter = letter_dict
                    break
        else:
            raise AssertionError('selector focus not in text grid')
        return focused_letter

    def nav_to_results(self, screen={}):
        self.log.step("Navigating to search results section")
        letter_focus = self.return_textpad_focus(text_grid=self.return_text_grid(screen=screen))
        col_focus = int(letter_focus['col'])
        self.menu_navigate_left_right(col_focus, 5)
        self.pause(2)

    def cleanup_search_result(self, search_text):
        self.log.info(f"Cleaning up search text:{search_text}")
        search_text = TextSearchBase.clean_template.sub("", search_text)
        return_text = search_text.replace(u'â\x80\x98', u'').replace(  # added to remove single quote symbol
            'â€˜', '')
        return_text = return_text.strip()
        self.log.info('cleaned up text {}: {}'.format(search_text, return_text))
        return return_text

    def preprocess_input(self, expected_text):
        article_list = ['The', 'An', "A"]
        self.log.info(f"Handling articles from search text:{expected_text}")
        if isinstance(expected_text, list):
            return f"{self.preprocess_input(expected_text[0])}: {expected_text[1]}"
        article_found = False
        # As a rule, the 1st occurrence of ':' means it's an end of a series title.
        # But some movies can have ':' sometimes too, so need to check if the title has '($year)' first
        movie_yr = re.search(r"\([0-9]{4}\)$", expected_text)
        if movie_yr:
            index = expected_text.rfind("(")
        else:
            index = expected_text.index(":") if expected_text.find(":") != -1 else -1
        part1 = expected_text[0:index].strip() if index > 0 else expected_text.strip()
        part2 = expected_text[index:len(expected_text)].strip() if index > 0 else ""
        for article in article_list:
            if part1[0:len(article) + 1] == article + ' ':
                space_after_article = " " if movie_yr else ""
                part1 = part1[(len(article) + 1):len(part1)] + ', ' + article + space_after_article
                expected_text = part1 + part2
                self.log.info("Expected Search Text is {}".format(expected_text))
                article_found = True
            if article_found:
                break
        return expected_text

    def remove_article(self, text):
        self.log.info(f"Removing articles from text:{text}")
        text = re.sub('ñ', 'n', text)
        newtext = re.sub('[&]', '', text)
        article_list = ['The', 'An', "A"]
        items = newtext.split(" ")
        if items[0] in article_list:
            return " ".join(items[1:])
        self.log.info(f"Search text after removing articles:{newtext}")
        return newtext

    def search_and_select(self, search_text, expected_text, max_attempts=2, select=True, watch_now=False, **kwargs):
        """
        Searching and selecting one of the found items

        Args:
            search_text (str): text for searching
            expected_text (str): text to compare to
            max_attempts (int): attemps to take screen dump again if menulist (search results list) is empty
            select (bool): if search result selection needs to be performed.
                           Note, that since Hydra v1.11 open_program_screen() is called when the param is True
            **kwargs:
                clear (bool): if input text clearing needs to be performed, True by default
                year (int): movie year, expected text will look like movie_title (year), if provided
        """
        self.log.step("Searching for {}".format(search_text))
        search_text = self.convert_special_chars(search_text)
        expected_text = self.convert_special_chars(expected_text)
        if TextSearchBase.year_template.search(search_text):
            search_text = TextSearchBase.year_template.sub("", search_text)
        if kwargs.get('clear', True):
            self.clear_search_text()
        if not Settings.is_apple_tv() and not Settings.is_dev_host():
            self.type_search_text(search_text=self.remove_article(search_text))
        else:
            self.input_text_search(search_text=self.remove_article(search_text))
        if kwargs.get('year'):
            year = kwargs['year']
            expected_text = "{} ({})".format(expected_text, str(year))
        expected_text = self.preprocess_input(expected_text)
        self.log.info("Selecting Search String : {}".format(expected_text))
        self.wait_loading_indicator_disappear()
        self.pause(3)
        self.screen.refresh()
        list = self.is_menu_list()
        if not list:
            cur_attempts = 0
            while not list:
                self.pause(3)
                self.screen.refresh()
                list = self.is_menu_list()
                cur_attempts += 1
                if cur_attempts >= max_attempts:
                    break
        if not list:
            raise AssertionError('search results not displayed')
        else:
            cleanup_list = []
            menu_list = self.menu_list()
            for text_item in menu_list:
                cleanup_list.append(self.cleanup_search_result(text_item).encode("iso8859").decode("utf8"))
            if expected_text in cleanup_list:
                self.nav_to_results()
                self.screen.refresh()
                focus_index = self.return_menu_focus_index()
                expected_index = cleanup_list.index(expected_text)
                self.menu_navigate_up_down(focus_index, expected_index)
                self.screen.refresh()
                focused_itm = self.get_current_item()
                self.log.info("Focus is on {} program being searched".format(focused_itm))
                if focused_itm != expected_text:
                    self.log.info("Fallback behaviour some presses were missed")
                    focus_index = self.return_menu_focus_index()
                    expected_index = cleanup_list.index(expected_text)
                    self.menu_navigate_up_down(focus_index, expected_index)
                if select:
                    self.log.info("selecting {} from search result list".format(expected_text))
                    if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_11):
                        # Preserving old behavior when the Program Screen opened after selecting
                        # a search result item, with https://jira.tivo.com/browse/IPTV-14925 playback may start
                        focussed_menu = self.image_focus()
                        self.log.info("focussed menu: {}".format(focussed_menu))
                        if focussed_menu is not None and self.home_labels.LBL_PERSON_ICON in focussed_menu:
                            self.screen.base.press_enter()
                        else:
                            self.open_program_screen(watch_now)
                    else:
                        self.screen.base.press_enter(2000)
                return
            if expected_text not in cleanup_list:
                self.menu_navigate_left_right(0, 5)
                cur_scroll = 0
                while cur_scroll < 50:
                    self.screen.refresh()
                    if cur_scroll == 0:
                        focus_index = self.return_menu_focus_index()
                        cur_last_list = cleanup_list[-1]
                        expected_index = cleanup_list.index(cur_last_list)
                        self.menu_navigate_up_down(focus_index, expected_index)
                    elif cur_scroll > 0:
                        focus_index = cleanup_list.index(cur_last_list)
                        cur_last_list = cleanup_list[-1]
                        expected_index = cleanup_list.index(cur_last_list)
                        self.menu_navigate_up_down(focus_index, expected_index)
                    time.sleep(4)
                    self.screen.refresh()
                    menu_list_loop = self.menu_list()
                    for text_item_1oop in menu_list_loop:
                        if self.cleanup_search_result(text_item_1oop) not in cleanup_list:
                            cleanup_list.append(self.cleanup_search_result(text_item_1oop))
                    if expected_text in cleanup_list:
                        focus_index = cleanup_list.index(cur_last_list)
                        expected_index = cleanup_list.index(expected_text)
                        self.menu_navigate_up_down(focus_index, expected_index)
                        self.screen.refresh()
                        focused_itm = self.get_current_item()
                        self.log.info("Focus is on {} program being searched".format(focused_itm))
                        if focused_itm != expected_text:
                            self.log.info("Fallback behaviour some presses were missed")
                            focus_index = cleanup_list.index(focused_itm)
                            expected_index = cleanup_list.index(expected_text)
                            self.menu_navigate_up_down(focus_index, expected_index)
                        if select:
                            self.log.info("selecting {} from search result list".format(expected_text))
                            if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_11):
                                # Preserving old behavior when the Program Screen opened after selecting
                                # a search result item, with https://jira.tivo.com/browse/IPTV-14925 playback may start
                                focussed_menu = self.image_focus()
                                self.log.info("focussed menu: {}".format(focussed_menu))
                                if focussed_menu is not None and self.home_labels.LBL_PERSON_ICON in focussed_menu:
                                    self.screen.base.press_enter()
                                else:
                                    self.open_program_screen(watch_now)
                            else:
                                self.screen.base.press_enter(2000)
                        break
                    cur_scroll += 1
            menu_item = self.get_menu_item()
            if len(menu_item) == 2 and isinstance(menu_item, type([])):
                if select:
                    self.log.info("We got only 1 search result. selecting {} from search result list".format(expected_text))
                    if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_11):
                        focussed_menu = self.image_focus()
                        self.log.info("focussed menu: {}".format(focussed_menu))
                        if focussed_menu is not None and self.home_labels.LBL_PERSON_ICON in focussed_menu:
                            self.screen.base.press_enter()
                        else:
                            self.open_program_screen(watch_now)
                    else:
                        self.screen.base.press_enter(2000)
                    return

            if expected_text not in cleanup_list:
                raise AssertionError('expected item %s not found in results\n%s'
                                     % (expected_text, cleanup_list))

    def get_current_item(self):
        return self.cleanup_search_result(self.menu_focus().encode("iso8859").decode("utf8"))

    def open_program_screen(self, watch_now=False):
        """
        Opening the Program Screen via the Info Card.
        A list item of the Search results should be highlighted before

        Note:
            InfoCard does not appear for a Person item in the Search results,
            also long key press does not work on Unamanged device when TTS is on
        """
        self.log.info("Opening the Info Card to proceed to the Program Screen")
        if Settings.is_managed():
            self.screen.base.press_info()
        elif Settings.is_unmanaged() and self.is_tts_on():
            self.press_ok_button()
            return
        else:
            self.screen.base.long_press_enter()
        self.wait_for_info_card_ready()
        self.screen.refresh()
        self.select_menu(self.text_search_labels.LBL_IC_OPTIONS_OPT)
        self.screen.refresh()
        if not watch_now:
            self.select_menu(self.text_search_labels.LBL_IC_MORE_INFO_OPTION)
        elif watch_now:
            self.select_menu(self.text_search_labels.LBL_WATCH_NOW)

    def return_text_grid(self, screen={}):
        if screen == {}:
            screen = self.screen.get_json()
        if 'xml' in screen.keys():
            if 'griditem' in screen['xml'].keys():
                grid_list = screen['xml']['griditem']
                return grid_list
            else:
                raise AssertionError('screen data is missing "griditem" key')
        else:
            raise AssertionError('screen data is missing "xml" key')

    def bookmark_content(self):
        self.pause(10)
        self.screen.refresh()
        limit = 0
        try:
            while (not self.is_in_menu("Bookmark")):
                if limit > 10:
                    break
                self.pause(10)
                limit += 1
        except Exception:
            self.log.info("Menu Item Not Found")
        self.nav_to_menu_by_substring("Bookmark")
        self.pause(0.5)
        self.screen.refresh()
        self.select_string_by_substring("Bookmark")

    def watch_on_netflix(self):
        self.screen.base.press_left()
        self.screen.refresh()
        self.select_menu("All Episodes")
        self.screen.base.press_enter(1000)

    def verify_person_screen(self, tester, person):
        self.log.step(f"Verifying person screen {person}")
        tester.text_search_assertions.verify_person_titlescreen(person)

    def create_one_pass_for_show(self):
        for i in range(3):
            self.screen.base.press_left()
        self.screen.refresh()
        if self.is_in_menu("OnePass"):
            self.select_menu_by_substring("OnePass")
            self.screen.refresh()
            self.select_menu_by_substring("Cancel")
            self.screen.refresh()
            self.select_menu_by_substring("cancel")
            self.screen.base.press_left()
            self.screen.refresh()
        self.select_menu_by_substring("Get This")
        self.screen.refresh()
        self.select_menu_by_substring("Create")
        self.screen.refresh()
        self.select_menu_by_substring("Create")

    def searchMovie(self, tester):
        self.log.step("Searching for a Current airing Movie")
        movie_details = tester.get_random_live_channel_rich_info(movie=True)
        program_name = None
        try:
            if isinstance(movie_details, list):
                for item in movie_details:
                    if isinstance(item, list):
                        program_name = item[2]
                        self.log.info("Found Program '{}'".format(program_name))
                    else:
                        self.log.info("Channel info not present")
            else:
                pytest.skip('Failed to get movie from service api: {}'.format(program_name))
            program = re.sub('[&]', 'AND', program_name)
            self.input_search_text(program)
            program_name = program
        except Exception as exception:
            self.log.info("Typing Movie name '{}' in the Search screen failed with error: {}"
                          .format(program_name, exception))
        program_name = self.replace_spanish_chars(program_name)
        return program_name

    def get_movie(self, tester):
        movie = tester.get_random_recordable_movie_channel(filter_channel=True)
        program_name = None
        if not movie:
            pytest.skip("No recordable movie channel found")
        try:
            if isinstance(movie, list):
                for item in movie:
                    self.log.info("Item is {}".format(item))
                    if isinstance(item, list):
                        program_name = item[2]
                        if item[3] and item[3] != 'None':
                            movie_year = item[3]
                        else:
                            movie_year = None
                        self.log.info("Found Movie Program {}".format(program_name))
                        return self.convert_special_chars(program_name), movie_year
                    else:
                        self.log.info("channel info not present")
        except Exception:
            self.log.info("Movie not found")
            pytest.skip("Movie Not Found")

    def record_from_movie_screen(self, tester):
        self.screen.refresh()
        if self.is_in_strip(tester.guide_labels.LBL_RECORD_MOVIE):
            self.log.info("Highlight record movie if the content is only available from TV")
        else:
            self.nav_to_menu_by_substring(tester.guide_labels.LBL_RECORD_STRING)
            self.screen.refresh()
            if self.is_in_strip(tester.guide_labels.LBL_MODIFY_RECORDING):
                self.log.info("Recording is already created and displayed in myshows")
                return
        self.select_string_by_substring(tester.guide_labels.LBL_RECORD_STRING)
        tester.text_search_assertions.verify_record_overlay(tester)
        self.log.info("Recording Overlay displayed")
        self.screen.refresh()
        self.select_menu_by_substring(tester.guide_labels.LBL_RECORD_STRING)
        self.wait_for_whisper_text(tester.guide_labels.LBL_RECORD_SUCCESS_WHISPER_MOVIE, 30000)

    def create_Explicit_Recording(self, tester):
        self.log.info("Create explicit recoring")
        try:
            self.screen.refresh()
            self.nav_to_menu(tester.my_shows_labels.LBL_ONE_PASS_AND_RECORDING_OPTIONS)
            self.screen.refresh()
            self.select_strip(tester.my_shows_labels.LBL_RECORD_EPISODE)
            self.wait_for_screen_ready(tester.my_shows_labels.LBL_RECORDING_OPTIONS_OVERLAY_NAME)
            self.screen.refresh()
            self.select_menu(tester.my_shows_labels.LBL_RECORD_WITH_OPTIONS)
        except Exception:
            self.screen.refresh()
            self.nav_to_menu(tester.my_shows_labels.LBL_ONE_PASS_AND_RECORDING_OPTIONS)
            self.screen.refresh()
            if self.is_in_strip(tester.my_shows_labels.LBL_RECORD_EPISODE):
                self.select_strip(tester.my_shows_labels.LBL_RECORD_EPISODE)
            elif self.is_in_menu(tester.my_shows_labels.LBL_RECORDING_OPTIONS):
                self.nav_to_menu(tester.my_shows_labels.LBL_RECORDING_OPTIONS)
                self.select_strip(tester.my_shows_labels.LBL_RECORD_AGAIN)
            self.wait_for_screen_ready(tester.my_shows_labels.LBL_RECORDING_OPTIONS_OVERLAY_NAME)
            self.screen.refresh()
            self.select_menu(tester.my_shows_labels.LBL_RECORD_WITH_OPTIONS)

    def explicit_recording_from_search(self, tester, program):
        tester.home_page.back_to_home_short()
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_SEARCH_SHORTCUT)
        self.search_and_select(program, program)
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_SERIES_SCREEN)
        self.screen.refresh()
        viewmode = self.screen.get_screen_dump_item('viewMode')
        menu_option = tester.guide_labels.LBL_LIVE_AND_UPCOMING
        if viewmode == tester.my_shows_labels.LBL_SERIES_SCREEN_VIEW:
            self.menu_navigate_left_right(1, 0)
            self.screen.refresh()
            if not self.is_in_menu(menu_option):
                menu_option = tester.guide_labels.LBL_UPCOMING
            self.select_menu(menu_option)
            self.screen.base.press_enter()
            self.create_Explicit_Recording(tester)
        else:
            self.create_Explicit_Recording(tester)
        return menu_option

    def go_to_search(self, tester):
        self.log.step("Launching search screen")
        tester.home_page.back_to_home_short()
        tester.home_page.select_menu_shortcut_num(tester, tester.home_labels.LBL_SEARCH_SHORTCUT)
        self.wait_for_screen_ready("SearchMainScreen")

    def search_person(self, person):
        self.log.step(f"Searching for a person: {person}")
        self.search_and_select(person, person)
        self.wait_for_screen_ready(self.text_search_labels.LBL_PERSON_SCREEN)
        self.screen.refresh()

    def search_and_play_livetv_program(self, tester, program, pc=False):
        self.search_and_select(program, program)
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_SERIES_SCREEN)
        viewmode = self.screen.get_screen_dump_item('viewMode')
        if viewmode == tester.my_shows_labels.LBL_SERIES_SCREEN_VIEW:
            self.menu_navigate_left_right(1, 0)
            self.select_menu(tester.guide_labels.LBL_LIVE_AND_UPCOMING)
            self.screen.base.press_enter(time=200)
            if pc:
                self.screen.base.press_enter(time=800)
                self.screen.base.press_enter(time=200)  # to get an enterpin overlay from livetv OSD.
                tester.menu_assertions.verify_enter_PIN_overlay()
                tester.menu_page.enter_default_parental_control_password(tester)
                tester.guide_assertions.verify_play_normal()
            else:
                self.screen.base.press_enter(time=1000)
                tester.guide_assertions.verify_play_normal()
        else:
            if pc:
                self.screen.base.press_enter(time=800)
                self.screen.base.press_enter(time=200)  # to get an enterpin overlay from livetv OSD.
                tester.menu_assertions.verify_enter_PIN_overlay()
                tester.menu_page.enter_default_parental_control_password(tester)
                tester.guide_assertions.verify_play_normal()
            else:
                self.screen.base.press_enter(time=1000)
                tester.guide_assertions.verify_play_normal()

    def create_bookmark_from_movie_screen(self, tester):
        self.log.step("Bookmarking Movie")
        self.screen.refresh()
        if not self.is_in_strip(tester.my_shows_labels.LBL_DELETE):
            if self.is_in_menu(tester.menu_labels.LBL_RECORDING_AND_BOOKMARK_OPTIONS):
                self.nav_to_menu(tester.menu_labels.LBL_RECORDING_AND_BOOKMARK_OPTIONS)
                self.select_strip(tester.menu_labels.LBL_BOOKMARK_THIS_MOVIE)
                self.verify_whisper_shown(tester.menu_labels.LBL_BOOKMARK_WHISPER)
            elif self.is_in_menu(tester.menu_labels.LBL_RECORDING_OPTIONS):
                self.nav_to_menu(tester.menu_labels.LBL_RECORDING_OPTIONS)
                self.select_strip(tester.menu_labels.LBL_BOOKMARK_THIS_MOVIE)
                self.verify_whisper_shown(tester.menu_labels.LBL_BOOKMARK_WHISPER)
        else:
            self.log.info("Bookmark is already created")

    def select_folder_from_myshows(self, tester, folder):
        self.log.step("Opening {} from My Shows".format(folder))
        tester.home_page.go_to_my_shows(tester)
        tester.my_shows_page.select_my_shows_category(tester, tester.my_shows_labels.LBL_ALL_SHOWS)
        self.screen.refresh()
        if not self.is_in_menu(folder):
            raise AssertionError("{} is not available".format(folder))
        self.log.info("{} is available under My Shows - All Shows".format(folder))
        self.select_menu(folder)

    def get_episodic_program(self, tester):
        self.log.step("Getting an episodic program")
        channel = tester.service_api.get_random_live_channel_rich_info(episodic=True, movie=False, entitled=True, live=True)
        if channel is None:
            raise AssertionError("Could not find any episodic channel")
        tester.home_page.go_to_guide(tester)
        tester.guide_page.enter_channel_number(channel[0][0])
        program = tester.guide_page.get_live_program_name(tester)
        if program is None:
            raise AssertionError("program is None")
        return channel, program

    def get_non_episodic_program(self, tester):
        self.log.step("Getting non episodic program")
        channel = tester.service_api.get_random_live_channel_rich_info(episodic=False, movie=False, entitled=True, live=True)
        if channel is None:
            pytest.fail("Could not find any non episodic channel")
        tester.home_page.go_to_guide(tester)
        tester.guide_page.enter_channel_number(channel[0][0])
        program = tester.guide_page.get_live_program_name(tester)
        if program is None:
            raise AssertionError("program is None")
        return program

    def get_filtered_program_from_grid_row(self, tester, is_recordable_channel=True, genre=None, with_ott=False,
                                           not_ppv=True, live_filter=True, filter_live_only=True, future=0, channels_count=1):
        api = tester.service_api
        is_preview_offer_needed = True if genre else False
        if is_recordable_channel:
            channel_source = api.get_random_recordable_channel(
                channel_count=-1, filter_channel=True, is_preview_offer_needed=is_preview_offer_needed)
        else:
            channel_source = api.get_nonrecordable_channels(is_preview_offer_needed=is_preview_offer_needed)
        # Let's get cached get_grid_row_search() since it's already called above
        channel = api.get_filtered_channels_from_grid_row(channel_source=channel_source,
                                                          grid_row=api.get_grid_row_search(use_cached_grid_row=True),
                                                          genre=genre, with_ott=with_ott, not_ppv=not_ppv,
                                                          live_filter=live_filter, filter_live_only=filter_live_only,
                                                          future=future, channels_count=channels_count)
        return channel

    def type_search_text(self, search_text):
        self.log.info("Entering Search text override :{}".format(search_text))
        self.screen.base.search_text_input(search_text)
        time.sleep(5)
        self.screen.refresh()

    def filter_good_for_search_content_list(self, input_content_list):
        """
        Filters content list by checking its titles if they are good to be used in Search

        Args:
            input_content_list: json representing contentList mind object

        Returns:
            List of content objects (json) that should be good candidates for search by title
        """
        self.log.step("Filtering contents that are good candidates for search")
        good_for_search_content_list = []
        if input_content_list:
            for content in input_content_list["content"]:
                if self.service_api.is_good_search_keyword(content['title']):
                    good_for_search_content_list.append(content)
        self.log.info(
            f"Selected {len(good_for_search_content_list)} from "
            f"{len(input_content_list['content']) if input_content_list else 0} content candidates")
        return good_for_search_content_list

    def unidecode(self, international_string):
        """
        Returns string with international characters replaced as ASCII
        There is a good library (unidecode) that should handle much more cases
        than adding one-by-one to this function.
        This function should be used to fix keyword in Search screen.

        Args:
            international_string: (str) string with possible Spanish (or other language) versions of English characters

        Returns:
            string with international characters replaced with ASCII
        """
        translation_table = str.maketrans("íó", "io")
        return international_string.translate(translation_table)

    def search_and_select_by_content(self, content, max_attempts=2, select=True, **kwargs):
        """
        Searching and selecting one of the found items using passed content item

        Args:
            content (dict): content item, one of the contentList
            max_attempts (int): attemps to take screen dump again if menulist (search results list) is empty
            select (bool): if search result selection needs to be performed.
                           Note, that since Hydra v1.11 open_program_screen() is called when the param is True
            **kwargs:
                clear (bool): if input text clearing needs to be performed, True by default
                year (int): movie year, expected text will look like movie_title (year), if provided
        """
        self.log.info("Search and select by content")
        # Setting year param to None since here's a specific implementation for movieYear
        kwargs['year'] = None
        search_select_title = f"{content['title']} ({content['movieYear']})" if 'movieYear' in content.keys() \
            else content['title']
        search_keyword_ascii_title = self.unidecode(content['title'])
        self.search_and_select(search_keyword_ascii_title, search_select_title, max_attempts, select, **kwargs)

    def get_search_pad_grid_array(self, keypad_map='actual'):
        """
        Method to get hydra's search keypad map for route calculation
        Args:
            keypad_map: str, flag to choose map: 'actual' or 'cache'

        Returns:
            list, two dimension list with dict's of each button
        """
        _screen_grid = self.screen.get_screen_dump_item('griditem')
        if isinstance(_screen_grid, dict):
            # for focused element
            _screen_grid = [_screen_grid]
        if not hasattr(self, "_screen_grid"):
            self._screen_grid = _screen_grid
        if keypad_map == 'actual':
            screen_grid = _screen_grid
        elif keypad_map == 'cache':
            screen_grid = self._screen_grid
        else:
            screen_grid = self._screen_grid
        row_number = 0
        col_number = 0
        for position in screen_grid:
            col_number = max(col_number, int(position['col']))
            row_number = max(row_number, int(position['row']))

        grid_array = []
        for _row in range(row_number + 1):
            grid_array.append([None] * (col_number + 1))

        for position in screen_grid:
            col = int(position['col'])
            row = int(position['row'])
            grid_array[row][col] = {'hasfocus': position.get('hasfocus'),
                                    'text': position['text'],
                                    'row': row,
                                    'col': col
                                    }
        return grid_array

    def get_current_position_on_text_input_pad(self):
        """
        Method to get coordinates of focused button
        Returns:
            dict, {'text': None, 'row': y, 'col': x, 'hasfocus': False}
        """
        keypad_grid = self.get_search_pad_grid_array()
        for row in keypad_grid:
            for button in row:
                if button is not None and button['hasfocus']:
                    return button
        else:
            try:
                griditem = self.screen.get_screen_dump_item('griditem')
            except KeyError:
                griditem = self.screen.screen_dump
            raise LookupError("There is no focused button in search keypad. DUMP:{}".format(griditem))

    def get_button_position_on_text_input_pad(self, key, keypad_map='cache'):
        """
        Method to get coordinates of empty button

        Args:
            key: str, value of key
            keypad_map: str, flag to use cached keypad map or actual from latest screen dump

        Returns:
            dict, {'text': None, 'row': y, 'col': x, 'hasfocus': False}
        """
        keypad_grid = self.get_search_pad_grid_array(keypad_map=keypad_map)
        for row in keypad_grid:
            for button in row:
                if button is not None and button['text'].upper() == key.upper():
                    return button
        else:
            try:
                griditem = self.screen.get_screen_dump_item('griditem')
            except KeyError:
                griditem = self.screen.screen_dump
            raise LookupError("Can't find key :'{}'. DUMP:{}".format(key, griditem))

    def get_none_position_on_text_input_pad(self):
        """
        Method to get coordinates of empty button
        Returns:
            dict, {'text': None, 'row': y, 'col': x, 'hasfocus': False}
        """
        keypad_grid = self.get_search_pad_grid_array(keypad_map='cache')
        for row in range(len(keypad_grid)):
            for col in range(len(keypad_grid[0])):
                if keypad_grid[row][col] is None:
                    blanc_btn = {'text': None,
                                 'row': row,
                                 'col': col,
                                 'hasfocus': False}
                    return blanc_btn
        else:
            try:
                griditem = self.screen.get_screen_dump_item('griditem')
            except KeyError:
                griditem = self.screen.screen_dump
            raise LookupError("There is no focused button in search keypad. DUMP:{}".format(griditem))

    def calculate_route(self, curr, dst):
        """
        Method to calculate number of steps to achive dst point from curr point

        Args:
            curr: dict, start point in format {'row': y, 'col': x}
            dst: dict, finish point in format {'row': y, 'col': x}

        Returns:
            tuple, of steps to achieve the dst point
        """
        middle_point = {'row': None, 'col': None}
        none_point = self.get_none_position_on_text_input_pad()
        middle_point['row'] = dst['row']
        middle_point['col'] = curr['col']
        if self.__is_between(curr, none_point, middle_point):
            middle_point['row'] = curr['row']
            middle_point['col'] = dst['col']
        steps_1 = middle_point['row'] - curr['row'], middle_point['col'] - curr['col']
        steps_2 = dst['row'] - middle_point['row'], dst['col'] - middle_point['col']
        if self.__is_between(middle_point, none_point, dst):
            if steps_2[0] != 0:
                vertical = steps_2[0] - 1 if steps_2[0] > 0 else steps_2[0] + 1
                horizontal = steps_2[0]
                steps_2 = vertical, horizontal
            else:
                vertical = steps_2[0]
                horizontal = steps_2[0] - 1 if steps_2[0] > 0 else steps_2[0] + 1
                steps_2 = vertical, horizontal
        return steps_1, steps_2

    def move_focus_by_route_on_text_pad(self, route):
        """
        method to perform motion by hydra's search keypad
        Args:
            route: list or tuple of keypress sequences. each element of sequence is containing tuple (Y, X)
                where Y steps to move by rows and X steps to move by cols. negative - back or left

        Returns:
            None
        """
        for step in route:
            if step[0] != 0:
                self.navigate_by_XY(step[0], "Y")
            else:
                self.navigate_by_XY(step[1], "X")

    @staticmethod
    def __is_between(start, point, finish):
        """
        Method to calcualte is the poin on the line start:finish
        Args:
            start: dict, coordinate of the first point {'row': y, 'col': x}
            point: dict, coordinate of the checking point {'row': y, 'col': x}
            finish: dict, coordinate of the end point {'row': y, 'col': x}

        Returns:
            bool
        """
        def distance(a, b):
            import math
            return math.sqrt((a['col'] - b['col']) ** 2 + (a['row'] - b['row']) ** 2)
        return distance(start, point) + distance(point, finish) == distance(start, finish)

    def set_focus_to_search_keypad(self):
        """
        Method to check current screen and move focus to keypad if it not focused
        Returns:
            None
        """
        self.screen.refresh()
        if not self.view_mode() == self.text_search_labels.LBL_SEARCH_SCREEN_VIEW_NAME:
            raise LookupError("Current screen is '{}' but for text "
                              "input must be '{}'".format(self.view_mode(),
                                                          self.text_search_labels.LBL_SEARCH_SCREEN_VIEW_NAME))
        try:
            focused_key = self.get_current_position_on_text_input_pad()
        except LookupError:
            focused_key = False
        if not focused_key:
            self.press_left_button()
            self.screen.get_json()

    def _select_key_on_search_text_pad(self, key, method='check'):
        """
        Method to select a SINGLE char by hydra's search keypad
        the method is getting start position, destination key, calculate the route and perform navigation
        The function can work in two ways:
            check: with each button verification. Before selecting key function is taking the smallest hydra
                    dump (focused)
            fast: only calculated key presses will be used without any real screen verificatin. Benefit 10% comparing
                    to "check"
        Args:
            key: str, char value to be entered
            method: str, name of mode to be used: 'check' or 'fast'

        Returns:
            None
        """
        retries = 3
        for _retry in range(retries):
            if method == 'fast' and hasattr(self, "_focused_key") and not self._focused_key['text'] == 'CLR':
                # for fast we dont refreshing a screen an using last focused button for route calculation
                start_point = self._focused_key
            elif method == 'fast' and hasattr(self, "_focused_key") and self._focused_key['text'] == 'CLR':
                # if last pressed button CLR - focus automativaly changed and we must refresh screen
                self.screen.get_json(dump_type='focused')
                start_point = self.get_current_position_on_text_input_pad()
            else:
                start_point = self.get_current_position_on_text_input_pad()
            finish_point = self.get_button_position_on_text_input_pad(key)
            steps = self.calculate_route(start_point, finish_point)
            self.move_focus_by_route_on_text_pad(steps)
            if method == 'fast':
                self._focused_key = finish_point
                focused_key = finish_point
            else:
                self.screen.get_json(dump_type='focused')
                self._focused_key = self.get_current_position_on_text_input_pad()
                focused_key = self._focused_key
            if focused_key['text'].upper() == key.upper():
                self.press_ok_button(refresh=False)
                break
        else:
            raise LookupError("Unable to select key: '{}'. Curr state: {}".format(key, self.screen.screen_dump))

    def clear_all_on_text_input_pad(self):
        """
        Method to press "CLR" button on hydra's search keypad
        if the text input is empty nothing will be pressed
        Returns:
            None
        """
        self.set_focus_to_search_keypad()
        current_text = self.get_text_search_value()
        if current_text != "_":
            self._select_key_on_search_text_pad("CLR", method='check')

    def delete_symbol_on_text_input_pad(self):
        """
        Method to press "DEL" button on hydra's search keypad
        Returns:
            None
        """
        self.set_focus_to_search_keypad()
        self._select_key_on_search_text_pad("DEL", method='check')

    def input_text_using_search_text_pad(self, text, method='check', is_clear_on_start=True):
        """
        Function to input text to hydra using hydra's search key pad.
        The function can work in two ways:
            check: with each button verification. Before selecting key function is taking the smallest hydra
                    dump (focused)
            fast: only calculated key presses will be used without any real screen verificatin. Benefit 10% comparing
                    to "check"
        Args:
            text: str, text value to be entered
            method: str, name of mode to be used: 'check' or 'fast'
            is_clear_on_start: bool, if True - will press CLR button before text input

        Returns:
            None
        """
        self.wait_for_screen_ready()
        if is_clear_on_start:
            self.clear_all_on_text_input_pad()
        else:
            self.set_focus_to_search_keypad()
        for char in text:
            if char == " ":
                char = "SPC"
            self._select_key_on_search_text_pad(char, method=method)

    def press_bail_button_verify_screen(self, key, screen):
        key()
        time.sleep(15)
        self.screen.refresh()
        self.verify_screen_title(screen)

    def bookmark_from_action_screen(self, tester):
        self.log.step("Bookmarking Movie")
        if self.is_in_menu(tester.menu_labels.LBL_RECORDING_AND_BOOKMARK_OPTIONS):
            self.nav_to_menu(tester.menu_labels.LBL_RECORDING_AND_BOOKMARK_OPTIONS)
            self.select_strip(tester.menu_labels.LBL_BOOKMARK_THIS_MOVIE)
            self.verify_whisper_shown(tester.menu_labels.LBL_BOOKMARK_WHISPER)
        elif self.is_in_menu(tester.menu_labels.LBL_RECORDING_OPTIONS):
            self.nav_to_menu(tester.menu_labels.LBL_RECORDING_OPTIONS)
            self.select_strip(tester.menu_labels.LBL_BOOKMARK_THIS_MOVIE)
            self.verify_whisper_shown(tester.menu_labels.LBL_BOOKMARK_WHISPER)

    def select_app_strip(self):
        self.screen.refresh()
        strip = self.strip_list()
        self.log.info("strip found is:{}".format(strip))
        self.screen.base.press_left()
        self.screen.base.press_left()
        self.screen.base.press_enter()

    def check_ott_index_and_select_ott(self, tester, strip_list, ott_list):
        '''
        check and select any ott from strip list
        '''
        self.log.info("checking if streaming options is available in striplist")
        if tester.menu_labels.LBL_STREAMING_OPTIONS in str(strip_list):
            self.select_strip(tester.menu_labels.LBL_STREAMING_OPTIONS)
            tester.menu_assertions.verify_all_streaming_options_overlay()

    def check_playback_options_are_not_tivo(self, play_options):
        '''
        checks if the preview icon in searchscreen has any tivo playback option as first option
        param: play_options - preview icons list/string
        return: boolean(True or False)
        '''
        tivo_playback = False
        playoption = play_options['imagename'][0] if isinstance(play_options['imagename'], list) else play_options['imagename']
        self.log.info("play options: {}".format(playoption))
        for tivo_option in self.home_labels.LBL_PLAY_OPTIONS_LIST_SEARCH:
            if tivo_option in playoption:
                self.log.info("play option available: {}".format(tivo_option))
                tivo_playback = True
                break
        return tivo_playback
