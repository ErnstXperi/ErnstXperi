import pytest

from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.client_api.my_shows.assertions import MyShowsAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.client_api.guide.assertions import GuideAssertions
from set_top_box.client_api.program_options.assertions import ProgramOptionsAssertions
from set_top_box.client_api.apps_and_games.assertions import AppsAndGamesAssertions
from set_top_box.client_api.VOD.assertions import VODAssertions
from set_top_box.client_api.api_integration.assertions import APIAssertions
from set_top_box.client_api.ott_deeplinking.assertions import DeeplinkAssertions
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from set_top_box.test_settings import Settings
from core_api.stb.base import StreamerBase
from tools.logger.logger import Logger
from set_top_box.conf_constants import HydraBranches, NotificationSendReqTypes, RemoteCommands


__log = Logger(__name__)


@pytest.fixture(autouse=True, scope="class")
def setup_liveTv(request):
    """
    Configure steps to be executed before the test cases run
    :param request:
    :return:
    """
    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_assertions = HomeAssertions(request.cls.screen)
    request.cls.home_labels = LabelFactory("home", Settings)
    request.cls.home_page.home_labels = request.cls.home_labels
    request.cls.home_assertions.home_labels = request.cls.home_labels

    request.cls.watchvideo_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.watchvideo_assertions = WatchVideoAssertions(request.cls.screen)
    request.cls.watchvideo_labels = LabelFactory("watchvideo", Settings)
    request.cls.watchvideo_assertions.watchvideo_labels = request.cls.watchvideo_labels
    request.cls.watchvideo_page.watchvideo_labels = request.cls.watchvideo_labels

    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)
    request.cls.menu_labels = LabelFactory("Menu", Settings)

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)
    request.cls.guide_page.guide_labels = request.cls.guide_labels
    request.cls.guide_assertions.guide_labels = request.cls.guide_labels
    request.cls.home_page.guide_page = request.cls.guide_page

    request.cls.text_search_page = PageFactory("text_search", Settings, request.cls.screen)

    request.cls.api_assertions = APIAssertions(request.cls.screen)

    # TODO remove duplicates
    # These are duplicates of watchvideo_* params from above
    request.cls.live_tv_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.live_tv_assertions = WatchVideoAssertions(request.cls.screen)
    request.cls.live_tv_labels = LabelFactory("watchvideo", Settings)

    request.cls.my_shows_labels = LabelFactory("my_shows", Settings)
    request.cls.my_shows_page = PageFactory("my_shows", Settings, request.cls.screen)
    request.cls.my_shows_assertions = MyShowsAssertions(request.cls.screen)

    request.cls.wtw_page = PageFactory("wtw", Settings, request.cls.screen)
    request.cls.wtw_page.labels = request.cls.wtw_labels = LabelFactory("wtw", Settings)

    request.cls.program_options_assertions = ProgramOptionsAssertions(request.cls.screen)
    request.cls.program_options_page = PageFactory("program_options", Settings, request.cls.screen)
    request.cls.program_options_labels = LabelFactory("program_options", Settings)

    # TODO remove duplicates
    # It's a duplicate of wathvideo_labels
    request.cls.liveTv_labels = request.cls.watchvideo_page.liveTv_labels \
                              = LabelFactory("watchvideo", Settings)

    request.cls.watchvideo_assertions.liveTv_labels = request.cls.liveTv_labels
    request.cls.watchvideo_page.liveTv_labels = request.cls.liveTv_labels
    request.cls.watchvideo_assertions.watchvideo_labels = request.cls.watchvideo_labels
    request.cls.watchvideo_page.watchvideo_labels = request.cls.watchvideo_labels
    request.cls.watchvideo_assertions.watchvideo_page = request.cls.watchvideo_page

    request.cls.apps_and_games_labels = LabelFactory("apps_and_games", Settings)
    request.cls.apps_and_games_assertions = AppsAndGamesAssertions(request.cls.screen)

    request.cls.vod_assertions = VODAssertions(request.cls.screen)
    request.cls.vod_page = PageFactory("VOD", Settings, request.cls.screen)
    request.cls.vod_labels = request.cls.vod_page.vod_labels = LabelFactory("VOD", Settings)

    request.cls.ott_deeplinking_page = PageFactory("ott_deeplinking", Settings, request.cls.screen)
    request.cls.ott_deeplinking_labels = LabelFactory("ott_deeplinking", Settings)
    request.cls.ott_deeplinking_assertions = DeeplinkAssertions(request.cls.screen)

    # TODO remove request.cls.base usage.
    # Don't use base directly, use pages and assertions derived from StreamerBase
    request.cls.base = StreamerBase(request.cls.screen)

    request.getfixturevalue('device_reboot_to_imporve_device_perf')
    request.getfixturevalue('clean_ftux_and_sign_in')
    request.getfixturevalue('disable_parental_controls')


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_tivo_plus_channels_first_launch(request):
    """
    To add 'DG_lp_tivoplus_100' flag
    Can be tracked at - https://sp.tivo.com/tcdtracker/getgroups.php?tsns=<your TSN>
    To assign package with TiVo+ channels before test and remove after test finish
    TiVo+ overlay is shown only at the first launch
    Information about first launch of TiVo+ is stored on device and pactsafe.io, so clear data is needed
    """
    gkey = Settings.tivo_plus_group_key
    try:
        request.cls.eula_api.set_user_consent_status(Settings.tsn, gkey, status=False)
    except ConnectionError as error:
        pytest.skip("Unable to reset User Agreement status with error: {}".format(error))
    request.cls.iptv_prov_api.service_group_store('lp_tivoplus_100', 'DG',
                                                  request.cls.service_api.get_mso_partner_id(Settings.tsn))
    request.cls.iptv_prov_api.account_entitlement_publish(
        [{'package': 'emo-st-cc11-tivoplus', 'start_date': '2015-12-02 09:30:00', 'end_date': '2099-12-02 11:30:59'}],
        request.cls.service_api.getPartnerCustomerId(Settings.tsn),
        request.cls.service_api.get_mso_partner_id(Settings.tsn))
    request.cls.home_page.clear_cache_launch_hydra_app()
    request.cls.home_page.go_to_guide(request.cls)
    request.cls.guide_page.press_ok_button()
    if request.cls.home_page.verify_onscreen_trickplay_overlay():
        request.cls.screen.base.press_ok_button()
    yield
    request.cls.iptv_prov_api.service_group_remove('lp_tivoplus_100', 'DG',
                                                   request.cls.service_api.get_mso_partner_id(Settings.tsn))
    request.cls.iptv_prov_api.account_entitlement_remove(
        ['emo-st-cc11-tivoplus'],
        request.cls.service_api.getPartnerCustomerId(Settings.tsn),
        request.cls.service_api.get_mso_partner_id(Settings.tsn))


@pytest.fixture(autouse=False, scope="function")
def cleanup_clear_app_data(request):
    """
    Clearing app data after running a test
    """
    yield
    request.cls.home_page.clear_cache_launch_hydra_app()


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_tivo_plus_channels(request):
    """
    To assign package with TiVo+ channels before test and remove after test finish
    """
    request.cls.home_page.go_to_guide(request.cls)
    request.cls.guide_page.press_ok_button()
    if request.cls.home_page.verify_onscreen_trickplay_overlay():
        request.cls.screen.base.press_enter()
    request.cls.iptv_prov_api.service_group_store('lp_tivoplus_100', 'DG',
                                                  request.cls.service_api.get_mso_partner_id(Settings.tsn))
    request.cls.iptv_prov_api.account_entitlement_publish(
        [{'package': 'emo-st-cc11-tivoplus', 'start_date': '2015-12-02 09:30:00', 'end_date': '2099-12-02 11:30:59'}],
        request.cls.service_api.getPartnerCustomerId(Settings.tsn),
        request.cls.service_api.get_mso_partner_id(Settings.tsn))
    yield
    request.cls.iptv_prov_api.service_group_remove('lp_tivoplus_100', 'DG',
                                                   request.cls.service_api.get_mso_partner_id(Settings.tsn))
    request.cls.iptv_prov_api.account_entitlement_remove(
        ['emo-st-cc11-tivoplus'],
        request.cls.service_api.getPartnerCustomerId(Settings.tsn),
        request.cls.service_api.get_mso_partner_id(Settings.tsn))


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_inactivity_timeout(request, is_relaunch_needed, is_package_add_needed):
    """
    To assign Inactivity Timeout AlaCarte package before test and remove after test finish.
    Note:
        It's not required to relaunch the app since Hydra v1.16, it's enough just to send RemoteCommands.FEATURE_STATUS
        notification after updating package.
        Hydra supports NSR RemoteCommands.FEATURE_STATUS since v1.16.
    Args:
        is_relaunch_needed (bool): True - relaunching app, False - sending RemoteCommands.FEATURE_STATUS notification
        is_package_add_needed (bool): True - adding inactivityTime package before starting test, False - no adding
    """
    __log.info(f"Setup. Inactivity timeout feature testing; is_relaunch_needed {is_relaunch_needed}, "
               f"is_package_add_needed {is_package_add_needed}")
    if not is_relaunch_needed:
        request.cls.home_page.validate_fcm_nsr_mts_req_usage(NotificationSendReqTypes.NSR, RemoteCommands.FEATURE_STATUS, True)
    package = request.cls.iptv_prov_api.get_fe_operator_name() + "-inactivityTime-5Minutes"
    if is_package_add_needed:
        is_present = request.cls.iptv_prov_api.verify_package_name_fe_alacarte(package, None, False)
        if is_present:
            state = request.cls.iptv_prov_api.update_device_alacarte_package(package, is_add=True)
            if not state:
                pytest.fail("It was unable to add '{}' AlaCarte package to device '{}'.".format(package, Settings.tsn))
    if is_relaunch_needed or Settings.hydra_branch() < Settings.hydra_branch(HydraBranches.STREAMER_1_16):
        request.cls.watchvideo_page.relaunch_hydra_app()
    else:
        request.cls.home_page.send_fcm_or_nsr_notification(NotificationSendReqTypes.NSR, RemoteCommands.FEATURE_STATUS)
    yield
    __log.info(f"Tearing down. Inactivity timeout feature testing; is_relaunch_needed {is_relaunch_needed}, "
               f"is_package_add_needed {is_package_add_needed}")
    is_present = request.cls.iptv_prov_api.verify_package_name_fe_alacarte(package, None, True)
    if is_present:
        request.cls.iptv_prov_api.update_device_alacarte_package(package, is_add=False)
    if is_relaunch_needed or Settings.hydra_branch() < Settings.hydra_branch(HydraBranches.STREAMER_1_16):
        request.cls.watchvideo_page.relaunch_hydra_app()
    else:
        request.cls.home_page.send_fcm_or_nsr_notification(NotificationSendReqTypes.NSR, RemoteCommands.FEATURE_STATUS)


@pytest.fixture(autouse=False, scope="function")
def reset_bandwidth_rule(request):
    def tear_down():
        __log.info("Tear down reset_bandwidth_rule")
        rasp = request.cls.watchvideo_page.get_rasp()
        rasp.limit_eth_channel_speed(102400, 102400)  # reset to high limit
    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_turn_on_device_power(request):
    request.cls.watchvideo_page.turn_on_device_power(Settings.equipment_id)
    yield
    request.cls.watchvideo_page.turn_on_device_power(Settings.equipment_id)


@pytest.fixture(autouse=False, scope="function")
def ensure_livetv_on_realtime(request):
    request.cls.home_page.back_to_home_short()
    request.cls.home_page.goto_livetv_short(request.cls)
    request.cls.watchvideo_page.navigate_to_end_of_video()
    yield
    request.cls.watchvideo_page.navigate_to_end_of_video()


@pytest.fixture(autouse=False, scope="function")
def increase_timeout_of_widgets_in_watch_video_screen(request):
    """
    fixture to override timeout value of the widgets displayed in Watch Video screens:  Full/Standard InfoBanner,
    TrickPlay Menu, Favorites/Continue Panel, PlayNext Banner, OLG - by using tcdui_test.conf override (IPTV-12653)
    """
    request.cls.home_page.update_test_conf_and_reboot(WIDGET_TIMEOUT_MS=20000)
