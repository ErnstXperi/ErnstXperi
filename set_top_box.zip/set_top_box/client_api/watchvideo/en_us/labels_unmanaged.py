from set_top_box.test_settings import Settings
from set_top_box.conf_constants import HydraBranches
from set_top_box.client_api.watchvideo.en_us.labels import LiveTvLabels as BaseLiveTvLabels


class UnmanagedLiveTvLabels(BaseLiveTvLabels):
    # When IPPPV feature is ON on an unmanaged device
    def __init__(self):
        super().__init__()
        self.LBL_IPPPV_RENTING_ALLOWED = "Pay Per View content may be watched on this device." \
            if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15) \
            else "Pay Per View is not supported on this device"
        self.LBL_LIVETV_VIEWMODE = "watchvideo.screens.WatchLiveTvScreenView"
