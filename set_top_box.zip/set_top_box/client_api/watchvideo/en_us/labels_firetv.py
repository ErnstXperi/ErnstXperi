from .labels import LiveTvLabels


class FireTVLiveTvLabels(LiveTvLabels):

    LBL_SCREEN_SAVER_PACK = "com.amazon.ftv.screensaver"
