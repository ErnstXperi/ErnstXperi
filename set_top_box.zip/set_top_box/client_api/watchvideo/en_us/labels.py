from set_top_box.test_settings import Settings
from set_top_box.conf_constants import HydraBranches


class LiveTvLabels(object):
    # Screen labels
    LBL_LIVETV_SCREEN = "TvWatchLiveHdScreen"
    LBL_WATCH_RECORDING_SCREEN = "TvWatchRecordingHdScreen"
    LBL_SOCU_PLAYBACK_SCREEN = "TvWatchStreamingVideoScreen"
    LBL_EPISODE_SCREEN = "EpisodeScreen"
    LBL_MOVIE_SCREEN = "MovieScreen"
    LBL_RECORD_OVERLAY = "RecordOverlay"
    LBL_STOP_RECORDING_OVERLAY = "StopRecordingOverlay"
    LBL_ONEPASS_OVERLAY = "OnePassOptionsOverlay"
    LBL_GOINGTOLIVETV_OVERLAY = "Going to Live TV"
    LBL_CREATE_ONEPASS_WITH_THESE_OPTIONS = "Create OnePass with these options"
    LBL_PROGRAM_OPTIONS_CREATE_ONEPASS = "Create a OnePass for this series"
    LBL_CREATE_ONEPASS_SERIES = "Create an OnePass for this series"
    LBL_RESUME_OVERLAY = "VODResumeStartOverOverlay"
    LBL_RESUME_PLAYING = "Resume playing"
    LBL_STARTOVER = "Start over from beginning"
    LBL_NEXT_EPISODE_OVERLAY = "Press OK/SELECT to watch Next Episode"
    # Stop recording overlay items
    LBL_STOP_AND_DELETE = "Stop recording & delete"
    # Veiwmode labels
    LBL_WATCH_VIDEO_MODE = 'watchvideo.screens'
    LBL_LIVETV_VIEWMODE = "watchvideo.screens.WatchLiveTvScreenView"
    LBL_VOD_VIEWMODE = "watchvideo.screens.WatchVodScreenView"
    LBL_WATCH_RECORDING_SCREEN_VIEW = "watchvideo.screens.WatchRecordingScreenView"
    LBL_VIDEO_RECORDING_SCREEN_VIEW = "watchvideo.screens.VideoPlaybackScreenView"
    LBL_ACTION_SCREEN_VIEWMODE = "actions.ActionsScreenView"
    LBL_HDMI_OVERLAY = "HDMI Not Permitted"
    LBL_HDMI_OSD = "HDMI connection not permitted"
    LBL_VIDEO_PLAYBACK_MODES = [LBL_LIVETV_VIEWMODE, LBL_VOD_VIEWMODE, LBL_WATCH_RECORDING_SCREEN_VIEW,
                                LBL_VIDEO_RECORDING_SCREEN_VIEW]
    # Trickplay labels
    LBL_PLAYBACK_IN_PAUSE_MODE = "playPause"
    LBL_PLAYBACK_IN_PLAY_MODE = "playNormal"
    LBL_PAUSE_NOT_ALLOWED = "Pause is not allowed"
    LBL_PAUSE_NOT_SUPPORTED = "Pause is not supported"
    LBL_REPLAY_BUTTON = "Replay"
    LBL_REWIND_BUTTON = "Rewind"
    LBL_FORWARD_BUTTON = "Forward"
    LBL_ADVANCE_BUTTON = "Advance"
    LBL_GO_TO_END_BUTTON = "Go to End"
    LBL_PLAYBACK_CONTENT = 60
    # Infobanner labels
    LBL_INFO_BANNER = "medium"
    LBL_FULL_INFO_BANNER = "full"
    LBL_COLLAPSED_INFO_BANNER = "collapsed"
    LBL_CHANGE_AUDIO_TRACK = "Change Audio Track"
    LBL_RECORD = "Record"
    LBL_RECORDING_NOT_PERMITTED = "Recording Not Permitted"
    LBL_STOP_RECORDING = "Stop Recording"
    LBL_CREATE_ONEPASS = "Create OnePass"
    LBL_MODIFY_ONEPASS = "Modify OnePass"
    LBL_BOOKMARK_EPISODE = "Bookmark Episode"
    LBL_BOOKMARK = "Bookmark"
    LBL_MORE_INFO = "More Info"
    # Infobanner labels
    LBL_TURN_CC_ON = "Turn Subtitles & CC ON"
    LBL_TURN_CC_OFF = "Turn Subtitles & CC OFF"
    LBL_CLOSED_CAPTIONING_CC_ON = "Turn Closed Captions ON"
    LBL_CLOSED_CAPTIONING_CC_OFF = "Turn Closed Captions OFF"
    LBL_CHANGE_SUBTITLE_CC_LANGUAGE = "Change Subtitle & CC Language"
    LBL_CHANGE_SUBTITLE_CC_OVERLAY_TITLE = "Subtitle & Closed Caption Language"
    # Text in Info Banner Message Area
    LBL_TURN_CC_ON_MESSAGE_TEXT = "Subtitles & Closed Captions are off | " \
                                  "Press OK/SELECT to turn Subtitles & Closed Captions on" \
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15) \
        else "Subtitles & Closed Captions are off | " \
             "Press OK to turn Subtitles & Closed Captions on"
    LBL_TURN_CC_OFF_MESSAGE_TEXT = "Subtitles & Closed Captions are on | " \
                                   "Press OK/SELECT to turn Subtitles & Closed Captions off" \
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15) \
        else "Subtitles & Closed Captions are on | " \
             "Press OK to turn Subtitles & Closed Captions off"
    # Channel Options overlay
    LBL_WATCH_NOW = "Watch now"
    LBL_ADD_TO_FAVORITE_CHANNELS = "Add to Favorite Channels"
    LBL_PRESS_AND_HOLD_BANNER_TIP = "Press & hold OK"  # this the beginning of the banner tip above the Info Banner
    LBL_PREDICTION_PANEL_TITLE = "HomePredictionPanel"
    LBL_AUDIO_TRACK_OVERLAY_TITLE = "Audio Track"
    LBL_CHECKMARK = "com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_checkmark.png"
    LBL_SOCU = "SOCU"
    LBL_STARTOVER_OVERLAY = [{'text': 'Resume playing', 'hasfocus': 'true'}, {'text': 'Start over from beginning'}]
    LBL_START_OVER_FROM_BEGINNING = "Start over from beginning"
    LBL_START_OVER = "Start Over"
    LBL_RESTART = "Restart"
    LBL_ENTER_PIN_OVERLAY = "Enter PIN"
    LBL_ENTER_PIN_SCREEN = "EnterPINOverlay"
    LBL_LOADING_VIDEO_OSD = "Loading video..."
    LBL_GETTING_YOUR_SHOW_OSD = "Getting your show"
    LBL_RATING_LIMITS_OSD = "This show is locked because it is rated . " \
                            "Press OK/SELECT to enter your PIN and watch this show." \
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15) \
        else "This show is locked because it is rated . " \
             "Press OK to enter your PIN and watch this show."
    LBL_RATING_UNKNOWN_OSD = "This show is locked because its rating is unknown. " \
                             "Press OK/SELECT to enter your PIN and watch the channel." \
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15) \
        else "This show is locked because its rating is unknown. " \
             "Press OK to enter your PIN and watch the channel."
    LBL_TITLE_HIDDEN_ADULT_CONTENT = "Title Hidden"
    LBL_ADULT_SHOW_LOCKED = "This adult show is locked. Press OK/SELECT to enter your PIN and watch this show." \
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15) \
        else "This adult show is locked. Press OK to enter your PIN and watch this show."
    # Ending of the OSD text for prohibited IPPPV case, the IPPPV feature is on
    LBL_IPPPV_RENTING_PROHIBITED_ON_DEVICE = "Renting is prohibited on this device"
    # IPPPV feature is off, text on OSD in the Live TV
    LBL_IPPPV_IS_NOT_SUPPROTED_ON_DEVICE = "Pay Per View is not supported on this device"
    # When IPPPV feature is ON on a managed device
    LBL_IPPPV_RENTING_ALLOWED = "Press OK/SELECT for Pay Per View info" \
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15) else \
        "Press OK for Pay Per View info."
    LBL_IPPPV_PAY_PER_VIEW = "Pay Per View"  # just part of the IPPPV OSD text
    LBL_ONELINE_GUIDE = "OneLineGuide"
    LBL_ERROR_OVERLAY = {'text': 'OK', 'hasfocus': 'true'}
    # Confirm Jump Channel Labels
    LBL_CONFIRM_JUMP_CHANNEL_OVERLAY_TEXT = 'You are about to leave live TV and launch.' \
                                            '*"Go to next channel" or use CHANNEL UP/DOWN on ' \
                                            'your remote to go to the next channel. Or choose "Launch.*"'
    LBL_LAUNCH_APP = "Launch"
    LBL_NEXT_CHANNEL = "Go to next channel"
    LBL_CONFIRM_JUMP_CHANNEL_TITLE = "Leaving Live TV"
    LBL_CONFIRM_JUMP_CHANNEL_OVERLAY_TIMEOUT = 300
    #
    LBL_MANAGED_BAIL_BUTTONS = ["home", "guide", "exit", "back", "clear", "vod", "apps", "netflix", "youtube"]
    LBL_NETFLIX_APP = "com.netflix.ninja"
    LBL_YOUTUBE_APP = "com.google.android.youtube.tv.main"
    LBL_SCREEN_SAVER_PACK = ["backdrop", "dreams"]
    LBL_SCREEN_SAVER_PACKAGE = "com.google.android.backdrop"
    # Resume Playing Overlay
    LBL_RESUME_PLAYING_OVERLAY = "Resume Playing?"
    LBL_RESUME_PLAYING_OVERLAY_TIMEOUT = 60
    LBL_TIMEOUT_BEFORE_RESUME_PLAYING_OVERLAY = 600
    LBL_STOP_PLAYING_OPTION = "Stop playing"
    LBL_PLAY_OPTION = "Play"
    LBL_PAUSE_OPTION = "Pause"
    # Play Next episode overlay
    LBL_ON_DEMAND = "On Demand"
    LBL_HIDE = "Hide"
    LBL_PRE_ROLL_VIEW_MODE = "watchvideo.screens.WatchUriScreenView"
    LBL_INFO_CARD = "overlay.InfoCardOverlayView"
    LBL_PPV_ICON = "com/tivo/applib/ResAppLibImages/applib/images/hydra/1080p/hydra_icon_ppv.png"
    LBL_RENT_THIS_SHOW = "Rent This Show"
    LBL_PPV_OVERLAY_TITLE = "Purchase PPV"
    LBL_INFO_OVERLAY = "overlay.InfoOverlayView"
    LBL_PURCHASED_CONFIRMED = "Purchase Confirmed"
    LBL_TRANSACTION_PROBLEM = "Transaction Problem"
    LBL_CHANNEL_OPTIONS = "Channel Options"
    LBL_REMOVE_FROM_FAVORITE_CHANNELS = "Remove from Favorite Channels"
    LBL_ENABLED = 'enabled'
    LBL_DISABLED = 'disabled'
    LBL_ACCEPT = 'Accept'
    LBL_CANCEL = 'Cancel'
    LBL_VIEW_USER_AGREEMENT = 'View TiVo + User Agreement'
    LBL_TIVO_PLUS_USER_AGREEMENT_SCREENTITLE = 'TIVO + USER AGREEMENT'
    LBL_VIEW_PRIVACY_POLICY = 'View TiVo + Privacy Policy'
    LBL_TIVO_PLUS_PRIVACY_POLICY_SCREENTITLE = 'TIVO + PRIVACY POLICY'
    LBL_TIVO_PLUS_EULA_OVERLAY_TITLE = 'TiVo+ User Agreement & Privacy Policy'
    LBL_TIVO_PLUS_EULA_OVERLAY_BODY = 'By clicking accept you agree to our User Agreement and Privacy Policy ' \
                                      'for TiVo+. Please click on the links to view the policies.'
    LBL_DELETE_REC_OVERL_TITLE = "Delete this recording?"
    LBL_TIVO_PLUS_EULA_OSD_TEXT = 'Press OK to view and accept the TiVo+ User Agreement & Privacy Policy.'
    LBL_CHANNEL_NOT_SUBSCRIBED_OSD_TEXT = 'requires a subscription.'
    LBL_INACTIVITY_TIME_OSD_TEXT = "This TiVo box will enter standby shortly. Press OK to continue watching."
    LBL_AREYOUSTILL_THERE_OSD_TEXT = "Are you still there? Press OK/SELECT to continue."
    LBL_INACTIVITY_TIME_OSD_TEXT = "This box will enter standby shortly."
    LBL_SCREENSAVER_TEXT_NEVER = "Never"
    LBL_SUBSCRIPTION_REQUIRED = "Subscription Required"
    LBL_SUBSCRIPTION_REQUIRED_ERR_CODE = "V410"

    # Yukon URL
    YUKON_TEST_URL = "http://test"
    # Blue tick
    LBL_BLUE_TICK = "com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_checkmark.png"

    LBL_CH_NO_8124 = "8124"
    LBL_SPANISH_1 = "Spanish 1"
    LBL_SPANISH_2 = "Spanish 2"
    LBL_ORIGINAL_LANG = "Original Language [CC]"
    LBL_LIST_SPANISH1_SELECT = [LBL_SPANISH_1, LBL_SPANISH_2, LBL_ORIGINAL_LANG]
    LBL_LIST_SPANISH2_SELECT = [LBL_SPANISH_2, LBL_SPANISH_1, LBL_ORIGINAL_LANG]
    LBL_CURRENT = "Current: "
    LBL_DESC_CHANGE_SUBTITLE_AND_CC_LANGUAGE = "Press OK/SELECT to change track" \
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15) \
        else "Press OK to change track"

    # Examiner events
    EXM_SUBSCRIPTION_REQUIRED_OVERLAY = "IPTVStreamingFailedOverlay"
    LBL_UHD_RESOLUTION = "2160p"
    LBL_4K_AUDIO_TRACK_CH_NO_10120 = "10120"
    LBL_4K_60_FPS_CH_NO = "10120"
    LBL_4K_24_FPS_CH_NO = "8264"
    LBL_4K_30_FPS_CH_NO = "10121"

    # Playback is prohibited on this device overlays
    LBL_CAN_NOT_WATCH_OVERLAY_SHOW_TITLE = "Can't Watch Show"
    LBL_V414_ERROR_CODE = "V414"
    LBL_PLAYBACK_IS_PROHIBITED_OVERLAY_BODY_TEXT = "Playback is prohibited on this device"
    UHD_CONNECTION_SPEED = 25000

    LBL_PROGRAM_TEMPORARILY_UNAVAILABILITY_CHANNEL_TITLE = "Program Temporarily Unavailable"

    # Network OSD Overlay
    LBL_OSD_PAUSE_TIME = 2
    LBL_FRAME_RATE_60 = "60fps"
    LBL_FRAME_RATE_24 = "24fps"
    LBL_FRAME_RATE_30 = "30fps"

    LBL_CHANNEL_NOT_SUBSCRIBED_OSD_FULL_TEXT = "This channel requires a subscription."

    LBL_4K_HDR10_CH_NO = "10124"
