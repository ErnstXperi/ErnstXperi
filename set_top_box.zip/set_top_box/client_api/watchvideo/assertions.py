import random
import re
from operator import add
from functools import reduce
from datetime import datetime

from hamcrest import assert_that, is_, equal_to, is_not, has_items, has_item, is_in, has_entries, has_value, \
    equal_to_ignoring_case, greater_than_or_equal_to, contains_string, matches_regexp

from set_top_box.client_api.watchvideo.page import WatchVideoBase
from set_top_box.test_settings import Settings
from tools.logger.logger import Logger


class WatchVideoAssertions(WatchVideoBase):
    __log = Logger(__name__)

    def verify_live_tv_details(self, tester):
        try:
            live_tv_dict = self.get_live_tv_display_details()
        except Exception:
            live_tv_dict = {'time_slot': None, 'current_time': None}
        assert_failures = []
        assert_failure_text = ''
        if 'channel_number' not in live_tv_dict.keys():
            assert_failures.append('no channel number')
        if 'channel_name' not in live_tv_dict.keys():
            assert_failures.append('no channel name')
        if 'description' not in live_tv_dict.keys():
            assert_failures.append('no description')
        if live_tv_dict['time_slot'] is None or live_tv_dict['current_time'] is None:
            assert_failures.append('incomplete or no airtime data')
        if len(assert_failures) > 0:
            assert_failure_text = 'Live TV has %s.' % (
                ', '.join(assert_failures)
            )
            raise AssertionError(assert_failure_text)
        return live_tv_dict

    def verify_channel_number(self, channel):
        self.__log.info("Verify channel number in the Right Column of the Info Banner header")
        channel_on_screen = self.get_channel_number()
        assert_that(channel_on_screen, equal_to(channel), "Channel number does not match")

    def verify_channel_callsign(self, channel_callsign):
        self.__log.info("Verify callsign")
        channel_on_screen = self.get_channel_callsign()
        assert_that(channel_on_screen, equal_to(channel_callsign), "Channel callsign does not match")

    def verify_video_format_icon_of_info_baner_header(self, video_format_icon=None):
        """
        :description:
            Verify video format icon (HD, SD) on the Info Banner
            Screen dump should contain Info Banner before using the method
        :params:
            video_format_icon - name of the icon file, e.g. hydra_icon_sd.png,
                                if None, then just checks if value is not empty on the screen
        :return:
        """
        self.__log.info("Verify video format icon in the Right Column of the Info Banner header")
        value_on_screen = self.get_video_format_icon()
        is_field_ok = False
        if video_format_icon is not None:
            if value_on_screen is not None:
                # comparing passed value with actual on the screen
                is_field_ok = video_format_icon.lower() in value_on_screen.lower()
        else:
            if value_on_screen is not None:
                # checking if value is not empty for the field
                is_field_ok = value_on_screen is not None and bool(value_on_screen.strip())
        assert_that(is_field_ok,
                    "Video format icon is not correct; video format icon from the screen - {}, passed video format icon - {}"
                    .format(value_on_screen, video_format_icon))

    def verify_channel_logo_of_info_baner_header(self, channel_logo=None):
        """
        :description:
            Verify channel logo on the Info Banner
            Screen dump should contain Info Banner before using the method
        :params:
            channel_logo - name of the icon file, e.g. 1157.png,
                           if None, then just checks if value is not empty on the screen
        :return:
        """
        self.__log.info("Verify channel logo in the Right Column of the Info Banner header")
        value_on_screen = self.get_channel_logo()
        is_field_ok = False
        if channel_logo is not None:
            if value_on_screen is not None:
                # comparing passed value with actual on the screen
                is_field_ok = channel_logo.lower() in value_on_screen.lower()
        else:
            if value_on_screen is not None:
                # checking if value is not empty for the field
                is_field_ok = value_on_screen is not None and bool(value_on_screen.strip())
        assert_that(is_field_ok,
                    "Channel logo is not correct; channel logo from the screen - {}, passed channel logo - {}"
                    .format(value_on_screen, channel_logo))

    def verify_clock_of_info_baner_header(self, clock=None):
        """
        :description:
            Verify clock on the Info Banner
            Screen dump should contain Info Banner before using the method
        :params:
            clock - current time, e.g. 11:11am, if None, then just checks if value is not empty on the screen
        :return:
        """
        self.__log.info("Verify clock in the Right Column of the Info Banner header")
        value_on_screen = self.get_time_info()
        is_field_ok = False
        if clock is not None:
            if value_on_screen is not None:
                # comparing passed value with actual on the screen
                is_field_ok = clock.lower() in value_on_screen.lower()
        else:
            if value_on_screen is not None:
                # checking if value is not empty for the field
                is_field_ok = value_on_screen is not None and bool(value_on_screen.strip())
        assert_that(is_field_ok,
                    "Clock is not correct; clock from the screen - {}, passed clock - {}"
                    .format(value_on_screen, clock))

    def verify_up_next_of_info_baner_header(self, up_next=None):
        """
        :description:
            Verify up next show on the Info Banner
            Screen dump should contain Info Banner before using the method
        :params:
            up_next - name of a show, if None, then just checks if value is not empty on the screen
        :return:
        """
        self.__log.info("Verify up next show in the Right Column of the Info Banner header")
        value_on_screen = self.get_up_next_show()
        is_field_ok = False
        if up_next is not None:
            if value_on_screen is not None:
                # comparing passed value with actual on the screen
                is_field_ok = up_next.lower() in value_on_screen.lower()
        else:
            if value_on_screen is not None:
                # checking if value is not empty for the field
                is_field_ok = value_on_screen is not None and bool(value_on_screen.strip())
        assert_that(is_field_ok,
                    "Up next show is not correct; up next from the screen - {}, passed up next - {}"
                    .format(value_on_screen, up_next))

    def verify_message_area_of_info_banner_does_not_contain_text(self, strip_item, is_wait=False):
        """
        :description:
            Verify Info Banner message area does NOT contain any text
        :params:
            strip_item
            is_wait - boolean, it's needed to wait for Info Banner to disappear
                      if the next step calls Info Banner
        :return:
        """
        self.__log.info("Verify Info Banner message area does NOT contain any text")
        is_text = self.is_message_area_text_visible_in_info_banner()
        item_text = None
        if is_text:
            item_text = self.screen.get_screen_dump_item('stripItemSubtitle')
        is_expected_item_name = strip_item in self.strip_focus()
        assert_that(is_not(item_text) and is_expected_item_name,
                    "Message area should not conain any text, expected item - '{}', actual item - '{}', text on UI - '{}'"
                    .format(strip_item, self.strip_focus(), item_text))
        if is_wait:
            # waiting for info banner to disappear, this is needed if the next step calls Info Banner again
            self.pause(3)

    def verify_target_option_not_present_in_info_banner(self, strip_item):
        stripitem = (self.screen.get_screen_dump_item('stripitem'))
        info_banner_options = []
        for item in stripitem:
            info_banner_options.append(item.get('text'))
        if strip_item in info_banner_options:
            raise AssertionError(f"Expected not to be present but info banner contains {strip_item} option")
        else:
            assert True, f"No {strip_item} option found info banner"

    def verify_message_area_of_info_banner_contains_text(self, strip_item, text=None, is_wait=False):
        """
        :description:
            Verify Info Banner message area contains some text
            If passed param text is None, then just checks if the message area is not empty
        :params:
            strip_item
            text
            is_wait - boolean, it's needed to wait for Info Banner to disappear
                      if the next step calls Info Banner
        :return:
        """
        self.__log.info("Verify Info Banner message area contains some text")
        is_text = self.is_message_area_text_visible_in_info_banner()
        item_text = None
        if is_text:
            item_text = self.screen.get_screen_dump_item('stripItemSubtitle')
        check_value = item_text == text if text else bool(item_text)
        is_expected_item_name = strip_item in self.strip_focus()
        assert_that(check_value and is_expected_item_name,
                    "Message area should conain some text, expected item - '{}', actual item - '{}', text on UI - '{}'"
                    .format(strip_item, self.strip_focus(), item_text))
        if is_wait:
            # waiting for info banner to disappear, this is needed if the next step calls Info Banner again
            self.pause(3)

    def verify_cc(self, option):
        """
        Verify Closed Captions option on the Info Banner (UI)

        Args:
            option (str): CC option name
        """
        stripitem = self.get_strip_list()
        assert_that(stripitem, has_items(has_value(option)), "CC option not in strip")

    def verify_cc_state(self, enable=True):
        """
        Verify Closed Captions state in log
        Should be called right after turning ON/OFF the CC

        Args:
            enable (bool): state for CC in log
        """
        state = self.wait_for_cc_toggle(enable)
        if state:
            self.__log.info(f"Request to enable/disable {enable} CC was sent to player")
        else:
            raise AssertionError(f"Request to enable/disable {enable} CC was not sent to player")

    def verify_playback_play(self, refresh=True, tivo_plus_channel=False, disconnected_state=False):
        # TODO: replace hardcode delay to wait_for_LiveTVPlayback()
        # self.pause(2)  # actual start time little delayed from issuing event
        self.log.info("Verifying playback play")
        playback_state = self.get_playback_raw_log_with_status()
        if refresh:
            self.screen.refresh()
        self.set_or_update_channel_playback_info(playback_state=playback_state)
        if self.is_overlay_shown():
            self.verify_error_overlay_not_shown()
        if not tivo_plus_channel:
            count = 5
            while count > 0:
                self.show_trickplay_if_not_visible()
                self.screen.refresh()
                dump = self.screen.get_screen_dump_item('trick-play')
                replay_time = self.convert_time_to_sec(dump['replay-size'])
                if replay_time > 0:
                    count = -2
                    break
                self.pause(3)
                count -= 1
            self.__log.info("Checking playback started or not")
            if count == -2:
                if not disconnected_state:
                    assertion_details = f"'channel' {self.screen.get_screen_dump_item('channel-number')}"\
                                        f" with 'show' {self.screen.get_screen_dump_item('title')} not streaming"
                else:
                    assertion_details = f"'channel' {self.screen.get_screen_dump_item('channel-number')} not streaming"
                assert_that(dump['start-time'], is_not(dump['end-time']), assertion_details)
            else:
                raise AssertionError("Failed to playback the program even after a waiting for 15-20 secs: {}".format(dump))
        self.skip_hdmi_connection_error()
        self.set_or_update_channel_playback_info(after_check=True)
        # self.verify_no_osd_on_screen()
        self.__log.step("Verification of playback is playing: PASSED")

    def set_or_update_channel_playback_info(self, playback_state=None, after_check=False):
        if Settings.is_internal_mso():
            if not after_check:
                details = self.get_playback_content_details(self.screen.get_screen_dump_item())
                url = None
                if playback_state:
                    self.log.info("playback state: {}".format(playback_state))
                    if playback_state[1] is not None and 'http' in playback_state[1]:
                        url = re.search(r"(\w+:\/\/.+?(?=,|\)))", playback_state[1])[0]  # noqa: W605
                        url = url.replace("(", "").replace("))", "")
                details.update({'url': url})
                self.service_api.cached_channel_info(details, mode="testcase")
            else:
                details = self.service_api.cached_channel_info(None, mode="testcase", use_cached_response=True)
                self.__log.info("channel: {}".format(details))
                if details:
                    details.update({'playback_status': True})
                    self.service_api.cached_channel_info(details, mode="testcase", use_cached_response=False)

    def get_playback_content_details(self, dump):
        expected_val = ['viewMode', 'channel-number', 'title', 'show-time', 'current-local-time']
        channel_det = {}
        if 'viewMode' in dump.keys() and dump.get('viewMode') in self.liveTv_labels.LBL_VIDEO_PLAYBACK_MODES:
            channel_det = {'playback_status': False}
            for key, val in dump.items():
                if key in expected_val:
                    channel_det.update({key: val})
        return channel_det

    def get_playback_url_from_network_osd(self):
        streaming_url = None
        self.show_network_osd()
        self.pause(2)
        self.screen.refresh()
        self.screen.base.press_back()
        try:
            metrics = self.screen.get_screen_dump_item('streammetrics')
            self.log.info("metrics: {}".format(metrics))
            if len(metrics) >= 6:
                streaming_url = metrics[5]['option']['text']
        except Exception as Err:
            self.log.warning("Failed to get streaming url:{}".format(Err))
        self.screen.refresh()
        return streaming_url

    def verify_currentPos_not_initial(self):
        self.log.step("Verifying trickplay position is not same trickplay initial position")
        try:
            pos = self.screen.get_screen_dump_item('trick-play', 'current-pos').split(":")
            pos = list(map(lambda x: float(x), pos))
            sum = reduce(add, pos)
            assert sum
        except Exception:
            self.__log.error(f"Trick play items was not available, screen was{self.screen.get_screen_dump_item('viewMode')}")

    def verify_show_title(self, title):
        self.__log.info("Verifying show title in Watch Video.")
        show_title = self.remove_service_symbols(self.get_show_title())
        title = self.remove_service_symbols(title)
        assert_that(show_title, is_(title),
                    "Title of streaming show not match, actual: {}, expected: {}".format(show_title, title))

    def verify_screen_title(self, title):
        screentitle = (self.screen.get_screen_dump_item('screentitle'))
        assert_that(screentitle, title)

    def verify_home_menu_widget_is_shown(self, widget):
        self.log.step(f"Checking home menu widget - {widget}")
        assert_that(self.show_home_menu_widget(), equal_to_ignoring_case(widget))

    def verify_default_info_banner_is_shown(self):
        """
        Description:
        To verify infobanner default mode.
        MIBOX has COLLAPSED infobanner and other devices have FULL infobanner by default
        """
        if Settings.is_mibox():
            assert_that(self.get_infobanner_mode(), equal_to(self.liveTv_labels.LBL_COLLAPSED_INFO_BANNER))
        else:
            assert_that(self.get_infobanner_mode(), equal_to(self.liveTv_labels.LBL_FULL_INFO_BANNER))

    def verify_standard_info_banner_shown(self):
        assert_that(self.get_infobanner_mode(), equal_to(self.liveTv_labels.LBL_INFO_BANNER))

    def verify_full_info_banner_is_shown(self):
        self.log.step("Checking if Full info banner was displayed or not")
        assert_that(self.full_info_banner_is_shown(), "Full infobanner wasn't showm")

    def verify_full_info_banner_is_not_shown(self):
        self.__log.info("Verifying that Info Banner is not shown.")
        screen = self.screen.get_json()['xml']
        assert_that(screen['bannercontrolvisible'], is_('false'), "Info Banner was shown.")

    def verify_socu_playback_started(self):
        """
        To verify that we're in WatchStreamingVideoScreen and asset is playing
        :return:
        """
        self.wait_for_screen_ready(self.liveTv_labels.LBL_SOCU_PLAYBACK_SCREEN)
        playback_state = self.get_playback_raw_log_with_status(timeout=8000)
        self.set_or_update_channel_playback_info(playback_state=playback_state)
        self.verify_view_mode(self.liveTv_labels.LBL_VOD_VIEWMODE)
        self.verify_video_playback_mode(self.liveTv_labels.LBL_PLAYBACK_IN_PLAY_MODE)
        self.set_or_update_channel_playback_info(after_check=True)

    def verify_video_resumed(self, last_played_position, resume_position):
        """
        To verify that partially watched show is resumed
        :param last_played_position: str
        :param resume_position: str
        :return:
        """
        self.__log.info("Verifying whether playback was resumed or not")
        start_position = self.get_trickplay_start_position()
        assert resume_position >= last_played_position and resume_position != start_position, \
            f"Video was not resumed. Video started from '{resume_position}' " \
            f"and last played position was {last_played_position}"

    def verify_video_resumed_after_tv_power_on(self, tester, last_played_position, resume_position):
        """
        To verify that watched show is resumed from the live point after tv power on.
        :param last_played_position: str
        :param resume_position: str
        :return:
        """
        last_played_position_seconds = tester.my_shows_page.get_timein_seconds(last_played_position, ms=False)
        resume_position_seconds = tester.my_shows_page.get_timein_seconds(resume_position, ms=False)
        self.log.info("last_played_position_seconds:{}".format(last_played_position_seconds))
        self.log.info("resume_position_seconds:{}".format(resume_position_seconds))
        diff = last_played_position_seconds - resume_position_seconds
        self.log.info("difference:{}".format(diff))
        assert resume_position == last_played_position_seconds or diff <= 300, \
            f"Video was not resumed from the last played position. Video started from '{resume_position}' " \
            f"and last played position was {last_played_position}"

    def verify_playback_streaming_for(self, last, current, delta=0):
        """
        To verify that playback played for
        :param last: last position  'HH:MM:SS.ms' - format str
        :param current: current position 'HH:MM:SS.ms' - format str
        :param delta: to verify cache, in minutes
        :return:
        """
        last = int(last.split(":")[1]) + delta
        current = int(current.split(":")[1])
        assert_that(current, greater_than_or_equal_to(last))

    def press_exit_and_verify_streaming(self, tester):
        self.__log.info("Verifying streaming")
        self.screen.base.press_exit_button(5)
        self.wait_for_screen_ready(timeout=600000)
        tester.watchvideo_page.wait_for_LiveTVPlayback(status="PLAYING")
        self.screen.refresh()
        self.pause(5)
        tester.watchvideo_assertions.verify_playback_play()

    def press_select_and_verify_streaming(self, tester):
        self.log.step("Verifying streaming")
        self.screen.base.press_enter()
        tester.watchvideo_page.wait_for_LiveTVPlayback(status="PLAYING")
        tester.watchvideo_assertions.verify_playback_play()

    def press_select_and_verify_recording_is_played(self, tester):
        self.log.step("Verifying recording is played")
        self.screen.base.press_enter()

        # When loading a recording, the text of the OSD is always "Getting your show".
        status = self.wait_for_osd_text(self.liveTv_labels.LBL_GETTING_YOUR_SHOW_OSD)
        if not status:
            tester.watchvideo_assertions.verify_error_overlay_not_shown()
            if self.osd_shown():
                osd_text = self.osd_text()
                assert_that(self.liveTv_labels.LBL_GETTING_YOUR_SHOW_OSD, is_in(osd_text),
                            "Text is in OSD: {}, expected: {}".format(osd_text,
                                                                      self.liveTv_labels.LBL_GETTING_YOUR_SHOW_OSD))
        tester.watchvideo_page.wait_for_LiveTVPlayback(status="PLAYING")
        tester.watchvideo_assertions.verify_playback_play()

    def verify_rating_limits_osd_in_live_tv(self, shown=None, error_code=None, tvrating=True):
        self.log.step(f"Verifying rating limits OSD in Live TV. Is OSD expected:{shown}, ODS error code: {error_code}")
        self.wait_loading_indicator_disappear()
        try:
            if shown:
                assert_that(self.osd_shown(), "OSD wasn't on the screen")
                if tvrating:
                    self.verify_osd_text(self.liveTv_labels.LBL_RATING_LIMITS_OSD)
                else:
                    self.verify_osd_text(self.liveTv_labels.LBL_RATING_UNKNOWN_OSD)
            elif error_code:
                assert_that(self.osd_shown(), "OSD wasn't on the screen")
                assert_that(self.get_osd_err_code(), is_(error_code), "Error code not match")
            else:
                assert_that(self.osd_shown(), is_(False), "OSD is shown.")
        except AssertionError:
            raise Exception("Parental Controls Limits OSD wasn't shown.")

    def verify_osd(self):
        self.log.step("Verifying osd displayed")
        assert_that(self.osd_shown(), "OSD wasn't on the screen")

    def verify_no_osd_on_screen(self):
        """ Method to asset there is no OSD on a screen. Check will be performed in 3 reties
        with accumulative delay."""
        self.log.info("Going to verify no osd on screen")
        retries = 3
        text = ""
        for try_i in range(retries):
            if self.osd_shown():
                text = self.osd_text()
                self.log.debug("OSD detected with text: '{}'".format(text))
                if "Going to Live TV" in text:
                    # if stream is loading then will wait a little bit more 7s -> 12s -> 17s
                    self.pause(5 * try_i + 7)
                else:
                    self.pause(2)
                self.screen.refresh()
            else:
                text = ""
                break
        assert not text, f"Unexpected osd detected with 'text' {text}"

    def verify_PIN_challenge_overlay(self):
        try:
            self.wait_for_screen_ready(self.liveTv_labels.LBL_ENTER_PIN_SCREEN)
            self.verify_overlay_title(self.liveTv_labels.LBL_ENTER_PIN_OVERLAY)
        except Exception:
            raise Exception("PIN challenge overlay wasn't shown.")

    def show_full_infobanner_and_verify_channel_change_button(self, button):
        """
        To verify that channel up and channel down buttons could change channels from
        Full Info Banner without closing it
        :param button: str, correct values are 'channel up' and 'channel down'
        """
        # self.show_info_banner()
        # self.verify_full_info_banner_is_shown()
        screen = self.screen.screen_dump['xml']
        start_channel = screen.get('channel-number')
        if button == 'channel up':
            self.press_channel_up_button()
        elif button == 'channel down':
            self.press_channel_down_button()
        else:
            raise Exception("Button option is invalid, please input correct value.")
        current_channel = self.get_channel_number()
        self.verify_full_info_banner_is_shown()
        assert_that(start_channel, is_not(equal_to(current_channel)), "Channel wasn't changed.")

    def verify_view_mode(self, view=None, refresh=True):
        if refresh:
            self.screen.refresh()
        view_mode = (self.screen.get_screen_dump_item('viewMode'))
        view = view or self.liveTv_labels.LBL_LIVETV_VIEWMODE
        self.__log.info(f"verifying current  view_mode {view_mode} with expected {view}")
        assert_that(view_mode, contains_string(view))

    def show_full_infobanner_and_verify_button_do_nothing(self, button):
        """
        To verify that button presses do nothing in Full Info Banner
        :param button: str, correct values are 'up' and 'down'
        """
        start_channel = self.get_channel_number(self.screen.screen_dump)
        if button == 'press up':
            self.press_up_button()
        elif button == 'press down':
            self.press_down_button()
        else:
            raise Exception("Button option is invalid, please input correct value.")
        current_channel = self.get_channel_number()
        self.verify_full_info_banner_is_shown()
        assert_that(start_channel, equal_to(current_channel), button + " changes channel number.")

    def verify_livetv_mode(self):
        self.__log.info("Verifying that we in LiveTV and error overlay is not shown.")
        self.wait_for_screen_ready()
        self.verify_view_mode()
        self.verify_error_overlay_not_shown()

    def fav_screen_matches_fav_panel(self, first_list, second_list, expectedResult):
        first = set(first_list)
        second = set(second_list)
        actualstatus = (first == second)
        if expectedResult != actualstatus:
            assert False, f"Expected result was not matched expected: {first}, but was: {second}"
        else:
            self.log.info("Expected result matched")

    def verify_vod_mode(self):
        self.__log.info("Verifying that we in VOD and error overlay is not shown.")
        self.verify_view_mode(self.liveTv_labels.LBL_VOD_VIEWMODE)
        self.verify_error_overlay_not_shown()

    def verify_watch_recording_mode(self, tester):
        self.log.info("Verifying that we in Watch Recording screen and error overlay is not shown.")
        self.verify_view_mode(tester.my_shows_page.get_watch_or_video_recording_view_mode(tester))
        self.verify_error_overlay_not_shown()

    def press_channel_button_and_verify_channel_change(self, button):
        """
        To verify that channel up and channel down buttons could change channels in LiveTV
        :param button: str, correct values are 'channel up' and 'channel down'
        """
        screen = self.screen.screen_dump['xml']
        start_channel = screen.get('channel-number')
        if button == 'channel up':
            self.press_channel_up_button()
        elif button == 'channel down':
            self.press_channel_down_button()
        else:
            raise Exception("Button option is invalid, please input correct value.")
        current_channel = self.get_channel_number()
        assert_that(start_channel, is_not(equal_to(current_channel)), "Channel wasn't changed.")

    def verify_confirm_jump_channel_overlay_shown(self):
        self.log.info("Verifying 'Confirm Jump Channel' overlay.")
        assert_that(self.get_confirm_jump_channel_overlay_visibility(),
                    "'Confirm Jump Channel' overlay wasn't shown")
        assert_that(self.get_overlay_body_text(),
                    matches_regexp(self.liveTv_labels.LBL_CONFIRM_JUMP_CHANNEL_OVERLAY_TEXT))

    def verify_confirm_jump_channel_overlay_not_shown(self):
        self.log.info("Verifying that 'Confirm Jump Channel' overlay is not shown.")
        assert_that(not self.get_confirm_jump_channel_overlay_visibility(),
                    "'Confirm Jump Channel' overlay was shown.")

    def verify_bail_buttons_in_confirm_jump_channel_overlay(self, tester, button, channel_number):
        """
        To verify bail buttons in Confirm Jump Channel overlay
        :param tester: object instance of calling test
        :param button: str
        :param channel_number: str
        """
        self.log.info(f"Verifying '{button}' press in Confirm Jump Channel overlay.")
        if button == "home":
            self.press_home_and_verify_screen(tester)
        elif button == "guide":
            self.press_guide_and_verify_screen(tester)
        elif button == "exit":
            self. screen.base.press_exit_button()
            self.verify_livetv_mode()
            self.verify_channel_number(channel_number)
        elif button == "back":
            self.screen.base.press_back_button()
            self.verify_livetv_mode()
            self.verify_channel_number(channel_number)
        elif button == "clear":
            self.screen.base.press_clear_button()
            self.verify_livetv_mode()
            self.verify_channel_number(channel_number)
        elif button == "vod":
            self.press_vod_and_verify_screen(tester)
        elif button == "apps":
            self.press_apps_and_verify_screen(tester)
        elif button == "netflix":
            self.press_netflix_and_verify_screen(tester)
        elif button == "youtube":
            self.press_youtube_and_verify_screen(tester)
        self.press_home_and_verify_screen(tester)

    def verify_confirm_jump_channel_overlay_timeout(self, timeout):
        self.log.info("Verifying Confirm Jump Channel overlay timeout")
        current_channel = self.screen.get_screen_dump_item('bodytext')
        self.pause(timeout)
        if self.get_confirm_jump_channel_overlay_visibility():
            next_channel = self.screen.get_screen_dump_item('bodytext')
        else:
            next_channel = self.get_channel_number()
        assert_that(next_channel is not current_channel,
                    "Channel wasn't changed by timeout in Confirm Jump Channel overlay.")

    def verify_resume_playing_overlay_shown(self, state=None):
        self.log.info(f"Verifying that Resume Playing overlay state is '{state}'")
        resume_overlay = self.get_resume_playing_overlay_state()
        assertion_msg = f"Resume Overlay state was '{resume_overlay}' but expected '{state}'"
        if state is True:
            assert_that(resume_overlay, assertion_msg)
        elif state is False:
            assert_that(not resume_overlay, assertion_msg)

    def verify_audio_track_selected(self, track):
        assert_that(self.get_menu_item(),
                    has_item(has_entries({"text": track, "imagename": self.liveTv_labels.LBL_CHECKMARK})))

    def verify_currently_playing_episode(self, episode):
        self.log.info("Verifying currently playing episode.")
        cur_episode = self.get_currently_playing_episode()
        assert_that(cur_episode, is_(episode))

    def verify_press_and_hold_ok_socu_tip(self, tip_text):
        """
        Verifying Press & Hold tip in the Watch Live TV screen

        Args:
            tip_text - tip text, if None, checks if the tip text is not empty
                       and checks if passed text is contained in UI tip otherwise
        """
        self.__log.info("Verify if Press & Hold tip is shown in the Watch Live TV screen")
        self.show_info_banner()
        # Pressing Back to dismiss Info Banner
        self.press_back_button()
        is_text = self.is_press_and_hold_tip_shown_in_watch_live_tv()
        item_text = None
        if is_text:
            item_text = self.screen.get_screen_dump_item('bannerTip')
        if is_text and tip_text:
            check = tip_text in item_text
        elif not is_text and tip_text:
            check = False
        else:
            check = bool(item_text)
        assert_that(check,
                    "The tip text either is empty or passed tip is not conained in one on UI; actual: '{}', passed: '{}'"
                    .format(item_text, tip_text))

    def verify_trickplay_restriction_message_shown(self, message=None):
        """
        Note:
            'restriction-message' is present in the parsed JSON only if restriction
            message is displayed
            If message message param is empty, then checks only if message is present
            and compares text otherwise

        Args:
            message (str): expected restriction message
        """
        self.__log.info("Verifying that trickplay restriction is displayed")
        self.screen.refresh()
        mes_ui = None
        is_message = False
        try:
            mes_ui = self.screen.get_screen_dump_item('trick-play', 'restriction-message')
            is_message = bool(mes_ui) if not message else message in mes_ui['text']
        except Exception as ex:
            self.__log.warning("verify_trickplay_restriction_message_shown:\n{}".format(ex))
            is_message = False
        assert_that(is_message, "Verification for trickplay restriction message failed, on UI: {}, passed: {}"
                                .format(mes_ui, message))

    def verify_overlay_mode(self, value):
        mode = self.screen.get_screen_dump_item('overlayMode')
        if mode != value:
            raise AssertionError("{} is not displayed".format(value))

    def verify_replay_timing(self, last, current):
        """
        To verify that playback played for
        :param last: last position  'HH:MM:SS.ms' - format str
        :param current: current position 'HH:MM:SS.ms' - format str
        :return:
        """
        sec = last.split(":")[2]
        last_min = last.split(":")[1]
        last_pos = int(sec.split(".")[0])
        cur_sec = current.split(":")[2]
        cur_min = current.split(":")[1]
        current = int(cur_sec.split(".")[0])
        if last_min == cur_min:
            if (last_pos - 8) < current:
                raise AssertionError('video is not replayed less than or eqaul to 8s.')
        elif last_min < cur_min:
            raise AssertionError('video is not replayed less than or eqaul to 8s.')

    def verify_cc_or_subtitle_is_rendered_when_ON_or_OFF(self, video, state, os_remove=True, raise_err=True):
        """
        To verify cc is rendered or not according to the state
        :param: file name to be used for screenrecord and state of CC
        :return:
        """
        ccrendered = self.get_cc_rendered(video, os_remove=os_remove)
        if state == "ON":
            if ccrendered:
                self.log.info("CC rendered during a playback when it is ON")
                return True
            else:
                if not raise_err:
                    return False
                raise AssertionError("CC not rendered during a playback when it is ON ")
        else:
            if not ccrendered:
                self.log.info("CC not rendered during a playback when it is OFF")
                return True
            else:
                if not raise_err:
                    return False
                raise AssertionError("CC rendered during a playback when it is OFF")

    def record_and_verify_cc(self, dst, time, log_path, state, os_remove=True, retries=3):
        self.log.info("attempting to verify CC with multiple records")
        for retry in range(retries):
            filename = "cc_" + state + str(retry) + ".mp4"
            self.take_screenrecord_and_pull(filename, "/sdcard/" + filename, dst, time)
            result = self.verify_cc_or_subtitle_is_rendered_when_ON_or_OFF(log_path + "/" + filename, state, os_remove=False,
                                                                           raise_err=False)
            if result:
                break

    def verify_ppv_icon_present_info_banner(self):
        self.log.step("Verify if PPV Icon is present in the infobanner")
        ppvicons = self.screen.get_screen_dump_item('ppvicon')
        assert ppvicons != self.liveTv_labels,\
               "Expected PPV icon: '{}', but actual: '{}'".format(self.liveTv_labels.LBL_PPV_ICON, ppvicons)

    def verify_ppv_icon_present_program_screen(self):
        self.log.step("Verifying ppv icon is present in the strip and the previe w window")
        ppv_icon = self.screen.get_screen_dump_item('stripitem', 'imagename')
        ppv_icon_preview = self.screen.get_screen_dump_item('previewPane', 'ppvicon')
        assert_that(self.liveTv_labels.LBL_PPV_ICON, is_in(ppv_icon),
                    "Expect {Unexpected PPV icon got")
        assert_that(self.liveTv_labels.LBL_PPV_ICON, is_in(ppv_icon_preview),
                    "Unexpected PPV preview icon")

    def verify_video_resumed_after_reboot(self, tester, last_played_position, resume_position):
        """
        resume_position - last_played_position should be >= 180 seconds.
        To verify that partially watched show is resumed
        :param last_played_position: str
        :param resume_position: str
        :return:
        """
        last_played_position_seconds = tester.my_shows_page.get_timein_seconds(last_played_position, ms=False)
        resume_position_seconds = tester.my_shows_page.get_timein_seconds(resume_position, ms=False)
        self.log.info("last_played_position_seconds:{}".format(last_played_position_seconds))
        self.log.info("resume_position_seconds:{}".format(resume_position_seconds))
        diff = resume_position_seconds - last_played_position_seconds
        self.log.info("difference:{}".format(diff))
        assert resume_position != last_played_position_seconds and diff >= 120, \
            f"Video was not resumed. Video started from '{resume_position}' " \
            f"and last played position was {last_played_position}"

    def is_forward_focused(self, refresh=True):
        # refresh is needed to get the updated dump
        if refresh:
            self.screen.get_json()
        dump = self.screen.get_screen_dump_item('trick-play')
        screen_dump = dump.get('stripitem')
        for eachitem in screen_dump:
            if eachitem.get('text') == "Forward":
                hasfocus = eachitem.get('hasfocus')
                if hasfocus:
                    self.log.info('hasfocus value {}:'.format(hasfocus))
                else:
                    assert False, "Focus is not present on Forward button"
                break

    def is_forward_button_focused(self, tester):
        focus = tester.watchvideo_page.get_strip_focus_of_trickplay_bar()
        if focus == self.liveTv_labels.LBL_FORWARD_BUTTON:
            self.log.info('Focus is on Forward button')
        else:
            assert False, "Focus is not present on Forward button"

    def is_guide_focused(self, refresh=True):
        # refresh is needed to get the updated dump
        if refresh:
            self.screen.get_json()
        dump_after = self.screen.get_screen_dump_item('trick-play')
        screen_dump_after = dump_after.get('stripitem')
        for eachitem in screen_dump_after:
            if eachitem.get('text') == "Guide":
                hasfocus = eachitem.get('hasfocus')
                if hasfocus:
                    self.log.info('hasfocus value {}:'.format(hasfocus))
                else:
                    assert False, "Focus is not present on Guide button"
                break

    def press_and_verify_back_on_trickplay(self):
        self.log.step("Pressing BACK button to dismiss trickplay bar if visible")
        self.screen.refresh()
        if self.is_infobanner_visible():
            self.screen.base.press_back()
            self.wait_for_trickplay_bar_dismiss(Settings.trickplay_bar_timeout_in_pause_mode)
            self.verify_trickplay_bar_not_shown()

    def is_rewind_focused(self, refresh=True):
        if refresh:
            self.screen.get_json()
        dump = self.screen.get_screen_dump_item('trick-play')
        screen_dump = dump.get('stripitem')
        for eachitem in screen_dump:
            if eachitem.get('text') == "Rewind":
                hasfocus = eachitem.get('hasfocus')
                if hasfocus:
                    self.log.info('hasfocus value {}:'.format(hasfocus))
                else:
                    assert False, "Focus is not present on rewind button"
                break

    def is_rewind_button_focused(self, tester):
        focus = tester.watchvideo_page.get_strip_focus_of_trickplay_bar()
        if focus == self.liveTv_labels.LBL_REWIND_BUTTON:
            self.log.info('Focus is on Rewind button')
        else:
            assert False, "Focus is not present on Rewind button"

    def is_startover_focused(self, refresh=True):
        if refresh:
            self.screen.get_json()
        dump_after = self.screen.get_screen_dump_item('trick-play')
        screen_dump_after = dump_after.get('stripitem')
        if screen_dump_after[0].get('hasfocus') and \
                screen_dump_after[0].get('text') == self.liveTv_labels.LBL_START_OVER:
            self.log.info('hasfocus value at extreme left position {}:'.format(screen_dump_after[0].get('hasfocus')))
        else:
            assert False, "Focus is not present at Start over"

    def verify_text_in_watch_video_osd(self, text, expected=True, raise_error=True):
        """
        Verifying text in the OSD in live TV

        Args:
            text (str): part of text to check if it's contained in the OSD
            expected (bool): checking if text is contained in the OSD if True and if it's not otherwise
            raise_error (bool): True - raising AssertionError if condtion not satisfied, False - returning bool

        Returns
            bool, if IPPPV feature is on
        """
        self.__log.info("Verifying that passed text is contained on the OSD in WatchVideo screen; "
                        f"text '{text}', expected {expected}, raise_error {raise_error}")
        self.wait_for_osd_text(text)
        self.screen.refresh()
        osd_text = self.osd_text()
        result = False
        if text in osd_text and expected or text not in osd_text and not expected:
            result = True
        err_msg = "Current OSD text: {}; passed text: {}; expected: {}".format(osd_text, text, expected)
        self.__log.warning(err_msg)
        if raise_error:
            assert_that(result, err_msg)
        return result

    def is_playpause_focused(self, value="Play", refresh=True):
        # needed to get the recent dump
        if refresh:
            self.screen.get_json()
        dump_after = self.screen.get_screen_dump_item('trick-play')
        screen_dump_after = dump_after.get('stripitem')
        for i in range(len(screen_dump_after)):
            if screen_dump_after[i].get('hasfocus') and screen_dump_after[i].get('text') == value:
                self.log.info(f'Focus is on {value} button')
                break
        else:
            assert False, f"Focus is not on {value} button"

    def verify_guide_button_selection(self, tester, refresh=True):
        self.screen.base.press_enter()
        if refresh:
            self.screen.get_json()
        tester.guide_assertions.verify_one_line_guide()

    def verify_favorite_channels_panel_not_shown(self):
        self.screen.refresh()
        state = self.is_favorite_channels_panel_visible()
        if state:
            raise AssertionError("Favorite Panel is still visible")
        else:
            self.__log.info("Verified that on removing all the Favorite Channels, Favorite Panel is not shown")

    def verify_info_icon_selection(self, refresh=True):
        self.screen.base.press_enter()
        if refresh:
            self.screen.get_json()
        self.verify_full_info_banner_is_shown()

    def is_go_to_live_focused(self, refresh=True):
        if refresh:
            self.screen.get_json()
        dump = self.screen.get_screen_dump_item('trick-play')
        screen_dump = dump.get('stripitem')
        for eachitem in screen_dump:
            if eachitem.get('text') == "Go to Live":
                hasfocus = eachitem.get('hasfocus')
                if hasfocus:
                    self.log.info('hasfocus value {}:'.format(hasfocus))
                else:
                    assert False, "Focus is not present on Go to Live button"
                break

    def verify_trickplay_button_status(self, button, disabled=False):
        """
        To verify trickplay menu button status
        :param button: string
        :param disabled: bool
        """
        button_status = self.get_trickplay_button_status(button)
        if disabled:
            assert_that(button_status, is_(self.liveTv_labels.LBL_DISABLED))
        else:
            assert_that(button_status, is_(self.liveTv_labels.LBL_ENABLED))

    def verification_of_jump_channel_overlay(self, refresh=True):
        # this is needed if there is change of screen when pressed ok button
        self.wait_for_screen_ready()
        if refresh:
            self.screen.get_json()
        if self.get_confirm_jump_channel_overlay_visibility():
            return True
        else:
            return False

    def verify_adult_content_is_hidden(self, tester):
        self.log.step("Verifying Title Hidden tile on Favorite Strip")
        if self.liveTv_labels.LBL_TITLE_HIDDEN_ADULT_CONTENT in self.strip_focus():
            self.__log.info("Verified {} is present in striplist".format(self.liveTv_labels.LBL_TITLE_HIDDEN_ADULT_CONTENT))
        else:
            raise AssertionError("{} is not displayed.".format(tester.my_shows_labels.LBL_TITLE_HIDDEN))

    def verify_adult_show_locked_osd(self):
        self.log.step("Verifying adult show locked OSD")
        self.pause(3)
        self.screen.refresh()
        if not self.osd_shown():
            error_overlay = self.get_error_overlay_visibility(self)
            if error_overlay:
                raise AssertionError("{} overlay on playback instead of OSD".format(error_overlay))
            raise AssertionError("OSD not shown")
        else:
            self.verify_osd_text(self.liveTv_labels.LBL_ADULT_SHOW_LOCKED)

    def verify_checkbox_status(self, tester, channel, status=True):
        """
        Verifying whether checkbox is marked/unmarked

        Args:
            channel (int): channel number
            status (bool): checking if checkbox is marked/checked, then True, otherwise False
        """
        state = False
        if str(self.menu_focus()[0]) != str(channel):
            self.press_up_button(refresh=True)  # selection highlighter moves down to the next channel after selecting
            # Checking if we see an expected channel number after moving up
            if str(self.menu_focus()[0]) != str(channel):
                raise AssertionError("Highlighted channel number doesn't match expected one")
        image = self.menu_item_image_focus()
        self.log.step("Check {}".format(image))
        if isinstance(image, list):
            state = any(tester.guide_labels.LBL_CHECKED in img for img in image)
        elif tester.menu_labels.LBL_CHECKED in image:
            state = True
        assert_that(state, equal_to(status), "Checkbox status verification unsuccessful")

    def verify_tivo_plus_eula_overlay_is_shown(self, refresh=False):
        self.log.step("Verifying TiVo+ EULA overlay is shown.")
        if refresh:
            self.screen.refresh()
        assert_that(self.is_tivo_plus_eula_overlay_shown(), "TiVo+ EULA overlay wasn't shown.")

    def verify_tivo_plus_eula_overlay_is_not_shown(self):
        self.log.step("Verifying TiVo+ EULA overlay is shown.")
        assert_that(not self.is_tivo_plus_eula_overlay_shown(), "TiVo+ EULA overlay was shown.")

    def verify_tivo_plus_eula_osd_is_shown(self):
        self.log.step("Verifying TiVo+ EULA overlay is shown.")
        assert_that(self.is_tivo_plus_eula_osd_shown(), "TiVo+ EULA OSD wasn't shown.")

    def verify_tivo_plus_eula_osd_is_not_shown(self):
        self.log.step("Verifying TiVo+ EULA overlay is shown.")
        assert_that(not self.is_tivo_plus_eula_osd_shown(), "TiVo+ EULA OSD was shown.")

    def verify_ff__status(self, status="disabled"):
        """
        To verify fast forward button status is as given
        :param status: string (disabled/enabled). By default, disabled
        """
        ffbuttonstatus = self.get_trickplay_button_status(self.liveTv_labels.LBL_FORWARD_BUTTON)
        if ffbuttonstatus == status:
            self.log.info("Fast Forward button is " + status)
        else:
            raise AssertionError("Fast Forward button is not " + status)

    def verify_rewind__status(self, status="disabled"):
        """
        To verify rewind button status is as given
        :param status: string (disabled/enabled). By default, disabled
        """
        rewindbuttonstatus = self.get_trickplay_button_status(self.liveTv_labels.LBL_REWIND_BUTTON)
        if rewindbuttonstatus == status:
            self.log.info(" Rewind button is " + status)
        else:
            raise AssertionError("Rewind button is not " + status)

    def verify_channel_change_from_olg(self):
        self.log.step("Verifying channel change from OLG screen.")
        start_channel = self.get_channel_number()
        self.log.info("start channel number: {}".format(start_channel))
        self.screen.base.press_left()
        self.screen.base.press_down()
        self.screen.base.press_enter()
        self.screen.base.press_enter()
        current_channel = self.get_channel_number()
        assert_that(start_channel, is_not(equal_to(current_channel)), "Channel wasn't changed.")

    def verify_red_dot_is_displayed_on_trickplay(self, status=True):
        """
                To verify red dot is displayed on trickplay or no
                :param status: bool (True/False). By default, True
                """
        self.__log.info("Verifying red do is displayed or not on tickplay.")
        screen_dump = self.screen.get_screen_dump_item('trick-play')
        if status:
            assert_that(screen_dump['show-recording-dot'], is_('true'), "Red dot is not displayed on trickplay.")
        else:
            assert_that(screen_dump['show-recording-dot'], is_('false'), "Red dot is displayed on trickplay.")

    def verify_mutiple_left_from_play_pause(self, tester, playpause_index):
        current_index = tester.watchvideo_page.get_strip_focus_index_of_trickplay_icon()
        if current_index < playpause_index and current_index == 0:
            self.log.info("Icon placed in the left of Play/Pause")
        else:
            raise AssertionError("CurrentIcon{} not placed in the left of PlayPauseIcon{}"
                                 .format(current_index, playpause_index))

    def verify_channel_up_multiple_times(self):
        for i in range(10):
            if self.get_confirm_jump_channel_overlay_visibility():
                self.select_menu_by_substring(self.liveTv_labels.LBL_NEXT_CHANNEL)
            else:
                self.press_channel_button_and_verify_channel_change('channel up')

    def verify_video_playback_started(self):
        """
        :description:
            verify if video render started
        :params:
        :return:
            bool, if video render started
        """
        status = self.wait_for_video_player_start()
        if status:
            self.__log.info("Video Playback Started")
            return True
        else:
            raise AssertionError("Failed to detect the video render started log message")

    def verify_video_playback_stopped(self, asert=True):
        """
        :description:
            verify if video playback stopped
        :params:
        :return:
            bool, if video playback stopped
        """
        status = self.wait_for_video_player_stop()
        if status:
            self.__log.info("Video Playback Stopped")
            return True
        else:
            if asert:
                raise AssertionError("Failed to detect the video playback stopped log message")
            else:
                self.log.error("Failed to detect the video playback stopped log message")

    def verify_forward_with_time(self, tester, current_position):
        self.log.info("The current position is {} : ".format(current_position))
        current_position_sec = tester.my_shows_page.get_timein_seconds(current_position, ms=True)
        self.log.info("Current pos in sec {}".format(current_position_sec))
        moved_position = tester.my_shows_page.get_trickplay_current_position_time(tester)
        moved_position_sec = tester.my_shows_page.get_timein_seconds(moved_position, ms=True)
        self.log.info("Moved pos in sec {}".format(moved_position_sec))
        if moved_position_sec > current_position_sec:
            self.log.info("Forward is successful")
        else:
            raise AssertionError("Forward is not successful")

    def verify_rewind_with_time(self, tester, current_position):
        self.log.info("The current position is {} : ".format(current_position))
        current_position_sec = tester.my_shows_page.get_timein_seconds(current_position, ms=True)
        self.log.info("Current pos in sec {}".format(current_position_sec))
        moved_position = tester.my_shows_page.get_trickplay_current_position_time(tester)
        moved_position_sec = tester.my_shows_page.get_timein_seconds(moved_position, ms=True)
        self.log.info("Moved pos in sec {}".format(moved_position_sec))
        if moved_position_sec < current_position_sec:
            self.log.info("Rewind is successful")
        else:
            raise AssertionError("Rewind is not successful")

    def verify_time_diff_for_all_forward_or_rewind_speeds(self, tester, forward, speed, start, end):
        self.log.info(f"verifying time diff for speed {speed} with start time {start} and end time {end}")
        start_time_in_ms = tester.my_shows_page.get_timein_seconds(start, ms=True)
        end_time_in_ms = tester.my_shows_page.get_timein_seconds(end, ms=True)
        if forward:
            diffrence = end_time_in_ms - start_time_in_ms
        else:
            diffrence = start_time_in_ms - end_time_in_ms
        self.log.info("difference in sec {}".format(diffrence))
        if speed == 1:
            if (diffrence >= 0) and (diffrence <= 120):
                self.log.info("Forward/Rewind with speed 1 is passed")
            else:
                raise AssertionError("Forward/Rewind with speed 1 has failed.")
        if speed == 2:
            if (diffrence >= 120) and (diffrence <= 360):
                self.log.info("Forward/Rewind with speed 2 is passed")
            else:
                raise AssertionError("Forward/Rewind with speed 2 has failed.")
        if speed == 3:
            if (diffrence >= 120) and (diffrence <= 720):
                self.log.info("Forward/Rewind with speed 3 is passed")
            else:
                raise AssertionError("Forward/Rewind with speed 3 has failed.")

    def is_advance_focused(self, tester):
        focus = tester.watchvideo_page.get_strip_focus_of_trickplay_bar()
        if focus == self.liveTv_labels.LBL_ADVANCE_BUTTON:
            self.log.info('Focus is on Advance button')
        else:
            assert False, "Focus is not present at Advance"

    def is_replay_focused(self, tester):
        focus = tester.watchvideo_page.get_strip_focus_of_trickplay_bar()
        if focus == self.liveTv_labels.LBL_REPLAY_BUTTON:
            self.log.info('Focus is on Replay button')
        else:
            assert False, "Focus is not present at Replay"

    def is_gotoend_focused(self, tester):
        focus = tester.watchvideo_page.get_strip_focus_of_trickplay_bar()
        if focus == self.liveTv_labels.LBL_GO_TO_END_BUTTON:
            self.log.info('Focus is on Go to End button')
        else:
            assert False, "Focus is not present at Go to End"

    def verify_critic_ratings_on_livetv(self, visible=True):
        self.log.info("Verifying Critic Ratings on live Tv")
        self.screen.refresh()
        screen_dump = self.screen.get_screen_dump_item()
        if visible:
            if screen_dump.get('criticRating', None) is None:
                raise AssertionError("Critic Rating is not visible")
        else:
            if screen_dump.get('criticRating', None) is not None:
                raise AssertionError("Critic Rating is visible on Action Page")

    def verify_throttle_network(self, tester, test_speed):
        netspeed = tester.watchvideo_page.get_connection_speed()
        if test_speed <= netspeed:
            raise AssertionError("Network throttle not detected current speed: {}".format(netspeed))

    def verify_language_with_blue_tick(self, selected_language):
        screen_dump = self.screen.get_screen_dump_item('menuitem')
        obtained_language = screen_dump[0]['text']
        blue_tick = screen_dump[0]['imagename']
        if selected_language == obtained_language and blue_tick == self.liveTv_labels.LBL_BLUE_TICK:
            self.log.info("Selected language with blue tick is available")
        else:
            raise AssertionError("Selected language with blue tick is not updated")

    def verify_subtitle_language_order(self, tester, selected_language):
        subtitle_list_after = tester.watchvideo_page.get_subtitle_list()
        if selected_language == tester.watchvideo_labels.LBL_SPANISH_1:
            if subtitle_list_after == tester.watchvideo_labels.LBL_LIST_SPANISH1_SELECT:
                self.log.info("Subtitle language order is verified successfuly")
            else:
                raise AssertionError("Subtitle language is not in a correct order")
        elif selected_language == tester.watchvideo_labels.LBL_SPANISH_2:
            if subtitle_list_after == tester.watchvideo_labels.LBL_LIST_SPANISH2_SELECT:
                self.log.info("Subtitle language order is verified successfuly")
            else:
                raise AssertionError("Subtitle language is not in a correct order")

    def verify_description_of_change_subtitle_and_cc_language(self, tester, selected_language):
        self.screen.refresh()
        subtitle_desc = self.screen.get_screen_dump_item('stripItemSubtitle')
        expected_desc = tester.watchvideo_labels.LBL_CURRENT + selected_language + " " + "|" + " " + \
            tester.watchvideo_labels.LBL_DESC_CHANGE_SUBTITLE_AND_CC_LANGUAGE
        if subtitle_desc == expected_desc:
            self.log.info("Description {} matches the expected description {}".format(subtitle_desc, expected_desc))
        else:
            raise AssertionError("Expected description {} donot match with {}".format(expected_desc, subtitle_desc))

    def verify_recording_not_permitted_button_on_info_banner(self, tester):
        tester.watchvideo_page.show_info_banner()
        strip_list = self.get_strip_list()
        if not strip_list:
            assert False, "No strip list found"
        strips = []
        for strip in strip_list:
            if strip['text']:
                strips.append(strip['text'])
        if self.liveTv_labels.LBL_RECORDING_NOT_PERMITTED in strips:
            assert True, "Recording option is disabled on info banner of offer restricted show"
        elif self.liveTv_labels.LBL_RECORD in strips:
            raise AssertionError("Record option is enabled for nDVR recording restricted offer")
        else:
            raise AssertionError("No option related to recording is available in info banner of live content")

    def verify_status_message_in_one_line_guide_for_nDVR_restricted_offer(self, tester):
        preview_pane = (self.screen.get_screen_dump_item('previewPane'))
        if not preview_pane:
            assert False, "No preview pane found on the screen"
        self.log.info(f"*** preview pane {preview_pane}")
        if 'recordingType' in preview_pane and \
                preview_pane.get('recordingType') == tester.guide_labels.LBL_STATUS_MESSAGE_NDVR_OFFER_RESTRICTION and \
                preview_pane.get('recordingIcon') == tester.guide_labels.LBL_COMMON_IMAGE_PATH + \
                tester.guide_labels.LBL_NON_RECORDABLE_CELL_ICON:
            assert True, "status message shown in oneline guide preview for nDVR restricted offer " \
                         "with proper non-recordable icon"
        else:
            raise AssertionError(
                "No status message shown in oneline guide preview for nDVR restricted offer ")

    def verify_channel_change_after_pressing_exit_button(self, channel1, channel2):
        self.log.info("verifying channel change after pressing exit button")
        if int(channel1) == int(channel2):
            raise AssertionError("Channel did not change to previous channel after pressing exit button")

    def verify_transition_to_past_olg_is_blocked(self, expected=True):
        """
        Applicable to One Line Guide, check if there is ability to move to Past OLG

        Args:
            expected (bool): True - transition to Past OLG is blocked, False - there's ability to go to Past OLG
        """
        self.__log.info(f"Verifying transition to Past One Line Guide is {'blocked' if expected else 'possible'}")
        self.press_left_button(refresh=False, repeat_count=5)
        self.screen.get_json()
        if not self.is_olg_visible():
            raise AssertionError("One Line Guide is not shown")
        is_past_guide = True if self.screen.get_screen_dump_item("isPastGuide") == "true" else False
        result = False
        if is_past_guide and not expected or not is_past_guide and expected:
            result = True
        err_msg = "Past One Line Guide Line Guide is shown" if is_past_guide and expected \
            else "Transtion to Past OLG did not happen"
        assert_that(result, "{}".format(err_msg))

    def verify_channel_cell_is_currently_focused(self):
        """
        Verifying that Channel cell is currently highlighted
        """
        self.__log.info("Verifying if channel cell is currently highlighted in OLG")
        self.screen.get_json()
        if not self.is_olg_visible():
            raise AssertionError("One Line Guide is not shown")
        # menuitem list represents channel info list in OLG
        assert_that(self.is_menu_focus(), "Highlight is not on a channel cell")

    def verify_ipppv_feature_is_on_or_off_in_osd_text(self, expected=True):
        """
        Verifying that there is specific text on OSD telling if IPPPV feature is on in WatchVideo screen

        Args:
            expected (bool): expected feature state on/off
        """
        self.log.info(f"Verifying if IPPPV feature is {expected} via OSD text")
        # V410 overlay may not appear if re-enter already tuned PPV channel after feature enabling tuning to a channel,
        # then feature disabling and re-opening the same channel,
        # see https://jira.tivo.com/browse/IPTV-23816
        if expected:
            current_feature_state = self.verify_text_in_watch_video_osd(
                text=self.watchvideo_labels.LBL_IPPPV_RENTING_ALLOWED, expected=expected, raise_error=expected)
        else:
            # Subscription Required (V410) overlay is thrown when IPPPV is off after starting playback since Hydra 1.9
            # https://jira.tivo.com/browse/BZSTREAM-6622
            self.wait_for_screen_ready(self.watchvideo_labels.EXM_SUBSCRIPTION_REQUIRED_OVERLAY)
            self.screen.get_json()
            cur_code = self.screen.get_screen_dump_item('overlayTitleText') if self.is_overlay_title() else None
            is_eq = cur_code == self.watchvideo_labels.LBL_SUBSCRIPTION_REQUIRED_ERR_CODE
            if not is_eq:
                raise AssertionError(f"Expected: {self.watchvideo_labels.LBL_SUBSCRIPTION_REQUIRED_ERR_CODE} error overlay; "
                                     f"cur: {cur_code}")
            current_feature_state = False  # IPPPV is off if LBL_SUBSCRIPTION_REQUIRED_ERR_CODE overlay is shown
        result = False
        if current_feature_state and expected or not current_feature_state and not expected:
            result = True
        screen_dump = self.screen.get_screen_dump_item()
        assert_that(result,
                    "WatchVideo: IPPPV feature is currently {}; expected - {}; screen dump: \n{}"
                    "".format(current_feature_state, expected, screen_dump))

    def verify_screen_resolution(self, tester):
        resolution = tester.watchvideo_page.get_screen_resolution()
        uhd_resolution = self.liveTv_labels.LBL_UHD_RESOLUTION
        assert_that(resolution, equal_to(uhd_resolution),
                    "screen resolution does not match, expected: {}actual: {}".format(uhd_resolution, resolution))
        tester.watchvideo_page.watch_video_for(30)  # watch video for sometime
        resolution1 = tester.watchvideo_page.get_screen_resolution()
        assert_that(resolution, is_(resolution1),
                    "Resolution does not maintain, first: {}, second: {}".format(resolution, resolution1))

    def verify_screen_frame_rate(self, tester, expected_frame_rate):
        frame_rate = tester.watchvideo_page.get_screen_frame_rate()
        frame_rate = frame_rate.strip()
        assert_that(frame_rate, equal_to(expected_frame_rate),
                    "screen frame rate does not match, expected: {}actual: {}".format(expected_frame_rate, frame_rate))
        tester.watchvideo_page.watch_video_for(30)  # watch video for sometime
        frame_rate_new = tester.watchvideo_page.get_screen_frame_rate()
        frame_rate_new = frame_rate_new.strip()
        assert_that(frame_rate, is_(frame_rate_new),
                    "Resolution does not maintain, first: {}, second: {}".format(frame_rate, frame_rate_new))

    def verify_screen_resolution_not_uhd(self, tester):
        resolution = tester.watchvideo_page.get_screen_resolution()
        resolution = int(resolution.replace("p", ""))
        if resolution <= 1080:
            self.log.info("content playing in HD/SD resolution")
        else:
            raise AssertionError("resolution not in HD/SD, current resolution{}".format(resolution))

    def verify_can_not_watch_show_overlay_shown(self):
        self.log.info("Verifying 'can't watch show' overlay.")
        assert_that(self.get_can_not_watch_show_overlay_visibility(),
                    "{} wasn't displayed".format(self.liveTv_labels.LBL_CAN_NOT_WATCH_OVERLAY_SHOW_TITLE))
        assert_that(self.get_overlay_body_text(),
                    matches_regexp(self.liveTv_labels.LBL_PLAYBACK_IS_PROHIBITED_OVERLAY_BODY_TEXT))

    def verify_uhd_streaming_bandwidth(self, tester):
        uhd_connection_speed = tester.watchvideo_labels.UHD_CONNECTION_SPEED
        current_speed = tester.watchvideo_page.get_connection_speed()
        if current_speed < uhd_connection_speed:
            raise AssertionError("Bandwidth is low to stream UHD profile expected{} actual{}"
                                 .format(uhd_connection_speed, current_speed))

    def verify_branding_ui_bundle_logos(self, branding_image, dump_image):
        self.log.info("Verifying images\n Expected: {}\n actual: {}".format(branding_image, dump_image))
        if dump_image not in branding_image:
            raise AssertionError("Fails to match with image returned from brandingUiBundle.\n {} \n{}".format(branding_image,
                                                                                                              dump_image))

    def verify_channel_video_quality_score(self, tester, channel):
        self.log.info("Verifying video quality score of a channel")
        quality_details = tester.watchvideo_page.fetch_video_quality_details(channel)
        if quality_details:
            overall_score = quality_details['QOE:score']
            score = overall_score / 4
            if score > 1:
                raise AssertionError("Expected video quality score to be equal to 1 but actual{}".format(score))
            else:
                self.log.info("Content playing with hightest video quality score{}".format(score))
        else:
            self.log.error(f"Failed to verify channel video quality score: quality_details - {quality_details}")

    def verify_program_time_and_system_time(self, tester):
        self.log.info("Verifying System time and program time on trickplay bar")
        self.screen.refresh()
        dump = self.screen.get_screen_dump_item()
        timeinfo = dump['timeinfo']
        current_pos = dump['trick-play']['current-position']
        if timeinfo != current_pos:
            raise AssertionError("Current position and system time are not same.")

    def verify_current_program_of_ppv_channel_is_already_rented(self, tester, ppv_channel_number):
        tester.watchvideo_assertions.verify_livetv_mode()
        # next method "wait_for_LiveTVPlayback" verify only LiveTV status paused or playing,
        # it does not verify is video blanked or unblanked
        state = tester.watchvideo_page.wait_for_LiveTVPlayback(status="PLAYING")
        if state:
            self.log.info(f"Current program of PPV channel {ppv_channel_number} is already rented")
            return True
        else:
            self.log.info(f"Current program of PPV channel {ppv_channel_number} is not rented yet")
            return False

    def verify_cc_track(self):
        """
        Verify Closed Caption tracks when we do not know the language
        """
        screen_dump = self.screen.get_screen_dump_item('menuitem')
        language = ""
        if screen_dump:
            language = screen_dump[0]['text'] if isinstance(screen_dump, list) else screen_dump['text']
        pattern1 = r"Original Language \[CC\d*\]"
        pattern2 = r"Original Language \[DTVCC\d*\]"
        if (re.search(pattern1, language) or re.search(pattern2, language)) is None:
            raise AssertionError("Original Language [<CC track>] not found")
