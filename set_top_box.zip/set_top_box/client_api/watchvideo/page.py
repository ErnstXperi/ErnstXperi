import os
import cv2
from dataclasses import dataclass
from urllib.parse import urlparse
from urllib.parse import parse_qs
from datetime import datetime, timedelta

import pytest
import pytesseract
from PIL import Image

from core_api.stb.assertions import CoreAssertions
from ..watchvideo.en_us.labels import LiveTvLabels
from tools.logger.logger import Logger
from set_top_box.test_settings import Settings
from tools.equipment_controller import DeviceController
from tools.ssh_adb_commands import SSH_ADBInterface  # used for controlling raspberry pi
from tools.video_qualty.video_qoe import Video_QOE
from set_top_box.conf_constants import DateTimeFormats


class WatchVideoBase(CoreAssertions):
    __log = Logger(__name__)
    liveTv_labels = LiveTvLabels()
    device_controller = DeviceController()

    def init_ssh(self):
        """
        Used to create a connection to raspberry pi
        """
        self._rasp = SSH_ADBInterface(Settings.rasp_ip, Settings.rasp_user, Settings.rasp_pwd,
                                      device_id=Settings.rasp_ip, transport="SSH",
                                      wondershaper_path="/sbin/wondershaper")

    def wait_for_playback(self, timeout=10000):
        """Method to wait for playback ongoing.

        Args:
            timeout: int, time in ms, to wait for info banner

        :return: bool, state of info banner visibility. True if ready and False if timeout ended
        """
        state = self.screen.base.driver.wait_for_event('LiveTvPlayback', timeout)
        return state

    def is_olg_visible(self):
        return self.ui_element_exists("oneLineGuideHeaderInfo")

    def get_live_tv_display_details(self, screen_dump={}, pause_time=5):
        self.pause(pause_time)
        if screen_dump == {}:
            screen_dump = self.screen.get_json()
            screen_data = (screen_dump['xml'])
        else:
            screen_data = screen_dump['xml']
        program_info_dict = {}
        if 'channel-number' in screen_data.keys():
            program_info_dict['channel_number'] = screen_data['channel-number']
            program_info_dict['channel_name'] = screen_data['call-sign']
            program_info_dict['description'] = screen_data['description']
        program_info_dict['time_slot'] = screen_data['show-time']
        program_info_dict['current_time'] = screen_data['current-local-time']
        self.screen.base.press_back()
        return program_info_dict

    def get_channel_number(self, screen_dump={}):
        self.log.info("Fetching channel number from screen dump")
        if screen_dump == {}:
            screen_dump = self.screen.get_json()
            screen_data = (screen_dump['xml'])
        else:
            screen_data = screen_dump['xml']
        return screen_data.get('channel-number')

    def get_video_format_icon(self):
        """
        :description:
            Field is located in the right column of the Info Baner Header
        :params:
        :return:
            string, video forma icon
        """
        return self.screen.get_screen_dump_item('videoformaticon')

    def get_channel_logo(self):
        """
        :description:
            Field is located in the right column of the Info Baner Header
        :params:
        :return:
            string, channel logo
        """
        return self.screen.get_screen_dump_item('channellogo')

    def get_channel_callsign(self):
        """
        :description:
            Get callsign from infobanner
        :params:
        :return:
            string, callsign
        """
        return self.screen.get_screen_dump_item('call-sign')

    def get_up_next_show(self):
        """
        :description:
            Field is located in the right column of the Info Baner Header
        :params:
        :return:
            string, up next show name
        """
        return self.screen.get_screen_dump_item('up-next')

    def is_message_area_text_visible_in_info_banner(self):
        """
        :description:
            Field is located in the message area of the Info Banner
            If message area is empty, then screen dump does not contain stripItemSubtitle
        :params:
        :return:
            bool, if Message Area contain any text
        """
        try:
            return bool(self.screen.get_screen_dump_item('stripItemSubtitle'))
        except Exception as ex:
            self.__log.warning("is_message_area_text_visible_in_info_banner: {}".format(ex))
            return False

    def turn_on_cc(self, tester, ON=True, press_back=True, consume_error=False):
        """
        Turn ON/OFF the CC

        Args:
            tester: instance of the test class
            ON (bool): if CC should be turned ON or OFF
            press_back (bool): if pressing back on the last Info Banner should be made.
                               It may be needed if next step calls Info Banner again
        """
        self.__log.step("Switch Close Captions using info banner to: '{}'".format("Enabled" if ON else "Disabled"))

        def f():
            self.__log.info(f"Pop up info banner and {ON} CC")
            label = self.liveTv_labels.LBL_TURN_CC_ON if ON else self.liveTv_labels.LBL_TURN_CC_OFF
            self.show_info_banner()
            self.navigate_by_strip(label)
            self.select_item(refresh=False)
            if Settings.is_managed():
                if ON:
                    self.__log.info("Enabling Closed captions")
                    tester.watchvideo_assertions.verify_cc_state(enable=True)
                else:
                    self.__log.info("Disabling Closed captions")
                    tester.watchvideo_assertions.verify_cc_state(enable=False)
            self.show_info_banner()
            label = self.liveTv_labels.LBL_TURN_CC_OFF if ON else self.liveTv_labels.LBL_TURN_CC_ON
            self.navigate_by_strip(label)
            tester.watchvideo_assertions.verify_cc(label)
            if press_back:
                self.screen.base.press_back()

        if consume_error:
            try:
                f()
            except Exception as err:
                self.__log.info("CC switching failed with err: {}".format(err))
                pass
        else:
            f()

    def show_home_menu_widget(self, screen_dump={}):
        self.log.info("Fetching home menu widgets from screendump")
        self.screen.base.press_down()
        if screen_dump == {}:
            self.screen.refresh()
            widget = self.screen.get_screen_dump_item('predictionPanelTitle')
        else:
            widget = self.screen.get_screen_dump_item('predictionPanelTitle')
        self.log.info(f"Widget: {widget}")
        return widget

    def watch_video_for(self, sec):
        self.__log.step(f"Going to watch playback for {sec} sec")
        step = 240  # 4 minutes
        wait_time = sec
        while (wait_time > 0):
            if wait_time > step:
                self.pause(step, "Staying in the recording playback")
                wait_time = wait_time - step
            else:
                self.pause(wait_time, "Staying in the recording playback")
                wait_time = 0
            self.verify_error_overlay_not_shown()
        self.screen.refresh()

    def calc_end_time_for_30_m_show(self, tester, vital_gap=3):
        """
        Counting show remaining time +2, to switch to new one.
        Gap should  be used if test preparing took longer.
        """
        to_wait = 30 - (int(tester.service_api.get_middle_mind_time()['currentTime'].split(":")[1]) % 30)
        if to_wait < vital_gap:
            self.log.info(f"Going to wait {to_wait + 1} for show rotation")
            self.pause((to_wait + 2) * 60)
            to_wait = 30 - (int(tester.service_api.get_middle_mind_time()['currentTime'].split(":")[1]) % 30)
        return to_wait + 2

    def full_info_banner_is_shown(self):
        screen = self.screen.screen_dump['xml']
        if self.is_infobanner_visible() and screen['mode'] == 'full':
            self.__log.info("Full info Banner is visible")
            return True
        else:
            self.__log.info("Full info Banner is not visible")
            return False

    def select_menu_in_infobanner(self, menu):
        self.__log.step("Select menu item: {} in infobanner".format(menu))
        count = 5
        while not self.substring_index(self.strip_list(), menu, ignore_error=True) and count > 0:
            self.press_right_button()
            self.screen.get_json()
            count = count - 1
        self.select_string_by_substring(menu)

    def press_pause_in_visual_trickplay(self, refresh=False):
        self.screen.base.press_enter()
        self.screen.base.press_enter()
        if refresh:
            self.screen.refresh()

    def tune_to_channel(self, channel):
        self.enter_channel_number(channel)
        self.wait_for_LiveTVPlayback(status="PLAYING")

    def startover_current_show_from_livetv_screen(self):
        self.screen.base.long_press_enter()
        self.screen.refresh()
        if self.is_overlay_shown():
            self.log.info("Overlay is displayed hence selecting Start over from beginning")
            self.select_menu(self.liveTv_labels.LBL_STARTOVER)
        self.wait_for_LiveTVPlayback(status="PLAYING")

    def wait_for_trickplay_bar_dismiss(self, time):
        self.log.step(f"Waiting for {time} for trickplay bar to dismiss")
        limit = 6
        self.screen.refresh()
        while self.is_infobanner_visible():
            self.pause(time)
            self.screen.refresh()
            limit -= 1
            if limit < 0:
                break

    def wait_for_resume_playing_overlay(self):
        self.log.info("Waiting for Resume Playing overlay.")
        self.pause(self.liveTv_labels.LBL_TIMEOUT_BEFORE_RESUME_PLAYING_OVERLAY)
        self.screen.refresh()

    def wait_for_resume_playing_overlay_timeout(self):
        self.log.info("Waiting for Resume Playing overlay dismiss by timeout.")
        self.pause(self.liveTv_labels.LBL_RESUME_PLAYING_OVERLAY_TIMEOUT)
        self.screen.refresh()

    def verify_standard_info_banner_brandingicon_shown(self):
        self.log.step("Checking branding icon on standard info banner")
        self.get_trickplay_visible()
        self.get_branding_icon()

    def verify_full_info_banner_brandingicon_is_shown(self):
        self.log.step("verifying if full info banner was displayed or not")
        state = self.wait_for_infobanner("FULL_EXPANDED")
        self.screen.refresh()
        self.get_branding_icon()
        if state:
            return True
        else:
            visibility = self.is_infobanner_visible()
            self.__log.info(f"Full info Banner visibility is: {visibility}")
            return visibility

    def select_startover_overlay_option(self, option):
        """
        Select desired option from startover overlay
        :param option: str, label to select
        :return:
        """
        if not self.is_menu_focus():
            loop_attempts = 0
            while not self.is_menu_focus():
                self.screen.base.press_down()
                self.screen.refresh()
                loop_attempts += 1
                if loop_attempts > 10:
                    break
        self.select_menu(option)

    def schedule_upcoming_rec_from_olg(self, one_pass=False, current=False):
        self.__log.step("schedule upcoming record from OLG. Params: one_pass={}, current={}".format(one_pass, current))
        self.open_olg()
        if current:
            self.screen.base.long_press_enter()
        else:
            self.press_right_button()
            self.pause(2)
            self.screen.base.press_enter()
        self.wait_for_screen_ready(self.liveTv_labels.LBL_RECORD_OVERLAY)
        self.screen.get_json()
        if not one_pass:
            lbl_record = self.liveTv_labels.LBL_RECORD
            lbl_overlay = self.liveTv_labels.LBL_RECORD
            screen_name = self.liveTv_labels.LBL_RECORD_OVERLAY
        else:
            lbl_record = self.get_onepass_menu_item()
            lbl_overlay = self.liveTv_labels.LBL_CREATE_ONEPASS_WITH_THESE_OPTIONS
            screen_name = self.liveTv_labels.LBL_ONEPASS_OVERLAY
        self.select_menu_by_substring(lbl_record)
        self.wait_for_screen_ready(screen_name)
        self.screen.get_json()
        if self.is_overlay_shown():
            self.select_menu_by_substring(lbl_overlay)

    def get_onepass_menu_item(self):
        self.log.info("Onepass menu item")
        self.screen.refresh()
        menu_item = self.menu_list()
        if self.liveTv_labels.LBL_PROGRAM_OPTIONS_CREATE_ONEPASS in menu_item:
            return self.liveTv_labels.LBL_PROGRAM_OPTIONS_CREATE_ONEPASS
        elif self.liveTv_labels.LBL_CREATE_ONEPASS in menu_item:
            return self.liveTv_labels.LBL_CREATE_ONEPASS
        elif self.liveTv_labels.LBL_CREATE_ONEPASS_SERIES in menu_item:
            return self.liveTv_labels.LBL_CREATE_ONEPASS_SERIES

    def startover_program_from_livetv_with_socu(self, tester, resume=False):
        """
        Starting SOCU offer from beginning while being in LiveTV
        """
        self.__log.info("Starting current show from beginning with 'SOCU'")
        self.screen.base.long_press_enter(time=5000)
        self.verify_error_overlay_not_shown()
        screen = self.screen.screen_dump['xml']
        if "overlayMode" in screen.keys() and screen['menuitem'] == self.liveTv_labels.LBL_STARTOVER_OVERLAY:
            self.select_startover_overlay_option(self.liveTv_labels.LBL_START_OVER_FROM_BEGINNING)
        else:
            self.screen.refresh()
            if self.screen.get_screen_dump_item('viewMode') == self.liveTv_labels.LBL_LIVETV_VIEWMODE:
                self.__log.warning(
                    "SOCU was NOT started with long pressing OK, trying 'Start over' option in Info Banner")
                self.show_info_banner()
                if "Start Over" in screen["trick-play"]["stripitem"]:
                    self.select_strip(self.liveTv_labels.LBL_START_OVER)
                else:
                    self.select_strip(self.liveTv_labels.LBL_RESTART)
        self.__log.info("Checking for VODResumeStartOverOverlay")
        state = self.wait_for_screen_ready(tester.guide_labels.LBL_RESUME_OVERLAY, timeout=10000)
        self.screen.refresh()
        if state and self.is_item_in_key('overlayMode'):
            self.__log.info("Overlay detected, trying to select resume/startover")
            if resume:
                self.select_menu(tester.guide_labels.LBL_RESUME_PLAYING)
            else:
                self.select_menu(tester.guide_labels.LBL_STARTOVER)
        else:
            self.log.info("Overlay is not shown, video is already playing.")

    def get_trickplay_current_position(self, refresh=True):
        if refresh:
            self.screen.get_json()
        trickplay = (self.screen.get_screen_dump_item('trick-play'))
        self.__log.info("current position size is {}".format(trickplay['current-pos']))
        return trickplay['current-pos']

    def get_trickplay_start_position(self, refresh=True):
        if refresh:
            self.screen.get_json()
        trickplay = (self.screen.get_screen_dump_item('trick-play'))
        self.__log.info("Start position size is {}".format(trickplay['replay-start']))
        return trickplay['replay-start']

    def get_trickplay_duration_in_sec(self, refresh=True):
        self.log.step("get duration of currently playing movie, recording, etc.")
        if refresh:
            self.screen.get_json()
        try:
            duration = self.convert_time_to_sec((self.screen.get_screen_dump_item('trick-play')['duration']))
            self.__log.info("Duration in seconds is {}".format(duration))
            return duration
        except KeyError:
            raise KeyError(
                "There is no trick-play menu or duration in screen dump: {}".format(self.screen.screen_dump['xml']))

    def rating_limits_osd_is_shown(self):
        self.__log.info("")
        screen = self.screen.get_json()['xml']
        if 'osdtext' in screen.keys() and screen['osdtext']['#text'] == self.liveTv_labels.LBL_RATING_LIMITS_OSD:
            return True
        else:
            return False

    def enter_channel_number_infobanner(self, channel):
        self.log.step("Entering channel {} by num keys".format(channel))
        if not str(channel).isnumeric():
            raise Exception(f"Wrong channel number: {channel}")
        self.screen.base.type_text(str(channel))
        self.screen.base.press_enter()
        return True

    def get_show_title(self):
        return self.screen.get_screen_dump_item('title')

    def show_trickplay(self, wait=False):
        """
        Trickplay appears with pressing OK
        Watch video screen should be displayed
        """
        self.__log.info("Showing the trickplay")
        self.screen.base.press_enter()
        if wait:
            self.wait_for_infobanner(status="STANDARD_WITH_TRICKPLAY")

    def get_overlay_body_text(self):
        self.log.info("Getting overlay body text.")
        screen = self.screen.screen_dump['xml']
        if 'bodytext' in screen.keys():
            return screen['bodytext']

    def get_confirm_jump_channel_overlay_visibility(self):
        self.log.info("Getting visibility of 'Confirm Jump Channel' overlay.")
        self.screen.refresh()
        if self.is_overlay_shown() and self.get_overlay_title() == self.liveTv_labels.LBL_CONFIRM_JUMP_CHANNEL_TITLE:
            return True
        else:
            return False

    def get_resume_playing_overlay_state(self):
        self.log.info("Getting Resume Playing overlay state")
        screen = self.screen.screen_dump['xml']
        if self.is_overlay_shown() and screen['overlayTitle'] == self.liveTv_labels.LBL_RESUME_PLAYING_OVERLAY:
            return True
        else:
            return False

    def _press_button_n_times(self, times, button):
        for _ in range(times):
            button()

    def navigate_to_the_end_of_video_and_complete(self, complete=True):
        """
        To navigate to the end of video. Use complete=False to reach NextEpisode banner in series
        :param complete: bool
        """
        self.log.step("Navigating to the end of video. (Forward)")
        self.press_ff(times=3)
        self.screen.get_json()
        while self.is_watch_video_mode(self) and \
                self.get_video_playback_mode() != self.liveTv_labels.LBL_PLAYBACK_IN_PLAY_MODE and \
                self.get_video_playback_mode() != self.liveTv_labels.LBL_PLAYBACK_IN_PAUSE_MODE and \
                not self.get_error_overlay_visibility(self):
            self.screen.refresh()
            if self.is_playnext_banner() or (self.is_overlay_title() and self.is_delete_recording_overlay()):
                if complete:
                    self.press_back_button()
                    self.screen.refresh()
                break

    def is_delete_recording_overlay(self):
        return self.get_overlay_title() == self.liveTv_labels.LBL_DELETE_REC_OVERL_TITLE

    def navigate_to_start_of_video(self):
        """
        To navigate to the start of the video.
        """
        self.log.step("Navigating to the start of video. (Rewind to the beginning)")
        self.press_rewind(3)
        self.screen.get_json()
        assert not self.get_error_overlay_visibility(self), f"Playback error: {self.get_ui_error()}"
        start = int(self.get_trickplay_start_position(refresh=False).split(":")[1])
        current = int(self.get_trickplay_current_position(refresh=False).split(":")[1])
        while self.is_watch_video_mode(self) and \
                self.get_video_playback_mode() != self.liveTv_labels.LBL_PLAYBACK_IN_PLAY_MODE and \
                not self.get_error_overlay_visibility(self):
            self.pause(current - start)
            self.screen.refresh()

    def navigate_to_end_of_video(self):
        """
        To navigate to the end of the video cache.
        """
        self.log.step("Navigating to the end of cache. (Forward to end of the cache)")
        self.screen.base.press_fast_forward()
        self.screen.base.press_fast_forward()
        self.screen.base.press_fast_forward()
        self.screen.get_json()
        assert not self.get_error_overlay_visibility(self), f"Playback error: {self.get_ui_error()}"
        start = int(self.get_trickplay_start_position(refresh=False).split(":")[1])
        current = int(self.get_trickplay_current_position(refresh=False).split(":")[1])
        self.log.info(f"start and current {start - current}")
        while self.is_watch_video_mode(self) and \
                self.get_video_playback_mode() != self.liveTv_labels.LBL_PLAYBACK_IN_PLAY_MODE and \
                not self.get_error_overlay_visibility(self):
            self.pause(current - start)
            self.screen.refresh()

    def fast_navigate_to_start_of_video(self):
        """
        To navigate to the start of the video cache. Used rewind + Replay for jumping through tickmarks
        """
        self.log.step("Navigating to the start of video. (Rewind to the beginning of the cache)")
        self.press_rewind(1)
        self.screen.get_json()
        while self.is_watch_video_mode(self) and \
                self.get_video_playback_mode() != self.liveTv_labels.LBL_PLAYBACK_IN_PLAY_MODE:
            self.press_replay_button()
            if self.get_error_overlay_visibility(self):
                raise Exception("Error overlay was shown while rewinding")
            self.screen.get_json()

    def fast_navigate_to_end_of_video(self):
        """
        To navigate to the end of the video cache. Used Forward + Advance for jumping through tickmarks
        """
        self.log.step("Navigating to the end of cache. (Forward to end of the cache)")
        self.screen.base.press_fast_forward()
        self.screen.get_json()
        while self.is_watch_video_mode(self) and \
                self.get_video_playback_mode() != self.liveTv_labels.LBL_PLAYBACK_IN_PLAY_MODE:
            self.press_advance_button()
            if self.get_error_overlay_visibility(self):
                raise Exception("Error overlay was shown while fast forwarding")
            self.screen.get_json()

    def get_cache_duration(self):
        """
        Get live cache duration in the str format. E.g. "00:59:33.570"
        Returns:
             str
        """
        trickplay = (self.screen.get_screen_dump_item('trick-play'))
        self.log.info("current cache size is {}".format(trickplay['replay-size']))
        return trickplay['replay-size']

    def get_cache_start_time_utc(self):
        """
        Get universal utc datetime for the start of the live tv cache
        Returns:
             datetime
        """
        utc_current_datetime = datetime.strptime(self.service_api.get_middle_mind_time(Settings.tsn)["currentTime"],
                                                 DateTimeFormats.TRIO_DT)
        cache_duration_datetime = datetime.strptime(self.get_cache_duration(), "%H:%M:%S.%f")
        cache_duration_timedelta = timedelta(hours=cache_duration_datetime.hour,
                                             minutes=cache_duration_datetime.minute,
                                             seconds=cache_duration_datetime.second)
        return utc_current_datetime - cache_duration_timedelta

    def get_cache_start_time_utc_open_api_str(self):
        """
        Get cache start time in utc in open api format
        Returns:
             str
        """
        return self.get_cache_start_time_utc().strftime(DateTimeFormats.ISO_DATE_TIME_WITH_Z)

    def select_option_in_playnext_banner(self, option):
        """
        Selects desired option in Play Next overlay
        :param option: str
        """
        screen = self.screen.get_json()['xml']
        count = 5
        if option == 'Hide':
            while 'playnextstrip' in screen['playnextbanner'].keys() and count != 0:
                self.press_right_button()
                self.screen.refresh()
                continue
            self.select_item()
        else:
            try:
                while option not in screen['playnextbanner']['playnextstrip'][0] and count != 0:
                    self.press_right_button()
                    self.screen.refresh()
                    continue
            except KeyError:
                self.screen.refresh()
                self.log.info("Verify whispher")
                self.verify_whisper(self.liveTv_labels.LBL_NEXT_EPISODE_OVERLAY, visible=False, raise_error=False)
                self.press_ok_button()
            self.select_item()
        self.pause(5)
        self.screen.refresh()

    def get_audio_tracks(self):
        """
        Return list of tuple of available audio track,
        currently selected contains True value
        """
        ret = []
        if not self.is_overlay_shown() or self.get_overlay_title() != self.liveTv_labels.LBL_AUDIO_TRACK_OVERLAY_TITLE:
            raise LookupError("Audio track overlay wasn't expanded cur screen {}".format(self.screen.screen_dump))
        for item in self.get_menu_item():
            if "imagename" in item.keys():
                ret.append({"text": item['text'], "selected": True, "imagename": item["imagename"]})
            else:
                ret.append({"text": item['text'], "selected": False, "imagename": None})
        return ret

    def contains_audio_track_name_duplicate(self, track_name):
        """
        Checking track name in change audio track overlay,
        sometimes it might contain same track name
        @param track_name: Track name to be examined
        @type track_name: string
        @rtype: bool
        """
        counter = 0
        for name in self.get_audio_tracks():
            if name["text"] == track_name:
                counter += 1
        if counter >= 2:
            return True
        return False

    def get_audio_track(self, selected=False):
        for item in self.get_audio_tracks():
            if selected is item['selected']:
                return item['text']

    def get_currently_playing_episode(self):
        self.log.info("Getting currently playing episode.")
        screen = self.screen.get_json()['xml']
        if 'series' in screen.keys():
            return screen['series']
        else:
            self.log.info("Currently playing show is not series.")

    def skip_hdmi_connection_error(self):
        """Method to confirm and skip HDMI permission error if Error is present else do nothing"""
        errors_list = self.get_ui_error()
        error_str = "{}".format(errors_list)
        if errors_list:
            for step in range(3):
                if self.liveTv_labels.LBL_GOINGTOLIVETV_OVERLAY in error_str:
                    # if stream is loading then will wait a little bit more 3s -> 8s -> 13s - > 18s
                    self.log.info("[confirm_modal_ui_errors] Stream is loading slow")
                    self.pause(5 * step + 3)
                    self.screen.refresh()
                    errors_list = self.get_ui_error()
                    error_str = "{}".format(errors_list)
                else:
                    break
            if self.liveTv_labels.LBL_HDMI_OSD in error_str:
                self.log.warning("Going to accept UI error: '{}'".format(error_str))
                self.screen.base.press_enter()
                self.screen.refresh()
                errors_list = self.get_ui_error()
                error_str = "{}".format(errors_list)
                if self.liveTv_labels.LBL_HDMI_OVERLAY in error_str:
                    self.log.warning("One more error: '{}'".format(error_str))
                    self.screen.base.press_enter()
                    self.screen.refresh()
                    errors_list = self.get_ui_error()
                    error_str = "{}".format(errors_list)
                    self.log.warning("State after accepting HDMI overlay {}".format(error_str))
            else:
                self.log.error("Looks like there is a bug: {}".format(error_str))
        else:
            self.log.info("No errors detected :)")

    def is_press_and_hold_tip_shown_in_watch_live_tv(self):
        """
        If Press & Hold tip text is displayed above the Info Banner
        bannerTip param is not present in the screen dump if there's no banner tip text on UI

        Returns:
            bool
        """
        try:
            return bool(self.screen.get_screen_dump_item('bannerTip'))
        except Exception as ex:
            self.__log.warning("is_press_and_hold_tip_shown_in_watch_live_tv: {}".format(ex))
            return False

    def show_info_banner(self):
        self.log.step("Invoking Info Banner.")
        self.screen.base.press_info()
        self.screen.get_json()
        self.wait_for_infobanner(status='dismissed', timeout=12000)  # default timeout for infobanner
        self.screen.base.press_info()

    def close_info_banner(self):
        self.log.step("Close Info Banner.")
        self.screen.base.press_info()
        self.screen.get_json()
        self.wait_for_infobanner(status='dismissed', timeout=12000)

    def press_ff(self, times=1):
        self._press_button_n_times(times, self.press_ff_button)

    def press_rewind(self, times=1):
        self._press_button_n_times(times, self.press_rewind_button)

    def take_screenrecord_and_pull(self, filename, source, destination, time):
        """
        :description:
            Invoke method to capture the screenrecord of the app
            pull the recorded video
        :param:
            filename - name to be used for recorded content
            source - source from where to pull the file
            destination - destination where to copy the file
            time - time to wait for info banner to dismiss
        :return:
        """
        self.screen.base.capture_screenrecord(filename, time=time, destination=destination)

    def get_cc_rendered(self, video, os_remove=True):
        """
        :description:
            get cc/subtitle is rendered on the screen on exoplayer
        :param:
            video - Video that is captured on exoplayer
        :return: If the subtitle rendered is True or False
        """
        self.log.step("Checking if cc is rendered or not in video : {}".format(video))
        videocapture = cv2.VideoCapture(video)
        length = int(videocapture.get(cv2.CAP_PROP_FRAME_COUNT))
        self.log.info("video frame count: {}".format(length))
        success, image = videocapture.read()
        ccrendered = False
        if success and length > 0:
            for i in range(length):
                cv2.imwrite("frame%d.jpg" % i, image)
                success, image = videocapture.read()
                frame = Image.open("frame%d.jpg" % i)
                text = pytesseract.image_to_string(frame)
                os.remove("frame%d.jpg" % i)
                self.log.info("text : {}".format(text))
                self.log.info("text length: {}".format(len(text)))
                len_text = len(text) - 1
                if len_text > 0:
                    self.log.info("CC in frame: {}".format(("frame%d.jpg" % i)))
                    ccrendered = True
                    break
        if os_remove:
            os.remove(video)
        self.log.info("ccrendered: {}".format(ccrendered))
        return ccrendered

    def press_left_multiple_times(self, no_of_times=1):
        self.screen.refresh()
        for i in range(no_of_times):
            self.screen.base.press_left()
        self.pause(2)

    def press_right_multiple_times(self, no_of_times=1, refresh=True):
        if refresh:
            self.screen.refresh()
        for i in range(no_of_times):
            self.screen.base.press_right()
        self.pause(2)

    def press_up_multiple_times(self, no_of_times=1):
        self.screen.refresh()
        for i in range(no_of_times):
            self.screen.base.press_up()

    def press_down_multiple_times(self, no_of_times=1):
        self.screen.refresh()
        for i in range(no_of_times):
            self.screen.base.press_down()

    def show_trickplay_if_not_visible(self, refresh=False, wait=False):
        if refresh:
            self.screen.refresh()
        if not self.is_infobanner_visible():
            self.show_trickplay(wait=wait)

    def index_position_of_icon(self, icon=None, refresh=True, exact_icon_match=False):
        # refresh is needed to get the updated dump
        if refresh:
            self.screen.get_json()
        dump_after = self.screen.get_screen_dump_item('trick-play')
        screen_dump_after = dump_after.get('stripitem')
        icons = []
        i = 0
        found_icon = True
        for item in screen_dump_after:
            icons.append([item.get('text'), item.get('imagename')])
        if not exact_icon_match:
            if icon not in str(icons):
                found_icon = False
        else:
            found_icon = list(filter(lambda x: x if x[0] == icon else None, icons))
        if not found_icon:
            self.log.error("Icon: {} is not there in trickplaybar".format(icon))
            return None
        for item in icons:
            if item[0] == icon and 'disabled' in item[1]:
                return None
            elif item[0] == icon:
                break
            elif 'disabled' not in item[1]:
                i = i + 1
        return i

    def set_favorite_channels(self, tester, count, adult=False):
        tester.menu_page.go_to_user_preferences(tester)
        tester.menu_page.go_to_favorite_channels()
        tester.menu_assertions.verify_favorite_channels_screen_title()
        if adult:
            channels = tester.api.get_random_live_channel_rich_info(channel_count=count, filter_channel=True,
                                                                    transport_type="stream", adult=True, episodic=True)
            if not channels:
                pytest.skip("Service query couldn't fetch adult channels")
            else:
                self.log.info("Channel list is : {}".format(str(channels)))
                actual_channel_count = len(channels)
                if count > actual_channel_count:
                    count = actual_channel_count
                for i in range(0, count):
                    self.log.info("Trying to select channel : {}".format(channels[i][0]))
                    tester.guide_page.enter_channel_number(channels[i][0])
                    self.pause(3)
                    tester.menu_page.checkbox_option_in_focus(tester)
        else:
            for i in range(count):
                tester.menu_page.checkbox_option_in_focus(tester)

    def remove_favorite_channels_from_favorite_panel(self, tester, count):
        self.open_favorite_panel(refresh=False)
        for i in range(count):
            tester.watchvideo_assertions.verify_favorite_channels_panel_shown()
            tester.guide_page.press_info_or_long_press_enter()
            tester.watchvideo_assertions.verify_overlay_title(self.liveTv_labels.LBL_CHANNEL_OPTIONS)
            self.select_menu(self.liveTv_labels.LBL_REMOVE_FROM_FAVORITE_CHANNELS)

    def get_trickplay_button_status(self, button):
        """
        To get trickplay menu button status
        :param button: string
        :return: string
        """
        trickplay = self.screen.get_screen_dump_item('trick-play', 'stripitem')
        status = ''
        for i in trickplay:
            if i['text'] != button:
                continue
            else:
                if 'disabled' in i['imagename']:
                    status = 'disabled'
                else:
                    status = 'enabled'
                break
        return status

    def get_playback_status(self):
        """
        DEMO method. need to be refactored
        Returns:

        """
        cur_raw_state = self.screen.base.driver.get_event_state('LiveTvPlayback')
        if cur_raw_state:
            state = "PLAY"
        else:
            state = "PAUSE"
        return state

    def play_pause_playback(self, state):
        """
        DEMO method. need to be refactored
        Returns:

        """
        if self.get_playback_status() != state:
            self.screen.base.press_enter()

    def is_tivo_plus_eula_overlay_shown(self):
        self.screen.refresh()
        return self.is_overlay_shown() and self.get_overlay_title() == self.liveTv_labels.LBL_TIVO_PLUS_EULA_OVERLAY_TITLE

    def is_tivo_plus_eula_osd_shown(self):
        return self.osd_shown() and self.osd_text() == self.liveTv_labels.LBL_TIVO_PLUS_EULA_OSD_TEXT

    def tune_to_tivo_plus_channel(self, channel):
        """
        Tunes to TiVo+ channel from watchvideo screen
        """
        self.enter_channel_number(channel)
        if self.get_trickplay_visible():
            self.wait_for_infobanner(status='dismissed')
        if self.is_tivo_plus_eula_osd_shown():
            self.press_ok_button()
            self.select_menu(self.liveTv_labels.LBL_ACCEPT)

    def press_back_to_navigate_to_action_screen(self):
        self.log.step("Navigating back to action screen from recording playback screen")
        self.screen.refresh()
        self.wait_for_trickplay_bar_dismiss(Settings.trickplay_bar_timeout_in_pause_mode)
        self.screen.base.press_back()

    def get_strip_focus_index_of_trickplay_icon(self, refresh=True):
        if refresh:
            self.screen.refresh()
        focus_index = self.return_trickplay_stripfocus_index()
        return focus_index

    def get_genre_details(self, refresh=False):
        if refresh:
            self.screen.refresh()
        genre_detail = self.screen.get_screen_dump_item('previewPane')['genre']
        count = len(genre_detail.split())
        if count > 1:
            genre_detail_split = genre_detail.split()
            genre = genre_detail_split[0]
        else:
            genre = genre_detail
        return genre

    def get_trickplay_text_play_or_pause(self):
        self.screen.refresh()
        trickplay = self.screen.get_screen_dump_item('trick-play', 'stripitem')
        for item in trickplay:
            self.log.info("item is {}".format(item))
            if self.liveTv_labels.LBL_PAUSE_OPTION == item['text']:
                mode = item['text']
                self.log.info("Mode is {}".format(mode))
                status = mode
                break
            elif self.liveTv_labels.LBL_PLAY_OPTION == item['text']:
                mode = item['text']
                self.log.info("Mode is {}".format(mode))
                status = mode
                break
            else:
                continue
        return status

    def startover_program_from_livetv_with_color_button_a(self, resume=False):
        """
        Starting SOCU offer from beginning while being in LiveTV
        """
        self.__log.info("Starting current show from beginning with 'SOCU' by pressing color button A")
        self.screen.base.press_color_button_a()
        self.__log.info("Checking for ResumeStartOverOverlay")
        state = self.wait_for_screen_ready(self.liveTv_labels.LBL_RESUME_OVERLAY, timeout=10000)
        if state:
            self.__log.info("Overlay detected, trying to select resume/startover")
            self.screen.refresh()
            if resume:
                self.select_menu(self.liveTv_labels.LBL_RESUME_PLAYING)
            else:
                self.select_menu(self.liveTv_labels.LBL_STARTOVER)
        else:
            self.log.info("Overlay is not shown, video is already playing.")
        self.verify_error_overlay_not_shown()

    def show_network_osd(self):
        self.screen.base.press_up()
        self.screen.base.press_up()
        self.screen.base.press_down()
        self.screen.base.press_down()
        self.screen.base.press_left()
        self.screen.base.press_right()
        self.screen.base.press_left()
        self.screen.base.press_right()
        self.screen.base.press_up()
        self.screen.base.press_up()
        self.screen.base.press_right()

    def wonder_restrict_bandwidth(self, upload, download):
        self._rasp.limit_eth_channel_speed(upload, download)

    def wonder_relax_bandwidth_restrictions(self):
        self._rasp.remove_eth_channel_limitation()

    def pause_with_video_buffer(self):
        self.pause(self.get_buffer_size())

    def get_rasp(self):
        return self._rasp

    def get_buffer_size(self):
        self.screen.refresh()
        screen_dump = self.screen.get_screen_dump_item()
        netstats = screen_dump.get('streammetrics')
        netstats = netstats[4]['option']['text']
        netstats = netstats.replace(" s", "")
        return int(netstats)

    def get_bitrate_used(self):
        screen_dump = self.screen.get_screen_dump_item()
        netstats = screen_dump.get('streammetrics')
        return netstats[3]['option']['text']

    def get_connection_speed(self):
        connection_speed = {}
        results = 0

        # take 3 snapshots of connection speed because connection speed fluctuate above throttle speed
        for i in range(3):
            self.screen.refresh()
            screen_dump = self.screen.get_screen_dump_item()
            netstats = screen_dump.get('streammetrics')
            netstats = netstats[2]['option']['text']
            netstats = netstats.replace(" Kbps", "")
            self.__log.info("Connection Speed: {}".format(netstats))
            connection_speed[i] = int(netstats)

        # average connection speed
        for index in connection_speed:
            results = results + connection_speed[index]
        results = results / 3

        self.__log.info("Average Connection Speed: {}".format(results))
        return int(results)  # return integer without unit

    def find_channel_on_favorite_panel(self, channel_num):
        channel_list = self.screen.get_screen_dump_item('stripitem')
        self.log.info("Favorite panel has {}".format(channel_list))
        if isinstance(channel_list, dict):
            self.press_ok_button()
        if isinstance(channel_list, list):
            for i in range(len(channel_list)):
                if channel_num == channel_list[i].get('text')[1].split()[1]:
                    self.log.info("pressing ok on {}".format(channel_num))
                    self.press_ok_button()
                    break
                else:
                    self.screen.base.press_right()

    def get_channels_list_on_favorite_panel(self):
        channel_list = self.screen.get_screen_dump_item('stripitem')
        self.log.info("Favorite panel has {}".format(channel_list))
        if isinstance(channel_list, dict):
            self.press_ok_button()
        if isinstance(channel_list, list):
            fav_list = []
            for i in range(len(channel_list)):
                channel_number = channel_list[i].get('text')[0].split()[1]
                if channel_list[i].get('text')[0].split()[0] != 'CH':
                    channel_number = channel_list[i].get('text')[1].split()[1]
                fav_list.append(channel_number)
            return fav_list

    def get_strip_focus_of_trickplay_bar(self):
        self.screen.refresh()
        strip_focus = self.return_trickplay_stripfocus()
        text = strip_focus['text']
        self.log.info("Focussed text is {}".format(text))
        return text

    def turn_on_device_power(self, equip_id):
        self.device_controller.toggle_device_power(equip_id, "ON")

    def turn_off_device_power(self, equip_id):
        self.device_controller.toggle_device_power(equip_id, "OFF")

    def verify_next_or_previous_channel_is_good_channel(self, tester, channel_num, channel="channel up"):
        tester.watchvideo_assertions.press_channel_button_and_verify_channel_change(channel)
        for i in range(10):
            self.log.info("Checking next or previous channel is good channel")
            self.wait_for_screen_ready()
            if self.get_confirm_jump_channel_overlay_visibility():
                self.select_menu_by_substring(self.liveTv_labels.LBL_NEXT_CHANNEL)
                tester.watchvideo_page.wait_for_LiveTVPlayback(status="PLAYING")
                if not self.get_confirm_jump_channel_overlay_visibility():
                    break
                else:
                    continue
            elif self.osd_shown():
                tester.watchvideo_assertions.press_channel_button_and_verify_channel_change(channel)
                tester.watchvideo_page.wait_for_LiveTVPlayback(status="PLAYING")
                if not self.osd_shown():
                    break
                else:
                    continue
            elif self.get_error_overlay_visibility(self):
                self.screen.base.press_enter()
                tester.guide_assertions.verify_guide_title()
                tester.guide_page.enter_channel_number(channel_num, confirm=True)
                tester.watchvideo_assertions.verify_livetv_mode()
                break
            else:
                tester.watchvideo_assertions.verify_livetv_mode()
                break

    def get_subtitle_list(self):
        menuitem = self.screen.get_screen_dump_item('menuitem')
        sub_list = []
        for item in menuitem:
            sub_list.append(item['text'])
        self.log.info("List items are {}".format(sub_list))
        return sub_list

    def get_screen_resolution(self, retries=3):
        resolution = None
        for i in range(0, retries):
            self.show_network_osd()
            self.pause(2)
            self.screen.refresh()
            screen_dump = self.screen.get_screen_dump_item()
            try:
                resolution = screen_dump.get('streammetrics')[1]['option']['text'].split(",")[0]
                break
            except TypeError as exception:
                self.log.debug(f"Got type error when trying to get screen resolution, retrying. {str(exception)}")
        if not resolution:
            raise LookupError(f"Failed to get resolution from overlay after {retries} retries.")
        self.log.info("Debug overlay screen resolution value is {}".format(resolution))
        self.screen.base.press_back()  # Dismiss debug overlay
        return resolution

    def get_screen_frame_rate(self):
        self.show_network_osd()
        self.pause(self.liveTv_labels.LBL_OSD_PAUSE_TIME)
        self.screen.refresh()
        screen_dump = self.screen.get_screen_dump_item()
        frame_rate = screen_dump.get('streammetrics')[1]['option']['text'].split(",")[1]
        self.log.info("Debug overlay frame rate value is {}".format(frame_rate))
        self.screen.base.press_back()  # Dismiss debug overlay
        return frame_rate

    def get_can_not_watch_show_overlay_visibility(self):
        self.log.info("Getting visibility of 'can't watch show ' overlay.")
        self.screen.refresh()
        if self.is_overlay_shown() and self.get_overlay_title() == \
                self.liveTv_labels.LBL_CAN_NOT_WATCH_OVERLAY_SHOW_TITLE:
            return True
        else:
            return False

    def get_playback_screen_channel_streaming_url_drm_details(self):
        @dataclass
        class ChannelInfo:
            """ Class for channel details """
            channel: str = None
            streaming_url: str = None
            drm_type: str = None
            media_format: str = None
        self.show_network_osd()
        self.pause(2)
        self.screen.refresh()
        screen_dump = self.screen.get_screen_dump_item()
        self.log.info(f"Screen Dump: {screen_dump}")
        try:
            streammetrics = screen_dump.get('streammetrics')
            channel_text = streammetrics[0].get('option', {}).get('text')
            if channel_text and channel_text.startswith('tivo:'):
                channel = channel_text
            elif channel_text:
                try:
                    channel = channel_text.split(' ')[1].lower()
                except IndexError as e:
                    raise IndexError(f"{e}. Channel text: {channel_text}")
            else:
                raise LookupError(f"Channel text: '{channel_text}'. Streammetrics: {streammetrics}")
            streaming_url = streammetrics[5]['option']['text']
            if streaming_url:
                # TODO delete workaround when fixed streaming_url for 4k channels
                if ('4k' in streaming_url or '4K' in streaming_url) and ('SaaS_hls_widevine' not in streaming_url):
                    first_streaming_url = streaming_url
                    streaming_url = streaming_url.replace('hls_widevine', 'SaaS_hls_widevine')
                    self.log.warning(f'streaming_url changed because of workaround: '
                                     f'was "{first_streaming_url}" now "{streaming_url}"')
                parsed_url = parse_qs(urlparse(streaming_url).query)
                if 'ccur_fmt_type' in parsed_url:
                    media_format = parsed_url.get('ccur_fmt_type')[0]
                else:
                    media_format = None
                    self.log.info("The streaming URL doesn`t contain media data.")
            else:
                raise LookupError(f"The streaming_url expected URL link but got: {streaming_url}")
        except Exception:
            raise LookupError(f"The screen dump doesn't have a 'streammetric' "
                              f"dictionary, the actual result: {screen_dump}")
        if "widevine" in streaming_url:
            drm_type = "Widevine"
        else:
            drm_type = "Verimatrix"
        channel_details = ChannelInfo(channel, streaming_url, drm_type, media_format)
        self.log.info(f"Debug overlay screen details are {channel_details.__dict__}")
        self.screen.base.press_back()  # Dismiss debug overlay
        return channel_details

    def schedule_recording_from_info_banner(self, tester):
        self.log.info("Scheduling record from info banner")
        self.show_info_banner()
        self.pause(4)
        self.close_info_banner()
        self.show_info_banner()
        tester.watchvideo_assertions.verify_full_info_banner_is_shown()
        self.select_strip(self.liveTv_labels.LBL_RECORD)
        self.wait_for_screen_ready(tester.guide_labels.LBL_RECORD_OVERLAY)
        tester.watchvideo_assertions.verify_overlay()
        self.nav_to_menu_by_substring(tester.guide_labels.LBL_RECORD)
        self.press_ok_button(refresh=False)
        tester.watchvideo_assertions.verify_whisper_shown(tester.guide_labels.LBL_RECORD_SCHEDULED)

    def perform_trickplay_operation(self, tester, channel_number, times=1):
        self.log.info("Perfoming trickplay operations")
        self.tune_to_channel(channel_number)
        tester.watchvideo_assertions.verify_playback_play()
        for i in range(times):
            tester.guide_page.rewind_show(tester, 3)
            self.screen.base.press_playpause()
            tester.guide_page.fast_forward_show(tester, 3)
            self.screen.base.press_playpause()
            tester.guide_page.pause_show(tester)
            self.screen.base.press_playpause()
            tester.watchvideo_assertions.verify_playback_play()

    def check_RAM_every_hour(self, tester, channel_number):
        self.log.info("CHecking RAM for every hour")
        self.schedule_recording_from_info_banner(tester)
        ram, zram, lostram = self.screen.base.driver.meminfo_stats()
        self.log.info(f"RAM after scheduling record: {ram} ZRAM {zram} LOSTRAM {lostram}")
        self.watch_video_for(60 * 120)
        ram, zram, lostram = self.screen.base.driver.meminfo_stats()
        self.log.info(f"After 2Hrs on LiveTv: RAM {ram} ZRAM {zram} LOSTRAM {lostram}")
        self.perform_trickplay_operation(tester, channel_number, times=5)
        ram, zram, lostram = self.screen.base.driver.meminfo_stats()
        self.log.info(f"RAM After performing trickplay ops: {ram} ZRAM {zram} LOSTRAM {lostram}")
        self.watch_video_for(60 * 180)
        ram, zram, lostram = self.screen.base.driver.meminfo_stats()
        self.log.info(f"After 3Hrs on LiveTv: RAM {ram} ZRAM {zram} LOSTRAM {lostram}")

    def launch_installed_apps_and_check_RAM(self, tester):
        self.log.info("Trying to launch installed apps from ADB.")
        for app in tester.home_labels.LBL_LIST_OF_PACKAGE_NAMES:
            if self.screen.base.is_app_installed(app):
                self.log.info(f"Launching app: {app}")
                self.screen.base.launch_application(app)
                self.pause(45)

    def fetch_video_quality_details(self, channel):
        file_name = self.screen.base.get_device_log_location()
        vq_measurement = Video_QOE(file_name)
        qoe_values = vq_measurement.fetch_video_quality_values(channel)
        self.log.info("Video Quality Details: {}".format(qoe_values))
        return qoe_values

    def get_program_temporarily_unavailable_overlay_visibility(self):
        self.log.info("Getting visibility of 'Program Temporarily Unavailable' overlay.")
        self.screen.refresh()
        if self.is_overlay_shown() and self.get_overlay_title() == \
                self.liveTv_labels.LBL_PROGRAM_TEMPORARILY_UNAVAILABILITY_CHANNEL_TITLE:
            return True
        else:
            return False

    def get_unsubscribed_osd_text(self, tester):
        self.log.step("Getting visibility of Unsubscribed OSD text.")
        self.screen.refresh()
        if self.osd_shown():
            osdtext = self.screen.get_screen_dump_item('osdtext')
            if tester.watchvideo_labels.LBL_CHANNEL_NOT_SUBSCRIBED_OSD_TEXT in osdtext:
                return True
            else:
                return False
        else:
            return False

    def verify_channel_name_present_on_unsubscribed_osdtext(self, tester, channel_name):
        self.log.step("Verifying Correct Channel name present on  Unsubscribed OSD text.")
        self.screen.refresh()
        osdtext = self.screen.get_screen_dump_item('osdtext')
        channel_name = self.convert_special_chars(channel_name)
        if tester.watchvideo_labels.LBL_CHANNEL_NOT_SUBSCRIBED_OSD_FULL_TEXT in osdtext:
            pass
        elif channel_name not in osdtext:
            raise AssertionError("Unable to verify Channel name on Unsubscription OSD text")

    def channel_change_including_error_channel(self, tester, channel="channel up", channel_name_confirmation=False,
                                               no_of_times=100):
        self.log.info("Checking focused/next/previous channel is error channel")
        for i in range(no_of_times):
            self.wait_for_screen_ready(self.liveTv_labels.LBL_LIVETV_VIEWMODE, timeout=10000)
            self.screen.refresh()
            if self.get_error_overlay_visibility(self) or \
                    self.get_program_temporarily_unavailable_overlay_visibility():
                self.select_menu(tester.home_labels.LBL_OK)
                tester.guide_assertions.verify_guide_title()
                tester.guide_assertions.verify_guide_screen(self)
                if channel == "channel up":
                    self.screen.base.press_up()
                    tester.guide_page.get_live_program_name(tester)
                    tester.guide_page.select_and_watch_program(tester)
                else:
                    self.screen.base.press_down()
                    tester.guide_page.get_live_program_name(tester)
                    tester.guide_page.select_and_watch_program(tester)
            elif self.get_confirm_jump_channel_overlay_visibility():
                self.select_menu_by_substring(self.liveTv_labels.LBL_NEXT_CHANNEL)
            elif self.get_unsubscribed_osd_text(tester) and channel_name_confirmation:
                channel_number = self.get_channel_number()
                channel_details_dict = tester.api_parser.get_channel_details(channel_number, is_received=None)
                channel_name = channel_details_dict["collectionTitle"]
                self.verify_channel_name_present_on_unsubscribed_osdtext(tester, channel_name)
                if channel == "channel up":
                    self.press_channel_up_button()
                else:
                    self.press_channel_down_button()
            else:
                if channel == "channel up":
                    self.press_channel_up_button()
                else:
                    self.press_channel_down_button()

    def verify_long_hours_playback(self, tester, no_of_hrs=24):
        self.log.info("Verifying playback for long hrs")
        for i in range(no_of_hrs):
            self.log.info("started {} hours ".format(i))
            self.watch_video_for(60 * 60)
            tester.watchvideo_assertions.verify_playback_play()
            tester.guide_assertions.verify_play_normal()

    def verify_program_time_and_sys_time_for_next_few_channels(self, tester):
        self.log.info("verifying program time and system time for next few channels..")
        for _ in range(5):
            self.channel_change_including_error_channel(tester, no_of_times=1)
            self.wait_for_screen_ready(self.liveTv_labels.LBL_LIVETV_SCREEN)
            tester.watchvideo_assertions.verify_playback_play()
            tester.watchvideo_page.show_trickplay_if_not_visible(refresh=True)
            tester.watchvideo_assertions.verify_program_time_and_system_time(tester)

    def check_current_program_has_tvrating(self, channel_number):
        channel_number, metadata_list = self.api_parser.get_meta_data_information_of_show(
            channel_no=channel_number)
        self.log.info(f"Metadata list of channel {channel_number} is {metadata_list}")
        if 'tvRating' in metadata_list:
            return True
        else:
            return False

    def get_channel_list_from_open_api(self):
        channel_list = self.mind_if.open_api.get_channel_search()
        return channel_list

    def stop_recording_from_info_banner_action_list(self, tester):
        """
        Go to Full Info Banner and delete recording by Stop Recording Action
        """
        self.wait_for_trickplay_bar_dismiss(Settings.trickplay_bar_timeout + 12)
        tester.watchvideo_assertions.verify_trickplay_bar_not_shown()
        self.press_down_button()
        self.screen.get_json()
        self.select_strip(self.liveTv_labels.LBL_STOP_RECORDING)
        self.wait_for_screen_ready(self.liveTv_labels.LBL_STOP_RECORDING_OVERLAY)
        self.nav_to_menu_by_substring(self.liveTv_labels.LBL_STOP_AND_DELETE)
        self.press_ok_button(refresh=False)
        self.pause(4)
