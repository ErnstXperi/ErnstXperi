from set_top_box.client_api.watchvideo.page import WatchVideoBase as Default
from set_top_box.test_settings import Settings
from tools.logger.logger import Logger


class UnManagedWatchVideo(Default):
    __log = Logger(__name__)

    def show_info_banner(self, refresh=True):
        self.__log.step("Show Info Banner. UnManged device")

        if self.get_trickplay_visible():
            self.wait_for_trickplay_bar_dismiss(70)  # max trickplay timeout
            self.screen.refresh()
        self.screen.base.press_down()
        self.pause(2)
        if refresh:
            self.screen.get_json()
            self.wait_for_infobanner(status='dismissed', timeout=12000)  # default timeout for infobanner
            self.screen.base.press_down()

    def close_info_banner(self):
        self.__log.step("Close Info Banner.")
        self.screen.base.press_back()
        self.screen.get_json()

    def press_ff(self, times=1):
        def button():
            self.press_right_button()
            self.press_ok_button(refresh=False)
            self.press_left_button()

        self._press_button_n_times(times, button)

    def press_rewind(self, times=1):

        def button():
            self.press_left_button()
            self.press_ok_button(refresh=False)
            self.press_right_button()
        self._press_button_n_times(times, button)
