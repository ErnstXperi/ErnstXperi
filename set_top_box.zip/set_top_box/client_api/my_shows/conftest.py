import pytest

from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.my_shows.assertions import MyShowsAssertions
from set_top_box.client_api.VOD.assertions import VODAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.client_api.guide.assertions import GuideAssertions
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.client_api.wtw.assertions import WhatToWatchAssertions
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from set_top_box.test_settings import Settings
from tools.logger.logger import Logger

__log = Logger(__name__)


@pytest.fixture(autouse=True, scope="class")
def setup_my_shows(request):
    """
    Configure steps to be executed before the test cases run
    :param request:
    :return:
    """
    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_assertions = HomeAssertions(request.cls.screen)
    request.cls.home_labels = LabelFactory("home", Settings)

    request.cls.wtw_page = PageFactory("wtw", Settings, request.cls.screen)
    request.cls.wtw_assertions = WhatToWatchAssertions(request.cls.screen)
    request.cls.wtw_assertions.wtw_page = request.cls.wtw_page
    request.cls.wtw_page.wtw_labels = request.cls.wtw_labels
    request.cls.wtw_assertions.wtw_labels = request.cls.wtw_labels
    request.cls.wtw_page.home_labels = request.cls.home_labels
    request.cls.wtw_assertions.home_labels = request.cls.home_labels
    request.cls.wtw_page.labels = request.cls.wtw_labels = LabelFactory("wtw", Settings)

    request.cls.my_shows_page = PageFactory("my_shows", Settings, request.cls.screen)
    request.cls.my_shows_labels = LabelFactory("my_shows", Settings)
    request.cls.my_shows_page.my_shows_labels = request.cls.my_shows_labels
    request.cls.my_shows_assertions = MyShowsAssertions(request.cls.screen)
    request.cls.my_shows_assertions.my_shows_labels = request.cls.my_shows_labels

    request.cls.text_search_labels = LabelFactory("text_search", Settings)
    request.cls.text_search_page = PageFactory("text_search", Settings, request.cls.screen)
    request.cls.text_search_page.text_search_labels = request.cls.text_search_labels

    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)
    request.cls.menu_labels = LabelFactory("Menu", Settings)

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)
    request.cls.guide_assertions.guide_labels = request.cls.guide_labels
    request.cls.guide_page.guide_labels = request.cls.guide_labels

    request.cls.watchvideo_page = request.cls.live_tv_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.watchvideo_assertions = request.cls.live_tv_assertions = WatchVideoAssertions(request.cls.screen)
    request.cls.live_tv_labels = request.cls.liveTv_labels = LabelFactory("watchvideo", Settings)
    request.cls.watchvideo_labels = request.cls.live_tv_labels
    request.cls.guide_assertions.liveTv_labels = request.cls.live_tv_labels
    request.cls.watchvideo_assertions.watchvideo_labels = request.cls.watchvideo_labels

    request.cls.vod_assertions = VODAssertions(request.cls.screen)

    request.cls.text_search_page = PageFactory("text_search", Settings, request.cls.screen)
    request.cls.text_search_page.text_search_labels = request.cls.text_search_labels

    request.getfixturevalue('device_reboot_to_imporve_device_perf')
    request.getfixturevalue('clean_ftux_and_sign_in')
    request.getfixturevalue('disable_parental_controls')


@pytest.fixture(autouse=False, scope="function")
def setup_my_shows_sort_to_date(request):
    __log.info("Start: setup_my_shows_sort_to_date")
    request.cls.home_page.back_to_home_short()
    request.cls.home_assertions.verify_menu_item_available(request.cls.home_labels.LBL_MENU_SHORTCUT)
    request.cls.home_page.select_menu_shortcut(request.cls.home_labels.LBL_MENU_SHORTCUT)
    request.cls.menu_page.nav_to_top_of_list()
    request.cls.menu_page.select_menu_category(request.cls.menu_labels.LBL_SETTINGS_SHORTCUT)
    request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_USER_PREFERENCES_SHORTCUT)
    request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_MY_SHOWS_OPTIONS)
    request.cls.menu_page.select_menu_items(request.cls.my_shows_labels.LBL_SORT_BY_DATE)
    __log.info("Finish: setup_my_shows_sort_to_date")


@pytest.fixture(autouse=False, scope="function")
def setup_adhoc_OTT_provider_and_functionality(request):
    request.cls.home_page.back_to_home_short()
    request.cls.home_assertions.verify_menu_item_available(request.cls.home_labels.LBL_MENU_SHORTCUT)
    request.cls.home_page.select_menu_shortcut(request.cls.home_labels.LBL_MENU_SHORTCUT)
    request.cls.menu_page.nav_to_top_of_list()
    request.cls.menu_page.select_menu_category(request.cls.menu_labels.LBL_SETTINGS_SHORTCUT)
    request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_USER_PREFERENCES_SHORTCUT)
    request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_MY_VIDEO_PROVIDERS)
    request.cls.menu_page.check_or_uncheck_all_menu_items()


@pytest.fixture(autouse=False, scope="function")
def setup_delete_book_marks(request):
    request.cls.service_api.delete_bookmarks(Settings.tsn)


@pytest.fixture(autouse=False, scope="function")
def setup_delete_all_one_pass(request):
    request.cls.service_api.cancel_all_onepass(Settings.tsn)


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_myshows(request):
    def tear_down():
        request.cls.api.delete_all_subscriptions()
        request.cls.api.delete_recordings_from_myshows()
    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def setup_myshows_delete_recordings(request):
    if Settings.is_ndvr_applicable():
        request.cls.api.delete_all_subscriptions()
        request.cls.api.delete_recordings_from_myshows()


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_exit_playback(request):
    def tear_down():
        __log.info("Tearing down")
        request.cls.service_api.delete_bookmarks(Settings.tsn)
    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def setup_enable_OTT_Netflix_provider(request):
    request.cls.home_page.back_to_home_short()
    request.cls.home_assertions.verify_menu_item_available(request.cls.home_labels.LBL_MENU_SHORTCUT)
    request.cls.home_page.select_menu_shortcut(request.cls.home_labels.LBL_MENU_SHORTCUT)
    request.cls.menu_page.nav_to_top_of_list()
    request.cls.menu_page.select_menu_category(request.cls.menu_labels.LBL_SETTINGS_SHORTCUT)
    request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_USER_PREFERENCES_SHORTCUT)
    request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_MY_VIDEO_PROVIDERS)
    request.cls.menu_page.nav_to_menu_by_substring("Netflix")
    request.cls.menu_page.checkbox_option_in_focus(request.cls)


@pytest.fixture(autouse=False, scope="function")
def setup_myshows_schedule_recording(request):
    channels = request.cls.service_api.get_random_recordable_channel()
    request.cls.home_page.back_to_home_short()
    request.cls.home_page.go_to_guide(request.cls)
    request.cls.home_page.wait_for_screen_ready(request.cls.guide_labels.LBL_GUIDE_SCREEN)
    request.cls.guide_assertions.verify_guide_screen(request.cls)
    request.cls.guide_page.enter_channel_number(channels[0][0])
    request.cls.guide_page.create_live_recording()
    try:
        request.cls.guide_page.verify_whisper_shown(request.cls.guide_labels.LBL_RECORD_SCHEDULED)
    except Exception:
        pytest.skip("Some issue appeared during adding show to record")
    else:
        request.cls.content = request.cls.guide_page.get_foucsed_content()['text']
