class MyShowsSpanishLabels(object):
    LBL_SERIES_RECORDINGS = "Recordings"
    LBL_ACTION_SCREEN_VIEW = "actions.ActionsScreenView"
    LBL_SORT_BY_DATE = "Sort by Date"
