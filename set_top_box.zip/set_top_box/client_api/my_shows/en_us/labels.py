class MyShowsLabels(object):
    LBL_MY_SHOWS_MAIN_STRIP_LIST = [u'SUGGESTIONS',
                                    u'ALL SHOWS',
                                    u'PAUSED',
                                    u'TV SERIES',
                                    u'MOVIES',
                                    u'SPORTS',
                                    u'KIDS']
    LBL_NETFLIX_ICON = "http://i.tivo.com/images-static/bravo/providers/hydra_icon_source_Netflix_D0_50x50.png"
    LBL_NETFLIX_PREVIEW_IMAGE_ICON = "hydra_icon_source_Netflix"
    LBL_VUDU_ICON = "http://i.tivo.com/images-static/bravo/providers/Vudu_Fandango_50x50.png"
    LBL_VUDU_PREVIEW_IMAGE_ICON = "Vudu_Fandango"
    LBL_HBO_ICON = "http://tivo.vo.llnwd.net/v1/appicons/HBO/HBO_icon_source_50x50.png"
    LBL_HBO_ICON_NEW = "HBO_icon_source"
    LBL_AMAZON_ICON = "http://i.tivo.com/images-static/bravo/providers/non_prime_icon_source_supplier_50x50.png"
    LBL_AMAZON_PRIME_ICON = "http://i.tivo.com/images-static/bravo/providers/prime_icon_source_supplier_50x50.png"
    LBL_AMAZON_ICON_PREVIEW_ICON = "non_prime_icon_source_supplier"
    LBL_AMAZON_PRIME_NEW = "prime_icon_source_supplier"
    LBL_HULU_ICON = "http://i.tivo.com/images-static/bravo/providers/hydra_icon_source_hulu_D0_50x50.png"
    LBL_HULU_PREVIEW_IMAGE_ICON = "hydra_icon_source_hulu"
    LBL_RCN_ICON = "http://i.tivo.com/images-static/bravo/providers/RCN_icon_source_D0_50x50.png"
    LBL_GOOGLE_PLAY_ICON = "http://i.tivo.com/images-static/bravo/providers/hydra_icon_source_Google_Play_D0_50x50.png"
    LBL_GOOGLE_PLAY_ICON_NEW = "http://i.tivo.com/images-static/bravo/providers/hydra_icon_source_Google_Play_D0.png"
    LBL_GOOGLE_PLAY_NEW = "hydra_icon_source_Google_Play"
    LBL_GOOGLE_PLAY_MOVIES = \
        "http://i.tivo.com/images-static/bravo/providers/Google_Play_Movies_TV_icon_source_D0_50x50.png"
    LBL_GOOGLE_PLAY_MOVIES_NEW = "Google_Play_Movies_TV_icon_source"
    LBL_DISNEYPLUS_ICON = "http://i.tivo.com/images-static/bravo/providers/Disney_Plus_icon_source_bigtxt_50x50.png"
    LBL_MGM_PLUS_ICON_NEW = "http://i.tivo.com/images-static/bravo/providers/mgm_plus_icon_mobile_source_supplier_50x50.png"
    LBL_MGM_PLUS_PREVIEW_IMAGE_ICON = "mgm_plus"
    LBL_DISNEYPLUS_PREVIEW_ICON = "Disney_Plus_icon_source_bigtxt"
    LBL_PEACOCK_ICON = "http://tivo.vo.llnwd.net/v1/appicons/Peacock_Free/Peacock_Free_Yellow_50x50.png"
    LBL_DISCOVERYPLUS_ICON = "http://i.tivo.com/images-static/bravo/providers/discovery_Plus_50x50.png"
    LBL_DISCOVERYPLUS_PREVIEW_ICON = "discovery_Plus"
    LBL_PEACOCK_PREVIEW_ICON = "Peacock"
    LBL_Freevee_ICON = "http://i.tivo.com/images-static/bravo/providers/freevee_icon_source_supplier_50x50.png"
    LBL_Freevee_PREVIEW_ICON = "freevee"
    LBL_HBO_MAX_ICON = "http://i.tivo.com/images-static/bravo/providers/HBO_max_icon_source_50x50.png"
    LBL_PLUTO_TV_ICON = "http://tivo.vo.llnwd.net/v1/appicons/PlutoTV/PlutoTV_icon_source_50x50.png"
    LBL_PLUTO_TV_PREVIEW_ICON = "PlutoTV"
    LBL_SHOWTIME_ICON = "http://tivo.vo.llnwd.net/v1/appicons/Showtime/ShowtimeIcon_TiVo_50x50.png"
    LBL_SHOWTIME_PREVIEW_ICON = "Showtime"
    LBL_PARAMOUNT_PLUS_ICON = "http://tivo.vo.llnwd.net/v1/appicons/paramount_plus/paramount_plus_50x50.png"
    LBL_PARAMOUNT_PLUS_PREVIEW_ICON = "paramount_plus"
    LBL_PBS_KIDS_ICON = "http://i.tivo.com/images-static/bravo/providers/pbs_kids_icon_source_supplier_v1_50x50.png"
    LBL_PBS_KIDS_PREVIEW_ICON = "pbs_kids"
    LBL_BLUESTREAM = "Blue Stream"
    LBL_MOVIES = "Movies"
    LBL_AMAZON = "Prime Video"
    LBL_PRIME_MEMBERSHIP = "Prime Membership"
    LBL_TV_SERIES = "TV Series"
    LBL_ALL_SHOWS = "All Shows"
    LBL_KIDS = "Kids"
    LBL_SPORTS = "Sports"
    LBL_PAUSED = "Paused"
    LBL_RECORDINGS = "Recordings"
    LBL_KEEP_RECORDING = "Keep this recording"
    LBL_START_OVER_FROM_BEGINNING = "Start over from beginning"
    LBL_SERIES_RECORDINGS = "Recordings"
    LBL_SERIES_SCREEN_VIEW = "actions.series.SeriesScreenView"
    LBL_ACTION_SCREEN_VIEW = "actions.ActionsScreenView"
    LBL_WATCH_RECORDING_SCREEN_VIEW = "watchvideo.screens.WatchRecordingScreenView"
    LBL_VIDEO_RECORDING_SCREEN_VIEW = "watchvideo.screens.VideoPlaybackScreenView"
    LBL_SORT_BY_DATE = "Sort by Date"
    LBL_SORT_BY_NAME = "Sort by Name"
    LBL_MY_SHOWS_OPTIONS = "My Shows Options"
    LBL_MYSHOWS_SCREEN = "MyShowsMainScreen"
    LBL_MYSHOWS_DELETE_SCREEN = "MyShowsRecentlyDeletedScreen"
    LBL_MOVIE_SCREEN = "MovieScreen"
    LBL_EPISODE_SCREEN = 'EpisodeScreen'
    LBL_SERIES_SCREEN = "SeriesScreen"
    LBL_ENTER_PIN_OVERLAY = "EnterPINOverlay"
    LBL_WATCH_SCREEN = "TvWatch"
    LBL_ACTION_SCREEN = "ActionScreen"
    LBL_BOOKMARK = "Bookmark"
    LBL_DELETE = "Delete"
    LBL_STOP = "Stop"
    LBL_PLAY = 'Play'
    LBL_TITLE_HIDDEN = "TITLE HIDDEN"
    LBL_STOP_REC = "Stop Recording"
    LBL_STOP_REC_AND_DELETE = "Stop recording & delete"
    LBL_RECENTLY_DELETED = "Recently Deleted Recordings"
    LBL_RECOVER = "Recover"
    LBL_KEEP = "Keep"
    LBL_MY_SHOWS = "MY SHOWS"
    LBL_KEEP_OVERLAY_TITLE = "Keep Until"
    LBL_DELETE_THIS_RECORDING = 'Delete this recording?'
    LBL_GET_THIS_SHOW = "Get This Show"
    LBL_LIVE_UPCOMING = "Live & Upcoming"
    LBL_WATCH_LIST = 'WatchList'
    LBL_CAST = "Cast"
    LBL_MAY_ALSO_LIKE = "May Also Like"
    LBL_ALL_EPISODES = "All Episodes"
    LBL_DELETE_GROUP = "Delete everything in this group"
    LBL_ONEPASS_OPTIONS = "OnePass Options"
    LBL_ONEPASS_AND_RECORDING_OPTIONS = "OnePass & Recording Options"
    LBL_WTW_SCREEN_VIEW = 'whattowatch2.WTWScreenView'
    LBL_MY_SHOWS_FILTER_OPTIONS_1_15_AND_LOWER = [LBL_ALL_SHOWS,
                                                  LBL_TV_SERIES,
                                                  LBL_MOVIES,
                                                  LBL_KIDS,
                                                  LBL_SPORTS,
                                                  LBL_PAUSED,
                                                  LBL_SERIES_RECORDINGS]
    LBL_MY_SHOWS_FILTER_OPTIONS_1_16_AND_HIGHER = [LBL_SERIES_RECORDINGS,
                                                   LBL_ALL_SHOWS,
                                                   LBL_TV_SERIES,
                                                   LBL_MOVIES,
                                                   LBL_KIDS,
                                                   LBL_SPORTS,
                                                   LBL_PAUSED]
    LBL_MY_SHOWS_STREAMING_MOVIES = "Streaming Movies"
    LBL_MY_SHOWS_STREAMING_MOVIES_SCREEN = "StreamingMoviesGallery"
    LBL_MY_SHOWS_NOT_CURRENTLY_AVAILABLE_FOLDER = "Not Currently Available"
    LBL_MY_SHOWS_NOT_CURRENTLY_AVAILABLE_SCREEN = "MyShowsNotCurrentlyAvailableScreen"
    LBL_TRICKPLAY_POSITION = "current-pos"
    LBL_TRICKPLAY_CURRENT_POSITION = "current-position"
    LBL_RECORDING_OPTIONS = "Recording Options"
    LBL_RECORDING_OPTIONS_OVERLAY = "RecordingOptionsOverlay"
    LBL_CANCEL_RECORDING_OVERLAY = "Cancel Recording?"
    LBL_RECORDING_ICON = "hydra_icon_status_recording_now"
    LBL_UPCOMING = "Upcoming"
    LBL_SERIES_CANCEL_RECORDING = "Cancel Recording"
    LBL_ONE_PASS_AND_RECORDING_OPTIONS = "OnePass & Recording Options"
    LBL_RECORD_EPISODE = "Record Episode"
    LBL_RECORD_WITH_OPTIONS = "Record this episode with these options"
    LBL_RECORD_MOVIE_WITH_OPTIONS = "Record this movie with these options"
    LBL_RECORD_AGAIN = "Record Again"
    LBL_RECORDING_OPTIONS_OVERLAY_NAME = "RecordingOptionsOverlay"
    LBL_TV = "TV"
    LBL_ONE_PASS_OPTIONS = "OnePass Options"
    LBL_DELETE_EPISODE_ICON = "com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_delete_episode.png"
    LBL_DELETE_ALL_EPISODES = "Delete All Episodes"
    LBL_CREATE_ONEPASS = "Create OnePass"
    LBL_DELETE_GROUP_OVERLAY_BODY_TEXT = "You can choose to delete everything in this group, delete recordings and" \
                                         " replace them with bookmarks to streaming videos (when available), or" \
                                         " delete everything and cancel this OnePass."
    LBL_DELETE_EVERYTHING = "Delete everything in this group"
    LBL_DELETE_AND_REPLACE_BOOKMARK = "Delete recordings & replace with bookmarks"
    LBL_NO_RECORDINGS_IN_YOUR_LIST = "no recordings in your list"
    LBL_CANCEL_GROUP = "Cancel (don't do anything)"
    LBL_DELETE_EVERYTHING_CANCEL_ONEPASS = "Delete everything & cancel this OnePass"
    LBL_DELETE_GROUP_OPTIONS = [LBL_DELETE_EVERYTHING,
                                LBL_DELETE_AND_REPLACE_BOOKMARK,
                                LBL_DELETE_EVERYTHING_CANCEL_ONEPASS,
                                LBL_CANCEL_GROUP]
    LBL_GROUP = "Group"
    LBL_LIVE_ICON = "com/tivo/applib/ResAppLibImages/applib/images/hydra/1080p/hydra_icon_live.png"
    LBL_MODIFY_RECORDING = "Modify Recording"
    LBL_MODIFY_ONEPASS = "Modify OnePass"
    LBL_INCLUDE = "Include:"
    LBL_START_FROM = "Start from:"
    LBL_KEEP_UNTILL = "Keep until:"
    LBL_KEEP_AT_MOST = "Keep at most:"
    LBL_RENT_OR_BUY = "Rent or buy:"
    LBL_RECORD = "Record:"
    LBL_CHANNEL = "Channel:"
    LBL_VIDEO_QUALITY = "Video quality:"
    LBL_START_STOP = "Start/Stop:"
    LBL_CREATE = "Create"
    LBL_ONEPASS_OPTIONS_OVERLAY = "OnePassOptionsOverlay"
    LBL_RECORD_ = "Record "
    LBL_RECORD_OVERLAY = "RecordOverlay"
    LBL_PROGRAM_OPTIONS_RECORD_EPISODE_WITH_THESE_OPTIONS = "Record this episode with these options"
    LBL_MODIFY_ONEPASS_PREVIEW_AREA_ITEMS = [LBL_INCLUDE,
                                             LBL_START_FROM,
                                             LBL_KEEP_UNTILL,
                                             LBL_KEEP_AT_MOST,
                                             LBL_RENT_OR_BUY,
                                             LBL_RECORD,
                                             LBL_CHANNEL,
                                             LBL_VIDEO_QUALITY,
                                             LBL_START_STOP]
    LBL_START_RECORDING = "Start recording:"
    LBL_STOP_RECORDING = "Stop recording:"
    LBL_MODIFY_RECORDING_OPTIONS_LIST = [LBL_KEEP_UNTILL,
                                         LBL_START_RECORDING,
                                         LBL_STOP_RECORDING]
    LBL_ONE_PASS_OPTIONS_LIST = [LBL_INCLUDE,
                                 LBL_START_FROM,
                                 LBL_KEEP_AT_MOST,
                                 LBL_KEEP_UNTILL,
                                 LBL_START_RECORDING,
                                 LBL_STOP_RECORDING]
    LBL_CANCEL_ONEPASS = "Cancel OnePass"
    LBL_CONFIRM_CANCEL_ONEPASS = "Yes, cancel this OnePass"
    LBL_EMPTY_TEXT_TV_SERIES = "There are currently no TV Series in your list."
    LBL_EMPTY_TEXT_MOVIES = "There are currently no movies in your list."
    LBL_EMPTY_TEXT_KIDS = "There are currently no kids shows in your list."
    LBL_EMPTY_TEXT_SPORTS = "There are currently no sporting events in your list."
    LBL_KEEP_UNTIL_SPACE_NEEDED = "Keep until space needed"
    LBL_KEEP_AS_LONG_AS_POSSIBLE = "As long as possible"
    LBL_MYSHOWS_SCREEN_VIEW = "myshows3.MyShowsScreenView"
    LBL_PREVIEW_RECORDING_MESSAGE = "This episode is currently recording"
    LBL_PREVIEW_ALAP_MESSAGE = "Will be kept as long as possible"
    LBL_HTTP = "http"
    LBL_m3u8 = "m3u8"
    LBL_SEASON_1 = "Season 1"
    LBL_DONT_INCLUDE = "Don't include"
    LBL_INCLUDE_NO_COLON = "Include"
    LBL_RECOVER_WHISPER = "This show has been recovered and is available in My Shows"
    LBL_OTT_LIST = [LBL_NETFLIX_ICON,
                    LBL_GOOGLE_PLAY_MOVIES,
                    LBL_VUDU_ICON,
                    LBL_HULU_ICON,
                    LBL_HBO_ICON,
                    LBL_GOOGLE_PLAY_ICON,
                    LBL_GOOGLE_PLAY_ICON_NEW,
                    LBL_AMAZON_PRIME_ICON,
                    LBL_AMAZON_ICON,
                    ]
    LBL_KEEP_RECORDING = "Keep this recording"

    LBL_EPIX_ICON = "epix_icon_source_supplier"
    LBL_DISNEYPLUS_ICON_NEW = "Disney_Plus_icon_source"
    LBL_OTT_LIST_ACTION_SCREEN = [LBL_NETFLIX_PREVIEW_IMAGE_ICON,
                                  LBL_GOOGLE_PLAY_MOVIES_NEW,
                                  LBL_VUDU_PREVIEW_IMAGE_ICON,
                                  LBL_HULU_PREVIEW_IMAGE_ICON,
                                  LBL_HBO_ICON_NEW,
                                  LBL_GOOGLE_PLAY_NEW,
                                  LBL_AMAZON_PRIME_NEW,
                                  LBL_AMAZON_ICON_PREVIEW_ICON,
                                  LBL_EPIX_ICON,
                                  LBL_DISNEYPLUS_ICON_NEW]
