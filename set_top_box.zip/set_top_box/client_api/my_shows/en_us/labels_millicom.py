class MillicomMyShowsLabels:
    LBL_SPORTS = "Deportes"
    LBL_KIDS = "Infantil"
    LBL_MOVIES = "Peliculas"
