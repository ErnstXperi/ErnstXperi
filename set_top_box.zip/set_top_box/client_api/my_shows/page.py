import re
from datetime import *

import pytest
import pytz

from core_api.stb.assertions import CoreAssertions
from core_api.stb.base import UINavigationException
from set_top_box.client_api.my_shows.en_us.labels import MyShowsLabels
from tools.sys_commands import Commands
from set_top_box.test_settings import Settings
from set_top_box.conf_constants import HydraBranches, FeaturesList


class MyShowsPage(CoreAssertions):
    # TODO
    # Switch to using my_shows_label from conftest due to LabelFactory and remove this one
    my_show_labels = MyShowsLabels()
    EXM_SCREEN_NAME = my_show_labels.LBL_MYSHOWS_SCREEN

    def select_my_shows_category(self, tester, category):
        self.log.step("selecting {} in my shows screen".format(category))
        self.wait_for_screen_ready()
        self.menu_navigate_left_right(1, 0)
        tester.my_shows_assertions.verify_content_in_category(category)
        self.select_menu(category)

    def extract_content_from_menu(self):
        menu_list = self.menu_list()
        if isinstance(menu_list[0], list):
            content_list = [x[0] for x in menu_list]
            return content_list
        return menu_list

    def scroll_to_top_my_shows(self):
        for i in range(100):
            self.screen.base.press_up(time=100)

    def verify_content(self, content):
        found = False
        self.screen.refresh()
        retries = 10
        item_name = None
        menu_list = self.extract_content_from_menu()
        if len(menu_list) < 11:
            retries = 2
        while retries > 0:
            menu_list = self.extract_content_from_menu()
            for item in menu_list:
                if content.lower() in item.lower() or str(item).lower() in content.lower():
                    found = True
                    item_name = item
                    break
            if found:
                break
            else:
                for i in range(12):
                    self.screen.base.press_down(time=100)
                self.screen.refresh()
                retries -= 1
        return found, item_name

    def navigate_to_series_screen_menu_list(self):
        """
        Navigating to the left action menu list in the Series Screen
        """
        self.log.step("Navigating to the menu list of the Series Screen")
        # Gallery tiles have max 5 items, the farthest point the highlight can be
        for i in range(0, 4):
            self.press_left_button()

    def delete_content_bookmark(self, tester, content):
        self.screen.refresh()
        self.select_menu_by_substring(content)
        self.wait_for_screen_ready(timeout=20000)
        self.screen.refresh()
        if self.view_mode() == tester.my_shows_labels.LBL_SERIES_SCREEN_VIEW:
            self.screen.base.press_left()
            self.screen.refresh()
            if self.is_in_menu(tester.my_shows_labels.LBL_GET_THIS_SHOW):
                self.select_menu(tester.my_shows_labels.LBL_GET_THIS_SHOW)
                self.screen.refresh()
                self.select_menu_by_substring(tester.my_shows_labels.LBL_DELETE)
                self.screen.refresh()
                self.select_menu_by_substring(tester.my_shows_labels.LBL_DELETE)
            else:
                self.screen.base.press_left()
                self.wait_for_screen_ready()
                self.select_menu(tester.my_shows_labels.LBL_WATCH_LIST)
                self.wait_for_screen_ready()
                self.screen.refresh()
                self.screen.base.press_right()
                self.screen.refresh()
                self.screen.base.press_enter()
                self.screen.refresh()
                self.select_string_by_substring(tester.my_shows_labels.LBL_DELETE)
                self.screen.refresh()
                self.select_menu_by_substring(tester.my_shows_labels.LBL_DELETE)
        else:
            self.select_string_by_substring(tester.my_shows_labels.LBL_DELETE)
            self.screen.refresh()
            self.select_menu_by_substring(tester.my_shows_labels.LBL_DELETE)
        self.pause(1)

    def search_select_program_from_OTT(self, tester, OTT=None, feedName=None, update_tivo_pt=True, cnt=1, skip=True, **kwargs):
        self.log.step("Searching for a program available from OTT")
        feedname = ""
        program = ""
        feed_list = tester.wtw_page.get_feed_name(feedName)
        for feed in feed_list:
            self.log.info("feed : {}".format(feed))
            if feed is not None:
                program = tester.service_api.get_show_available_from_OTT(OTT=OTT, feedName=feed,
                                                                         update_tivo_pt=update_tivo_pt, count=cnt)
                if len(program) > 0:
                    feedname = feed
                    break
            else:
                self.log.info("feed list is None: {}".format(feed))
                return feed
        self.log.info("programs returned: {}, {}".format(program, feedname))
        if cnt > 1 and len(program) > 1:
            for prog in program:
                tester.text_search_page.go_to_search(tester)
                year = self.check_program_if_year_exists(prog)
                result, program_name = self.search_deeplink_ott_program(tester, prog, year, select=kwargs.get("select", True))
                if result:
                    break
            else:
                self.log.error("Programs were not found using search")
        elif len(program) == 1:
            year = self.check_program_if_year_exists(program[0])
            result, program_name = self.search_deeplink_ott_program(tester, program[0], year,
                                                                    select=kwargs.get("select", True))
            if not result:
                self.log.error("Programs were not found using search")
        elif skip:
            pytest.skip("No programs returned from service api for OTT: {}".format(OTT))
        else:
            return None
        if kwargs.get("action_screen"):
            ott = kwargs.get("icon")
            if ott:
                self.search_and_select_ott(tester, program_name, ott)
        return program_name

    def get_show_start_time_on_upcoming_screen(self, show):
        """
            This method return focused show start time on upcoming screen

            :param show: menu item
        """
        try:
            day = show[0] + f"/{datetime.now().year}"
            start_time = show[1]
            in_time = self.convert_tivo_time(start_time)
            out_time = datetime.strftime(in_time, "%H:%M:%S")
            correct_start_time = str(day + ' ' + out_time)
            dt_object = datetime.strptime(correct_start_time, "%m/%d/%Y %H:%M:%S")
            return dt_object
        except Exception:
            self.log.info("Upcoming screen is empty. There are no any shows.")

    def get_channel_by_id(self, channel_id):
        """
            This method return list of shows for current day from channel with channel_id

            :param channel_id: channel id
        """
        try:
            channel_list = self.service_api.get_channel_search()
            guide_rows = self.service_api.get_guide_rows(channel_list)
            chan = []
            for channel_number in guide_rows:
                if channel_number == channel_id:
                    chan = guide_rows[channel_number]
                    break
            return chan
        except Exception:
            self.log.info(f"There are no channel with id: {channel_id}")

    def is_socu_playback_on_upcoming_by_api(self):
        """
        This method return True in case when socu playback icon displayed or False when icon not displayed
        Returns:
            True or False
        """
        time_zone = self.service_api.get_time_zone_with_body_search()
        focused_menu_item = self.menu_item_option_focus()
        screen_title = self.screen.get_screen_dump_item('screentitle')
        channel_id = focused_menu_item[3]
        dt_object = self.get_show_start_time_on_upcoming_screen(focused_menu_item)
        channel_details_from_mind = self.get_channel_by_id(channel_id)
        offer_id = ""
        for chan in channel_details_from_mind:
            start_time = datetime.strptime(datetime.fromtimestamp(int(chan.start_time))
                                           .strftime(self.service_api.MIND_DATE_TIME_FORMAT),
                                           self.service_api.MIND_DATE_TIME_FORMAT)
            show_start_time = self.service_api.convert_given_time_to_local_time(start_time,
                                                                                pytz.timezone(time_zone))
            if chan.title.lower() == screen_title.lower() and show_start_time == dt_object:
                offer_id = chan.offer_id
                break
        show_data = self.service_api.get_preview_offer(offer_id, screen_type="guideHeader")
        is_available_in_socu = show_data.is_available_in_socu
        return is_available_in_socu

    def search_deeplink_ott_program(self, tester, program_name, movie_year, select=True):
        self.log.info("program passed: {}".format(program_name))
        prog = self.convert_special_chars
        result = False
        if not movie_year:
            try:
                tester.text_search_page.search_and_select(prog(program_name[0]), prog(program_name[0]), select=select,
                                                          asert=False)
                result = True
            except Exception as Err:
                self.log.error("Failed to search program {} with err :{}".format(program_name, Err))
                result = False
        else:
            try:
                tester.text_search_page.search_and_select(prog(program_name[0]), prog(program_name[0]),
                                                          year=program_name[1], select=select, asert=False)
                result = True
            except Exception as Err:
                self.log.error("Failed to search program {} with err :{}".format(program_name, Err))
                result = False
            program_name = prog(program_name[0]) + " (" + str(program_name[1]) + ")"
        self.log.info("Program Searched is {}".format(program_name))
        return result, program_name

    def check_program_if_year_exists(self, program):
        if not program:
            return program
        prog = program[0]
        self.log.info("Program Found is : {}".format(prog))
        if not str(program[1]).strip():
            self.log.info("Program does not have year")
            return False
        else:
            self.log.info("Program has year")
            return True

    def select_menu_category(self, category):
        self.screen.refresh()
        if not self.is_strip_focus():
            self.log.info("No Strip Present")
            while not self.is_strip_focus():
                self.screen.base.press_up()
                self.screen.refresh()
        else:
            self.log.info("Strip Present")
        self.select_strip(category)
        self.screen.refresh()

    def select_show(self, category, truncate=0, matcher_type="in"):
        category = self.convert_special_chars(category)
        self.log.step("Selecting : {}".format(category))
        self.menu_navigate_left_right(0, 1)
        self.wait_for_screen_ready()
        self.screen.refresh()
        if truncate:
            category = category[:truncate]
        try:
            if self.is_in_menu(category):
                self.select_menu_by_substring(self.remove_service_symbols(category), matcher_type=matcher_type)
            elif self.is_in_menu(self.my_show_labels.LBL_MY_SHOWS_NOT_CURRENTLY_AVAILABLE_FOLDER):
                self.log.info("Checking in {}".format(self.my_show_labels.LBL_MY_SHOWS_NOT_CURRENTLY_AVAILABLE_FOLDER))
                self.select_menu(self.my_show_labels.LBL_MY_SHOWS_NOT_CURRENTLY_AVAILABLE_FOLDER)
                self.wait_for_screen_ready()
                self.screen.refresh()
                if self.is_in_menu(category):
                    self.select_menu_by_substring(self.remove_service_symbols(category), matcher_type=matcher_type)
        except LookupError as e:
            self.log.error(e)
            if self.is_in_menu(self.my_show_labels.LBL_ALL_SHOWS):
                raise UINavigationException(
                    "Expected title: '{}' in myshows, but got: '{}'.".format(category, self.get_bodytext()))
            if category.title() not in self.menu_list():
                raise UINavigationException("Expected title: '{}' in myshows, but got: '{}'.".format(category,
                                                                                                     self.menu_list()))
            self.select_menu(category.title())
        self.wait_for_screen_ready(self.my_show_labels.LBL_SERIES_SCREEN, timeout=20000)
        self.screen.refresh()

    def nav_to_show(self, category):
        self.menu_navigate_left_right(0, 1)
        self.pause(10)
        self.screen.refresh()
        self.nav_to_menu_by_substring(category)

    def watch_netflix(self, tester):
        self.log.info("Launching Netflix")
        self.pause(10)
        self.screen.base.press_enter()
        self.pause(6)
        tester.my_shows_assertions.verify_netflix_screen()
        self.pause(6)

    def check_icons(self, tester):
        # TODO
        # 0. Check if there are appropriate methods to avoid duplicates
        # 1. Move the method to my_shows/assertions.py
        # 2. Make this method more flexible, perhaps, pass icon name in input param in order to check.
        # Note: not all asserts are available from Netflix and Google Play at the same time,
        # so this method will fail in most cases
        self.pause(1)
        self.screen.refresh()
        tester.my_shows_assertions.verify_OTT_icon(tester.my_shows_labels.LBL_NETFLIX_ICON)
        tester.my_shows_assertions.verify_OTT_icon(tester.my_shows_labels.LBL_GOOGLE_PLAY_ICON)

    def bookmark_from_wtw(self, tester):
        self.log.step("Creating Bookmark from What to Watch")
        self.pause(3)
        self.screen.base.press_enter(time=1000)
        self.screen.refresh()
        content = self.get_title_from_pane()
        try:
            self.nav_to_menu(tester.menu_labels.LBL_RECORDING_AND_BOOKMARK_OPTIONS)
        except Exception:
            self.nav_to_menu(tester.vod_labels.LBL_BOOKMARK_OPTIONS)
        self.screen.refresh()
        self.select_string_by_substring(tester.my_shows_labels.LBL_BOOKMARK)
        return content

    def get_title_from_pane(self):
        self.log.info("Getting title from Preview Pane")
        panes = self.get_preview_panel()
        if isinstance(panes, dict):
            panelist = [panes]
        else:
            panelist = panes
        for pane in panelist:
            if 'title' in pane:
                content = pane['title']
                return content

    def get_description_from_pane(self):
        """
        Return description from Preview Pane
        Can be applicable on What to Watch, Guide, TTS, VOD, My Shows screens
        """
        self.log.info("Getting description from Preview Pane")
        panes = self.get_preview_panel()
        if isinstance(panes, dict):
            panelist = [panes]
        else:
            panelist = panes
        for pane in panelist:
            if 'description' in pane:
                content = pane['description']
                return content
            else:
                raise LookupError(f"The list doesn't contain description. List: {pane}")

    def playback_recording(self, tester, content):
        self.log.step("Trying to start playback of recorded program")
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_SERIES_SCREEN, timeout=12000)
        self.screen.refresh()
        screen_type = self.screen.screen_dump['xml']
        if screen_type.get("viewMode") == tester.my_shows_labels.LBL_SERIES_SCREEN_VIEW:
            self.log.info("Entered series screen")
            self.menu_navigate_left_right(1, 0)
            self.wait_for_screen_ready()
            tester.my_shows_assertions.verify_content_in_category(content)
            self.nav_to_menu(content)
            self.pause(2)  # UI not responding
            self.select_item()
            self.pause(15)
            self.screen.refresh()
            if not self.is_menu_focus():
                raise AssertionError("No content highlighted after recording option selected in series screen")
            self.screen.base.press_enter(1000)
        elif screen_type.get("viewMode") == tester.my_shows_labels.LBL_ACTION_SCREEN_VIEW:
            self.log.info("Entered program Screen")
            self.select_strip(tester.watchvideo_labels.LBL_PLAY_OPTION)
        self.wait_for_screen_ready(self.my_show_labels.LBL_WATCH_SCREEN)
        self.screen.get_json()
        if self.is_overlay_title():
            try:
                self.select_menu(self.my_show_labels.LBL_START_OVER_FROM_BEGINNING)
            except Exception:
                # Exception to handle any other overlay like enterpin
                self.log.info(f"overlay displayed {self.is_overlay_title()}")
        status = self.get_error_overlay_visibility(self)
        count = 6
        while status and count > 0:
            self.screen.base.press_enter()
            self.pause(30)
            self.screen.base.press_enter()
            count = count - 1
            self.wait_for_screen_ready(tester.live_tv_labels.LBL_WATCH_RECORDING_SCREEN, 30000)
            status = self.get_error_overlay_visibility(self)

    def open_playback_overlay_for_recording(self, tester, content):
        """ Find recording but don`t press enter after that. Used in performance test cases. """
        self.log.step("Trying to start playback of recorded program")
        self.wait_for_screen_ready(self.my_show_labels.LBL_SERIES_SCREEN, timeout=12000)
        self.screen.refresh()
        if self.view_mode() == self.my_show_labels.LBL_SERIES_SCREEN_VIEW:
            self.log.info("Entered series screen")
            self.menu_navigate_left_right(1, 0)
            self.wait_for_screen_ready()
            self.log.info("Verify content {} exist in menu. ".format(content))
            self.screen.refresh()
            self.log.debug("Content: {}".format(content))
            check = self.is_in_menu(content)
            current_menu = self.menu_list() if not check else None
            assert check, f"Menu doesn't contain '{content}', cur menu: {current_menu}"
            self.nav_to_menu(content)
            self.pause(2)  # UI not responding
            self.select_item()
            if not self.is_menu_focus():
                raise LookupError("No content highlighted after recording option selected in series screen")
        elif self.view_mode() == self.my_show_labels.LBL_ACTION_SCREEN_VIEW:
            self.log.info("Entered program Screen")
            self.navigate_by_strip(self.my_show_labels.LBL_PLAY)

    def select_and_wait_pin_overlay(self, tester):
        self.log.info("Launching Enter PIN overlay")
        self.screen.base.press_enter()
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_ENTER_PIN_OVERLAY)

    def select_and_wait_for_playback_play(self):
        self.screen.refresh()
        self.log.step(f"Select show name {self.get_menu_item()}")
        self.screen.base.press_enter()
        self.wait_for_screen_ready(self.my_show_labels.LBL_WATCH_SCREEN)
        self.screen.refresh()
        if self.is_overlay_title():
            try:
                self.select_menu(self.my_show_labels.LBL_START_OVER_FROM_BEGINNING)
            except Exception:
                # Exception to handle any other overlay like enterpin
                self.log.info(f"Overlay displayed: '{self.is_overlay_title()}'")

    def get_partner_logo_action_screen(self, tester):
        # size of the netflix icon on action screen
        width = 50
        height = 50
        logo = tester.api.get_partner_source_logo(width, height)
        self.log.info("Partner logo :{}".format(logo))
        return logo

    def delete_recording_in_my_show(self, content):
        content = self.convert_special_chars(content)
        self.log.step(f"Deleting recoring {content} from my shows")
        for _ in range(2):
            self.nav_to_top_of_list()
        self.screen.refresh
        self.nav_to_show(content)
        self.screen.base.press_clear()
        self.pause(10)
        self.screen.refresh()
        screen_dump = self.screen.screen_dump['xml']
        if "overlayMode" in screen_dump.keys():
            self.select_menu_by_substring(self.my_show_labels.LBL_DELETE)

    def cancel_one_pass(self, testee):
        """
        Cancel one pass from Series screen
        """
        # step log in select_my_shows_category()
        self.log.info("cancel one pass {}")
        self.select_my_shows_category(testee, testee.my_shows_labels.LBL_ONEPASS_OPTIONS)
        self.nav_to_show(testee.my_shows_labels.LBL_CANCEL_ONEPASS)
        self.press_ok_button()
        if self.is_overlay_shown():
            self.select_menu_by_substring(self.my_show_labels.LBL_CONFIRM_CANCEL_ONEPASS)

    def undelete_recording_in_my_show(self, tester, content):
        content = content.encode("iso8859").decode("utf8")
        self.log.step(f"Recovering {content} from recently deleted folder")
        tester.home_page.nav_to_top_menuitem_in_list()
        while self.is_in_menu(content):
            self.log.info("{} found. Selecting to Recover".format(content))
            self.select_show(content)
            self.select_menu_by_substring(self.my_show_labels.LBL_RECOVER)
            self.wait_for_screen_ready()
            tester.my_shows_page.go_to_recently_deleted_folder(tester)
            tester.home_page.nav_to_top_menuitem_in_list()
            self.wait_for_screen_ready()
            self.screen.refresh()

    def go_to_recently_deleted_folder(self, tester):
        self.log.step("Navigating to recently deleted folder under My Shows")
        tester.home_page.go_to_my_shows(tester)
        self.select_my_shows_category(tester, tester.my_shows_labels.LBL_ALL_SHOWS)
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_MYSHOWS_SCREEN)
        tester.menu_page.select_menu_items(tester.my_shows_labels.LBL_RECENTLY_DELETED)
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_MYSHOWS_DELETE_SCREEN)

    def delete_episodic_program(self, tester, program):
        program = self.convert_special_chars(program)
        self.log.step(f"Deleting {program} from my shows recordings")
        tester.home_page.back_to_home_short()
        tester.home_assertions.verify_menu_item_available(tester.home_labels.LBL_MYSHOWS_SHORTCUT)
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_MYSHOWS_SHORTCUT)
        self.wait_for_screen_ready()
        self.menu_navigate_left_right(1, 0)
        self.screen.refresh()
        tester.my_shows_assertions.verify_content_in_category(self.my_show_labels.LBL_SERIES_RECORDINGS)
        self.select_menu(self.my_show_labels.LBL_SERIES_RECORDINGS)
        self.screen.refresh()
        self.select_show(program)
        self.wait_for_screen_ready(program.upper())
        self.screen.base.press_left()
        self.screen.refresh()
        menu = self.menu_list()
        if tester.my_shows_labels.LBL_GET_THIS_SHOW in menu:
            self.log.info("Deleting from category Get This Show")
            tester.home_page.select_menu_item(tester.my_shows_labels.LBL_GET_THIS_SHOW)
            tester.home_page.select_menu_by_substring(tester.my_shows_labels.LBL_DELETE)
            self.screen.refresh()
            tester.my_shows_assertions.verify_delete_overlay()
            self.select_menu_by_substring(tester.my_shows_labels.LBL_DELETE_GROUP)
        elif tester.my_shows_labels.LBL_ONEPASS_OPTIONS in menu:
            self.log.info("Deleting from One Pass Options")
            tester.home_page.select_menu_item(tester.my_shows_labels.LBL_ONEPASS_OPTIONS)
            tester.home_page.select_menu_by_substring(tester.my_shows_labels.LBL_DELETE)
            self.screen.refresh()
            tester.my_shows_assertions.verify_delete_overlay()
            self.select_menu_by_substring(tester.my_shows_labels.LBL_DELETE_GROUP)
        elif tester.my_shows_labels.LBL_RECORDING_OPTIONS in menu:
            self.log.info("Deleting from Recording Options")
            self.nav_to_menu(self.my_show_labels.LBL_RECORDING_OPTIONS)
            self.select_strip(self.my_show_labels.LBL_MODIFY_RECORDING)
            tester.home_page.select_menu_by_substring(tester.guide_labels.LBL_CANCEL)
            tester.home_page.select_menu_by_substring(tester.my_shows_labels.LBL_STOP_REC_AND_DELETE)
        self.pause(5)  # settling time after deleting
        self.screen.base.press_back()
        # Navigating back to home and validating the content not available in myshows until the bug fix BZSTREAM-5974
        tester.home_page.go_to_my_shows(tester)
        self.select_my_shows_category(tester, tester.my_shows_labels.LBL_ALL_SHOWS)
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_MYSHOWS_SCREEN)
        tester.my_shows_assertions.verify_content_not_in_category(tester, program)

    def navigate_to_recordings_filter(self, tester):
        tester.home_page.back_to_home_short()
        tester.home_assertions.verify_menu_item_available(tester.home_labels.LBL_MYSHOWS_SHORTCUT)
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_MYSHOWS_SHORTCUT)
        self.wait_for_screen_ready()
        self.menu_navigate_left_right(1, 0)
        self.screen.refresh()
        tester.my_shows_assertions.verify_content_in_category(self.my_show_labels.LBL_SERIES_RECORDINGS)
        self.select_menu(self.my_show_labels.LBL_SERIES_RECORDINGS)
        self.screen.refresh()

    def validate_advance_move(self, tester, current_position):
        self.log.info("The current position is {} : ".format(current_position))
        self.screen.base.press_advance()
        self.screen.base.press_advance()
        self.screen.refresh()
        moved_position = self.get_trickplay_current_position_time(tester)
        self.log.info("The moved position is {} : ".format(moved_position))
        self.log.info(
            "The time difference is {} : ".format(self.check_time_diff(moved_position, current_position, ms=False)))
        if self.check_time_diff(moved_position, current_position, ms=False) < 15:
            tester.my_shows_assertions.verify_time_diff()
        self.pause(3)

    def validate_replay(self, tester, current_position, key_press=8):
        self.log.info("The current position is {} : ".format(current_position))
        # As per spec, replay press in pause or play mode rewinds around 8 seconds in one key press.
        # Hence have repeated keypresses
        self.replay_navigation_and_replay_press(tester, count=key_press)
        self.screen.refresh()
        moved_position = self.get_trickplay_current_position_time(tester)
        self.log.info("The moved position is {} : ".format(moved_position))
        self.log.info(
            "The time difference is {} : ".format(self.check_time_diff(current_position, moved_position, ms=False)))
        if self.check_time_diff(current_position, moved_position, ms=False) < 5:
            tester.my_shows_assertions.verify_time_diff()
        self.pause(3)

    def get_trickplay_position(self, tester):
        self.log.info("Fetching Trickplay position")
        self.screen.refresh()
        trickplay = self.screen.get_screen_dump_item('trick-play')
        return trickplay[tester.my_shows_labels.LBL_TRICKPLAY_POSITION]

    def check_time_diff(self, current_position, moved_position, ms=True):
        self.log.info("Finding time difference")
        time_diff = self.get_timein_seconds(current_position, ms) - self.get_timein_seconds(moved_position, ms)
        return time_diff

    def get_timein_seconds(self, time_str, ms=True):
        self.log.info(f"Converting time {time_str} to seconds")
        if ms:
            ms = time_str.split('.')
            h, m, s = ms[0].split(':')
        else:
            h, m, s = time_str.split(':')
        return int(h) * 3600 + int(m) * 60 + float(s)

    def go_to_cached_action_screen(self, tester, content=None, Recording=False):
        self.log.step("Trying to launch action screen")
        self.screen.refresh()
        screen_type = self.screen.screen_dump['xml']
        if screen_type.get("viewMode") == tester.my_shows_labels.LBL_SERIES_SCREEN_VIEW:
            self.log.info("In Series Screen")
            self.menu_navigate_left_right(1, 0)
            if not content:
                content = self.get_menu_item_for_upcoming_program(tester)
            tester.my_shows_assertions.verify_content_in_category(content)
            self.select_menu(content)
            self.menu_navigate_left_right(0, 1)
            if Recording:
                self.log.info("Looking for a episode scheduled for record")
                attempt = 0
                record_icon = False
                while Recording and attempt <= 15:
                    self.wait_for_screen_ready()
                    self.screen.refresh()
                    preview = self.get_preview_panel()['previewImage']
                    if preview is not None:
                        if isinstance(preview, list):
                            for image in range(len(preview)):
                                if tester.guide_labels.LBL_EXPLICIT_RECORD_ICON in preview[image]:
                                    self.log.info("Found an episode scheduled for recording")
                                    record_icon = True
                                    Recording = False
                                    break
                        else:
                            if tester.guide_labels.LBL_EXPLICIT_RECORD_ICON in preview:
                                self.log.info("Found an episode scheduled for recording")
                                record_icon = True
                                Recording = False
                                break
                        if Recording:
                            self.screen.base.press_down()
                        attempt += 1
                    else:
                        self.screen.base.press_down()
                        attempt += 1
                        continue
                if preview is None or not record_icon:
                    raise AssertionError(
                        "Either preview was not displayed or episode scheduled for record was not found")
            self.log.info("Launching action screen")
            self.screen.base.press_enter()
            self.wait_for_screen_ready(tester.my_shows_labels.LBL_EPISODE_SCREEN, timeout=30000)
            self.screen.refresh()

    def cancel_upcoming_recording_from_guide(self, tester, program):
        self.log.step(f"Cancelling recording for program :{program}")
        focused_program = tester.guide_page.get_focussed_grid_item(tester)
        tester.my_shows_assertions.verify_focused_program(program, focused_program)
        self.screen.base.press_enter()
        self.wait_for_screen_ready(tester.guide_labels.LBL_RECORD_OVERLAY)
        self.screen.refresh()
        self.select_menu_by_substring(tester.guide_labels.LBL_MODIFY)
        self.screen.refresh()
        self.select_menu_by_substring(tester.guide_labels.LBL_CANCEL)
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_CANCEL_RECORDING_OVERLAY)
        self.screen.refresh()
        self.select_menu_by_substring(tester.guide_labels.LBL_YES_CANCEL)

    def cancel_upcoming_recording_in_todo_list(self, tester):
        self.log.step("Cancel upcoming recording from todo list")
        self.nav_to_menu(tester.my_shows_labels.LBL_RECORDING_OPTIONS)
        self.screen.refresh()
        self.select_strip(tester.my_shows_labels.LBL_SERIES_CANCEL_RECORDING)
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_CANCEL_RECORDING_OVERLAY)
        self.screen.refresh()
        self.select_menu_by_substring(tester.guide_labels.LBL_YES_CANCEL)

    def create_recording_from_live_tv(self, tester, channel):
        viewmode = self.view_mode()
        if viewmode == tester.guide_labels.LBL_LIVE_TV_VIEW_MODE:
            self.log.info("Found channel is : {}".format(channel))
            self.pause(1)
            tester.guide_page.enter_channel_number(channel)
            tester.watchvideo_page.skip_hdmi_connection_error()
            tester.guide_assertions.verify_live_playback()
            self.screen.refresh()
            show_name = self.screen.get_screen_dump_item('title')
            self.log.info("Trying to schedule recording of program : {} on channel : {}".format(show_name, channel))
            self.screen.base.press_record()
            self.screen.refresh()
            state = self.wait_for_screen_ready(tester.guide_labels.LBL_RECORD_OVERLAY, 200000)
            # Check record overlay is displayed before doing further navigations
            if not state:
                raise LookupError("Record overlay is not visible.")
            self.screen.refresh()
            menulist = self.menu_list()
            liststr = ' '.join([str(elem) for elem in menulist])
            stoprecording = self.my_show_labels.LBL_STOP_REC_AND_DELETE
            if stoprecording in liststr:
                self.log.info(f"Recording is already in progress for program : {show_name} on channel : {channel}")
            else:
                self.log.info("Scheduling live recording")
                self.select_menu_by_substring(tester.guide_labels.LBL_RECORD)
                self.wait_for_screen_ready(tester.guide_labels.LBL_RECORD_OVERLAY)
                self.screen.refresh()
                if self.is_overlay_shown():
                    self.select_menu_by_substring(tester.guide_labels.LBL_RECORD)
                    tester.guide_page.verify_whisper_shown(tester.guide_labels.LBL_RECORD_SCHEDULED)
                    self.log.info(f"Successfully scheduled recording of program : {show_name} on channel : {channel}")
            return show_name
        else:
            self.log.error("Currently not in Live TV. Hence unable to schedule the recording")
            return None

    def is_series_screen_view_mode(self, refresh=False):
        if refresh:
            self.screen.refresh()
        return self.view_mode() == self.my_show_labels.LBL_SERIES_SCREEN_VIEW

    def is_action_screen_view_mode(self):
        return self.view_mode() == self.my_show_labels.LBL_ACTION_SCREEN_VIEW

    def is_w2w_scree_view_mode(self):
        return self.view_mode() == self.my_show_labels.LBL_WTW_SCREEN_VIEW

    def record_tvseries_from_wtw(self):
        """
        Creating single record or one pass from w2w from series or episode screen depends on availability.
        Before using show tile should be selected
        @return: show name within array
        @rtype: list
        """
        self.log.step("Recording program from tv series - WTW")
        self.screen.base.press_enter()
        self.wait_for_screen_ready(self.my_show_labels.LBL_SERIES_SCREEN, timeout=12000)
        self.screen.refresh()
        if self.is_w2w_scree_view_mode():
            self.log.warning("After pressing tile still remain in w2w screen, retying")
            self.screen.base.press_enter()
            self.wait_for_screen_ready(self.my_show_labels.LBL_SERIES_SCREEN, timeout=12000)
            self.screen.refresh()
        program = None
        if self.is_series_screen_view_mode():  # checking if series screen is launched
            self.log.info("Screen Launched : {}".format(self.my_show_labels.LBL_SERIES_SCREEN))
            self.menu_navigate_left_right(1, 0)
            self.pause(2)  # settling time
            self.screen.refresh()
            menu_list = self.menu_list()
            program = self.screen_title()
            self.log.info("Program Title is : {}".format(program))
            if self.my_show_labels.LBL_GET_THIS_SHOW in menu_list:
                self.select_menu(self.my_show_labels.LBL_GET_THIS_SHOW)
            elif self.my_show_labels.LBL_ONEPASS_OPTIONS in menu_list:
                self.log.info("OnePass already created")
                return [program]
        elif self.is_action_screen_view_mode():  # checking if episode screen is launched
            self.log.info("Screen Launched : {}".format(self.my_show_labels.LBL_EPISODE_SCREEN))
            program = str(self.screen_title()).split("-")[0]
            self.log.info("Program Title is : {}".format(program))
            if self.is_in_menu(self.my_show_labels.LBL_ONEPASS_OPTIONS):
                self.log.info("OnePass already created")
                return [program]
            elif self.is_in_menu(self.my_show_labels.LBL_ONEPASS_AND_RECORDING_OPTIONS):
                self.nav_to_menu(self.my_show_labels.LBL_ONEPASS_AND_RECORDING_OPTIONS)
            elif self.is_in_menu(self.my_show_labels.LBL_RECORDING_OPTIONS):
                self.log.info("Recording already created")
                return [program]

        self.screen.refresh()
        if self.is_strip_list():
            if self.is_in_strip(self.my_show_labels.LBL_RECORD_, matcher_type="in"):
                self.set_record_or_onepass("strip",
                                           self.my_show_labels.LBL_RECORD_, self.my_show_labels.LBL_RECORD_OVERLAY,
                                           self.my_show_labels.LBL_PROGRAM_OPTIONS_RECORD_EPISODE_WITH_THESE_OPTIONS)
            elif self.is_in_strip(self.my_show_labels.LBL_CREATE, matcher_type="in"):
                self.set_record_or_onepass("strip",
                                           self.my_show_labels.LBL_CREATE,
                                           self.my_show_labels.LBL_ONEPASS_OPTIONS_OVERLAY,
                                           self.my_show_labels.LBL_CREATE)
        else:
            if self.is_in_menu(self.my_show_labels.LBL_RECORD_):
                self.set_record_or_onepass("menu",
                                           self.my_show_labels.LBL_RECORD_, self.my_show_labels.LBL_RECORD_OVERLAY,
                                           self.my_show_labels.LBL_RECORD_)
            elif self.is_in_menu(self.my_show_labels.LBL_CREATE):
                self.set_record_or_onepass("menu",
                                           self.my_show_labels.LBL_CREATE,
                                           self.my_show_labels.LBL_ONEPASS_OPTIONS_OVERLAY,
                                           self.my_show_labels.LBL_CREATE)

        self.log.info("Record/Create One Pass program: {}".format(program))
        return [program]

    def set_record_or_onepass(self, source, first_lbl, screen_to_wait, scd_lbl):
        """
        Setting record or one pass from menu or strip
        """
        assert source in ("menu", "strip")
        if source == "menu":
            self.select_menu_by_substring(first_lbl)
        elif source == "strip":
            self.select_string_by_substring(first_lbl)
        self.wait_for_screen_ready(screen_to_wait)
        self.screen.refresh()
        self.is_overlay_shown()
        self.select_menu_by_substring(scd_lbl)

    def select_series_from_myshows(self, program):
        """
        My Shows screen should be opened and an episode of a series assert should be recored before.
        Steps:
            1. Selecting Recordings strip in My Shows
            2. Selecting program in Recordings strip
            3. Selecting OnePass Options in Series screen
        """
        self.log.step(f"Selecting {program} from my shows")
        self.menu_navigate_left_right(1, 0)
        self.screen.refresh()
        self.select_menu(self.my_show_labels.LBL_SERIES_RECORDINGS)
        self.menu_navigate_left_right(0, 1)
        self.screen.refresh()
        if self.menu_focus() != self.my_show_labels.LBL_SERIES_RECORDINGS:
            self.log.info("In Myshows - Recordings")
            self.select_menu(program)
            self.wait_for_screen_ready(self.my_show_labels.LBL_SERIES_SCREEN)
            self.log.info("In Sereis screen")
            self.menu_navigate_left_right(1, 0)
            self.wait_for_screen_ready(self.my_show_labels.LBL_SERIES_SCREEN)
            self.screen.refresh()
            self.log.info("Selecting One Pass options")
            self.select_menu(self.my_show_labels.LBL_ONE_PASS_OPTIONS)
            self.screen.refresh()
        else:
            self.log.error("One pass created has failed to record the show")

    def cleanup_text_char(self, title, rstr=''):
        return_text = title.replace('â\x80\x98', rstr).replace('â\x80\x99', rstr).replace("\xc3\x83\xc2\xa9", rstr)
        return_text = return_text.strip()
        self.log.info('cleaned up text {}: {}'.format(title, return_text))
        return return_text

    def select_delete_pause_overlay(self, tester):
        self.log.step("Select delete/stop from pause overlay")
        self.pause(3)
        self.screen.refresh()
        if self.get_overlay_title():
            try:
                self.select_menu_by_substring(tester.my_shows_labels.LBL_STOP)
            except Exception:
                self.select_menu_by_substring(tester.my_shows_labels.LBL_DELETE)
        else:
            tester.my_shows_assertions.overlay_title_assertion()

    def navigate_from_home_screen_to_myshows_categories(self, tester, destination_tab):
        self.log.step("Navigate to {} categories in myshows".format(destination_tab))
        tester.home_page.back_to_home_short()
        tester.home_assertions.verify_menu_item_available(tester.home_labels.LBL_MYSHOWS_SHORTCUT)
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_MYSHOWS_SHORTCUT)
        tester.my_shows_assertions.verify_my_shows_title()
        tester.my_shows_page.select_my_shows_category(tester, destination_tab)

    def validate_trickplay_actions(self, tester, platform):
        tester.guide_page.pause_show(tester)
        tester.guide_page.rewind_show(tester, 3)
        tester.guide_page.pause_show(tester)
        tester.guide_page.fast_forward_show(tester, 3)
        tester.guide_page.pause_show(tester)
        current_position = self.get_trickplay_current_position_time(tester)
        if platform == 'amino':
            self.log.info("Testing replay now")
            if not self.get_trickplay_visible():
                self.screen.base.press_enter()
            tester.my_shows_page.validate_replay(tester, current_position)
            tester.guide_page.pause_show(tester)
            current_position = self.get_trickplay_current_position_time(tester)
            self.log.info("Testing advance now")
            tester.my_shows_page.validate_advance_move(tester, current_position)

    def navigate_to_recordings(self):
        self.log.info("Navigating to recordings menu")
        self.wait_for_screen_ready()
        self.screen.base.press_left()
        self.screen.refresh()
        screen = self.screen.screen_dump['xml']
        if self.my_show_labels.LBL_SERIES_RECORDINGS not in str(screen['menuitem']):
            self.screen.base.press_left()
            self.screen.refresh()
        self.select_menu_by_substring(self.my_show_labels.LBL_SERIES_RECORDINGS)

    def play_recording(self, show):
        """
        Plays first available recording from MY SHOWS
        """
        self.navigate_to_recordings()
        self.select_menu_by_substring(show)
        self.wait_for_screen_ready()
        if self.screen.get_screen_dump_item('viewMode') == self.my_show_labels.LBL_ACTION_SCREEN_VIEW:
            last_screen = self.my_show_labels.LBL_ACTION_SCREEN_VIEW
            self.select_strip("Play")
        else:
            self.wait_for_screen_ready(self.my_show_labels.LBL_SERIES_SCREEN_VIEW)
            self.navigate_to_recordings()
            self.select_item()
            last_screen = self.my_show_labels.LBL_SERIES_SCREEN_VIEW
        self.wait_for_screen_ready()
        return last_screen

    def select_and_schedule_recording_from_predictions(self, tester, tsn):
        # TODO: no doc and comments, also direct xml processing must be refactored
        self.log.step("selecting program and scheduling for record")
        title = None
        channel = None
        self.screen.refresh()
        tester.home_assertions.verify_predictions()
        channel_list = self.get_recordable_channel_list(tester, tsn)
        i = 0
        while i <= 10:
            striplist = self.get_strip_list()
            second_strip_element = striplist[1]  # need to find a hidden logic
            img_of_avail_element = striplist[1]['availableOn']['imagename']  # must be refactored. direct XML processing
            if 'hasfocus' in second_strip_element and tester.my_shows_labels.LBL_LIVE_ICON in img_of_avail_element:
                self.screen.base.press_enter()
                self.screen.refresh()
                viewmode = self.view_mode()
                self.wait_for_screen_ready(tester.my_shows_labels.LBL_SERIES_SCREEN)
                if viewmode == tester.my_shows_labels.LBL_SERIES_SCREEN_VIEW:
                    self.log.info("checking if program is recordable")
                    channel, title = self.verify_if_program_is_recordable(tester, tsn, channel_list)
                    self.log.info("title is {}".format(title))
                    if title is not None:
                        tester.text_search_page.create_Explicit_Recording(tester)
                        break
                    else:
                        self.log.info("program was not recordable. Moving back to Home Screen")
                        self.screen.base.press_back()
                        self.screen.base.press_back()
                        self.wait_for_screen_ready(tester.home_labels.LBL_HOME_SCREEN_NAME)
                        self.screen.refresh()
                        self.verify_screen_title(tester.home_labels.LBL_HOME_SCREENTITLE)
                elif viewmode == tester.watchvideo_labels.LBL_LIVETV_VIEWMODE:
                    tester.guide_assertions.verify_live_playback()
                    channel, title = self.verify_if_program_is_recordable(tester, tsn, channel_list, viewmode=True)
                    if title is not None:
                        self.create_recording_from_live_tv(tester, channel)
                        break
                    else:
                        self.log.info("Program was not available for recording")
                        self.screen.base.press_back()
                        self.wait_for_screen_ready(tester.home_labels.LBL_HOME_SCREEN_NAME)
                else:
                    self.log.info("program was not a series.. moving back to Home Screen")
                    self.screen.base.press_back()
                    self.wait_for_screen_ready(tester.home_labels.LBL_HOME_SCREEN_NAME)
            self.screen.base.press_right()
            self.screen.refresh()
            self.log.info("Reached Home Main Screen")
            i += 1
        if title is None:
            raise AssertionError("No programs found in Predictions for recording")
        return title

    def verify_if_program_is_recordable(self, tester, tsn, channel_list, viewmode=False):
        self.log.info("Started checking if program was recordable")
        preview = {}
        if viewmode:
            self.screen.base.press_info()
            self.screen.refresh()
            dump = self.screen.get_screen_dump_item()
            preview.update({"channelNumber": dump['channel-number']})
            preview.update({"title": dump['title']})
        else:
            self.menu_navigate_left_right(1, 0)
            self.screen.refresh()
            self.select_menu(tester.guide_labels.LBL_LIVE_AND_UPCOMING)
            self.screen.base.press_enter()
            preview = self.get_preview_panel()
        if preview['channelNumber'] in channel_list:
            self.log.info("channel is recordable:{}".format(preview['channelNumber']))
            return preview['channelNumber'], preview['title']
        else:
            self.log.error("program is from a non recordable channel")
            return None, None

    def get_recordable_channel_list(self, tester, tsn):
        channel_list = []
        channels = tester.api.get_restrictedcapability_channels_details(tsn)
        for item in channels:
            if not item.get('restricted'):
                channel_list.append(item.get('number'))
        return channel_list

    def modify_recording_options(self, tester, Recording=False):
        if Recording:
            self.log.info("Modifying Recording options")
            self.nav_to_menu(self.my_show_labels.LBL_RECORDING_OPTIONS)
            preview = self.get_preview_panel()
            if preview is None:
                self.log.error("Preview is not displayed")
                assert False
            self.screen.refresh()
            self.select_strip(self.my_show_labels.LBL_MODIFY_RECORDING)
            self.log.info("Selected modify recording from strip")
            self.wait_for_screen_ready(self.my_show_labels.LBL_RECORDING_OPTIONS_OVERLAY)
            self.change_recording_or_onepass_options(self.my_show_labels.LBL_MODIFY_RECORDING_OPTIONS_LIST, Recording)
            self.log.info("modified options")
            self.screen.refresh()
            menu = self.menu_list()
            self.select_menu(menu[0])
            self.wait_for_screen_ready()
        else:
            self.log.info("Modifying One Pass options")
            if self.is_in_menu("OnePass"):
                self.nav_to_menu_by_substring("OnePass")
            else:
                raise AssertionError(
                    "OnePass Options/OnePass & Recording Options is not available for the program")
            preview = self.get_preview_panel()
            self.screen.refresh()
            self.select_strip(tester.guide_labels.LBL_MODIFY_ONEPASS)
            self.log.info("Selected onepass recording from strip")
            self.wait_for_screen_ready(tester.guide_labels.LBL_ONEPASS_OPTIONS_OVERLAY)
            self.change_recording_or_onepass_options(self.my_show_labels.LBL_ONE_PASS_OPTIONS_LIST, Recording)
            self.log.info("modified options")
            self.select_menu(tester.guide_labels.LBL_USE_THESE_OPTIONS)
            self.wait_for_screen_ready()
        return preview

    def change_recording_or_onepass_options(self, optionlist, recording):
        self.log.info("Modify recording or one pass options")
        for item in optionlist:
            self.log.info("Modifying {}".format(item))
            if recording:
                self.screen.refresh()
                self.nav_to_menu(item)
            else:
                index, count, index_list = self.get_menu_index(item)
                current_focus_index = self.return_menu_focus_index()
                if current_focus_index <= index:
                    if len(index_list) > 0 and current_focus_index > max(index_list):
                        count = 0
                    index = index - count
                    index_diff = index - current_focus_index
                    for i in range(abs(index_diff)):
                        self.screen.base.press_down()
            self.screen.base.press_right()
            self.log.info("Modified option {}".format(item))

    def get_menu_index(self, item):
        count = 0
        index_value = 0
        self.screen.refresh()
        menulist = self.menu_list()
        index_list = []
        if item in menulist:
            index_value = menulist.index(item)
            menuitem = self.screen.get_screen_dump_item('menuitem')
            for litem in range(3, len(menulist)):
                if menuitem[litem]['option'].__contains__('unselectable') and menuitem[litem]['option']['unselectable'] \
                        and litem < index_value:
                    index_list.append(litem)
                    count += 1
        return index_value, count, index_list

    def get_non_episodic_recordable_channel(self, tester, non_episodic_channel, tsn):
        channel_list = self.get_recordable_channel_list(tester, tsn)
        if channel_list is None or len(channel_list) < 0:
            return False
        for i in range(len(non_episodic_channel)):
            if non_episodic_channel[i][0] in channel_list:
                self.log.info("Non episodic recordable channel is {}".format(non_episodic_channel[i][0]))
                return non_episodic_channel[i][0]

    def select_prediction_ad(self, tester):
        self.log.step("Select an AD from predictions bar")
        self.screen.refresh()
        tester.home_assertions.verify_predictions()
        strip_item = self.screen.get_screen_dump_item('stripitem')
        i = 0
        while i <= 11:
            if strip_item[1].__contains__('ad') and strip_item[1]['ad'] and strip_item[1]['hasfocus']:
                self.log.info("Prediction AD found")
                self.screen.base.press_enter()
                self.pause(5)
                return True
            else:
                self.screen.base.press_left()
                self.screen.refresh()
                strip_item = self.screen.get_screen_dump_item('stripitem')
            i += 1
        self.log.info("Prediction AD not available")
        return False

    def playback_recording_and_verify_app_running(self, tester, category):
        self.log.step("Playback recording and verify app running")
        self.menu_navigate_left_right(1, 0)
        tester.my_shows_assertions.verify_content_in_category(category)
        self.select_menu(category)
        preview_image = self.get_preview_panel()['previewImage'][1]
        app_name = tester.apps_and_games_page.get_app_name_by_icon(tester, preview_image)
        self.screen.base.press_enter()
        self.verify_ott_app_is_foreground(self, app_name)

    def get_modify_onepass_preview_area_items(self):
        self.log.info("Getting Modify OnePass preview area items.")
        items = list(self.get_preview_panel()[1].values())
        return items

    def verify_focus_is_on_delete_icon(self):
        self.log.info("Verifying focus is on delete 'X' icon")
        self.screen.refresh()
        menuitem = self.screen.get_screen_dump_item('menuitem')
        if type(menuitem) is dict:
            if not menuitem.get('focusedicon'):
                self.log.info("focus is not on X icon")
                self.menu_navigate_left_right(0, 2)
        elif type(menuitem) is list:
            for menu in menuitem:
                if menu.get("hasfocus") and menu.get('focusedicon'):
                    self.log.info("focus is on X mark")
                    break
            else:
                self.log.info("focus is not on X icon")
                self.menu_navigate_left_right(0, 2)

    def get_focused_program_time(self):
        self.log.info("Getting focused program from series screen")
        self.screen.refresh()
        preview = self.screen.get_screen_dump_item('previewPane')
        return preview.get('airingTime')

    def verify_program_is_removed(self, deletd_program, new_program):
        self.log.info("Verifying program is deleted from current page")
        if deletd_program == new_program:
            raise AssertionError(f"{deletd_program} is not deleted yet.")

    def verify_focus_is_on_watchlist(self, lbl_watchlist):
        self.log.info("Verifying focus is on WatchList after deleting the program.")
        self.screen.refresh()
        menuitem = self.screen.get_screen_dump_item('menuitem')
        for menu in menuitem:
            if menu.get('text') == lbl_watchlist and not menu.get("hasfocus"):
                raise AssertionError("focus is not on WatchList")

    def delete_recording(self):
        """
        Delete recording using 'x' icon
        """
        self.log.step("Deleting recording.")
        if not self.is_item_in_key('menuitem'):
            self.menu_navigate_left_right(1, 0)
            self.menu_navigate_left_right(0, 3)
            self.press_ok_button()
            if self.is_overlay_shown():
                self.select_menu(self.my_show_labels.LBL_STOP_REC_AND_DELETE)
        else:
            menuitem = self.screen.get_screen_dump_item('menuitem')
            if type(menuitem) is dict:
                self.menu_navigate_left_right(0, 2)
                self.verify_focus_is_on_delete_icon()
                self.press_ok_button()
                if self.is_overlay_shown():
                    self.select_menu(self.my_show_labels.LBL_STOP_REC_AND_DELETE)
                self.wait_for_screen_ready()
            elif type(menuitem) is list:
                self.menu_navigate_left_right(0, 2)
                for item in menuitem:
                    self.verify_focus_is_on_delete_icon()
                    focused_program = self.get_focused_program_time()
                    self.log.info(f"Trying to delete program: {focused_program}")
                    self.press_ok_button()
                    if self.is_overlay_shown():
                        self.select_menu(self.my_show_labels.LBL_STOP_REC_AND_DELETE)
                    new_focused_program = self.get_focused_program_time()
                    self.log.info(f"focused program from series screen: {new_focused_program}")
                    self.verify_program_is_removed(focused_program, new_focused_program)

    def modify_inprogress_recording_options(self, tester):
        self.log.step("Modify inprogress recording options")
        self.nav_to_menu(self.my_show_labels.LBL_RECORDING_OPTIONS)
        preview = self.get_preview_panel()
        if preview is None:
            self.log.error("Preview is not displayed")
            assert False
        self.screen.refresh()
        self.select_strip(self.my_show_labels.LBL_MODIFY_RECORDING)
        self.wait_for_screen_ready(self.my_show_labels.LBL_RECORDING_OPTIONS_OVERLAY)
        self.change_recording_or_onepass_options([self.my_show_labels.LBL_KEEP_UNTILL], True)
        self.screen.refresh()
        menu = self.menu_list()
        self.select_menu(menu[0])
        return preview

    def wait_for_record_completion(self, tester, showtime):
        self.screen.refresh()
        dumptime = self.screen.screen_dump['xml']['timeinfo']
        guidetime = dumptime.strip('%a%p%m')
        guidetime_to_mins = tester.guide_page.convert_time_to_sec(guidetime)
        if guidetime_to_mins >= 720:
            self.log.info("Time was {}. Setting back to 0 + minutes in time".format(guidetime))
            guidetime_to_mins -= 720
        showtime_end_to_mins = tester.guide_page.convert_time_to_sec(showtime[1][0])
        diff_time = showtime_end_to_mins - guidetime_to_mins + 1
        self.log.info("Sleeping for {} minutes for the recording to complete".format(diff_time))
        if diff_time >= 1:
            self.pause(diff_time * 60)

    def select_keep_from_watch_now_strip(self, tester):
        self.log.step("Select keep from watch now strip")
        self.nav_to_top_of_list()
        self.screen.refresh()
        self.nav_to_menu(tester.vod_labels.LBL_WATCH_NOW)
        self.screen.base.press_back()
        self.go_to_cached_action_screen(tester, tester.my_shows_labels.LBL_SERIES_RECORDINGS)
        strip = self.strip_list()
        if self.my_show_labels.LBL_KEEP not in strip:
            self.log.info("Keep option not available in strip list. Recording is still in progress. waiting")
            record = True
            while record:
                self.log.info("Checking if recording is completed or not")
                self.screen.base.press_back()
                self.go_to_cached_action_screen(tester, tester.my_shows_labels.LBL_SERIES_RECORDINGS)
                recordType = self.get_preview_panel()['recordingType']
                self.log.info("Recording Preview message:{}".format(recordType))
                if recordType != self.my_show_labels.LBL_PREVIEW_RECORDING_MESSAGE:
                    self.log.info("Recording is completed")
                    record = False
                    break
                self.log.info("Pausing for a min to see if it completes")
                self.pause(60)
                strip = self.strip_list()
        self.select_strip(self.my_show_labels.LBL_KEEP)
        self.screen.refresh()
        if not self.screen.screen_dump['xml']['overlaytitle'] == self.my_show_labels.LBL_KEEP_OVERLAY_TITLE:
            return False
        self.select_menu(self.my_show_labels.LBL_KEEP_AS_LONG_AS_POSSIBLE)
        self.screen.refresh()
        return self.get_preview_panel()['recordingType']

    def select_keep_option(self, tester):
        self.screen.refresh()
        screen_dump = self.screen.screen_dump['xml']
        if "overlayMode" in screen_dump.keys():
            self.select_menu_by_substring(self.my_show_labels.LBL_KEEP)

    def select_socu_playback(self, tester, label=None):
        self.log.step("select socu content to stream")
        self.wait_for_screen_ready()
        self.menu_navigate_left_right(1, 0)
        self.screen.refresh()
        menulist = self.menu_list()
        if tester.guide_labels.LBL_LIVE_AND_UPCOMING in menulist:
            self.select_socu_playback_from_live_and_upcoming(tester, label=label)
        elif tester.my_shows_labels.LBL_WATCH_LIST in menulist:
            self.select_socu_playback_from_watchlist(tester, label=label)
        else:
            raise AssertionError(
                "WatchList or Live & Upcoming option is not available for inprogress bookmark created show")
        self.screen.refresh()

    def select_socu_playback_from_live_and_upcoming(self, tester, label=None):
        self.log.step("select socu content for playback from live and upcoming menu in series screen")
        self.select_menu(tester.guide_labels.LBL_LIVE_AND_UPCOMING)
        self.screen.refresh()
        self.verify_menu_has_focus()
        # is_prod should be remover when FA
        # CA-22166
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_19) and not Settings.is_prod():
            tester.my_shows_assertions.verify_upcoming_socu_playback_icon_displayed_by_api()
        else:
            tester.guide_assertions.verify_catchup_socu_icon_on_program_screen(lbl=label)
        self.screen.base.press_enter()
        self.wait_for_screen_ready()
        self.screen.refresh()
        self.select_strip(tester.home_labels.LBL_WTW_SOCU_ICON, matcher_type="in")
        self.screen.refresh()
        if self.is_overlay_shown() and tester.vod_labels.LBL_RESUME_PLAYING in self.menu_list():
            self.select_menu(tester.vod_labels.LBL_RESUME_PLAYING)

    def select_socu_playback_from_watchlist(self, tester, label=None):
        self.log.step("select socu content for playback from watchlist menu in series screen")
        self.select_menu(tester.my_shows_labels.LBL_WATCH_LIST)
        self.screen.refresh()
        tester.guide_assertions.verify_catchup_socu_icon_on_program_screen(lbl=label)
        menu = self.screen.get_screen_dump_item('menuitem')
        if tester.guide_labels.LBL_SOCU in str(menu):
            self.screen.base.press_enter()
            self.screen.refresh()
            if self.is_overlay_shown() and tester.vod_labels.LBL_RESUME_PLAYING in self.menu_list():
                self.select_menu(tester.vod_labels.LBL_RESUME_PLAYING)
        else:
            self.screen.base.press_right(time=1000)
            tester.my_shows_page.press_ok_button()
            self.wait_for_screen_ready()
            self.screen.refresh()
            self.select_strip(tester.home_labels.LBL_WTW_SOCU_ICON, matcher_type="in")
            self.screen.refresh()
            if self.is_overlay_shown() and tester.vod_labels.LBL_RESUME_PLAYING in self.menu_list():
                self.select_menu(tester.vod_labels.LBL_RESUME_PLAYING)

    def navigate_to_start_of_video_with_replay_button(self, tester):
        # As per spec, replay press in pause or play mode rewinds around 8 seconds in one key press.
        # Hence have repeated keypresses to reached start of the video
        current_position = self.get_trickplay_current_position_time(tester)
        cur_pos = self.get_timein_seconds(current_position, ms=False)
        self.log.info("The current position is {} : ".format(current_position))
        cache_size = tester.guide_page.get_live_cache()
        self.log.info("The Cache Size is {} : ".format(cache_size))
        count = int(self.get_timein_seconds(cache_size) / 8)
        self.navigate_to_replay_icon(tester)
        for i in range((count + 5)):
            self.screen.base.press_enter()
        self.screen.refresh()
        moved_position = self.get_trickplay_current_position_time(tester)
        move_pos = self.get_timein_seconds(moved_position, ms=False)
        self.log.info("The moved position is {} : ".format(moved_position))
        if move_pos >= cur_pos:
            tester.my_shows_assertions.verify_time_diff()

    def curl_streaming_playback_url(self, tester):
        self.log.step("Get session created playback url and return the curl response")
        try:
            session_details = tester.api.get_streaming_playback_session_details()
            self.log.info(f"playlist url >> {session_details.playlist_url}")
            command = "curl " + session_details.playlist_url
        except Exception:
            self.log.info("sessionCreate service API failed to response, trying to get url from adb logs")
            playback = self.wait_for_playback_url_string()
            self.log.info("playback loggg{}".format(playback))
            if not playback:
                self.log.info("playback url not available in adb logs")
                return
            if playback:
                x = playback.split(self.my_show_labels.LBL_m3u8, 1)
                y = x[0].split(self.my_show_labels.LBL_HTTP, 1)
                playback_url = self.my_show_labels.LBL_HTTP + y[1] + self.my_show_labels.LBL_m3u8
                command = "curl " + playback_url
        player_url_responce = Commands().issue_sys_command_sync_output(command, ignore_error=True)
        self.log.info("curl responce of playback url{} : ".format(player_url_responce))

    def verify_recording_playback_and_curl_url(self, tester):
        self.log.step("Verify recording content playback and curl the playback URL")
        tester.watchvideo_page.skip_hdmi_connection_error()
        self.curl_streaming_playback_url(tester)
        tester.watchvideo_assertions.verify_playback_play()
        tester.guide_assertions.verify_play_normal()

    def check_time_diff_min(self, current_position, pause_position):
        self.log.info("The current position is {} : ".format(current_position))
        cur_min = current_position.split(':')
        self.log.info("The moved position is {} : ".format(pause_position))
        pau_min = pause_position.split(':')
        time_diff = (int(cur_min[1]) - int(pau_min[1]))
        return time_diff

    def create_one_pass_and_wait_second_offer(self, tester):
        self.log.step("create one pass and wait second offer")
        collection_id, duration = tester.service_api.get_collectionID_min_duration()
        title = tester.service_api.season_pass_subscribe(collection_id)
        self.log.info("Wait  {} s ".format(duration))
        self.pause(duration)
        return title

    def get_cur_and_next_episodes_info(self):
        self.log.step("get info about current (focused) and next (unfocused) episodes")
        self.screen.base.press_up()
        self.pause(3)
        self.screen.refresh()
        try:
            episode_list = self.get_menu_item_array()
            self.log.debug("EPISODE LIST FROM get_menu_item_array(): \n"
                           "{}".format(episode_list))
            focus_index = self.get_focus_index(episode_list)
            self.log.debug("INDEX OF FOCUSED EPISODE: {}".format(focus_index))
            focused_episode = episode_list[focus_index]
            self.log.debug("FOCUSED EPISODE: {}".format(focused_episode))
            focused_episode_name = focused_episode['text'][0]
            self.log.debug("FOCUSED EPISODE NAME: {}".format(focused_episode_name))
            if focused_episode['text'][1].__contains__('Press'):
                self.log.info("focused episode text contains 'Press' getting next index for episode number")
                focused_episode_num = focused_episode['text'][2]
                self.log.debug("FOCUSED EPISODE NUMBER: {}".format(focused_episode_num))
            else:
                focused_episode_num = focused_episode['text'][1]
                self.log.debug("FOCUSED EPISODE NUMBER: {}".format(focused_episode_num))
            next_episode = episode_list[focus_index + 1]
            self.log.debug("NEXT EPISODE AFTER FOCUSED: {}".format(next_episode))
            next_episode_name = next_episode['text'][0]
            self.log.debug("NEXT EPISODE NAME AFTER FOCUSED: {}".format(next_episode_name))
            next_episode_num = next_episode['text'][1]
            self.log.debug("NEXT EPISODE NUMBER AFTER FOCUSED: {}".format(next_episode_num))
            focused_episode_dict = {}
            next_episode_dict = {}
            focused_episode_dict['name'] = focused_episode_name
            focused_episode_dict['num'] = focused_episode_num
            next_episode_dict['name'] = next_episode_name
            next_episode_dict['num'] = next_episode_num
            return focused_episode_dict, next_episode_dict
        except TypeError:
            raise TypeError("There is no episode list, object is a NoneType: {}".format(self.screen.screen_dump['xml']))
        except KeyError:
            raise KeyError("There are no some of items in episode objects: {}".format(self.get_menu_item_array()))

    def OTT_from_cached_action_screen(self, tester):
        self.log.info("Fetching OTT Image name")
        self.screen.refresh()
        strip_list = self.strip_list_type("imagename")
        strip = [i for i in strip_list if i]
        self.log.info("strip Image name{}".format(strip))
        found = False
        for image in strip:
            if image in tester.my_shows_labels.LBL_OTT_LIST:
                found = True
        if found:
            self.log.info("Found OTT Image name{}".format(image))
            return image
        else:
            pytest.skip("Program does not have OTT content in available list")

    def get_menu_item_for_upcoming_program(self, tester):
        self.log.info("Menu item for Upcoming program.")
        self.screen.refresh()
        menu_item = self.menu_list()
        if tester.guide_labels.LBL_UPCOMING in menu_item:
            return tester.guide_labels.LBL_UPCOMING
        elif tester.guide_labels.LBL_LIVE_AND_UPCOMING in menu_item:
            return tester.guide_labels.LBL_LIVE_AND_UPCOMING

    def get_and_search_vod_OTT_program(self, tester, mapped=None):
        status, result = tester.vod_api.getOffer_playable_rating_movie(mapped=mapped)
        if not status:
            return status, None
        program = tester.vod_page.extract_title(result)
        year = tester.vod_page.extract_movie_year(result)
        expected = program
        if year:
            expected = f"{program} {year}"
        tester.text_search_page.search_and_select(program, expected)
        return status, program

    def get_trickplay_current_position_time(self, tester, refresh=True):
        self.log.info("Fetching Trickplay current position")
        if refresh:
            self.screen.refresh()
        trickplay = self.screen.get_screen_dump_item('trick-play')
        time = trickplay[tester.my_shows_labels.LBL_TRICKPLAY_POSITION]
        time = (str(datetime.strptime(time, '%H:%M:%S.%f')).split(" "))
        return time[1]

    def replay_navigation_and_replay_press(self, tester, count=1):
        self.navigate_to_replay_icon(tester)
        self.log.info("Pressing replay Button multiple times")
        for i in range(count):
            self.screen.base.press_enter()

    def navigate_to_replay_icon(self, tester):
        self.log.info("Navigate to replay icon on Trickplaybar.")
        tester.watchvideo_page.wait_for_trickplay_bar_dismiss(Settings.trickplay_bar_timeout_in_pause_mode)
        tester.watchvideo_assertions.verify_trickplay_bar_not_shown()
        tester.watchvideo_page.show_trickplay_if_not_visible()
        pause = tester.watchvideo_page.index_position_of_icon(icon="Pause", refresh=False)
        if not pause:
            pause = tester.watchvideo_page.index_position_of_icon(icon="Play", refresh=False)
        replay = tester.watchvideo_page.index_position_of_icon(icon="Replay", refresh=False)
        tester.watchvideo_page.press_left_multiple_times(no_of_times=(pause - replay))

    def navigate_to_gotoend_icon(self, tester, exact_icon_match=False):
        self.log.info("Navigate to goto end icon on Trickplaybar.")
        pause = tester.watchvideo_page.index_position_of_icon(icon="Pause")
        if not pause:
            pause = tester.watchvideo_page.index_position_of_icon(icon="Play")
        gotolive = tester.watchvideo_page.index_position_of_icon(icon="Go to Live", exact_icon_match=exact_icon_match)
        if gotolive is None:
            gotolive = tester.watchvideo_page.index_position_of_icon(icon="Go to End")
        tester.watchvideo_page.show_trickplay_if_not_visible()
        tester.watchvideo_page.press_right_multiple_times(no_of_times=(gotolive - pause))

    def navigate_to_start_over_icon(self, tester):
        self.log.info("Navigate to start over icon on Trickplaybar.")
        pause = tester.watchvideo_page.index_position_of_icon(icon="Pause")
        if not pause:
            pause = tester.watchvideo_page.index_position_of_icon(icon="Play")
        startover = tester.watchvideo_page.index_position_of_icon(icon="Start Over")
        if startover is None:
            startover = tester.watchvideo_page.index_position_of_icon(icon="Start from buffer")
        tester.watchvideo_page.show_trickplay_if_not_visible()
        tester.watchvideo_page.press_left_multiple_times(no_of_times=(pause - startover))

    def select_and_start_recording_playback(self, tester, pgm):
        self.pause(30)
        tester.home_page.go_to_my_shows(tester)
        self.select_my_shows_category(tester, tester.my_shows_labels.LBL_SERIES_RECORDINGS)
        program = tester.text_search_page.cleanup_search_result(pgm)
        tester.my_shows_assertions.verify_content_in_category(program)
        menu = self.menu_focus()
        if isinstance(menu, list) and int(menu[1]) <= 1:
            self.screen.base.press_playpause()
        else:
            self.select_show(program)
            self.go_to_cached_action_screen(tester, tester.my_shows_labels.LBL_SERIES_RECORDINGS)
            self.playback_recording(tester, tester.my_shows_labels.LBL_SERIES_RECORDINGS)

    def play_recording_multiple_times(self, tester, recording, count):
        for i in range(count):
            self.log.step("Iteration {}".format(i))
            self.playback_recording(tester, tester.my_shows_labels.LBL_SERIES_RECORDINGS)
            if self.is_overlay_shown():
                self.select_menu(self.my_show_labels.LBL_KEEP_RECORDING)
                self.wait_for_screen_ready()
            if self.screen.get_screen_dump_item('viewMode') == self.get_watch_or_video_recording_view_mode(tester):
                tester.watchvideo_page.wait_for_trickplay_bar_dismiss(20)
                tester.watchvideo_assertions.verify_trickplay_bar_not_shown()
                self.screen.base.press_back()
            self.log.step("Iteration {} ends".format(i))

    def play_recording_and_check_prediction(self, tester, recording):
        for i in range(20):
            if i == 0:
                count = 40
            else:
                count = 1
            tester.home_page.go_to_my_shows(tester)
            tester.my_shows_assertions.verify_my_shows_title()
            tester.my_shows_page.select_my_shows_category(tester, tester.my_shows_labels.LBL_SERIES_RECORDINGS)
            self.select_menu_by_substring(recording[0][0])
            tester.home_page.wait_for_screen_ready()
            self.play_recording_multiple_times(tester, recording, count)
            tester.home_page.back_to_home_short()
            tester.home_page.wait_for_screen_ready()
            tester.home_page.goto_prediction()
            tester.home_page.wait_for_screen_ready()
            tester.home_assertions.verify_highlighter_on_prediction_strip()
            shows = tester.home_page.get_prediction_bar_shows(tester)
            status = tester.home_assertions.is_content_available_in_prediction(tester, recording, shows)
            if status:
                break
            else:
                if i == 19:
                    pytest.skip("Recording not found in prediction bar")
                continue

    def play_vod_asset_multiple_times_from_search(self, tester, asset_name, count):
        for i in range(count):
            if self.view_mode() != tester.text_search_labels.LBL_SEARCH_SCREEN_VIEW_NAME:
                tester.text_search_page.go_to_search(tester)
                tester.vod_assertions.verify_view_mode(tester.text_search_labels.LBL_SEARCH_SCREEN_VIEW_NAME)
                tester.text_search_page.search_and_select_by_content(asset_name, select=False)
            self.press_ok_button(refresh=True)
            if tester.vod_page.validate_resume_overlay(tester) is True:
                self.screen.base.press_enter()
            self.wait_for_screen_ready(tester.vod_labels.LBL_VOD_PLAYBACK)
            self.screen.refresh()
            if self.view_mode() == tester.vod_labels.LBL_WATCHVOD:
                tester.vod_assertions.verify_vod_playback(tester)
                tester.watchvideo_page.wait_for_trickplay_bar_dismiss(Settings.trickplay_bar_timeout_in_pause_mode)
                current_pos = tester.watchvideo_page.get_trickplay_current_position()
                duration = tester.watchvideo_page.get_trickplay_duration_in_sec()
                current_pos_sec = tester.guide_page.convert_time_to_sec(current_pos)
                status = tester.vod_page.check_if_current_pos_near_to_end(current_pos_sec, duration)
                if not status:
                    self.screen.base.press_back()
                else:
                    self.pause(240)
                self.screen.refresh()
                tester.vod_assertions.verify_view_mode(tester.text_search_labels.LBL_SEARCH_SCREEN_VIEW_NAME)

    def remove_year_from_title(self, show):
        year = re.split(r'\s\([0-9][0-9][0-9][0-9]\)$', show)
        show_name = year[0]
        self.log.info("show name {}".format(show_name))
        return show_name

    def play_socu_program_multiple_times(self, tester, expected_program_name, expected_desc, channel, count):
        for i in range(count):
            if self.view_mode() != tester.guide_labels.LBL_VIEW_MODE:
                tester.home_page.go_to_guide(tester)
                self.wait_for_screen_ready()
                tester.guide_assertions.verify_guide_screen()
                tester.guide_page.enter_channel_number(channel[0][0])
            actual_program_name = tester.guide_page.get_live_program_name(tester)
            if expected_program_name == actual_program_name:
                actual_desc = tester.guide_page.get_grid_focus_details()['description']
                if expected_desc != actual_desc:
                    break
            else:
                break
            tester.guide_page.select_and_watch_program(tester, socu=True, resume=True)
            tester.watchvideo_assertions.verify_playback_play()
            tester.watchvideo_page.wait_for_trickplay_bar_dismiss(Settings.trickplay_bar_timeout_in_pause_mode)
            tester.watchvideo_assertions.verify_trickplay_bar_not_shown()
            self.screen.base.press_back()
            tester.home_page.wait_for_screen_ready()
            tester.guide_assertions.verify_guide_title()

    def get_ndvr_space_display(self, tester):
        try:
            branding_UI = tester.api.branding_ui()
        except Exception:
            assert False, "Failed to call service branding UI"
        if branding_UI:
            client_disk_configuration = branding_UI.client_disk_configuration.get(
                'ndvrSpaceDisplay') if branding_UI.client_disk_configuration else None
        if client_disk_configuration == "hdAvailQuarterHours":
            self.log.info("Client disk configuration is in Time format")
            return "time"
        else:
            self.log.info("Client disk configuration is in Precentage format")
            return "precentage"

    def get_diskmeter_from_UI(self, tester):
        tester.home_page.back_to_home_short()
        tester.home_page.go_to_my_shows(tester)
        tester.my_shows_assertions.verify_my_shows_title()
        self.screen.refresh()
        self.wait_for_screen_ready(self.my_show_labels.LBL_MYSHOWS_SCREEN)
        screen_dump = self.screen.get_json()
        diskmeter = None
        if 'diskmeter' in screen_dump['xml']:
            diskmeter = screen_dump['xml']['diskmeter']['text']
        self.log.info(f"Disk meter is {diskmeter}")
        return diskmeter

    def search_and_select_recently_deleted_folder(self, tester):
        attempt = 0
        while attempt < 4:
            self.log.info("Attempt no. : {}".format(attempt))
            if not self.is_in_menu(tester.my_shows_labels.LBL_RECENTLY_DELETED):
                self.nav_to_bottom_of_list()
                self.screen.refresh()
                attempt += 1
            else:
                self.wait_for_screen_ready(tester.my_shows_labels.LBL_MYSHOWS_SCREEN)
                tester.menu_page.select_menu_items(tester.my_shows_labels.LBL_RECENTLY_DELETED)
                break

    def recover_and_verify_storage_limit_overlay(self, tester, verify_overlay=True):
        self.log.info("Trying to recover and checking storage limit overlay")
        tester.home_page.nav_to_top_menuitem_in_list()
        self.press_ok_button()
        self.select_menu_by_substring(self.my_show_labels.LBL_RECOVER)
        self.wait_for_screen_ready()
        if verify_overlay:
            if self.is_overlay_shown():
                overlay_title = self.get_overlay_title()
                if overlay_title is not None and tester.guide_labels.LBL_OVERLAY_STORAGE_LIMIT_TITLE in overlay_title:
                    self.select_menu(tester.guide_labels.LBL_OVERLAY_STORAGE_LIMIT_OK)
                    self.press_ok_button()
            else:
                raise AssertionError("Storage limit overlay is not shown and nDVR storage is not full")

    def get_expected_ordered_filter_list_in_my_shows(self, is_rec_enabled=True):
        """
        Getting expected ordered filter list in My Shows screen.
        E.g. Recordings, All Shows, TV Series etc depending on if recording feature is enabled or not and Hydra version.
        My Shows screen should be opened before calling this method.

        Args:
            is_rec_enabled (bool): True - nDVR is enabled and Recordings filter is shonw in My Shows,
                                   False - no Recordings filter
        """
        self.log.info("Getting expected ordered filter list in My Shows; is_rec_enabled = {is_rec_enabled}")
        self.press_left_button(refresh=True)  # highlighting filter name
        filter_list_to_check = []
        # base_* list dose not contain Recordings filter, it's appended/prepended further
        my_shows_filters = {
            "base_rec_on": [self.my_show_labels.LBL_ALL_SHOWS, self.my_show_labels.LBL_TV_SERIES,
                            self.my_show_labels.LBL_MOVIES, self.my_show_labels.LBL_KIDS,
                            self.my_show_labels.LBL_SPORTS, self.my_show_labels.LBL_PAUSED],
            "base_rec_off": [self.my_show_labels.LBL_ALL_SHOWS, self.my_show_labels.LBL_TV_SERIES,
                             self.my_show_labels.LBL_MOVIES, self.my_show_labels.LBL_KIDS,
                             self.my_show_labels.LBL_SPORTS]}
        if is_rec_enabled:
            if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_16):
                # Since Hydra v1.16, Recordings filter is located above all others in My Shows, if present
                my_shows_filters["base_rec_on"].insert(0, self.my_show_labels.LBL_RECORDINGS)
            else:
                # Old behavior: All Shows is the 1st fileter and Recordings filter is shown on the last position
                # in the list, if present
                my_shows_filters["base_rec_on"].append(self.my_show_labels.LBL_RECORDINGS)
        filter_list_to_check = my_shows_filters["base_rec_on"] if is_rec_enabled else my_shows_filters["base_rec_off"]
        self.log.debug(f"filter_list_to_check = {filter_list_to_check}")
        return filter_list_to_check

    def get_watch_or_video_recording_view_mode(self, tester):
        if Settings.hydra_branch() <= Settings.hydra_branch("b-hydra-streamer-1-15"):
            self.log.info("Returning watch recording screen view")
            return tester.my_shows_labels.LBL_WATCH_RECORDING_SCREEN_VIEW
        else:
            self.log.info("Returning video recording screen view")
            return tester.my_shows_labels.LBL_VIDEO_RECORDING_SCREEN_VIEW

    def sort_by_name(self, name_of_recordings):
        """
        params:
        name_of_recordings is a parameter which is list of show names with articles
        Ignores articles A,An,The from show names and sorting is done
        returns sorted list
        """
        prog = name_of_recordings
        art_dict = {}
        show_list = []
        for show in prog:
            name = None
            article_list = ['The', 'An', "A"]
            items = show.split(" ")
            if items[0] in article_list:
                name = " ".join(items[1:])
                art_dict.update({name: items[0]})
            if name:
                show_list.append(name)
            else:
                show_list.append(show)
        show_list = sorted(show_list)
        for k in art_dict.keys():
            index = show_list.index(k)
            new_val = art_dict.get(k) + " " + show_list[index]
            show_list[index] = new_val
        return show_list

    def my_shows_sort_by_name_or_date(self, tester, sort):
        """
        params:
        sort is a parameter to either sort by name or date
        """
        tester.home_page.back_to_home_short()
        sort_option = sort
        tester.menu_page.go_to_user_preferences(tester)
        tester.menu_page.wait_for_screen_ready(tester.menu_labels.LBL_USER_PREFERENCES_TITLE)
        tester.menu_page.select_menu_items(tester.my_shows_labels.LBL_MY_SHOWS_OPTIONS)
        self.screen.refresh()
        if str(sort_option) == "name":
            tester.menu_page.select_menu_items(tester.my_shows_labels.LBL_SORT_BY_NAME)
            tester.log.info("Selected sort by Name")
        elif str(sort_option) == "date":
            tester.menu_page.select_menu_items(tester.my_shows_labels.LBL_SORT_BY_DATE)
            tester.log.info("Selected sort by Date")

    def compare_different_channel_for_recording(self, tester, channel, recording):
        """
        Compares existing recording show name and inputs a non existing showname channel number
        params: channel numbers as input, existing recording name
        """
        check = False
        for i in range(len(channel)):
            if channel[i][2] != recording[0][0]:
                tester.guide_page.enter_channel_number(channel[0][0])
                check = True
                break
        return check

    def play_recording_continously(self, tester, program, wait_time=24):
        """
        Plays a scheduled recording and waits for 1 hour
        params:no of hours to watch recording, recording name
        """
        for x in range(wait_time):
            tester.home_page.go_to_my_shows(tester)
            tester.my_shows_page.select_my_shows_category(tester, tester.my_shows_labels.LBL_SERIES_RECORDINGS)
            tester.my_shows_assertions.verify_content_in_category(program)
            tester.my_shows_page.select_show(program)
            tester.my_shows_page.playback_recording(tester, tester.my_shows_labels.LBL_SERIES_RECORDINGS)
            tester.watchvideo_page.navigate_to_start_of_video()
            tester.my_shows_page.verify_recording_playback_and_curl_url(tester)
            tester.watchvideo_page.watch_video_for(60 * 60)
            self.select_keep_recording(tester)
            tester.home_page.back_to_home_short()

    def select_keep_recording(self, tester):
        """
        Navigates and selects keep recording, if overlay displayed
        """
        self.screen.refresh()
        del_rec_overlay = tester.watchvideo_page.is_delete_recording_overlay()
        if self.is_overlay_title() and del_rec_overlay:
            self.nav_to_menu(tester.my_shows_labels.LBL_KEEP_RECORDING)
            self.select_item()

    def get_my_shows_recordings_date_ui(self, tester, no_of_recordings):
        """
        Gets recordings details from myshows
        params: no_of_recordings available in device
        """
        shows_date_ui = []
        format_date = []
        actual_date = []
        tester.home_page.go_to_my_shows(tester)
        tester.my_shows_page.select_my_shows_category(tester, tester.my_shows_labels.LBL_SERIES_RECORDINGS)
        for i in range(no_of_recordings):
            shows_date_ui.append(tester.screen.get_screen_dump_item('menuitem')[i]['text'][2])
        for i in range(no_of_recordings):
            shows_date_ui[i] = shows_date_ui[i].split()
            shows_date_ui[i][0] = shows_date_ui[i][0].split("-")
            format_date.append(shows_date_ui[i][1])
            format_date[i] = format_date[i].split("/")
            actual_date.append(format_date[i][1])
        return actual_date

    def OTT_from_ca_screen(self, tester):
        self.log.info("Fetching OTT Image name")
        self.screen.refresh()
        strip_list = self.strip_list_type("imagename")
        strip = [i for i in strip_list if i]
        self.log.info("strip Image name{}".format(strip))
        found = False
        for image in strip:
            for img in tester.my_shows_labels.LBL_OTT_LIST_ACTION_SCREEN:
                if img in image:
                    found = True
                    break
            if found:
                self.log.info("Found OTT Image name{}".format(image))
                break
        else:
            pytest.skip("Program does not have OTT content in available list")
        return image

    def select_delete_option(self, tester):
        self.screen.refresh()
        screen_dump = self.screen.screen_dump['xml']
        if "overlayMode" in screen_dump.keys():
            self.select_menu_by_substring(self.my_show_labels.LBL_DELETE)

    def search_and_select_ott(self, tester, program_name, ott_name):
        """
        This api will search and select the program name/offer which has multiple name of same offername
        """
        self.screen.refresh()
        cleanup_list = []
        menu_list = self.menu_list()
        for text_item in menu_list:
            cleanup_list.append(
                tester.text_search_page.cleanup_search_result(text_item).encode("iso8859").decode("utf8"))
        self.log.debug(f"CLEANUP_LIST_IN_ACTION_SCREEN_TRUE and program_name is {cleanup_list} {program_name}")
        if cleanup_list.count(program_name) > 1:
            self.log.debug("programs are greater than one")
            for index in range(len(cleanup_list)):
                if cleanup_list[index] == program_name:
                    tester.wtw_page.wait_for_screen_ready()
                    ott_icon = tester.guide_page.get_preview_panel().get('availableOn', None)
                    if not self.check_ott_preview_images_are_available(ott_icon, ott_name):
                        self.screen.base.press_down()
                    else:
                        break
            else:
                raise AssertionError("OTT icon is not present even after checking all menu Items")

        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_11):
            # Preserving old behavior when the Program Screen opened after selecting
            # a search result item, with https://jira.tivo.com/browse/IPTV-14925 playback may start
            tester.text_search_page.open_program_screen(watch_now=False)

        else:
            self.screen.base.press_enter(2000)

    def check_ott_preview_images_are_available(self, ott_icon, ott_name):
        try:
            ott_icon_list = ott_icon['imagename']
            self.log.debug(f"Get ott is :{ott_icon_list}")
            if type(ott_icon_list) is list:
                for ott in ott_icon_list:
                    if ott_name.lower() in ott.lower():
                        self.log.info("OTT icon exists {}".format(ott_name.lower()))
                        return True
            else:
                if ott_name.lower() in ott_icon_list.lower():
                    self.log.info("OTT icon exists {}".format(ott_name.lower()))
                    return True
        except Exception:
            self.log.info("Images are not available on the seached asset")
            return False

    def select_series_screen_menu_list_upcoming(self, program):
        """
         My Shows screen should be opened and an episode of a series assert should be recored before.
        Steps:
            1. Selecting TV Series strip in My Shows
            2. Selecting program in TV Series strip
            3. Selecting Upcoming or Live & Upcoming Options in Series screen
        """
        self.log.step(f"Selecting {program} from my shows")
        self.menu_navigate_left_right(1, 0)
        self.screen.refresh()
        self.select_menu(self.my_show_labels.LBL_TV_SERIES)
        self.menu_navigate_left_right(0, 1)
        self.screen.refresh()
        if self.menu_focus() != self.my_show_labels.LBL_TV_SERIES:
            self.log.info("In MyShows - TV Series")
            self.select_menu(program)
            self.wait_for_screen_ready(self.my_show_labels.LBL_SERIES_SCREEN)
            self.log.info("In Series screen")
            self.menu_navigate_left_right(1, 0)
            self.wait_for_screen_ready(self.my_show_labels.LBL_SERIES_SCREEN)
            self.screen.refresh()
            self.log.info("Selecting Upcoming or Live&Upcoming")
            menu_list = self.menu_list()
            if self.my_show_labels.LBL_UPCOMING in menu_list:
                self.select_menu(self.my_show_labels.LBL_UPCOMING)
            elif self.my_show_labels.LBL_LIVE_UPCOMING in menu_list:
                self.select_menu(self.my_show_labels.LBL_LIVE_UPCOMING)
            self.screen.refresh()
        else:
            self.log.error("Failed to select Upcoming or Live&Upcoming")

    def get_available_shows_in_all_shows(self, show_list):
        menus = self.menu_list()
        available = [menus[item][0] if isinstance(menus[item], list) and len(menus[item]) > 0
                     else menus[item] for item in range(len(menus))]
        shows = [show for show in show_list if show in available]
        return shows if shows and len(shows) > 0 else None
