import time
import re
from datetime import datetime, timedelta

from hamcrest import assert_that, equal_to_ignoring_case, contains_string, not_none, equal_to, is_, has_item, not_

from set_top_box.client_api.my_shows.en_us.labels import MyShowsLabels
from set_top_box.client_api.my_shows.page import MyShowsPage
from set_top_box.conf_constants import HydraBranches
from set_top_box.test_settings import Settings


# TODO
# It's better to inherit properties from core_api.stb.assertions.CoreAssertions due to PageFactory
class MyShowsAssertions(MyShowsPage):
    # TODO
    # Switch to using my_shows_label from confest due to LabelFactory and remove this one
    my_shows_labels = MyShowsLabels()

    def verify_my_show_option(self, my_show_option):
        assert_that(self.screen.get_screen_dump_item('tiptext')[1], my_show_option)

    def verify_my_shows_content_filters(self, tester):
        tester.menu_page.menu_navigate_left_right(1, 0)
        self.screen.refresh()
        menu_list = self.menu_list()
        found = False
        categories_list = tester.my_shows_labels.LBL_MY_SHOWS_FILTER_OPTIONS_1_16_AND_HIGHER \
            if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_16) else \
            tester.my_shows_labels.LBL_MY_SHOWS_FILTER_OPTIONS_1_15_AND_LOWER
        for menu in categories_list:
            self.log.info("My Shows Content File Validation: Expected: {}".format(menu))
            for item in menu_list:
                if menu == item:
                    self.log.info("Validation PASSED : Expected:{} Actual: {}".format(menu, item))
                    found = True
            assert_that(found)

    def verify_content_in_category(self, content):
        self.log.info("Verify content {} exist in menu. ".format(content))
        time.sleep(1)
        self.screen.refresh()
        self.log.debug("content: {}".format(content))
        content = self.remove_service_symbols(content)
        check = self.is_in_menu(content)
        current_menu = self.menu_list() if not check else None
        assert check, "Menu doesn't contain '{}', cur menu: {}".format(content, current_menu)

    def verify_content_not_in_category(self, tester, content, folder_name=None):
        self.screen.refresh()
        dump = self.screen.get_json()
        if dump.__contains__('menuitem'):
            self.log.step("Verifying that {} is not available".format(content))
            self.screen.refresh()
            assert not self.is_in_menu(content)
        else:
            tester.home_page.go_to_my_shows(tester)
            tester.my_shows_page.select_my_shows_category(tester, tester.my_shows_labels.LBL_ALL_SHOWS)
            self.wait_for_screen_ready(tester.my_shows_labels.LBL_MYSHOWS_SCREEN)
            self.screen.refresh()
            if folder_name is None:
                assert not self.is_in_menu(content)
            else:
                assert not self.is_in_menu(folder_name)

    def verify_my_shows_title(self):
        self.log.step("Verifying MY SHOWS screen title.")
        self.screen.refresh()
        assert_that(self.screen_title(), equal_to_ignoring_case(self.my_shows_labels.LBL_MY_SHOWS))

    def verify_series_screen(self, tester):
        self.log.step("Verifying series screen view")
        self.screen.refresh()
        self.verify_view_mode(tester.my_shows_labels.LBL_SERIES_SCREEN_VIEW)

    def verify_series_screen_strip_order(self, mode="bookmark", is_recording_required=False):
        """
        Verifying action menu items order in the Series Screen.
        Some action menu items may not be displayed if they does not contain any asset e.g. Recordings, Cast etc.,
        see may_not_be_shown_if_empty_list variable below.
        Series screen shoud be opened before calling this method.

        Note:
            Since Hydra v1.16, Recordings action menu should be the 1st item above all other ones,
            if there are some recordings.
            Preserving behavior for older versions and adding new one.

        Args
            mode (str): one of (bookmark, onepass, recording), menu items differ depending on the mode
            is_recording_required (bool): True - Recording action menu item is expected to be shown
                                                 (e.g. when OnePass created with nDVR on);
                                          False - check Recordings strip postion only if it has some items
                                                  (common case when we don't know for sure if there are items in the list)
        """
        self.log.step("Verifying series screen strip order")
        self.press_left_button(refresh=True)  # highlighting action menu item on the left
        # The list of action menu items which may be not displayed if empty
        may_not_be_shown_if_empty_list = [self.my_shows_labels.LBL_WATCH_LIST.lower(),
                                          self.my_shows_labels.LBL_SERIES_RECORDINGS.lower(),
                                          self.my_shows_labels.LBL_CAST.lower()]
        self.screen.refresh()
        if mode == "bookmark" or mode == "recording":
            # Action menu list in the Series Screen when OnePass is not created
            template_list = [self.my_shows_labels.LBL_GET_THIS_SHOW.lower(),
                             self.my_shows_labels.LBL_WATCH_LIST.lower(),
                             self.my_shows_labels.LBL_SERIES_RECORDINGS.lower(),
                             self.my_shows_labels.LBL_CAST.lower(),
                             self.my_shows_labels.LBL_MAY_ALSO_LIKE.lower(),
                             self.my_shows_labels.LBL_ALL_EPISODES.lower(),
                             self.my_shows_labels.LBL_UPCOMING.lower()]
        else:
            # Action menu list in the Series Screen with created OnePass
            template_list = [self.my_shows_labels.LBL_WATCH_LIST.lower(),
                             self.my_shows_labels.LBL_SERIES_RECORDINGS.lower(),
                             self.my_shows_labels.LBL_CAST.lower(),
                             self.my_shows_labels.LBL_MAY_ALSO_LIKE.lower(),
                             self.my_shows_labels.LBL_ALL_EPISODES.lower(),
                             self.my_shows_labels.LBL_UPCOMING.lower(),
                             self.my_shows_labels.LBL_ONE_PASS_OPTIONS.lower()]
        # Actual action menu list on the Series screen
        actual = [item.lower() for item in self.menu_list()]
        upcoming = self.my_shows_labels.LBL_UPCOMING.lower()
        recordings = self.my_shows_labels.LBL_SERIES_RECORDINGS.lower()
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_16):
            template_list.remove(recordings)
            template_list.insert(0, recordings)
        # Preparing Series Screen menu list in proper order taking into account absent items
        expected = []
        for item in template_list:
            if not (item not in actual and item in may_not_be_shown_if_empty_list):
                # Setting correct label to expected list for Upcoming item since it may have some addings
                if item == upcoming:
                    for i in actual:
                        if upcoming in i:
                            item = i
                            break
                expected.append(item)
        self.log.debug(f"template_list = {template_list}")
        self.log.debug(f"expected list = {expected}")
        self.log.debug(f"actual list = {actual}")
        self.log.debug(f"may_not_be_shown_if_empty_list = {may_not_be_shown_if_empty_list}")
        if is_recording_required and recordings not in expected:
            raise AssertionError("Recordings action menu item is not shown on Series screen but expected")
        assert_that(actual, equal_to(expected), "Not correct order of the menu action list in the Series Screen")

    def verify_series_screen_items(self):
        self.log.step("Verifying series screen items")
        assert_that(self.get_menu_item(), not_none(), "No Sub menu found")
        assert_that(self.get_unfocused_menu_item(), not_none(), "No menu found")
        assert_that(self.screen_title(), not_none(), "No screen title found")
        assert_that(self.get_preview_panel(), not_none(), "No header")

    def verify_netflix_screen(self):
        self.log.step("Verifying netflix screen")
        data = self.screen.base.get_window_dump("Netflix")
        self.log.info("Netflix Screen Visibility : {}".format(data))
        assert_that(data)

    def verify_OTT_icon(self, icon):
        self.log.step(f"Verifying OTT icon existence: {icon}")
        assert_that(self.is_in_strip(icon), True)

    def verify_category_has_content(self):
        self.screen.refresh()
        menu = (self.screen.get_screen_dump_item('menuitem'))
        if isinstance(menu, list):
            menuitems = menu
        else:
            menuitems = [menu]
        for item in menuitems:
            assert_that(item, not_none())

    def select_keep_and_verify(self):
        self.log.info("Verifying if Keep overlay was launched or not")
        self.screen.refresh()
        overlayTitle = (self.screen.get_screen_dump_item('overlaytitle'))
        assert_that(overlayTitle, contains_string(self.my_shows_labels.LBL_KEEP_OVERLAY_TITLE))

    def wait_and_verify_delete_recording_overlay(self):
        self.pause(15)
        self.screen.refresh()
        trick_play = self.get_trickplay()
        pattern = '%H:%M:%S'
        current_time = int(time.mktime(time.strptime(trick_play['current-pos'].split(".")[0], pattern)))
        end_time = int(time.mktime(time.strptime(trick_play['replay-size'].split(".")[0], pattern)))
        wait_time = end_time - current_time
        self.log.debug("End time of the program is:{} and current time is:{}".format(end_time, current_time))
        self.log.debug("Waiting for {} seconds to watch the show until the end".format(wait_time))
        self.pause(wait_time)
        self.screen.refresh()
        if not self.is_overlay_shown():
            self.pause(90)
            self.screen.refresh()
        overlay_title = self.get_overlay_title()
        if not self.is_overlay_shown():
            self.log.debug("Waiting for *** {} *** overlay".format(self.my_shows_labels.LBL_DELETE_THIS_RECORDING))
            self.pause(5)  # Grace time added for the overlay to launch
        assert_that(overlay_title, contains_string(self.my_shows_labels.LBL_DELETE_THIS_RECORDING))

    def verify_delete_overlay(self):
        self.log.info("Verifying delete overlay")
        overlaytitle = self.get_overlay_title()
        assert_that(overlaytitle, contains_string(self.my_shows_labels.LBL_DELETE))

    def verify_program_in_recently_deleted_folder(self, tester, program):
        program = self.convert_special_chars(program)
        self.log.info(f"Verifying {program} existence from recently deleted folder after deletion")
        tester.home_page.nav_to_top_menuitem_in_list()
        menu = self.menu_list()
        assert_that(str(menu), contains_string(program))

    def verify_content_under_recordings_filter(self, content):
        self.log.step(f"Checking for {content} under recordings filter")
        menu = self.menu_list()
        found = False
        for item in menu:
            if content in item[0]:
                found = True
                self.log.info("\nRecorded program is displayed under Recordings filter\n")
        assert_that(found)

    def verify_time_diff(self):
        raise AssertionError('Trick-play time validation failed')

    def verify_onepass_options_overlay(self, tester):
        self.log.step("Verifying One Pass options")
        self.pause(2)
        tester.menu_page.menu_navigate_left_right(1, 0)
        self.screen.refresh()
        menu = self.menu_list()
        if tester.my_shows_labels.LBL_GET_THIS_SHOW not in menu:
            self.select_menu(tester.vod_labels.LBL_ONEPASS_OPTIONS)
            self.screen.refresh()
            self.select_menu(tester.home_labels.LBL_MODIFY_ONEPASS)
        else:
            self.select_menu(tester.my_shows_labels.LBL_GET_THIS_SHOW)
            self.select_menu(tester.home_labels.LBL_CREATE_ONEPASS)
        self.screen.refresh()
        if not self.wait_for_screen_ready(tester.guide_labels.LBL_ONEPASS_OPTIONS_OVERLAY, 150000):
            raise AssertionError("Unable to verify OnePass Options Overlay")

    @staticmethod
    def verify_focused_program(program, focused_program):
        assert_that(focused_program, equal_to(program))

    def verify_empty_to_do_list(self, tester):
        self.log.step("Verifying if To Do List was empty or not")
        empty_body_text = self.get_bodytext()
        if empty_body_text != tester.menu_labels.LBL_EMPTY_TODO_LIST:
            raise AssertionError("TO DO LIST is not empty")

    def verify_recording_icon(self):
        self.screen.refresh()
        focused_image = self.menu_item_image_focus()
        self.log.info("Focused Image: {}".format(focused_image))
        Found = False
        if isinstance(focused_image, list):
            for image in focused_image:
                if self.my_show_labels.LBL_RECORDING_ICON in image:
                    self.log.info("Recording icon is displayed")
                    Found = True
                    break
        else:
            if self.my_show_labels.LBL_RECORDING_ICON in focused_image:
                self.log.info("Recording icon is displayed")
                Found = True
        assert_that(Found)

    def verify_recording_playback(self, tester):
        self.log.step("Verifying recording playback")
        self.wait_for_screen_ready(tester.live_tv_labels.LBL_WATCH_RECORDING_SCREEN, 30000)
        url = self.get_playback_raw_log_with_status(timeout=20000)
        tester.watchvideo_assertions.set_or_update_channel_playback_info(playback_state=url)
        current_screen = self.get_screen_name()
        trickplay = self.screen.get_screen_dump_item('trick-play')
        if current_screen == tester.live_tv_labels.LBL_WATCH_RECORDING_SCREEN and "play-status" in trickplay and \
           trickplay['play-status'] == tester.live_tv_labels.LBL_PLAYBACK_IN_PLAY_MODE:
            self.log.info("Verification of recording playback is successful without any issues")
        else:
            tester.watchvideo_assertions.verify_error_overlay_not_shown()
        tester.watchvideo_assertions.set_or_update_channel_playback_info(after_check=True)

    def verify_recorded_programs(self, programs):
        self.log.step(f"Verifying availability of program: {programs}")
        count = 0
        self.screen.refresh()
        recordings = self.menu_list()
        self.log.info("Menu list is : {}".format(recordings))
        for prog in recordings:
            if isinstance(prog, list):
                for item in prog:
                    for i in range(len(programs)):
                        self.log.info("Available Program:{} Expected Program : {}".format(item, programs[i]))
                        if programs[i].strip().lower() in item.lower():
                            self.log.info("{} found".format(programs[i]))
                            count += 1
                        if len(programs) == count:
                            assert_that(True)
                            return
            else:
                for i in range(len(programs)):
                    self.log.info("Available Program:{} Expected Program : {}".format(prog, programs[i]))
                    if programs[i].strip().lower() in prog.lower():
                        self.log.info("{} found".format(programs[0]))
                        count += 1
                    if len(programs) == count:
                        assert_that(True)
                        return
                    else:
                        self.log.info("{} not found".format(programs[0]))
        if (count < len(programs)):
            self.log.info("{} not found".format(programs[0]))
            raise AssertionError("Recorded programs are not found")

    def verify_recorded_content(self, tester, program):
        program = self.remove_service_symbols(program)
        assert_that(program, "Program is not recording")
        try:
            self.log.info("Verifying if recorded content is available in MyShows")
            tester.home_page.back_to_home_short()
            tester.home_assertions.verify_menu_item_available(tester.home_labels.LBL_MYSHOWS_SHORTCUT)
            tester.home_page.select_menu_shortcut(tester.home_labels.LBL_MYSHOWS_SHORTCUT)
            tester.my_shows_page.wait_for_screen_ready()
            tester.my_shows_page.select_my_shows_category(tester, tester.my_shows_labels.LBL_ALL_SHOWS)
            self.verify_recorded_programs(program)
            self.log.info("Program Found in MyShows")
        except Exception:
            self.log.info("Verifying if recorded content is available in ToDoList")
            tester.home_page.back_to_home_short()
            tester.home_page.select_menu_shortcut(tester.home_labels.LBL_MENU_SHORTCUT)
            self.nav_to_top_of_list()
            tester.menu_page.select_menu_category(tester.menu_labels.LBL_SETTINGS_SHORTCUT)
            tester.menu_page.select_menu_items(tester.menu_labels.LBL_TODO_LIST)
            assert_that(self.get_menu_item(), not_none(), "Program not found and todolist is empty")
            self.log.info("Program Found in ToDoList")

    def verify_delete_group_overlay(self, tester, program):
        self.log.step(f"Verifying delete group overlay for {program}")
        self.select_menu(tester.my_shows_labels.LBL_DELETE_ALL_EPISODES)
        self.screen.refresh()
        overlaytitle = self.screen.get_screen_dump_item('overlaytitle')
        cleaneduptitle = self.cleanup_text_char(overlaytitle)
        title = tester.my_shows_labels.LBL_DELETE + " " + program + " " + tester.my_shows_labels.LBL_GROUP
        menu = self.menu_list()
        overlay_body = self.screen.get_screen_dump_item('overlayBody')
        if title.lower() == cleaneduptitle.lower() and \
                tester.my_shows_labels.LBL_DELETE_GROUP_OVERLAY_BODY_TEXT == overlay_body \
                and tester.my_shows_labels.LBL_DELETE_GROUP_OPTIONS == menu:
            self.log.info("Delete group overlay displayed")
            assert True
        else:
            self.log.error("Failed to launch delete group overlay: title: {} - cleanuptitle: {}".format(title, cleaneduptitle))
            assert False

    def overlay_title_assertion(self):
        raise AssertionError('Overlay validation failed')

    def verify_modified_recording_or_onepass_options(self, preview, Recording=False):
        self.log.step("Verifying modified recording/onepass options")
        self.screen.refresh()
        preview_after_change = self.get_preview_panel()
        if preview_after_change is None:
            self.log.error("Preview was empty after modifying options")
            assert False
        if Recording:
            if preview['keepUntilValue'] == preview_after_change['keepUntilValue'] or preview['startRecordingValue'] == \
                    preview_after_change['startRecordingValue'] or preview['stopRecordingValue'] == \
                    preview_after_change['stopRecordingValue']:
                raise AssertionError("Recording Options modification failed")
            assert True
        else:
            if preview['includeValue'] == preview_after_change['includeValue'] or preview["startFromValue"] == \
                    preview_after_change["startFromValue"] or \
                    preview['keepAtMostValue'] == preview_after_change['keepAtMostValue'] or \
                    preview['keepUntilValue'] == preview_after_change['keepUntilValue'] or \
                    preview['startStopRecordingValue'] == preview_after_change['startStopRecordingValue']:
                raise AssertionError("One Pass modification failed")
            assert True

    def verify_prediction_ad_launch(self, tester, app):
        self.log.step("Verifying AD launch")
        self.screen.refresh()
        if self.view_mode() == tester.my_shows_labels.LBL_ACTION_SCREEN_VIEW:
            self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
        if self.screen.base.verify_foreground_app(app_name=app):
            raise AssertionError("Prediction app launch failed")
        self.log.info("App launched successfully")

    def verify_body_text_in_category(self, tester, category, body_text):
        """
        Description:
            Going to category and
        :param shortcut: str, index of shortcut
        """
        self.log.step("Verify body text {} in category {}. ".format(body_text, category))
        self.select_my_shows_category(tester, category)
        self.screen.refresh()
        screen_dump = self.screen.screen_dump['xml']
        assert_that(screen_dump['bodytext'], equal_to(body_text))

    def verify_modify_onepass_preview_area(self):
        self.log.step("Verifying Modify OnePass preview area.")
        modify_onepass_items = self.get_modify_onepass_preview_area_items()
        errors = []
        for item in self.my_shows_labels.LBL_MODIFY_ONEPASS_PREVIEW_AREA_ITEMS:
            if item not in modify_onepass_items:
                errors.append(item)
        assert_that(not errors, f"'{errors}' not shown in Modify OnePass preview area.")

    def verify_modified_recording_options(self, preview):
        self.log.step("Verifying modified recording options")
        self.screen.refresh()
        preview_after_change = self.get_preview_panel()
        if preview_after_change is None:
            self.log.error("Preview was empty after modifying options")
            assert False
        if preview['keepUntilValue'] == preview_after_change['keepUntilValue']:
            assert False

    def verify_cached_action_screen(self, program):
        self.screen.refresh()
        screen_title = self.screen_title()
        assert program in screen_title, "Cached Action screen is not reached." \
                                        " Expected '{}' but not found  in {}".format(program, screen_title)

    def verify_preview_message(self, tester, preview):
        self.log.step("Verifying preview message")
        if preview != tester.my_shows_labels.LBL_PREVIEW_ALAP_MESSAGE:
            raise AssertionError("After recording completion, keep option modification failed")

    def navigate_to_live_point_using_keys(self, tester, key, count, time=5):
        if key == 'advance':
            self.log.info("Navigating to the live point with Advance")
            for i in range(count):
                self.screen.base.press_advance()
        elif key == 'fastforward':
            self.log.info("Navigating to the live point with fastforward")
            self.watchvideo_page.press_ff(times=3)
            self.pause(time)
        tester.guide_assertions.verify_play_normal()

    def check_time_different(self, time_diff, actual_time, greater=False, lesser=False, gt=False, lt=False):
        self.log.info("Verifying the time difference")
        # self.log.info("Time Diff : {} & Actual Time : {}".format(time_diff, actual_time))
        if greater:
            if time_diff >= actual_time:
                self.log.info("Current position is greater than equal to paused position.")
            else:
                raise AssertionError("Current position is not greater than actual position.")
        elif lesser:
            if time_diff <= actual_time:
                self.log.info("Current position is lesser than equal to paused position.")
            else:
                raise AssertionError("Current position is not lesser than actual position.")
        elif gt:
            if time_diff < actual_time:
                raise AssertionError("Current position is not greater than actual position.")
        elif lt:
            if time_diff > actual_time:
                raise AssertionError("Current position is not lesser than actual position.")
        else:
            if time_diff != actual_time:
                raise AssertionError("Current position and actual position are not same.")

    def verify_and_playback_the_paused_program(self, tester, program):
        tester.home_page.go_to_my_shows(tester)
        tester.my_shows_page.select_my_shows_category(tester, self.my_shows_labels.LBL_PAUSED)
        tester.my_shows_page.select_menu_by_substring(program[0][0])
        tester.home_page.wait_for_screen_ready()
        tester.home_page.select_strip(self.my_shows_labels.LBL_PLAY)
        tester.watchvideo_assertions.verify_playback_play()

    def verify_focused_episode(self, episode):
        self.wait_for_screen_ready()
        self.screen.refresh()
        assert_that(' '.join(map(str, self.menu_focus())), contains_string(episode))

    def validate_trickplay_tickmark_position(self, pre_min, cur_min, replay=False, advance=False):
        previous_position = pre_min.split(':')
        pre_min = int(previous_position[1])
        current_position = cur_min.split(':')
        cur_min = int(current_position[1])
        if replay:
            self.log.info("Navigate to previous tick_mark with replay button")
            if pre_min > 15:
                if cur_min > 15:
                    raise AssertionError("Video is not moved to 15 minutes tick_mark")
            else:
                if cur_min != 0:
                    raise AssertionError("Video is not moved to 15 minutes tick_mark")
        elif advance:
            self.log.info("Navigate to next tick_mark with advance button")
            if pre_min > 15:
                if cur_min > 15:
                    raise AssertionError("Video is not moved to 15 minutes tick_mark")
            else:
                if cur_min > cur_min:
                    raise AssertionError("Video is not moved to 15 minutes tick_mark")

    def verify_start_over(self, tester, refresh=False):
        value = tester.api.get_catchup_and_startover_name()
        self.log.info(f"get_catchup_and_startover_name values: {value}")
        if value is None:
            value = tester.api.get_catchup_and_startover_name_partnerInfoSearch()
            self.log.info(f"get_catchup_and_startover_name_partnerInfoSearch value: {value}")
        if refresh:
            self.screen.refresh()
        strip_item = self.strip_list()
        self.log.info("Strip item {}".format(strip_item))
        if value[1] not in strip_item:
            raise AssertionError("Start Over option is not present.")

    def verify_show_is_selected(self, tester, program):
        screentitle = tester.guide_page.get_screen_title(refresh=True)
        self.log.info("Screentitle is {}".format(screentitle))
        if screentitle.lower() == program.lower():
            self.log.info("{} is selected successfully".format(program))
        else:
            raise AssertionError("{} is not selected successfully".format(program))

    def verify_content_in_any_category(self, tester, content):
        folder_name = None
        self.log.step("verifying content availablity: {}".format(content))
        self.wait_for_screen_ready()
        categories = [tester.my_shows_labels.LBL_MOVIES, tester.my_shows_labels.LBL_TV_SERIES,
                      tester.my_shows_labels.LBL_ALL_SHOWS]
        try:
            found = False
            content = content
            item_name = None
            for cat in categories:
                self.select_my_shows_category(tester, cat)
                self.screen.refresh()
                s_menu = self.menu_focus()
                if s_menu == cat:
                    self.log.info("{} does not seem to have any programs. selected category is : {}".format(cat, s_menu))
                    unfocussed_menu_list = self.get_unfocused_menu_item()
                    self.log.info("unfocussed menu list: {}".format(unfocussed_menu_list))
                    self.scroll_to_top_my_shows()
                    continue
                self.scroll_to_top_my_shows()
                found, item_name = self.verify_content(content)
                if found:
                    break
            assert found, "{} wasn't found in any my shows category".format(content)
            return item_name, folder_name
        except AssertionError:
            self.select_my_shows_category(tester, self.my_shows_labels.LBL_ALL_SHOWS)
            self.screen.refresh()
            categories = [self.my_shows_labels.LBL_MY_SHOWS_NOT_CURRENTLY_AVAILABLE_FOLDER,
                          self.my_shows_labels.LBL_MY_SHOWS_STREAMING_MOVIES]
            for cat in categories:
                self.log.step("checking {} in {}".format(content, cat))
                self.screen.refresh()
                if self.is_in_menu(cat):
                    self.select_menu(cat)
                    found, item_name = self.verify_content(content)
                    if found:
                        folder_name = cat
                        break
                    self.screen.base.press_back()
                    self.wait_for_screen_ready(self.my_show_labels.LBL_MYSHOWS_SCREEN)
                else:
                    self.log.info("{} folder not available under my shows".format(cat))
            assert found, "{} wasn't found in any my shows category".format(content)
            return item_name, folder_name

    def validate_bookmarked_content_in_myshows(self, tester, content):
        self.log.info(f"Validating bookmarked content : {content}")
        self.select_my_shows_category(tester, self.my_shows_labels.LBL_ALL_SHOWS)
        try:
            self.select_menu(self.my_shows_labels.LBL_MY_SHOWS_STREAMING_MOVIES)
            self.wait_for_screen_ready(self.my_shows_labels.LBL_MY_SHOWS_STREAMING_MOVIES_SCREEN, 30000)
            self.screen.refresh()
            title = self.get_title_from_pane()
            self.log.info("PreviewPane Title is: {}".format(title))
            if title in content:
                self.log.info(
                    "{} is Available in {}".format(content, self.my_shows_labels.LBL_MY_SHOWS_STREAMING_MOVIES))
            else:
                self.log.info("Content {} is not available ".format(content) + "in {}".format(
                    self.my_shows_labels.LBL_MY_SHOWS_STREAMING_MOVIES))
        except Exception as err:
            self.log.info("Movie is not available in Streaming Movies."
                          " Hence checking for movie in Not Currently Available Folder")
            self.log.debug("validate_bookmarked_content_in_myshows> err: {}".format(err))
            try:
                self.select_menu(self.my_shows_labels.LBL_MY_SHOWS_NOT_CURRENTLY_AVAILABLE_FOLDER)
                self.wait_for_screen_ready(self.my_shows_labels.LBL_MY_SHOWS_NOT_CURRENTLY_AVAILABLE_SCREEN, 30000)
                tester.menu_assertions.verify_menu_item_available(content)
                self.log.info("{} is present".format(content) + " in {}".format(
                    self.my_shows_labels.LBL_MY_SHOWS_NOT_CURRENTLY_AVAILABLE_FOLDER))
            except Exception as err:
                self.log.debug("validate_bookmarked_content_in_myshows> retry 3 err {}".format(err))
                assert False, "Movie is not available in Not Currently Available Folder or MyShows"

    def verify_preview_pane_title(self, tester, feed):
        self.screen.refresh()
        title = self.get_title_from_pane()
        title1 = tester.my_shows_page.remove_service_symbols(title)
        final_title = tester.my_shows_page.remove_year_from_title(title1)
        self.log.info("Title from service is {}, Title from UI is {}".format(feed, final_title))
        assert_that(feed, equal_to(final_title))

    def verify_preview_pane_description(self, tester, feed):
        """
        Verifying preview pane description.

        Args:
            feed (str): program description
        """
        self.screen.refresh()
        description = self.get_description_from_pane()
        final_description = tester.my_shows_page.remove_service_symbols(description)
        self.log.info("Description from service is {}, Description from UI is {}".format(feed, final_description))
        assert_that(feed, equal_to(final_description))

    def verify_resume_playing_overlay_not_shown(self):
        self.log.info("Verifying Resume Playing Overlay is not displayed")
        if self.is_overlay_shown():
            raise AssertionError("Resume Playing overlay has displayed")

    def verify_recording_folder_is_visible(self, tester):
        self.log.info("Verifying Recordings folder is present")
        tester.menu_page.menu_navigate_left_right(1, 0)
        self.pause(5)
        self.screen.refresh()
        assert_that(self.is_in_menu(tester.my_shows_labels.LBL_SERIES_RECORDINGS))

    def verify_diskconfig_against_ui(self, clientdiskconfig, diskmeter):
        regex = re.compile('%')
        if clientdiskconfig == "precentage" and (regex.search(diskmeter)):
            assert True, "nDVR space display is in precentage in UI and its as per service configuration"
        elif clientdiskconfig == "time" and not (regex.search(diskmeter)):
            assert True, "nDVR space display is in time format in UI and its as per service configuration"
        else:
            assert False, "nDVR space display in UI is not per service configuration"

    def verify_disk_meter_change(self, diskmeter_before, diskmeter_after, clientdiskconfig, add_recording=False,
                                 delete_recording=False):
        diskmeter_before = int(''.join(re.findall(r'\d', diskmeter_before)))
        diskmeter_after = int(''.join(re.findall(r'\d', diskmeter_after)))
        self.log.info(f"diskmetere before {diskmeter_before} and diskmeter after {diskmeter_after}")
        if clientdiskconfig == "time":
            if len(str(diskmeter_before)) == 2:
                diskmeter_before = int(str(diskmeter_before) + "00")
            if len(str(diskmeter_after)) == 2:
                diskmeter_after = int(str(diskmeter_after) + "00")
            if add_recording:
                if diskmeter_before > diskmeter_after:
                    assert True, f"After scheduling multiple recordings, " \
                                 f"remaining disk space decreased in UI when nDVR space is set as  {clientdiskconfig}"
                else:
                    assert False, f"Disk space not decreased even after " \
                                  f"scheduling multiple recordings when nDVR space is set as  {clientdiskconfig}"
            elif delete_recording:
                if diskmeter_before < diskmeter_after:
                    assert True, f"After deleting recordings in myshows, " \
                                 f"remaining disk space increased in UI when nDVR space is set as  {clientdiskconfig}"
                else:
                    assert False, f"Disk space not increased even after " \
                                  f"deleting recordings in myshows nDVR space is set as  {clientdiskconfig}"
            else:
                self.log.info("No parameter set to verify")
        else:
            if add_recording:
                if diskmeter_before < diskmeter_after:
                    assert True, f"After scheduling multiple recordings, " \
                                 f"remaining disk space increased in UI when nDVR space is set as  {clientdiskconfig}"
                else:
                    assert False, f"Disk space not increased even after " \
                                  f"scheduling multiple recordings when nDVR space is set as  {clientdiskconfig}"
            elif delete_recording:
                if diskmeter_before > diskmeter_after:
                    assert True, f"After deleting recordings in myshows, " \
                                 f"remaining disk space decreased in UI when nDVR space is set as  {clientdiskconfig}"
                else:
                    assert False, f"Disk space not decreased even after " \
                                  f"deleting recordings in myshows nDVR space is set as  {clientdiskconfig}"
            else:
                self.log.info("No parameter set to verify")

    def verify_sorted_shows_by_name(self, tester, name_of_recordings):
        """
        Compares manually sorted and screen dump show names
        :return:
        """
        shows_ui = []
        compare_shows_ui = []
        tester.home_page.go_to_my_shows(tester)
        tester.my_shows_page.select_my_shows_category(tester, tester.my_shows_labels.LBL_SERIES_RECORDINGS)
        for i in range(3):
            shows_ui.append(tester.screen.get_screen_dump_item('menuitem')[i]['text'])
        for i in range(3):
            compare_shows_ui.append(shows_ui[i][0])
        assert_that(name_of_recordings, equal_to(compare_shows_ui))

    def verify_filter_available_in_myshows_screen(self, filter_to_check):
        self.menu_navigate_left_right(1, 0)
        self.screen.refresh()
        menu_list = self.menu_list()
        self.log.info("My Shows Content Filter Availablility Validation: Expected: {}".format(filter_to_check))
        assert_that(menu_list, has_item(filter_to_check))

    def get_difference_between_two_timestamps(self, time1, time2, in_sec=True):
        """
        Timestamp format should be in %I:%M %p
        example: "3:00AM"
        """
        self.log.info(f"Calculating time difference between {time1} and {time2}")
        time_obj1 = datetime.strptime(time1, "%I:%M%p")
        time_obj2 = datetime.strptime(time2, "%I:%M%p")

        time1_mins = time_obj1.hour * 60 + time_obj1.minute
        time2_mins = time_obj2.hour * 60 + time_obj2.minute
        time_diff_in_min = (time2_mins + 24 * 60 - time1_mins) % (24 * 60)
        self.log.info(f"time difference between {time1} and {time2}: {time_diff_in_min}")
        if in_sec:
            return time_diff_in_min * 60
        else:
            return time_diff_in_min

    def get_padding_for_ICM_channel(self, showtime, timeinfo, padding_in_sec):
        self.log.info("Getting padding for ICM channels.")
        show_end_time = showtime[1][0] + showtime[1][1]
        time_diff = self.get_difference_between_two_timestamps(timeinfo, show_end_time)
        actual_padding = padding_in_sec + time_diff
        return actual_padding

    def get_padding_for_CCM_channel(self, showtime, padding_in_sec):
        self.log.info("Getting padding for CCM channels.")
        start_time = showtime[0][0] + showtime[0][1]
        end_time = showtime[1][0] + showtime[1][1]
        time_diff = self.get_difference_between_two_timestamps(start_time, end_time)
        actual_padding = padding_in_sec + time_diff
        return actual_padding

    def get_trickplay_padding(self):
        self.log.info("Getting trickplay padding.")
        dump = self.screen.get_screen_dump_item()
        if dump.get("recordingTrickplay"):
            if dump.get("recordingTrickplay").get("recordingDuration"):
                padding = dump.get("recordingTrickplay").get("recordingDuration")
            else:
                raise AssertionError("Trickplay padding is not present. looks like product bug")
        else:
            raise AssertionError("Trickplay padding is not present. looks like product bug")
        return padding

    def get_duration_for_given_program(self, program, myShowsItemSearch):
        self.log.info("Getting duration for {} in {}".format(program, myShowsItemSearch))
        for obj in myShowsItemSearch:
            if not isinstance(obj, dict):
                show = obj.__dict__
                if show.get("_BaseEntity__dict_item").get('title') in program:
                    return show.get("_BaseEntity__dict_item").get('duration')

    def verify_padding_from_myShowItemSearch(self, tester, program, myShowsItemSearch):
        padding = self.get_trickplay_padding()
        self.log.info(f"Trickplay padding: {padding}")
        if 'h' in padding and 'm' in padding:
            padding = padding.replace(' ', '').replace('h', ':').replace('m', ':00')
        if 'min' in padding:
            padding = f"00:{padding.replace(' min', ':00')}"
        if 'h' in padding:
            if 'hr' in padding:
                padding = padding.replace(' hr', ':00:00')
            else:
                padding = padding.replace(' h', ':00:00')
        trickplay_padding = tester.my_shows_page.get_timein_seconds(padding)
        self.log.info(f"Trickplay padding after converting it to seconds: {trickplay_padding}")
        actual_padding = self.get_duration_for_given_program(program, myShowsItemSearch)
        res = actual_padding - trickplay_padding
        self.log.info(f"Padding result: {res}")
        if not (-60 <= res <= 60):
            raise AssertionError(f"Padding is not matching: calculated padding {actual_padding} != {trickplay_padding}")

    def verify_padding(self, tester, ch_state, showtime, timeinfo, start_padding=0, stop_padding=0):
        self.log.info(f"Verifying padding for {ch_state}, showtime:{showtime} timeinfo:{timeinfo} stop_padding:{stop_padding}")
        self.screen.refresh()
        padding = self.get_trickplay_padding()
        self.log.info(f"Trickplay padding: {padding}")
        user_padding = start_padding + stop_padding
        padding_in_sec = tester.my_shows_page.get_timein_seconds(f'00:{user_padding}:00')
        if ch_state == "icm":
            actual_padding = self.get_padding_for_ICM_channel(showtime, timeinfo, padding_in_sec)
        if ch_state == "ccm":
            actual_padding = self.get_padding_for_CCM_channel(showtime, padding_in_sec)
        if 'h' in padding and 'm' in padding:
            padding = padding.replace(' ', '').replace('h', ':').replace('m', ':00')
        if 'min' in padding:
            padding = f"00:{padding.replace(' min', ':00')}"
        if 'h' in padding:
            if 'hr' in padding:
                padding = padding.replace(' hr', ':00:00')
            else:
                padding = padding.replace(' h', ':00:00')
        trickplay_padding = tester.my_shows_page.get_timein_seconds(padding)
        res = actual_padding - trickplay_padding
        if not (res == 0 or res == 60 or res == -60):
            raise AssertionError(f"Padding is not matching: calculated padding {actual_padding} != {trickplay_padding}")

    def verify_sorted_shows_by_date(self, tester, recording_date):
        """
        Compares ui show date's and screen dump my shows recordings date's
        :return:
        """
        expected_date = []
        actual_date = []
        swap = 0
        recording_date[0] = recording_date[0].split()
        recording_date[0][0] = recording_date[0][0].split("-")
        expected_date.append(recording_date[0][0][2])
        expected_date.append(0)
        swap = (int(expected_date[0]) + 1)
        expected_date[1] = str(swap)
        swap = int(expected_date[0])
        expected_date[0] = str(swap)
        actual_date = tester.my_shows_page.get_my_shows_recordings_date_ui(tester, no_of_recordings=2)
        expected_date[0], expected_date[1] = expected_date[1], expected_date[0]
        assert_that(expected_date, equal_to(actual_date))

    def verify_filter_has_focus(self, filter_name):
        """
        Verify highlight is on expected filter in My Shows.
        """
        menu = self.get_menu_item_array()
        focused_item_raw = self.get_focused_item(menu)
        focused_item_values = focused_item_raw.values()
        assert_that(str(focused_item_values), contains_string(filter_name))

    def verify_upcoming_socu_playback_icon_displayed_by_api(self):
        """
        This method verifies that catchup icon is on highlighted program
        """
        self.log.info("Verifying that catchup icon is on highlighted program.")
        is_socu_playback_icon_displayed = self.is_socu_playback_on_upcoming_by_api()
        assert_that(is_socu_playback_icon_displayed, "Socu icon is not displayed as expected")

    def verify_substring_string_not_in_string(self, substring, string_raw):
        assert_that(string_raw, not_(contains_string(substring)))

    def verify_my_show_upcoming_title(self, show_title, mode="seriesScreenUpcoming"):
        """
        Verifying show title on series screen

        Args:
            show_title (str): program title
            mode (str): seriesScreenUpcoming
        """
        self.log.info(f"Verifying show title '{show_title}'; mode {mode}")
        screen_dump = self.screen.get_json()
        show_title_no_sys_symbols = self.remove_service_symbols(show_title)
        program_name = None
        if mode == "seriesScreenUpcoming":
            program_name = self.remove_service_symbols(self.screen.get_screen_dump_item("previewPane", "title"))
        else:
            raise ValueError(f"Not supported mode - {mode}")
        is_contained = True if show_title_no_sys_symbols in program_name else False
        assert_that(is_contained,
                    f"Show title does not match; current: {program_name}; expected: {show_title_no_sys_symbols}; "
                    f"screen_dump:\n\n{screen_dump}")
