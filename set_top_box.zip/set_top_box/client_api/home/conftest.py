import os
import shutil
import yaml
from inspect import isclass

import pytest

from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.my_shows.assertions import MyShowsAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.client_api.Menu.conftest import disable_parental_controls  # noqa: F401
from set_top_box.client_api.guide.assertions import GuideAssertions
from set_top_box.client_api.VOD.assertions import VODAssertions
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.client_api.apps_and_games.assertions import AppsAndGamesAssertions
from set_top_box.client_api.provisioning.assertions import ProvisioningAssertions
from set_top_box.client_api.home.labels_loki import Loki_HomeLabels
from set_top_box.client_api.api_integration.assertions import APIAssertions
from set_top_box.conf_constants import HydraBranches, NotificationSendReqTypes, RemoteCommands
from set_top_box.client_api.wtw.assertions import WhatToWatchAssertions
from set_top_box.client_api.program_options.assertions import ProgramOptionsAssertions
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from set_top_box.test_settings import Settings
from core_api.stb.base import StreamerBase
from tools.logger.logger import Logger
from set_top_box.conftest import get_actual_tsn

__log = Logger(__name__)
signin_code = []


@pytest.fixture(autouse=True, scope="class")
def setup_home(request):
    """
    Configure steps to be executed before the test cases run
    :param request:
    :return:
    """
    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_labels = request.cls.home_page.home_labels = LabelFactory("home", Settings)
    request.cls.home_assertions = HomeAssertions(request.cls.screen)
    request.cls.home_assertions.home_labels = request.cls.home_labels
    request.cls.home_assertions.home_page = request.cls.home_page

    request.cls.loki_labels = Loki_HomeLabels()

    request.cls.api_assertions = APIAssertions(request.cls.screen)

    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)
    request.cls.menu_labels = request.cls.menu_page.menu_labels = LabelFactory("Menu", Settings)
    request.cls.menu_page.menu_labels = request.cls.menu_labels

    request.cls.my_shows_labels = LabelFactory("my_shows", Settings)
    request.cls.my_shows_page = PageFactory("my_shows", Settings, request.cls.screen)
    request.cls.home_page.my_shows_page = request.cls.my_shows_page
    request.cls.my_shows_assertions = MyShowsAssertions(request.cls.screen)

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_page.guide_labels = request.cls.guide_labels
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)
    request.cls.guide_assertions.guide_labels = request.cls.guide_labels
    request.cls.home_page.guide_page = request.cls.guide_page

    request.cls.vod_assertions = VODAssertions(request.cls.screen)
    request.cls.vod_page = PageFactory("VOD", Settings, request.cls.screen)
    request.cls.vod_labels = LabelFactory("VOD", Settings)

    request.cls.wtw_page = PageFactory("wtw", Settings, request.cls.screen)
    request.cls.wtw_assertions = WhatToWatchAssertions(request.cls.screen)
    request.cls.wtw_page.labels = request.cls.wtw_labels = LabelFactory("wtw", Settings)

    request.cls.watchvideo_assertions = WatchVideoAssertions(request.cls.screen)

    request.cls.text_search_page = PageFactory("text_search", Settings, request.cls.screen)

    request.cls.watchvideo_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.watchvideo_labels = request.cls.liveTv_labels = LabelFactory("watchvideo", Settings)

    request.cls.apps_and_games_labels = LabelFactory("apps_and_games", Settings)
    request.cls.apps_and_games_assertions = AppsAndGamesAssertions(request.cls.screen)
    request.cls.apps_and_games_page = PageFactory("apps_and_games", Settings, request.cls.screen)

    request.cls.program_options_assertions = ProgramOptionsAssertions(request.cls.screen)
    request.cls.program_options_page = PageFactory("program_options", Settings, request.cls.screen)
    request.cls.program_options_labels = LabelFactory("program_options", Settings)

    request.cls.system_page = PageFactory("system", Settings, request.cls.screen)
    request.cls.system_labels = LabelFactory("system", Settings)
    request.cls.system_page.system_labels = request.cls.system_labels
    request.cls.home_page.system_labels = request.cls.system_labels

    request.cls.acc_locked_labels = LabelFactory("account_locked", Settings)
    request.cls.acc_locked_page = PageFactory("account_locked", Settings, request.cls.screen)
    request.cls.acc_locked_page.acc_locked_labels = request.cls.acc_locked_labels

    request.cls.provisioning_page = PageFactory("provisioning", Settings, request.cls.screen)
    request.cls.provisioning_labels = request.cls.provisioning_page.provisioning_labels = LabelFactory("provisioning",
                                                                                                       Settings)
    request.cls.provisioning_page.provisoning_labels = request.cls.home_labels
    request.cls.provisioning_assertions = ProvisioningAssertions(request.cls.screen)

    request.getfixturevalue('device_reboot_to_imporve_device_perf')
    request.getfixturevalue('clean_ftux_and_sign_in')
    request.getfixturevalue('disable_parental_controls')


@pytest.fixture(autouse=False, scope="function")
def relaunch_hydra_app(request):
    def tear_down():
        __log.info("Tearing down.")
        request.cls.home_page.relaunch_hydra_app()
        request.cls.home_page.back_to_home_short()

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def back_to_home(request):
    def tear_down():
        __log.info("Tearing down.Navigating to home screen")
        request.cls.home_page.back_to_home_short()

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False)
def reset_tivo_eula_consent_status(request):
    """
    To set user consent status DISAGREED before test and to AGREED after it.
    These changes are needed to show TiVo User Agreement screen after sign in on unmanaged devices.
    """
    __log.info("Setting user consent status to DISAGREED.")
    gkey = Settings.tivo_eula_group_key
    request.cls.eula_api.set_user_consent_status(Settings.tsn, gkey, status=False)
    if request.cls.home_page.clear_data().strip() != "Success":
        pytest.skip("Skipping due to failing of clearing data")
    request.cls.screen.base.grant_app_permissions()
    request.cls.home_page.relaunch_hydra_app()
    if Settings.is_unmanaged():
        request.cls.home_page.sign_in()
    request.cls.home_page.wait_for_screen_ready(request.cls.home_labels.LBL_FTUX_EULA, timeout=30000)
    request.cls.screen.refresh()
    yield
    __log.info("Setting user consent status to AGREED.")
    request.cls.eula_api.set_user_consent_status(Settings.tsn, gkey, status=True)
    request.cls.home_page.relaunch_hydra_app()


@pytest.fixture(autouse=False, scope="function")
def cleanup_ftux(request):
    def tear_down():
        __log.info("Tear down initiated")
        request.cls.home_page.skip_ftux()

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def set_bridge_status_up(request):
    def tear_down():
        __log.info("Tearing down")
        request.cls.home_page.manage_network_change(request.cls.home_labels.LBL_SET_BRIDGE_UP)
        attempts = 0
        while attempts < 3:
            request.cls.guide_page.clear_data()
            request.cls.home_page.clear_cache_launch_hydra_app()
            request.cls.home_page.back_to_home_short()
            request.cls.home_page.nav_to_predictions_strip()
            if request.cls.home_page.check_predictions():
                return
            attempts += 1

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False)
def decrease_screen_saver(request):
    """
    Reduce screen saver timeout to 30 seconds,
    afterwards return it default value
    """
    request.cls.driver.driver.set_screen_saver_timeout(30000)
    yield
    request.cls.driver.driver.set_screen_saver_timeout()


@pytest.fixture(autouse=False)
def enable_disable_stay_awake(request):
    """
    fixture to disable/enable stay awake option from 'Developer Options'
    """
    request.cls.driver.driver.enable_disable_stay_awake(turn='false')


@pytest.fixture(autouse=False)
def enable_stay_awake(request):
    """
    fixture to enable stay awake option from 'Developer Options'
    """
    request.cls.driver.driver.enable_disable_stay_awake()


@pytest.fixture(autouse=False, scope="function")
def cleanup_EAS(request):
    def tear_down():
        __log.info("Tearing down")
        attempts = 0
        while attempts <= 5:
            request.cls.home_page.press_back_button(refresh=True)
            request.cls.screen.wait_for_screen_ready()
            if request.cls.home_page.screen_title() == request.cls.home_labels.LBL_HOME_SCREENTITLE:
                __log.info("Reached Home Screen")
                break
            attempts += 1

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def enable_canadian_eas_by_override(request):
    """
    fixture to enable Candian EAS for internal MSO (by default Canadian EAS is supported only by Telus MSO)
    """
    request.cls.home_page.update_test_conf_and_reboot(EAS_MODE_OVERRIDE="CANADA")


@pytest.fixture(autouse=False, scope="function")
def enable_floating_eas_by_override(request):
    """
    fixture to enable Floating EAS for internal MSO (by default Floating EAS is supported only by Millicom)
    """
    request.cls.home_page.update_test_conf_and_reboot(EAS_MODE_OVERRIDE="FLOATING")


@pytest.fixture(autouse=False, scope="function")
def reset_language_code_to_en_us(request):
    def tear_down():
        if request.cls.system_page.change_language(user_language_code="en-US", user_action="down"):
            __log.info("Language change is successful while navigate to down ")
        else:
            if request.cls.system_page.change_language(user_language_code="en-US", user_action="up"):
                __log.info("Language change is successful while navigate to up ")
            else:
                __log.info("Language change is failed due to known language code")
                raise Exception("Language change is failed due to known language code")
        request.cls.home_page.press_back_button(refresh=False)
        request.cls.home_page.press_ok_button(refresh=False)
        request.cls.home_page.handling_hydra_app_after_exit(Settings.app_package, is_wait_home=True)

    request.addfinalizer(tear_down)


def change_language(request, locale):
    is_language_changed = False
    if request.cls.system_page.change_language(user_language_code=locale, user_action="down"):
        __log.info(" {} Language change is successful while navigate to down ".format(locale))
        is_language_changed = True
    else:
        if request.cls.system_page.change_language(user_language_code=locale, user_action="up"):
            __log.info("{} Language change is successful while navigate to up ".format(locale))
            is_language_changed = True
        else:
            __log.info("{} Language change is failed due to known language code".format(locale))
            raise Exception("Language change is failed due to known language code")

    request.cls.home_page.press_back_button(refresh=False)
    request.cls.home_page.press_ok_button(refresh=False)
    return is_language_changed


@pytest.fixture(autouse=False, scope="function")
def language_changed_supported_locale_spanish(request):
    return change_language(request=request, locale="es-US")


@pytest.fixture(autouse=False, scope="function")
def language_changed_unsupported_locale_filipino(request):
    return change_language(request=request, locale="fil-PH")


@pytest.fixture(autouse=False, scope="function")
def setup_bridge_status_up(request):
    def setup():
        __log.info("Setup")
        request.cls.home_page.manage_network_change(request.cls.home_labels.LBL_SET_BRIDGE_UP)

    setup()


@pytest.fixture(scope='function')
def clear_client_cache(request):
    """
    Fixture used in purpose of rebooting the box or restarting the app dependent on env variable.
    """
    clearing = os.getenv("CLEAR_CLIENT_CACHE", None)
    if clearing and clearing.lower() == 'reboot_box':
        __log.warning(f"ClientPerf: Going to reboot box and relaunch hydra. ({clearing})")
        request.cls.home_page.relaunch_hydra_app(reboot=True)
    elif clearing and clearing.lower() == 'restart_app':
        __log.warning(f"ClientPerf: Going to clear cache and relaunch hydra. ({clearing})")
        request.cls.home_page.clear_cache_launch_hydra_app()


@pytest.fixture(autouse=False, scope="function")
def rebind_hsn(request):
    def tear_down():
        __log.info("Tearing down")
        pcid = request.cls.home_labels.LBL_PCID
        if not pcid:
            pcid = request.cls.service_api.getPartnerCustomerId()
        request.cls.iptv_prov_api.bind_hsn(Settings.hsn, request.cls.service_api.get_mso_partner_id(Settings.tsn),
                                           pcid)
        request.cls.home_page.clear_cache_launch_hydra_app()
        request.cls.home_assertions.verify_screen_title(request.cls.home_labels.LBL_HOME_SCREENTITLE)

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def cleanup_package_names_native(request, feature, package_type):
    """
    Cleaning up packages depending on initial package state, if it was present or absent.
    @pytest.mark.parametrize("feature", value) and
    @pytest.mark.parametrize("package_type", value) and
    request.config.cache.set("feature_state", feature_state) and
    request.config.cache.set("initial_pkg_name", feature_state) (only if there's some package)
    should be set before calling this fixture
    """

    def tear_down():
        __log.info(f"Tearing down. Returning initial package for '{feature}'")
        feature_state = request.config.cache.get("feature_state", None)
        initial_pkg_name = request.config.cache.get("initial_pkg_name", None)
        __log.debug(f"initial_pkg_name = {initial_pkg_name}, feature_state = {feature_state}")
        if feature is None:
            raise AttributeError("feature param wasn't set, or some requests failed")
        if initial_pkg_name:
            mso_name = request.cls.iptv_prov_api.get_fe_operator_name()
            init_package_t = \
                initial_pkg_name.replace(mso_name, "").replace("Staging", "").replace(feature, "").replace("-", "") \
                .replace("USQE1", "")
            # Resetting values to not interfere with other tests in case when there's non-default initial package
            request.config.cache.set("feature_state", None)
            request.config.cache.set("initial_pkg_name", None)
            if init_package_t != package_type:
                request.cls.home_page.update_drm_package_names_native(feature, package_type, False)
            else:
                __log.info(f"'{package_type}-{feature}' package already is present, no need to add it")
                return
            request.cls.home_page.update_drm_package_names_native(feature, init_package_t, feature_state)
            request.cls.home_assertions.verify_drm_package_names_native(feature, init_package_t, feature_state)
        else:
            # Resetting values to not interfere with other tests in case when initial package is set to default
            request.config.cache.set("feature_state", None)
            request.config.cache.set("initial_pkg_name", None)
            if feature_state is None:
                # E.g. when test failed before calling preserve_initial_package_state
                __log.warning(
                    "initial_pkg_name and feature_state are not set, skipping resetting the package to default")
                return
            else:
                # means that feature was set to default package
                if request.cls.iptv_prov_api.verify_package_name_fe_alacarte(feature, package_type, True):
                    request.cls.home_page.update_drm_package_names_native(feature, package_type, False)

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def preserve_initial_package_state(request, feature, package_type):
    """
    Saving DRM package state, if it's present or absent.
    @pytest.mark.parametrize("feature", value) and
    @pytest.mark.parametrize("package_type", value)
    should be set before calling this fixture
    """
    __log.info(f"Preserving {feature} DRM package initial state, if enabled/disabled")
    if feature is None or package_type is None:
        raise AttributeError("feature or package_type param wasn't set, or some requests failed")
    feature_state = None
    pkgs = request.cls.iptv_prov_api.fe_alacarte_get_package_native_drm()
    if "error" in pkgs["type"]:
        raise AssertionError(f"Failed to retrieve DRM packages with {pkgs}")
    full_name = None
    other_full_name = None
    if "deviceAlaCartePackage" in pkgs:
        for p_name in pkgs["deviceAlaCartePackage"]:
            if (package_type + "-" + feature) in p_name:
                full_name = p_name  # feature is enabled under passed package_type
            elif feature in p_name:
                other_full_name = p_name  # feature is enabled under different package_type
    if other_full_name or full_name:
        feature_state = True
    elif not other_full_name and not full_name:
        feature_state = False
    request.config.cache.set("feature_state", feature_state)
    request.config.cache.set("initial_pkg_name", full_name or other_full_name)
    __log.info(
        f"Initial package name: {request.config.cache.get('initial_pkg_name', None)}; feature_state: {feature_state}")


@pytest.fixture(autouse=False, scope="function")
def remove_packages_if_present_before_test(request, feature, package_type):
    """
    Removes initial package, if it's present.
    @pytest.mark.parametrize("feature", value) and
    @pytest.mark.parametrize("package_type", value) and
    request.config.cache.set("feature_state", feature_state) and
    request.config.cache.set("initial_pkg_name", feature_state) (only if there's some package)
    should be set before calling this fixture
    """
    feature_state = request.config.cache.get("feature_state", None)
    initial_pkg_name = request.config.cache.get("initial_pkg_name", None)
    __log.info(f"Removing {feature} DRM package before starting the test, if enabled, pkgs enabled = {feature_state}")
    if feature is None or feature_state is None:
        raise AttributeError("Either feature or feature_state param wasn't set, or some requests failed")
    if feature_state:
        mso_name = request.cls.iptv_prov_api.get_fe_operator_name()
        init_package_t = initial_pkg_name.replace(mso_name, "").replace("Staging", "").replace(feature, "").replace("-",
                                                                                                                    "") \
            .replace("USQE1", "") \
            if initial_pkg_name else None
        request.cls.home_page.update_drm_package_names_native(feature, init_package_t, False)
        request.cls.home_assertions.verify_drm_package_names_native(feature, init_package_t, False)


@pytest.fixture(autouse=False, scope="function")
def setup_enable_notification_access(request):
    """
    To have Android Notifications, Notification access should be enabled for the Hydra app.
    Android Notifications are available in the Hydra app only for managed boxes
    """
    __log.info("Enabling notification access for the Hydra app")
    if Settings.is_managed():
        request.cls.system_page.launch_device_settings_screen()
        request.cls.system_page.select_device_settings_menu_item(request.cls.system_labels.LBL_APPS,
                                                                 request.cls.system_labels.LBL_SPECIAL_APP_ACCESS,
                                                                 request.cls.system_labels.LBL_NOTIFICATION_ACCESS)
        request.cls.system_page.toggle_device_settings_option(request.cls.system_labels.LBL_HYDRA_APP_NAME)
        request.cls.system_page.go_back_to_main_device_settings_screen()
    else:
        __log.info(f"Skipping enabling notification access, {Settings.platform} is not a managed box")


@pytest.fixture(autouse=False, scope="function")
def setup_disable_notification_access(request):
    """
    To have Android Notifications, Notification access should be enabled for the Hydra app.
    Android Notifications are available in the Hydra app only for managed boxes
    """
    __log.info("Disabing notification access for the Hydra app")
    if Settings.is_managed():
        request.cls.system_page.launch_device_settings_screen()
        request.cls.system_page.select_device_settings_menu_item(request.cls.system_labels.LBL_APPS,
                                                                 request.cls.system_labels.LBL_SPECIAL_APP_ACCESS,
                                                                 request.cls.system_labels.LBL_NOTIFICATION_ACCESS)
        request.cls.system_page.toggle_device_settings_option(request.cls.system_labels.LBL_HYDRA_APP_NAME, False)
        request.cls.system_page.go_back_to_main_device_settings_screen()
    else:
        __log.info(f"Skipping enabling notification access, {Settings.platform} is not a managed box")


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_add_google_account(request):
    """
    Adding a Google account if it's not set
    Params:
        request.config.cache.get("is_reboot_needed", False), True - box reboot is needed after tearing down
    """

    def setup():
        __log.info("Setting up test Google account...")
        request.cls.system_page.launch_device_settings_screen()
        if request.cls.system_page.is_google_account_present():
            __log.info("Skipping adding Google account since it's already added")
        else:
            __log.info("Didn't find any Google account, adding one")
            request.cls.system_page.signin_google_account(Settings.google_account, Settings.google_password)
            request.cls.home_page.back_to_home_short()

    setup()

    def tear_down():
        __log.info("Tearing down.")
        is_reboot_needed = request.config.cache.get("is_reboot_needed", False)
        setup()
        if is_reboot_needed:
            # Workaround due to https://jira.xperi.com/browse/IPTV-24494
            request.cls.home_page.relaunch_hydra_app(reboot=True)

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def ndvr_health_store(request):
    """
    ndvr health store
    """

    def tear_down():
        __log.step("ndvr channel Store tear down")
        try:
            channel = request.cls.service_api.cached_channel_info(None, mode="ndvr", use_cached_response=True)
            __log.info("channel: {} type:{}".format(channel, type(channel)))
            channel_number_index = 0
            channel_name_index = 1
            health_index = 2
            error_code_index = 3
            program_name_index = 4
            program_start_time_index = 5
            record_status_index = 6
            __log.info("index set to variables")

            request.config.option.channel_number = str(channel[channel_number_index])
            request.config.option.channel_name = str(channel[channel_name_index])
            request.config.option.health = str(channel[health_index]).lower()
            request.config.option.error_code = str(channel[error_code_index])
            request.config.option.program_name = str(channel[program_name_index])
            request.config.option.program_start_time = str(channel[program_start_time_index])
            request.config.option.record_status = str(channel[record_status_index])
            # request.cls.guide_assertions.verify_channel_store_response(status)
            status = request.cls.health_api.db_store(channel, ndvr=True)
            request.config.option.ndvr_store_resp = str(status)
            if not status:
                __log.warning("Failed to store channel details to DB")
            __log.info("db store status: {}".format(status))
        except Exception as Err:
            raise AssertionError("Issue observed while storing channel: {}".format(Err))
        request.cls.service_api.delete_all_subscriptions()
        request.cls.service_api.delete_recordings_from_myshows()
    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def socu_health_store(request):
    """
    socu health store
    """

    def tear_down():
        __log.step("Socu channel Store tear down")
        try:
            channel = request.cls.service_api.cached_channel_info(None, mode="socu", use_cached_response=True)
            __log.info("channel: {} type:{}".format(channel, type(channel)))
            channel_number_index = 0
            channel_name_index = 1
            st_enabled_index = 2
            startover_pgm_index = 3
            startover_health_status_index = 4
            startover_pgm_error_code_index = 5
            cu_enabled_index = 6
            catchup_pgm_index = 7
            catchup_health_status_index = 8
            catchup_pgm_error_code_index = 9
            __log.info("index set to variables")
            request.config.option.channel_number = str(channel[channel_number_index])
            request.config.option.channel_name = str(channel[channel_name_index])
            request.config.option.st_enabled = str(channel[st_enabled_index])
            request.config.option.startover_pgm = str(channel[startover_pgm_index])
            request.config.option.startover_health_status = str(channel[startover_health_status_index])
            request.config.option.startover_pgm_error_code = str(channel[startover_pgm_error_code_index])
            request.config.option.cu_enabled = str(channel[cu_enabled_index])
            request.config.option.catchup_pgm = str(channel[catchup_pgm_index])
            request.config.option.catchup_health_status = str(channel[catchup_health_status_index])
            request.config.option.catchup_pgm_error_code = str(channel[catchup_pgm_error_code_index])
            status = request.cls.health_api.db_store(channel, socu=True)
            request.config.option.socu_store_resp = str(status)
            if not status:
                __log.warning("Failed to store channel details to DB")
            # request.cls.guide_assertions.verify_channel_store_response(status)
            __log.info("db store status: {}".format(status))
        except Exception as Err:
            raise AssertionError("Issue observed while storing channel: {}".format(Err))

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_return_initial_feature_state(request, req_type, feature_status_feature, device_info_store_feature):
    """
    If feature is enabled before running the test - this method turns on the feature.
    If feature is disabled before running the test - this method turns off the feature.
    Next params should be set before using this fixture:
     - @pytest.mark.parametrize("device_info_store_feature", DeviceInfoStoreFeatures.feature)
     - @pytest.mark.parametrize("feature_status_feature", FeaturesList.feature)
     - @pytest.mark.parametrize("req_type", one of (NotificationSendReqTypes.FCM, NotificationSendReqTypes.NSR))
     - request.config.cache.get("is_relaunch_needed", deafult_val)
     - request.config.cache.get("feature_in_feature_status", None)

    Args:
        request (fixture): pytest fixture
        device_info_store_feature(str): represents feature name from deviceInfoStore request
    """

    def setup():
        __log.info(f"Preserving initial '{feature_status_feature}' feature state from featureStatusSearch")
        if not device_info_store_feature:
            raise AssertionError("'device_info_store_feature' param is not set")
        if not feature_status_feature:
            raise AssertionError("'feature_status_feature' param is not set")
        # Skip conditions
        request.cls.home_page.validate_fcm_nsr_mts_req_usage(req_type, RemoteCommands.FEATURE_STATUS, True)
        feature_in_feature_status = request.cls.service_api.get_feature_status(feature_status_feature)
        # Handling case when featureStatusSearch request failed to avoid turning off the feature, it may be on in this case
        if feature_in_feature_status is None:
            request.config.cache.set("feature_in_feature_status", None)
            raise Exception(f"Either '{feature_status_feature}' feature was not found in "
                            "the feature status list or featureStatusSearch request failed")
        request.config.cache.set("feature_in_feature_status", feature_in_feature_status)

    def tear_down():
        __log.info("Tearing down. Return initial feature state")
        # Fast feature status update through FCM is enabled since Hydra 1.15 for Managed boxes.
        # Fast feature status update through NSR is enabled since Hydra 1.16 for Managed and Unmanged boxes.
        relaunch_default_val = not request.cls.home_page.validate_fcm_nsr_mts_req_usage(
            req_type=req_type, p_type=RemoteCommands.FEATURE_STATUS, is_skip=None)
        is_relaunch_needed = request.config.cache.get("is_relaunch_needed", relaunch_default_val)
        turn_on = request.config.cache.get("feature_in_feature_status", None)
        if turn_on is not None:
            request.cls.iptv_prov_api.device_info_store(
                request.cls.service_api.getPartnerCustomerId(Settings.tsn),
                request.cls.service_api.get_mso_partner_id(Settings.tsn),
                request.cls.service_api.get_device_type(),
                request.cls.service_api.fe_device_mso_service_id_get()["msoServiceId"],
                device_info_store_feature, turn_on)
            if is_relaunch_needed:
                # Feature status change can be applied after app restart for older Hydra versions like 1.13 and lower
                request.cls.guide_page.relaunch_hydra_app()
            else:
                request.cls.home_page.send_fcm_or_nsr_notification(req_type=req_type,
                                                                   payload_type=RemoteCommands.FEATURE_STATUS)
        else:
            __log.info(f"Skipping tearing down since {device_info_store_feature} feature state is not set")
        # Let's reset the cross test variable to avoid affecting other tests
        request.config.cache.set("is_relaunch_needed", None)

    setattr(Settings, "tsn", get_actual_tsn())
    setup()
    yield
    tear_down()


def get_loki_labels(feature="home"):
    labels = []
    if Settings.localization:
        loki_file_name = "labels_loki"
        utaf_path = os.path.abspath(__file__).partition("set_top_box")[0]
        label_file_path = os.path.join(utaf_path, f"set_top_box/client_api/{feature}/{loki_file_name}")
        rel_file_path = (os.path.relpath(label_file_path, utaf_path).replace('/', '.'))
        module_name = __import__(rel_file_path, fromlist=[None])
        class_name = [x for x in dir(module_name) if isclass(getattr(module_name, x)) and feature.lower() in x.lower()]
        obj_name = getattr(module_name, class_name[0])
        obj_ref = obj_name()
        labels = [attr for attr in dir(obj_ref) if attr.startswith("LBL")]
    return labels


@pytest.fixture(params=get_loki_labels("home"), autouse=False, scope="module")
def loki_home_label(request):
    return request.param


@pytest.fixture(autouse=False, scope="function")
def setup_disable_stay_awake(request):
    """
    Turn off stay awake from android settings
    """
    request.cls.driver.driver.disable_stay_awake()


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_remove_all_messages_from_client(request):
    """
    Removing all messages on the client using service API.
    Add list of message IDs to remove to request.config.cache.set("message_ids", None) before this fixture,
    if you need messages to be removed on the service
    """

    def tear_down():
        request.cls.home_page.validate_fcm_nsr_mts_req_usage(NotificationSendReqTypes.MTS,
                                                             RemoteCommands.REMOVE_ALL_MESSAGES, True)
        message_ids = request.config.cache.get("message_ids", None)
        if message_ids:
            # Setting message_ids to None to not affect other tests
            request.config.cache.set("message_ids", None)
            # Removing messaging in service
            for i in message_ids:
                request.cls.iptv_prov_api.mts_message_remove(message_id=i)
        message_data = [request.cls.iptv_prov_api.get_message_data(payload_type=RemoteCommands.REMOVE_ALL_MESSAGES)]
        message = request.cls.iptv_prov_api.mts_message_store(request.cls.service_api.get_mso_partner_id(Settings.tsn),
                                                              [Settings.hsn],
                                                              message_data=message_data)
        request.cls.iptv_prov_api.mts_message_state_update(message_id=message["messageId"])
        request.cls.home_page.pause(5, f"Waiting the box to receive messageStore -> {RemoteCommands.REMOVE_ALL_MESSAGES}")
        # Removing also RemoteCommands.REMOVE_ALL_MESSAGES message in service
        request.cls.iptv_prov_api.mts_message_remove(message_id=message["messageId"])

    __log.info("Initial setup. Removing all the messages on the client")
    tear_down()
    yield
    __log.info("Tearing down. Removing all the messages on the client")
    tear_down()
    request.cls.home_page.relaunch_hydra_app()
    # It's expected that User Message will not shown when Hydra recieved RemoteCommands.REMOVE_ALL_MESSAGES
    # and the app was relaunched
    request.cls.home_assertions.verify_overlay_shown(expected=False)


@pytest.fixture(autouse=False, scope="function")
def cleanup_sign_in_and_skip_ftux(request):
    """
    Signing in and skipping FTUX.
    Can be used after clearing Hydra app data (licenseplate screen is not shown in this case).
    """

    def tear_down():
        __log.info("Tearing down. Signin in and skipping FTUX")
        if Settings.is_unmanaged() and not Settings.is_cc3():
            request.cls.home_page.proceed_with_sign_in()
        request.cls.home_page.skip_ftux()

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def fill_internal_storage_by_installing_apps(request):
    """
    Trying to fill internal storage by installing some apps
    """
    __log.info("Trying to fill internal storage by installing some apps")
    available_data = request.cls.home_page.get_data_in_mb()
    __log.info("Current device memory: {}Mb".format(available_data))
    if int(available_data) > request.cls.home_labels.LBL_MINIMUM_MEMORY:
        for app in request.cls.home_labels.LBL_LIST_OF_APP_NAMES:
            __log.info("Installing {} app.".format(app))
            request.cls.home_page.download_game_using_GA(app)
            if request.cls.screen.base.is_text_present(request.cls.home_labels.LBL_INSUFFICIENT_STORAGE):
                request.cls.screen.base.select_item_by_text(request.cls.home_labels.LBL_CANCEL)
            if request.cls.screen.base.is_text_present(request.cls.home_labels.LBL_NOT_ENOUGH_STORAGE):
                request.cls.screen.base.select_item_by_text(request.cls.home_labels.LBL_CANCEL)
            available_data = request.cls.home_page.get_data_in_mb()
            __log.info("Available_data after installing {}Mb".format(available_data))
            if int(available_data) <= request.cls.home_labels.LBL_MINIMUM_MEMORY:
                break
    request.cls.home_page.relaunch_hydra_app(reboot=True)


@pytest.fixture(autouse=False, scope="function")
def free_up_internal_memory_by_uninstalling(request):
    """
    Trying to free up internal memory
    """

    def tear_down():
        __log.info("Trying to free up internal storage by uninstalling some apps")
        for app in request.cls.home_labels.LBL_LIST_OF_PACKAGE_NAMES:
            if request.cls.screen.base.is_app_installed(app):
                __log.info("Uninstalling app: {}".format(app))
                request.cls.screen.base.driver.uninstall(app)
            else:
                __log.info("{} is not installed".format(app))
        available_data = request.cls.home_page.get_data_in_mb()
        __log.info("Available memory after uninstalling some apps: {}Mb".format(available_data))

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def restore_mind_availability(request):
    """
    Activate back TiVo services with backdoor after it has been used to disable them in test
    """

    def cleanup():
        __log.info("Switching off backdoor that disables TiVo services.")
        request.cls.home_page.back_to_home_short()
        network_status = request.cls.home_page.wait_for_connected_disconnected_state(timeout=10)
        if network_status:
            request.cls.home_page.toggle_mind_availability()
            request.cls.home_assertions.verify_connected_disconnected_state_happened(timeout=10, wait_disconnect=False)

    request.addfinalizer(cleanup)


@pytest.fixture(autouse=False, scope="function")
def cleanup_set_sleep_timeout_to_never(request):
    """
    Cleaning up the sleep timeout value, setting it to -1 (never enter standby mode)
    """

    def cleanup():
        __log.info("Cleanup. Setting sleep timeout to -1 (never enter standby mode)")
        request.cls.home_page.set_sleep_timeout()  # default value is -1

    request.addfinalizer(cleanup)


@pytest.fixture(autouse=False, scope="function")
def restore_tivo_service_connection(request):
    """
        Set TiVo Service connection to enable state
    """

    def tear_down():
        __log.info("Tearing down")
        request.cls.home_page.relax_bandwidth_restrictions()

    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def launch_hydra_app_when_script_is_on_ott(request):
    """
    Trying to launch hydra app
    """
    def tear_down():
        __log.info("Trying to launch hydra app")
        request.cls.home_page.launch_hydra_when_script_is_on_ott()
    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def refresh_ppv_credit_limit(request):
    """
    Trying to refresh credit limit for account to avoid problem with purchasing ppv offers
    """
    if Settings.is_cc11():
        __log.info("Trying to refresh credit ppv limit")
        request.cls.service_api.refresh_ppv_credit()
    else:
        __log.info("Credit ppv limit for your account could not  be refreshed")


def get_signin_overlay_data():
    __log.info("Reading yaml file to get signin overlay data.")
    list_of_overlay = []
    with open(Settings.TEST_DATA + '/signin_overlay_tc.yml', 'r') as ymlfile:
        global signin_code
        overlay_details = yaml.load(ymlfile, Loader=yaml.FullLoader)
        signin_code = list(map(lambda od: od, overlay_details))
        __log.info(f"signin overlay data: {overlay_details}\nsignin code: {signin_code}")
        for overlay in overlay_details:
            list_of_overlay.append(overlay_details.get(overlay))
        __log.info(f"list_of_overlay: {list_of_overlay}")
        return list_of_overlay


@pytest.fixture(params=get_signin_overlay_data(), ids=signin_code, autouse=False, scope="module")
def get_signin_overlay_data_from_yml(request):
    """
    Fixture to get signin overlay data from yaml file
    """
    __log.info(f"Overlay data from yaml file: {request.param}")
    return request.param
