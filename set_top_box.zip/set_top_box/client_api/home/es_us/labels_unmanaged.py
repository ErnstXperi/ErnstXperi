from set_top_box.client_api.home.es_us.labels import SpanishHomeLabels as SpanishBaseHomeLbls


class SpUnmanagedHomeLabels(SpanishBaseHomeLbls):

    def __init__(self):
        super().__init__()
        self.LBL_HOME_MENU_ITEMS = [self.LBL_MENU_SHORTCUT, self.LBL_LIVETV_SHORTCUT, self.LBL_MYSHOWS_SHORTCUT,
                                    self.LBL_WHATTOWATCH_SHORTCUT, self.LBL_GUIDE_SHORTCUT, self.LBL_ONDEMAND_SHORTCUT,
                                    self.LBL_SEARCH_SHORTCUT]
        self.LBL_HOME_MENU_ITEMS_SHORTCUTS = [self.LBL_MENU_SHORTCUT, self.LBL_LIVETV_SHORTCUT,
                                              self.LBL_MYSHOWS_SHORTCUT,
                                              self.LBL_WHATTOWATCH_SHORTCUT, self.LBL_GUIDE_SHORTCUT,
                                              self.LBL_ONDEMAND_SHORTCUT,
                                              self.LBL_SEARCH_SHORTCUT]
