from set_top_box.client_api.home.en_us.labels import HomeLabels


class SpanishHomeLabels(HomeLabels):
    LBL_HOME_SCREENTITLE = "INICIO"
    LBL_MENU_LOCK_SHORTCUT_ICON = "com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_strip_lock_active.png"
    LBL_MENU_UNLOCK_SHORTCUT_ICON = "com/tivo/applib/ResAppLibImages/" \
                                    "applib/images/hydra/hydra_icon_strip_unlock_active.png"
    LBL_MENU_SHORTCUT = "MENÃ\x9a"
    LBL_MENU_SCREENTITLE = "MENÃ\x9a"
    LBL_WATCHVIDEO_SHORTCUT = "VER TV"
    LBL_GUIDE_SHORTCUT = "GUÃ\x8dA"
    LBL_GUIDE_SCREENTITLE = "GUÃ\x8dA"
    LBL_MYSHOWS_SHORTCUT = "MIS PROGRAMAS"
    LBL_SEARCH_SHORTCUT = "BUSCAR"
    LBL_WHATTOWATCH_SHORTCUT = "QUÃ\x89 VER"
    LBL_LIVETV_SHORTCUT = "VER TV"
    LBL_NOTIFICATION_SHORTCUT = "NOTIFICACIONES"
    LBL_APPSANDGAME_SHORTCUT = "APPS Y JUEGOS"
    LBL_ONDEMAND_SHORTCUT = "ON DEMAND"
    LBL_ONDEMAND_SCREENTITLE = "ON DEMAND"
    LBL_CREATE_ONEPASS = "Crear OnePass"
    LBL_FTUX_TITLE = "FIRST TIME UX"
    LBL_FTUX_VIEW_MODE = "ftux.FtuxOnePassScreenView"
    LBL_LICENSE_PLATE = "LICENSE PLATE"
    LBL_LICENSE_PLATE_VIEW = "signin.licenseplate.LicensePlateScreenView"
    LBL_CREATE_ONEPASS_WITH_THESE_OPTIONS = "Crear OnePass con estas opciones"
    LBL_ONEPASS_WHISPER = "Se ha creado un OnePass."
    LBL_ONEPASS_WHISPER_CANCEL = 'Esta serie no se grabará.'
    # What to Watch lables
    LBL_ON_TV_TODAY = "En la tele hoy"
    LBL_COLLECTIONS = "Collections"
    LBL_SPORTS = "Deportes"
    LBL_MOVIES = "Movies"
    LBL_TV_SERIES = "TelevisiÃ³n"
    LBL_KIDS = "Juventud"
    LBL_LIVE_TV = "Live TV"
    LBL_MODIFY_ONEPASS = "Modificar OnePass"
    LBL_HOME_SCREEN_NAME = "HomeMainScreen"
    LBL_HOME_ENGLISH_SCREEN_TITLE = "HOME"
    LBL_HOME_VIEW_MODE = "home.HomeScreenView"
    LBL_ONEPASS_FTUX = "OnePassQuickSelectScreen"
    LBL_HOME_SCREEN_MODE = "home.HomeScreenView"
    LBL_WTW_SCREEN_MODE = "whattowatch2.WTWScreenView"  # What to Watch screen mode
    LBL_EAS_VIEW = "eam.EamScreenView"
    LBL_CANADIAN_EAS_VIEW = "eam.EamCanadaScreenView"
    LBL_GOING_TO_LIVE_TV_OSD = "Ir a la televisiÃ³n en vivo"
    LBL_WTW_PRIMARY_SCREEN = "W2WPrimaryScreen"
    LBL_WTW_SIDE_PANEL = "W2WSidePanelScreen"
    LBL_STREAMINGAPPS_FTUX = "StreamingAppsScreen"
    LBL_STREAMINGAPPS_FTUX_VIEW_MODE = "ftux.FtuxStreamingAppsScreenView"
    LBL_ONEPASS_ICON_FTUX = "hydra_icon_status_onepass.png"
    LBL_SIGN_IN = "SamlSignInScreen"
    LBL_FTUX_ANIMATION_SCREEN = "OpeningAnimationScreen"
    LBL_SYSTEM_AND_ACCOUNT = "SISTEMA Y CUENTA"
    LBL_WHAT_TO_WATCH_TV_ICON = "hydra_icon_source_tv_C0.png"
    LBL_STREAMING_VIDEO_ICON = "hydra_icon_source_streaming_video.png"
    LBL_WHAT_TO_WATCH_NETFLIX_ICON = "hydra_icon_source_Netflix_C0_32x32.png"
    LBL_WHAT_TO_WATCH_VUDU_ICON = "hydra_icon_source_vudu_C0_32x32.png"
    LBL_WHAT_TO_WATCH_HULU_ICON = "hydra_icon_source_hulu_C0_32x32.png"
    LBL_WHAT_TO_WATCH_GOOGLE_PLAY_ICON = "hydra_icon_source_Google_Play_C0_32x32.png"
    LBL_WHAT_TO_WATCH_HBO_ICON = "HBOGO_C0_32x32.png"
    LBL_FTUX_ANIMATION_VIEW_MODE = "ftux.FtuxOpeningAnimationScreenView"
    LBL_ONEPASS_FTUX_VIEW_MODE = "ftux.FtuxOnePassScreenView"

    def __init__(self):
        super().__init__()
        self.LBL_HOME_MENU_ITEMS = [self.LBL_MENU_SHORTCUT, self.LBL_LIVETV_SHORTCUT, self.LBL_MYSHOWS_SHORTCUT,
                                    self.LBL_WHATTOWATCH_SHORTCUT, self.LBL_GUIDE_SHORTCUT,
                                    self.LBL_APPSANDGAME_SHORTCUT,
                                    self.LBL_ONDEMAND_SHORTCUT, self.LBL_SEARCH_SHORTCUT]
