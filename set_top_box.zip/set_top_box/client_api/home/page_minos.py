from set_top_box.client_api.home.page import HomePage as DefaultHomePg


class StbHomePage(DefaultHomePg):

    def go_to_guide(self, tester):
        self.log.step("minos go to guide")
        self.press_guide_button()
        if not self.wait_for_screen_ready(tester.guide_labels.LBL_GUIDE_SCREEN) and \
                tester.guide_labels.LBL_SCREENTITLE != self.screen_title():
            self.press_guide_button()
        tester.guide_assertions.verify_guide_title()
