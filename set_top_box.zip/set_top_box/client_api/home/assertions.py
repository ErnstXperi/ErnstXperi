import re
import os
import yaml

import pytest
from hamcrest import assert_that, contains_string, is_not, is_, equal_to, has_item, equal_to_ignoring_case

from tools.logger.logger import Logger
from set_top_box.client_api.home.page import HomePage
from set_top_box.client_api.home.en_us.labels import HomeLabels
from set_top_box.test_settings import Settings


class HomeAssertions(HomePage):
    log = Logger(__name__)
    # TODO
    #   1. Move home_label variable initialization to conftest.py to support LabelFactory
    #   2. Replace HomeLabels.label with self.home_label.label
    home_labels = HomeLabels()

    def verify_menu_item_available(self, menu_item):
        self.log.info("Verifying Menu Item: {} availability".format(menu_item))
        loop_attempts = 0
        strip_list = self.strip_list()
        menu_item = self.remove_service_symbols(menu_item)
        self.log.info(f"Check if menu_item='{menu_item}' exists in strip_list.")
        while menu_item not in strip_list:
            self.log.debug(f"menu_item='{menu_item}' not found in strip_list='{str(strip_list)}'. "
                           f"Move Right and get strip_list again.'")
            self.navigate_by_strip(strip_list[-1])
            self.screen.refresh()
            scrolled_strip_list = self.strip_list()
            for item in scrolled_strip_list:
                if item not in strip_list:
                    strip_list.append(item)
            loop_attempts += 1
            if loop_attempts > 5:
                self.log.debug("verify_menu_item_available> Retries overlimit")
                break
            if scrolled_strip_list[-1] in strip_list:
                self.log.debug("verify_menu_item_available> Reached to the end of the strip")
                break
        assert_that(strip_list, has_item(menu_item))
        self.log.info(f"menu_item='{menu_item}' was found in the strip_list='{str(strip_list)}'.")

    def verify_highlighter_on_prediction_strip(self):
        self.log.step("Verifying highlighter on prediction strip")
        strip = self.strip_list()
        for item in self.home_labels.LBL_HOME_MENU_ITEMS:
            if item in strip:
                raise AssertionError(f"highlighter not on prediction strip, {item} found in strip")

    def get_error_type(self, body_text):
        self.log.info("Determining Error Type")
        dir_path = os.path.dirname(os.path.realpath(__file__))
        with open(dir_path + '/error_classifications.yml') as self.yfile:
            self.error_types = yaml.load(self.yfile, Loader=yaml.FullLoader)
        for error, keyword in self.error_types["ErrorTypes"].items():
            if any(item in body_text for item in keyword):
                return error

    def verify_predictions(self):
        self.log.info("Asserting prediction strip exists")
        error_code = None
        error_type = None
        (error_code, body_text) = self.check_error_in_predictions()
        if body_text:
            self.log.info("error found in predictions")
            error_type = self.get_error_type(body_text)
        network_status = self.is_mind_disconnected()
        if network_status:
            error_type = f"Mind Connectivity Error : {network_status}"
        if error_type:
            assert False, f"{error_type}-{error_code} : {body_text}"
        if self.is_prediction_strip_focused():
            self.log.info("Predictions bar loaded with prediction items")
        else:
            self.log.info("Predictions bar not loaded with prediction items and no error code observed")

    def check_error_in_predictions(self):
        self.screen.refresh()
        error_code = None
        body_text = None
        predictions_body = self.screen.get_screen_dump_item()
        if 'bodyText' in predictions_body:
            body_text = predictions_body['bodyText']
            extract_code = re.findall(r'\(.*?\)', body_text)
            if extract_code:
                error_code = extract_code[0]
        return error_code, body_text

    def verify_w2w_menu_items(self, content_list):
        for i in content_list:
            assert_that(self.is_in_menu(i))

    def verify_ftux_view_mode(self):
        self.log.step("Verifying if view mode is One Pass Quick Select screen or not")
        self.screen.refresh()
        self.verify_view_mode("ftux.FtuxOnePassScreenView")

    def verify_ftux_eula_mode(self):
        self.log.step("Verifying if view mode is FTUX EULA screen or not")
        self.verify_view_mode(self.home_labels.LBL_FTUX_EULA)

    def verify_streaming_apps_checked_unchecked(self, provider_list=[], is_check=True):
        """
        Verify if Video Providers are checked/unchecked on FTUX -> Streaming Apps screen.

        Args:
            provider_list (list): names of providers to check/uncheck e.g. ["NETFLIX", "STARZ"];
                                  Note: if empty, all providers are checked/unchecked, provider names can be taken from
                                        screen dump
            is_check (bool): True checking tiles, False - checking tiles
        """
        info_msg_part = "Checked" if is_check else "Unchecked"
        vp_msg_part = "all" if not provider_list else provider_list
        self.log.info("Verifying if {} Video Providers on FTUX -> Streaming Apps screen {}".format(vp_msg_part, info_msg_part))
        screen_dump = self.screen.get_json()
        result, not_matched = self.check_uncheck_ftux_streaming_apps_providers(provider_list, is_check, False)
        err_msg = "checked" if not is_check else "unchecked"
        assert_that(all(result), "{} providers are {}, expected {}; screen dump: \nscreen_dump = {}"
                                 .format(not_matched, err_msg, is_check, screen_dump))

    def verify_home_title(self, label=None):
        self.screen.refresh()
        label = label or self.home_labels.LBL_HOME_SCREENTITLE
        self.log.info("Asserting for current title is specific title as per supported language selected")
        assert_that(self.screen_title(), equal_to_ignoring_case(label), "Box not in Home Screen")

    def verify_home_screen_after_pressing_home(self):
        if Settings.is_unmanaged():
            assert_that(not self.screen.base.verify_foreground_app(Settings.app_package),
                        "Foreground app is Hydra")
        else:
            self.verify_home_title()

    def verify_w2w_preview_title(self):
        self.pause(1)
        self.screen.refresh()
        preview_panel = self.get_preview_panel()
        preview_panel1 = preview_panel['title']
        self.screen.base.press_enter()
        self.pause(4)  # Delay added for the screen to settle down
        self.screen.refresh()
        self.wait_for_screen_ready()
        preview_panel = self.get_preview_panel()
        preview_panel2 = preview_panel['title']
        assert_that(preview_panel1, preview_panel2)

    def verify_prediction_tile(self):
        assert_that(self.is_strip_focus())
        strip = self.screen.get_screen_dump_item('stripitem')
        for item in strip:
            try:
                assert_that(item['availableOn'], "No asset shown")
                self.log.info(f"strip asset is shown: {item}")
            except KeyError:
                raise LookupError("No asset shown")

    def verify_parental_lock(self):
        """
        Verify PIN overlay is visible
        """
        expected = "PIN Overlay"
        if self.osd_shown(refresh=False) and self.home_labels.LBL_GOING_TO_LIVE_TV_OSD not in self.osd_text():
            actual_osd_text_value = expected
            self.log.info(f"Verification PIN: {self.osd_text()}")
        else:
            actual_osd_text_value = f"No PIN is visible. Details: {self.screen_title()}, {self.get_ui_error()}"
        assert_that(actual_osd_text_value, is_(expected))

    def verify_parental_is_not_locked(self):
        '''
        :description:
            Checks if there's NO OSD text on the WatchVideo screen
        '''
        screen = self.screen.screen_dump['xml']
        assert_that(True,
                    is_not("osdtext" in screen and not HomeLabels().LBL_GOING_TO_LIVE_TV_OSD in screen["osdtext"]))

    def verify_EAS_screen(self, eas="default"):
        self.log.info("verifying eas widget and it title")
        if Settings.is_telus() or eas == "canadian":
            eas_view_mode = self.home_labels.LBL_CANADIAN_EAS_VIEW
            self.wait_for_screen_ready(eas_view_mode)
            self.verify_view_mode(eas_view_mode)
        elif eas == "floating":
            eas_view_mode = self.home_labels.LBL_FLOATING_EAS_VIEW
            self.wait_for_EAS_HLS_Stream(timeout=10000)
            self.verify_view_mode(eas_view_mode)
        else:
            eas_view_mode = self.home_labels.LBL_EAS_VIEW
            self.wait_for_EAS_HLS_Stream(timeout=10000)
            self.verify_view_mode(eas_view_mode)
            content = self.get_eas_content()
            if content:
                regular_body_text = self.home_labels.LBL_REGULAR_EAS_BODY
                if Settings.is_apple_tv():
                    regular_body_text = self.home_labels.LBL_REGULAR_EAS_BODY_APPLE
                assert_that(content, is_(regular_body_text), "Mismatch observed in EAS text message")
            elif content is None and Settings.mso.lower() == "millicom":
                pass
        self.log.info("EAS view mode validation successful")

    def verify_home_screen(self):
        self.log.info("verifying focus is on strip or not")
        assert_that(self.is_strip_focus())

    def verify_screen_rendered(self):
        assert_that(self.is_screen_rendered())

    def verify_voice_search(self):
        self.log.step("Checking if voice overlay was launched or not")
        assert_that(self.screen.get_screen_dump_item('overlayMode'), 'overlay.voice.VoiceStatusOverlayView')

    def verify_full_info_banner(self):
        self.screen.refresh()
        assert self.is_infobanner_visible(), "Full Info Banner not Visible"

    def verify_whisper(self, whisper, refresh=True):
        self.log.step("Verifying that a whisper was shown with the text {}".format(whisper))
        if refresh:
            self.screen.get_json()
        try:
            curr_whisper = self.screen.get_screen_dump_item('whisper', 'text')
        except KeyError:
            curr_whisper = ""
        assert_that(curr_whisper, contains_string(whisper), "Whisper is not shown")

    def verify_show_in_my_shows(self, tester, show):
        self.log.step(f"Verifying program {show} existence under my shows")
        tester.home_page.nav_to_top_menuitem_in_list()
        self.screen.refresh()
        menu = self.menu_list()
        found = False
        for item in menu:
            if show in item:
                found = True
        if found:
            self.log.info("{} found".format(show))
        else:
            assert False, show + "not found"

    def verify_show_in_one_pass_manager(self, tester, show):
        self.log.step("Verify {} existence in one pass manager".format(show))
        tester.home_page.nav_to_top_menuitem_in_list()
        menu = []
        textlist = []
        menu_list = (self.screen.get_screen_dump_item('menuitem'))
        if type(menu_list) is list:
            for item in menu_list:
                if isinstance(item, dict):
                    if "text" in item.keys():
                        self.log.info(item['text'])
                        textlist = item['text']
                        if isinstance(textlist, list):
                            self.log.info(textlist[0])
                            menu.append(textlist[0])
                        menu.append(item['text'])
        else:
            if isinstance(menu_list, dict):
                if "text" in menu_list.keys():
                    self.log.info(menu_list['text'])
                    textlist = menu_list['text']
                    if isinstance(textlist, list):
                        self.log.info(textlist[0])
                        menu.append(textlist[0])
                    menu.append(menu_list['text'])
        menu_decoded = []
        for item in menu:
            if isinstance(item, list):
                item = self.remove_service_symbols(item)
                item = [string.encode('iso-8859-1').decode() for string in item]
                menu_decoded.append(item)
            else:
                item = self.remove_service_symbols(item)
                item = item.encode('iso-8859-1').decode()
                menu_decoded.append(item)
        if menu_decoded:
            menu = menu_decoded
        show = self.remove_service_symbols(show)
        show = show.encode('iso-8859-1').decode()
        self.log.step("Show & Menu are as below :")
        self.log.info(show)
        self.log.info(menu)

        def __fun(menu_item):
            if isinstance(menu_item, list):
                return any(map(__fun, menu_item))
            else:
                if show.lower() in menu_item.lower():
                    return True
                else:
                    return False

        while menu is not False:
            if any(map(__fun, menu)):
                assert_that(True, "Show found : {}".format(show))
                return
            menu = tester.home_page.nav_to_next_menu_list_page()
        assert_that(False, "Show not found : {}".format(show))

    def verify_ftux_one_pass_selections(self):
        self.log.info("Verifying selected One Pass")
        self.screen.refresh()
        dump = self.screen.get_screen_dump_item('stripitem')

        def __check_created_onepass_icon(item_list):
            lbl_onepass = self.home_labels.LBL_ONEPASS_ICON_FTUX
            for item in item_list:
                if type(item) is dict and type(item.get('imagename')) is list and item.get('hasfocus'):
                    # Checking only a tile under focus
                    return __check_created_onepass_icon(item.get('imagename'))
                elif type(item) is dict and item.get('hasfocus') and lbl_onepass in item.get('imagename'):
                    # Case when item contains imagename key
                    return True
                elif lbl_onepass in item:
                    # Case when item is str and item_list is a list of imagename
                    return True
            return False

        assert_that(__check_created_onepass_icon(dump), f"Could not find OnePass icon; screen dump \n{dump}")

    def verify_ftux_streamingapps_screen(self):
        self.log.info("Verifying if Streaming Apps screen is displayed")
        self.wait_for_screen_ready(self.home_labels.LBL_STREAMINGAPPS_FTUX)
        self.verify_view_mode(self.home_labels.LBL_STREAMINGAPPS_FTUX_VIEW_MODE)

    def verify_ftux_pcsettings_screen(self):
        self.log.info("Verifying if Parental Controls Settings screen is displayed")
        self.wait_for_screen_ready(self.home_labels.LBL_PCSETTINGS_FTUX)
        self.verify_view_mode(self.home_labels.LBL_PCSETTINGS_FTUX_VIEW_MODE)

    def verify_eas_alert_message(self, text):
        status = self.wait_for_EAS_Message(text)
        if status:
            return True
        else:
            raise AssertionError("Emergency Notification Alert message not displayed")

    def validate_alert_stream(self):
        self.log.step("Checking EAS Stream/Playback")
        status = self.wait_for_EAS_HLS_Stream()
        if status:
            return True
        else:
            raise AssertionError("Emergency Notification Alert Streaming not displayed")
        self.log.info("Back to home page")
        self.screen.base.press_back()

    def verify_all_episodes_list_view(self, icon_check='False'):
        episode_name = ''
        series_episode = ''
        print('value of icon_check:', icon_check)
        self.screen.refresh()
        viewmode = self.screen.get_screen_dump_item('viewMode')
        self.log.info('Type of screen is  {}:'.format(viewmode))
        self.nav_to_top_menuitem_in_list()
        self.screen.base.press_down()
        if viewmode == 'actions.series.SeriesScreenView':
            self.screen.refresh()
            screen_details = self.screen.get_screen_dump_item('menuitem')
            self.log.info('screen_details:{}'.format(screen_details))
            for item in screen_details:
                if "hasfocus" in item.keys() and item["hasfocus"] == "true":
                    episode_name = item['text'][0]
                    self.log.info('series title is :{}'.format(episode_name))
                    if len(item['text']) == 2:
                        series_episode = item['text'][1]
                    else:
                        series_episode = item['text'][2]
                    self.log.info('series episode is :{}'.format(series_episode))
                    if icon_check == 'streaming_icon':
                        for streaming_icon in item['imagename']:
                            if self.home_labels.LBL_STREAMING_VIDEO_ICON in streaming_icon:
                                self.log.info('streaming icon found')
                                break
                            else:
                                self.log.info('streaming icon not found')
        else:
            self.screen.refresh()
            screen_details = self.screen.screen_dump['xml']
            self.log.info('screen_details:{}'.format(screen_details))
            self.get_series_episode_episode_name(screen_details)
            if icon_check == 'streaming_icon':
                for item_no in range(len(self.menu_list())):
                    self.log.info('menu_list in OTT+TV:{}'.format(self.menu_list()))
                    dump = self.screen.get_screen_dump_item('menuitem').get('imagename')[1]
                    if dump is None:
                        dump = self.screen.get_screen_dump_item('menuitem')[item_no].get('imagename')
                    for eachitem in dump:
                        if self.home_labels.LBL_STREAMING_VIDEO_ICON in eachitem:
                            self.log.info('streaming icon should be present')
                            assert_that(dump, self.home_labels.LBL_STREAMING_VIDEO_ICON)
                            break
                    else:
                        self.log.info('streaming icon not found')
        self.validate_episodetitle(episode_name)
        self.validate_seriesname(series_episode)

    def validate_episodetitle(self, episode_name):
        episode_name_exist_status = bool(re.match('([a-zA-Z0-9]+)', episode_name))
        self.log.info('title existence status is:{}'.format(episode_name_exist_status))
        assert_that(episode_name_exist_status, 'True')

    def validate_seriesname(self, series_episode):
        series_episode_exist_status = bool(re.match(r'S[0-9]+[\s]E[0-9]+', series_episode) or  # noqa: W504
                                           re.match(r'S[0-9]+', series_episode))  # noqa: W504
        self.log.info('series episode existence status is:{}'.format(series_episode_exist_status))
        assert_that(series_episode_exist_status, 'True')

    def get_series_episode_episode_name(self, screen_details):
        if isinstance(screen_details['menuitem'], dict):
            series_episode = screen_details['menuitem'].get('text')[1]
            episode_name = screen_details['menuitem'].get('text')[0]
        else:
            series_episode = screen_details['menuitem'][0]['text'][1]
            episode_name = screen_details['menuitem'][0]['text'][0]
        self.log.info('series episode is :{}'.format(series_episode))
        self.log.info('series title is :{}'.format(episode_name))

    def verify_socu_playback(self, tester):
        self.log.step("Verifying SOCU playback")
        max_retries = 3
        while max_retries > 0:
            max_retries -= 1
            state = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
            if state:
                try:
                    self.log.info("Selecting HD option from resolution selector overlay")
                    self.select_menu_by_substring(self.home_labels.LBL_HD)
                except Exception:
                    raise AssertionError('Unable to playback the SOCU offer from Guide')
            state = self.wait_for_screen_ready(self.home_labels.LBL_SOCU_PLAYBACK_SCREEN)
            url = self.get_playback_raw_log_with_status(timeout=10000)
            tester.watchvideo_assertions.set_or_update_channel_playback_info(playback_state=url)
            if not state:
                state = self.wait_for_screen_ready(self.home_labels.LBL_TRY_AGAIN_SCREEN)
                if not state:
                    self.log.info("Trying again...")
                else:
                    self.screen.refresh()
                    raise AssertionError('Unexpected Overlay : TryAgainLaterOverlay')
            else:
                self.log.info("SOCU Playback : VALIDATION SUCCEEDED")
                tester.watchvideo_assertions.set_or_update_channel_playback_info(after_check=True)
                break

    def verify_device_setting(self, text):
        self.log.step("Verify settings with google assistance")
        if not self.screen.base.is_text_present(text):
            raise AssertionError("Device Setting is not launched")

    def validate_notifications(self):
        if not self.screen.base.is_text_present(self.home_labels.LBL_NOTIFICATIONS):
            raise AssertionError("Notifications not listed after selecting NOTIFICATION from home")

    def check_and_validate_green_box_status(self, dump, dump_after_tts_on):
        if dump.keys() != dump_after_tts_on.keys():
            self.log.info("Screen Keys before TTS ON: {}".format(dump.keys()))
            self.log.info("Screen Keys after TTS ON: {}".format(dump_after_tts_on.keys()))
            raise AssertionError("Greenhighlighter is getting displayed")

    def validate_left_right_up_down_ok_key_actions(self, tester):
        self.log.step("Perform various key actions and validate")
        if Settings.is_managed():
            tester.home_page.goto_notification(tester)
            self.screen.base.press_back()
            self.verify_home_title()
        tester.home_page.goto_home_menu_items_from_prediction()
        self.screen.refresh()
        current_focus_index = self.return_strip_focus_index()
        self.screen.base.press_left()
        self.screen.refresh()
        left_focus_index = self.return_strip_focus_index()
        assert_that(left_focus_index, equal_to(current_focus_index), "failed in left key action")
        self.screen.base.press_right()
        self.screen.refresh()
        right_focus_index = self.return_strip_focus_index()
        assert_that(right_focus_index, equal_to(left_focus_index + 1), "failed in right key action")
        self.screen.base.press_down()
        self.verify_predictions()
        self.screen.base.press_up()
        self.screen.refresh()
        if not self.is_strip_focus():
            raise AssertionError("failed in up key action")
        self.select_menu_shortcut(self.home_labels.LBL_MENU_SHORTCUT)
        tester.menu_assertions.verify_menu_screen_title()

    def select_live_channel_from_prediction(self, tester):
        self.goto_prediction()
        self.verify_highlighter_on_prediction_strip()
        for i in range(12):
            self.pause(5)
            self.screen.refresh()
            screen = self.screen.screen_dump['xml']['stripitem']
            self.log.info("dump values: {}".format(screen))
            self.log.info("dump values for screen: {}".format(screen[1].keys()))
            if 'availableOn' in screen[1].keys():
                if tester.my_shows_labels.LBL_LIVE_ICON in screen[1]['availableOn']['imagename'] and \
                        screen[1]['hasfocus'] == "true":
                    self.screen.base.press_enter()
                    self.wait_for_screen_ready()
                    tester.watchvideo_assertions.verify_view_mode(tester.watchvideo_labels.LBL_LIVETV_VIEWMODE)
                    break
                else:
                    self.screen.base.press_right()
            else:
                self.log.error("Could not find {} in screendump".format(KeyError))
                self.screen.base.press_right()
            i += 1
        else:
            pytest.skip("Live channel is not found in prediction")

    def verify_video_window_on_home_screen(self):
        """
        Verifying the visibility of video window on home screen
        """
        status = self.wait_for_home_screen_video_window()
        if status:
            self.log.info("Video window is visible on Home Screen")
            return True
        else:
            raise AssertionError("Video window is not visible on Home Screen")

    def verify_pc_on_unlocked_on_home_screen(self, tester):
        if tester.home_page.is_in_strip(self.home_labels.LBL_MENU_UNLOCK_SHORTCUT_ICON, "in"):
            self.log.info("Parental Controls is On-Unlocked on Home Screen")
        else:
            raise AssertionError("Parental Controls is not On-Unlocked on Home Screen")

    def validate_disconnected_state(self, tester, timeout=120):
        state = True
        while timeout > 0:
            self.pause(30)
            timeout = timeout - 30
            tester.home_page.go_to_guide(tester)
            self.screen.base.press_enter()
            self.screen.refresh()
            overlay = self.screen.get_screen_dump_item()
            self.log.info(f"overlay dump : {overlay}")
            if overlay.__contains__('overlaytitle'):
                if overlay['overlaytitle'] != tester.home_labels.LBL_NO_NETWORK_OVERLAY_TITLE and \
                        overlay['overlayBody'] != tester.home_labels.LBL_NO_NETWORK_OVERLAY_BODYTEXT:
                    state = False
                    self.screen.base.press_enter()
                    break
            elif overlay.__contains__('whisper') and overlay['whisper']['visible'] == 'true':
                if overlay['whisper']['text'] != tester.home_labels.LBL_DISCONNECTED_WHISPER_TEXT:
                    state = False
                    break
            elif overlay.__contains__('bodyText'):
                if "â\x80\x99" in overlay['bodyText']:
                    body_text = tester.my_shows_page.cleanup_text_char(overlay['bodyText'], rstr="'")
                    if body_text != tester.home_labels.LBL_C228_BODYTEXT:
                        state = False
                        break
            if self.is_overlay_shown():
                self.log.info("exiting overlay")
                self.screen.base.press_enter()
        if not state:
            raise AssertionError("Device failed to enter disconnected state")

    def verify_bridge_state(self, state):
        result = self.manage_network_change()
        if state is self.home_labels.LBL_BRIDGE_STATUS_UP:
            if self.home_labels.LBL_BRIDGE_STATUS_UP not in result:
                raise ConnectionError("Bridge connection is not UP")
        elif state is self.home_labels.LBL_BRIDGE_STATUS_DOWN:
            if self.home_labels.LBL_BRIDGE_STATUS_DOWN not in result:
                raise ConnectionError("Bridge connection is not DOWN")

    def verify_resume_overlay(self, tester):
        if self.is_overlay_shown() and tester.vod_labels.LBL_RESUME_PLAYING not in self.menu_list():
            raise AssertionError("Resume overlay was not displayed")

    def verify_language_not_supported(self):
        self.screen.refresh()
        self.wait_for_screen_ready(timeout=30000)
        if self.is_overlay_shown():
            if self.get_overlay_title() == self.home_labels.LBL_LANGUAGE_NOT_SUPPORTED_OVERLAY_TITLE or \
                    self.get_overlay_body() == self.home_labels.LBL_LANGUAGE_NOT_SUPPORTED_BODY_TEXT:
                return True
        else:
            raise AssertionError("Language not supported overlay "
                                 "is not shown may reason whether prediction bar is not loaded on time")

    def select_netflix_shortcut_and_verify_netflix_launch(self, tester):
        self.back_to_home_short()
        self.select_menu_shortcut(self.home_labels.LBL_NETFLIX_SHORTCUT)
        assert_that(self.screen.base.verify_foreground_app(tester.apps_and_games_labels.NETFLIX_PACKAGE_NAME),
                    "Didn't start")

    def verify_predictions_error_code(self, code):
        self.screen.refresh()
        body_text = self.screen.get_screen_dump_item('bodyText')
        assert_that(body_text, not contains_string(code),
                    f"{code} error is not displayed on predictions, error displayed: {body_text}")

    def verify_predictions_error_message(self, tester, error):
        self.wait_for_screen_ready()
        self.screen.refresh()
        self.verify_home_title()
        body_text = self.screen.screen_dump['xml']['bodyText']
        if "â\x80\x99" in body_text:
            body_text = tester.my_shows_page.cleanup_text_char(body_text, rstr="'")
        pattern = (r".*{0}.*".format(error))
        cond = re.search(pattern, body_text)
        if not cond:
            raise AssertionError(f"{body_text} not displayed on predictions")

    def validte_disconnected_state_whisper(self):
        self.wait_for_whisper_text(self.home_labels.LBL_DISCONNECTED_WHISPER_TEXT)
        self.screen.refresh()
        overlay = self.screen.screen_dump['xml']
        self.log.info("xml overlay: {}".format(overlay))
        if overlay.__contains__('whisper'):
            if overlay['whisper']['text'] != self.home_labels.LBL_DISCONNECTED_WHISPER_TEXT:
                raise AssertionError("Network connection is still intact")

    def verify_disconnected_state_overlay(self, lb_overlay=None):
        if self.is_overlay_shown():
            bodytext = [lb_overlay[1], lb_overlay[3]] if len(lb_overlay) == 4 else [lb_overlay[1]]
            if self.get_overlay_title() != lb_overlay[0] or self.screen.get_screen_dump_item('bodytext') not in bodytext \
                    or self.screen.get_screen_dump_item('overlayTitleText') != lb_overlay[2]:
                raise AssertionError(f"Overlay verification failed {lb_overlay}")
            self.screen.base.press_enter()
        else:
            raise AssertionError(f"{lb_overlay[0]} not displayed")

    def verify_action_type_in_slot0_ads(self, slot0_wtw_hero_obj, expected_action_type):
        self.log.info("find the action type of ad")
        if 'action' in slot0_wtw_hero_obj.keys():
            key = 'action'
        else:
            raise LookupError("Can't continue because there are no 'kernel' and 'action' keys \n"
                              "(this data is needed to determine where ad should lead us). \n"
                              "slot0_wtw_hero_obj: {}".format(slot0_wtw_hero_obj))
        action_type = slot0_wtw_hero_obj[key]['type']
        if action_type == expected_action_type:
            return action_type
        else:
            pytest.skip("Authored Ad will not lead to the expected screen. \n"
                        "Can't continue without correct Ad published")

    def verify_drm_type_ipLinear(self, drm_type):
        self.log.info("Checking DRM Configs for ipLinearConfiguration")

        for k, v in drm_type.items():

            if k == self.home_labels.KEY_IPLINEAR_SESSIONMANAGERTYPE and v == self.home_labels.KEY_DRM_APPLETV_NATIVE or \
                    v == self.home_labels.KEY_DRM_ANDROID_NATIVE:
                self.log.info("IP LINEAR  DRM Configs  ARE USING NATIVE PACKAGES")
            elif k == self.home_labels.KEY_IPLINEAR_SESSIONMANAGERTYPE and v == self.home_labels.KEY_DRM_ANDROID_DEFAULT or \
                    v == self.home_labels.KEY_DRM_APPLETV_DEFAULT:
                self.log.info("IP LINEAR  DRM Configs  ARE USING DEFAULT PACKAGES")
            else:
                raise AssertionError("No DRMSERVERTYPE found FOR IP LINEAR FEATURE UNDER TEST")

    def verify_drm_type_npvr(self, drm_type):
        self.log.info("Checking DRM Configs for nDVR Configuration")

        for k, v in drm_type.items():

            if k == self.home_labels.KEY_NPVR_SESSIONMANAGERTYPE and v == self.home_labels.KEY_DRM_APPLETV_NATIVE or \
                    v == self.home_labels.KEY_DRM_ANDROID_NATIVE:
                self.log.info("NDVR  DRM Configs  ARE USING NATIVE PACKAGES")
            elif k == self.home_labels.KEY_NPVR_SESSIONMANAGERTYPE and v == self.home_labels.KEY_DRM_ANDROID_DEFAULT or \
                    v == self.home_labels.KEY_DRM_APPLETV_DEFAULT:
                self.log.info("NDVR  DRM Configs ARE USING DEFAULT PACKAGES")
            else:
                raise AssertionError("No DRMSERVERTYPE found FOR NDVR FEATURE UNDER TEST")

    def verify_drm_type_ipvod(self, drm_type):

        for k, v in drm_type.items():

            if k == self.home_labels.KEY_CUBIVOD_SESSIONMANAGERTYPE:
                self.log.info("Checking CUBI DRM Configs for ipVodConfiguration ")
                if v == self.home_labels.KEY_DRM_APPLETV_NATIVE or v == self.home_labels.KEY_DRM_ANDROID_NATIVE:
                    self.log.info("CUBI  DRM Configuration for ipVodConfiguration ARE USING NATIVE PACKAGES")
                elif v == self.home_labels.KEY_DRM_ANDROID_DEFAULT or v == self.home_labels.KEY_DRM_APPLETV_DEFAULT:
                    self.log.info("CUBI DRM Configuration for ipVodConfiguration ARE USING DEFAULT PACKAGES")
                else:
                    raise AssertionError(" Cubivod has no DRM config")
            if k == self.home_labels.KEY_SOCU_SESSIONMANAGERTYPE:
                self.log.info("Checking SOCU DRM Configs for ipVodConfiguration ")
                if v == self.home_labels.KEY_DRM_APPLETV_NATIVE or v == self.home_labels.KEY_DRM_ANDROID_NATIVE:
                    self.log.info("SOCU DRM Configs for ipVodConfiguration ARE USING NATIVE PACKAGES")
                elif v == self.home_labels.KEY_DRM_ANDROID_DEFAULT or v == self.home.KEY_DRM_APPLETV_DEFAULT:
                    self.log.info("SOCU DRM Configs for ipVodConfiguration ARE USING DEFAULT PACKAGES")
                else:
                    raise AssertionError("Socu has no DRM config")

    def verify_foreground_package_matches_uri(self, uri_access):
        fg_package = self.screen.base.get_foreground_package()
        if fg_package in uri_access:
            self.log.info("Slot0 ad directed to the OTT app")
        else:
            raise AssertionError("The OTT app for the authored Ad not launched")

    def verify_OTT_app_destination_screen(self, expected=True):
        fg_package = self.screen.base.get_foreground_package()
        if self.screen.base.is_exist_by_resource_id(fg_package + ":id/playerContainer"):
            result = True
            self.log.info("Reached the OTT App program screen.")
        else:
            result = False
        assert_that(result, f"Actual result is {result}; expected = {expected}")

    def verify_drm_package_names_native(self, feature, package_type, is_add=True):
        """
        Verify if a DRM package is assigned in service
        pr1ProvDeviceAlaCarteUpdate

        Args:
            feature (str): part of package name representing the feature name
            is_add (bool): if True, we check package is present,
                           if False, we check package is absent
        """
        result = self.iptv_prov_api.verify_package_name_fe_alacarte(feature, package_type, is_add)
        error_msg = f"'{package_type}-{feature}' DRM package name is not present" if is_add \
            else f"'{package_type}-{feature}' DRM package name is found"
        assert_that(result, f"{error_msg} in Service")

    def verify_eas_not_displayed(self):
        self.log.step("Validating that EAS alert was not displayed")
        status = self.wait_for_EAS_HLS_Stream()
        if status:
            self.log.step("Pressing back to dismiss EAS alert")
            self.screen.base.press_back()
            raise AssertionError("EAS alert message was not expected but was still displayed")

    def verify_expected_focused_menu_item(self, expected_item):
        """
        Verify if expected menu item is under focus

        Args:
            focused_item (str): expected focused menu item
        """
        assert_that(self.strip_focus(), expected_item, f"Expected menu item '{expected_item}' is not under focus")

    def verify_connected_disconnected_state_happened(self, error_code=None, timeout=300, wait_disconnect=True,
                                                     is_select=True):
        """
        Waiting for the connected/disconnected state, and verifying if it's happened.
        Internet should be enabled/disabled and Home screen should be displayed before using this method.
        Applicable as for Managed as for Unamanaged boxes.

        Args:
            error_code (str): applicable only for disconnected state, error code in an error message
                              shown instead of the Prediction bar on the Home screen,
                              if None, checking presence of any error in the bodyText of Home screen
            timeout (int): time to wait in seconds
            wait_disconnect (bool): True, checks if Hydra got to the disconnected state,
                                    False, checks if Hydra got to the connected state
            is_select (bool): True - selecting menu shortcut on the Home screen so Hydra will make requests
                                     to get into connected/disconnected state faster;
                              False - no additional selecting of menu shortcuts on the Home screen
        """
        state = "Disconnected" if wait_disconnect else "Connected"
        err_code = error_code if error_code else "any error code"
        use_err_code = err_code if wait_disconnect else ""
        assertion_str = f"The Hydra app is not in the {state} state {use_err_code}"
        self.log.info(f"Verifying if Hydra app got into {state} state")
        assert_that(self.wait_for_connected_disconnected_state(error_code, timeout, wait_disconnect, is_select),
                    f"{assertion_str} \n\n screen dump \n\n {self.screen.get_json()}")

    def is_content_available_in_prediction(self, tester, show, prediction_list):
        found = False
        for i in prediction_list:
            self.log.info("{} is {}".format(show, i))
            if show in i:
                found = True
                break
            else:
                found = False
        return found

    def verify_focus_is_on_menu(self, tester):
        self.log.step("Verifying focus is on Menu")
        self.screen.refresh()
        focused_item = self.strip_focus()
        if focused_item != tester.menu_labels.LBL_MENU_TITLE:
            raise AssertionError("Focus is not on Menu")

    def verify_domain_token_renew_silently(self, tester):
        self.log.info("verify domain token changes silently without affecting othe operation")
        self.wait_for_screen_ready(self.home_labels.LBL_HOME_SCREEN_NAME, timeout=600000)
        self.verify_home_title()
        self.pause(60)
        status = self.is_domain_token_getting_changed(timeout=2000)
        tester.guide_page.timestamp_test_end()
        if status:
            self.log.info("Domain token has changed {}".format(status))
        else:
            raise AssertionError("Domain Token has not renewed")

    def verify_error_overlay_code(self, suppress_log=None):
        self.log.info("Verifying Sign In overlay code")
        status = self.is_overlay_code_displayed(suppress_log=suppress_log)
        if status:
            self.log.info("Overlay is displayed {}".format(status))
        else:
            raise AssertionError("Overlay is not shown")

    def verify_version(self, version):
        self.log.info("verifying version...")
        version_list = version.split()
        self.log.info("version_list {}".format(version_list))
        for version in range(len(version_list)):
            current_version = float(re.findall(r'[\d\.\d]+', version_list[version])[0][:3])
            if current_version < 3:
                raise AssertionError("GLOBAL_ASSIST_TRIGGERING is not set correctly")

    def verify_device_serial_number(self):
        self.log.info("Verifying presence of device serial number")
        serial_num = self.screen.base.get_serial_number()
        if serial_num:
            self.log.info("Device serial number is : {}".format(serial_num))
        else:
            raise AssertionError("Device serial number not found")

    def verify_skip_this_step_option(self, screen_dump):
        self.log.info("Verifying focus is on 'Skip this step'.")
        screen_dump = self.screen.get_screen_dump_item()
        if not screen_dump.get('option')[1].get('hasfocus'):
            raise AssertionError("Focus is not on 'Skip this step'.")

    def verify_logcontrol_op_logs_present_in_adb_logs(self, tester):
        self.log.info("Verifying logcontrol operational 3rd part logs of device'.")
        tester.menu_assertions.verify_string_in_adb_logs(tester.home_labels.LBL_LOGCONTROL_OPERATIONAL_3rd_PARTY_LOGS)
        tester.menu_assertions.verify_string_in_adb_logs(tester.home_labels.LBL_OPERATIONAL_3rd_PARTY_LOGS)
        tester.menu_assertions.verify_string_in_adb_logs(tester.home_labels.LBL_NEWVALUE)
        tester.menu_assertions.verify_string_in_adb_logs(tester.home_labels.LBL_OLDVALUE)

    def verify_devicefeature_diagnostics_logs_in_adb_logs(self, tester):
        self.log.info("Verifying diagnostics feature attribute logs for device'.")
        tester.menu_assertions.verify_string_in_adb_logs(tester.home_labels.LBL_DIAGNOSTICS_FEATURE_ATTRIBUTE_MODEL)
        tester.menu_assertions.verify_string_in_adb_logs(tester.home_labels.LBL_FORCEBACKHAUL)

    def verify_ftux_animation_screen(self):
        self.log.info("Verifying if ftux animation screen is displayed")
        self.verify_view_mode(self.home_labels.LBL_FTUX_ANIMATION_VIEW_MODE)

    def verify_sls_endpoints_request_in_adb_logs(self, status=True):
        if status:
            str_log = self.screen.base.find_str_in_log(string=self.home_labels.LBL_SLS_ENDPOINTS_REQUEST, since="start")
            if not str_log:
                raise AssertionError(f"'{self.home_labels.LBL_SLS_ENDPOINTS_REQUEST}' is not found")
            else:
                self.log.info(f"'{self.home_labels.LBL_SLS_ENDPOINTS_REQUEST}' returned in request")
        else:
            str_log = self.screen.base.find_str_in_log(string=self.home_labels.LBL_SLS_ENDPOINTS_REQUEST, since="now")
            if str_log:
                raise AssertionError(f"'{self.home_labels.LBL_SLS_ENDPOINTS_REQUEST}' returned in request")
            else:
                self.log.info(f"'{self.home_labels.LBL_SLS_ENDPOINTS_REQUEST}' request is not sent")

    def verify_cache_file_modified(self, status=True, file_name=None, curr_file_time=None):
        """
        Verify cache file updated or not updated
        Args:
            file_name: name of cache file
            curr_file_time: file creation time
            status (bool): True, file should be updated
                           False, verifying file shouldn't be updated
        """
        new_file_time = self.screen.base.driver.get_cache_file_time(file_name)
        result = curr_file_time != new_file_time if status else curr_file_time == new_file_time
        msg_err = "not updated" if status else "updated"
        assert_that(result, f"{file_name} is {msg_err} curr: {curr_file_time} new: {new_file_time}")

    def verify_sleep_mode(self):
        """
        Verify device in sleep mode
        """
        self.log.info("Verifying device in sleep mode")
        power_state, wakefulness_state = self.screen.base.driver.get_power_state()
        assert_that(power_state, contains_string("OFF"), f"Device in {wakefulness_state}")

    def verify_gatekeeper_logs(self):
        gatekeeper_response = self.screen.base.find_str_in_log(string=self.home_labels.LBL_GK_LOGS_VERIFY, since="now")
        if gatekeeper_response:
            self.verify_predictions()
        else:
            self.log.info("Allow service connection is not received from gatekeeper, falling back to existing \n"
                          "mechanism and connecting to service")
            self.verify_predictions()

    def verify_notification_overlay_enabled(self):
        self.wait_for_screen_ready(timeout=30000)
        if self.is_overlay_shown():
            self.home_assertions.verify_overlay_title(self.home_labels.LBL_ENABLE_SYSTEM_NOTIFICATIONS)
            self.home_assertions.verify_overlay_body(self.home_labels.LBL_ESM_BODY_TEXT)
            self.home_assertions.verify_overlay_line_separator()
            self.menu_assertions.verify_menu_item_available(
                [self.home_labels.LBL_HELP, self.home_labels.LBL_CLOSE],
                mode="equal")
            self.log.info("Enable System notification overlay is displayed")
            self.home_page.select_menu(self.home_labels.LBL_CLOSE)
            return True
        else:
            raise AssertionError("Enable System notification is not displayed")

    def verify_notification_overlay_disabled(self):
        self.wait_for_screen_ready(timeout=30000)
        if self.is_overlay_shown():
            raise AssertionError("Enable System notification is displayed")

    def verify_pc_lock_icon(self):
        is_pc_lock_icon = True
        if self.is_in_strip(self.home_labels.LBL_MENU_LOCK_SHORTCUT_ICON, "in") is False:
            is_pc_lock_icon = False
        if not is_pc_lock_icon:
            raise AssertionError("PC lock icon not found in home screen menu shortcut")
