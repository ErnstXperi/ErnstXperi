"""
Created on Aug 1, 2017

@author: sghosh
"""

import re
import os
import timeit
import time
from datetime import datetime, timedelta
import shutil
import pytesseract
import yaml
from PIL import Image

import pytest

from core_api.stb.assertions import CoreAssertions
from set_top_box.test_settings import Settings
from tools.logger.logger import Logger
from set_top_box.client_api.home.en_us.labels import HomeLabels
from core_api.stb.base import UIObjError
from set_top_box.conf_constants import PlatformList, HydraBranches, MindEnvList, NotificationSendReqTypes, \
    RemoteCommands
from shared_components.shared_constants import SharedUrls
from tools.tcdui_config_parser import TcduiConf
from mind_api.url_resolver import UrlResolver


class HomePage(CoreAssertions):
    log = Logger(__name__)
    EXM_SCREEN_NAME = "HomeMainScreen"
    # TODO
    # Declare home_labels in home/conftest.py to support LabelFactory
    home_labels = HomeLabels()

    def __init__(self, screen):
        super().__init__(screen)

    def is_home_screen_active(self):
        """
        Method to detect is current screen is home screen. It bases on screen title and view mode
        Returns:
        """
        if self.screen_title() and self.home_labels.LBL_HOME_SCREENTITLE in self.screen_title() and \
                self.view_mode() and "HomeScreen" in self.view_mode() and\
                self.screen.base.verify_foreground_app(Settings.app_package):
            active = True
        else:
            active = False
        self.log.info("Home screen visibility status:{}. Current screen is '{}'".format(active, self.view_mode()))
        return active

    def wait_for_sign_in_form(self):
        self.log.info("waiting for sign in form ")
        self.screen.base.wait_ui_element_appear(self.home_labels.LOC_SAML_USERNAME, 180000)
        if not self.screen.base.is_text_present(self.home_labels.LOC_SAML_USERNAME):
            self.log.info("raise error - sign in form not loaded on specified time")
            raise UIObjError("Form for login not found on screen")

    def is_ftux_foreground(self):
        """
        Method to detect is current screen is ftux. It bases on screen title and view mode
        Returns: None
        """
        return self.screen_title() and self.home_labels.LBL_FTUX_TITLE in self.screen_title() or \
            self.view_mode() and self.home_labels.LBL_FTUX_VIEW_MODE in self.view_mode()

    def is_license_plate_foreground(self):
        """
        Method to detect is current screen is License Plate. It bases on screen title and view mode
        Returns: None
        """
        return self.screen_title() and self.home_labels.LBL_LICENSE_PLATE in self.screen_title() or \
            self.view_mode() and self.home_labels.LBL_LICENSE_PLATE_VIEW in self.view_mode()

    def is_sign_in_foreground(self):
        return self.screen_title() and self.home_labels.LBL_SIGN_IN_TITLE in self.screen_title() or \
            self.view_mode() and self.home_labels.LBL_SIGN_IN.lower() in self.view_mode().lower()

    def wake_up_box(self):

        for i in range(3):
            fg_package = self.screen.base.get_foreground_package()
            if fg_package != Settings.app_package:
                self.screen.base.press_up()
                self.pause(i * 2 + 3)
            else:
                break
        else:
            self.log.warning("Foreground package from ui dump is: {}".format(fg_package))

    def sign_in_and_wake_up(self):
        """
        Method to sign in to hydra app
        """
        self.wake_up_box()
        self.screen.refresh()
        if self.is_sign_in_foreground() or self.is_license_plate_foreground():
            self.sign_in()

    def sign_in(self, wait_home=True):
        """
        Method to sign in to hydra app

        Args:
            wait_home (bool): True - waiting untill Home screen is shown, False - no waiting right after sign-in
        """
        self.wait_loading_indicator_disappear()
        self.wait_for_screen_ready("Screen", timeout=120000)
        self.screen.refresh()
        if self.is_license_plate_foreground():
            self.log.step("LP Sign In...")
            self.issue_activation_code()
            a_code = self.get_activation_code()
            self.iptv_prov_api.bind_device_with_activation_code(
                a_code, self.service_api.getPartnerCustomerId(Settings.tsn), self.service_api.get_mso_partner_id(Settings.tsn))
            self.wait_loading_indicator_disappear()
            self.screen.refresh()
            return
        if self.is_sign_in_foreground():
            self.log.step("SAML Sign In...")
            self.verify_ui_element_on_screen(self.home_labels.LOC_SAML_USERNAME, 180000)
            if self.screen.base.is_text_present(self.home_labels.LOC_SAML_USERNAME):
                self.log.step("SAML Sign In...")
                self.screen.base.clear_text_by_locator(self.home_labels.LOC_SAML_USERNAME)
                self.screen.base.click_by_locator(self.home_labels.LOC_SAML_USERNAME)
                self.screen.base.type_text(Settings.username)
                self.screen.base.click_by_locator(self.home_labels.LOC_SAML_PASSWORD)
                self.screen.base.type_text(Settings.password)
                if not self.screen.base.is_text_present(self.home_labels.LOC_SAML_SIGN_IN):
                    self.press_back_button()
                    self.pause(1)
                self.screen.base.click_by_locator(self.home_labels.LOC_SAML_SIGN_IN)
                if wait_home:
                    self.wait_for_screen_ready(self.EXM_SCREEN_NAME, timeout=90000)
                self.screen.refresh()

    def back_to_home(self):
        self.log.step("Back to Home...")

        loop_attempts = 0
        while self.screen_title() is None or self.home_labels.LBL_HOME_SCREENTITLE not in self.screen_title():
            self.screen.base.press_back()
            self.screen.refresh()
            loop_attempts += 1
            if loop_attempts > 10:
                break

        self.log.info("Back to First Menu Item...")
        for i in range(10):
            self.screen.base.press_left()
            self.screen.refresh()

        self.dismiss_popup_overlay(self)

    def verify_exit_video_overlay(self):
        self.log.info("Verifying Exit overlay is displayed on LiveTv")
        self.screen.refresh()
        if not self.is_overlay_shown():
            self.log.info("Overlay is not appeared.")
            overlay = False
        elif self.get_overlay_title() != self.home_labels.LBL_EXIT_VIDEO_OVERLAY:
            self.log.info("Are You Sure You Want to Exit overlay is not appeared.")
            overlay = False
        else:
            self.log.info("Are You Sure You Want to Exit overlay is appeared.")
            overlay = True
        return overlay

    def exit_video_overlay(self):
        self.log.info("Checking for exit video overlay")
        if self.verify_exit_video_overlay():
            if Settings.is_unmanaged():
                self.select_menu(self.home_labels.LBL_EXIT_VIDEO)
            else:
                self.select_menu(self.home_labels.LBL_GO_TO_HOME)

    def back_to_home_short(self):
        """
        Managed only
        method to get HOME screen using home btn.
        """
        self.log.step("Back to Home short...")
        self.screen.refresh()

        for i in range(5):
            self.dismiss_popup_overlay(self)
            if self.is_overlay_shown():
                # select Go to Home Menu to dismiss overlay and reach home screen
                self.exit_video_overlay()
                # press back to close overlay if it showed
                self.screen.base.press_back()
                self.screen.get_json()  # quick refresh
            elif not self.is_home_screen_active():
                self.screen.base.press_home(100)
                self.wait_for_screen_ready()
                self.screen.refresh()
            else:
                break
        else:
            current_screen = self.view_mode()
            if self.get_error_overlay_status():
                overlay_code = self.screen.get_screen_dump_item('overlayTitleText')
                raise LookupError(f"Error overlay displayed after home screen retries. "
                                  f"Overlay code:{overlay_code} Current view:{current_screen}")
            raise LookupError(f"After {5} retries still not at home screen. Current view:{current_screen}")

        self.wait_for_ui_element_exists('stripitem')
        # set focus to main strip if focus on prediction strip
        if self.is_prediction_strip_focused():
            self.press_up_button()
            self.screen.get_json()

        # move focus to first position (left)
        if not self.is_in_strip(self.home_labels.LBL_MENU_SHORTCUT):
            steps_to_move = 10
        else:
            strip = self.get_strip_array()
            steps_to_move = self.get_focus_index(strip)
        if steps_to_move:
            for i in range(steps_to_move):
                self.press_left_button()
            self.screen.get_json()

    def is_prediction_strip_focused(self):
        """
        Function to check is prediction strip on HomeScreen has focus
        Returns:
            bool
        """
        focused_item = self.strip_focus()
        self.log.info("Focused strip item {}".format(focused_item))
        all_menu_options = [self.home_labels.LBL_NOTIFICATION_SHORTCUT, ]
        all_menu_options.extend(self.home_labels.LBL_HOME_MENU_ITEMS)
        result = focused_item and focused_item not in all_menu_options
        return result

    def go_to_home_screen(self, tester):
        self.screen.base.press_back()
        self.screen.base.press_home()
        home_screen = tester.home_labels.LBL_HOME_SCREEN_NAME
        current_screen = self.get_screen_name()
        if (home_screen == current_screen):
            self.log.info("We are on central screen")
        else:
            self.log.info("Trying again")
            self.screen.base.press_back()
            self.screen.base.press_home()
        strip_list = []
        strip_list = (self.screen.get_json()['xml']['stripitem'])
        for item in strip_list:
            if "hasfocus" in item.keys():
                if "showTitle" in item.keys():
                    self.screen.base.press_up()
                else:
                    break
        strip = tester.home_labels.LBL_HOME_MENU_ITEMS
        current_focus_index = strip.index(self.strip_focus())
        if (current_focus_index > 0):
            for i in range(current_focus_index):
                self.screen.base.press_left()

        # Dismiss overlay popup...
        if self.is_item_in_key('overlaytitle'):
            self.screen.base.press_enter()
            self.pause(5)
            self.screen.refresh()
        self.screen.refresh()

    def select_done(self, times, screenname=EXM_SCREEN_NAME):
        self.log.step("Ftux screen detected foreground, calling routine to skip it")
        for _ in range(times):
            self.screen.base.press_down()
            self.press_enter()
        self.wait_for_screen_ready(screenname, timeout=15000)
        self.screen.refresh()

    def select_skip_this_step_ftux_pcsetting_screen(self):
        self.log.step("Ftux pcsetting screen detected foreground, calling routine to skip it")
        self.press_right_button(refresh=False)
        self.press_ok_button(refresh=False)

    def issue_activation_code(self):
        """
        Updating activation code by pressing on get activation code button
        """
        self.select_menu(self.home_labels.LBL_GET_ACTIVATION_CODE)

    def get_bind_url(self):
        """
        Getting bind url from screen dump
        @return: url
        @rtype: string
        """
        raw_url = self.screen.get_screen_dump_item('leftpaneltext')
        reg = re.compile(r"http.*(?=&lt)")
        search = reg.search(raw_url)
        if search:
            return search.group(0)
        pytest.fail("Url for binding not found on screen")

    def get_activation_code(self):
        return self.screen.get_screen_dump_item('activationcode')

    def select_menu_shortcut(self, menu):
        self.log.step("Selecting {} shortcut".format(menu))
        if isinstance(menu, list):
            menu = menu[0]
            self.log.info(f"Select_menu_shortcut() received a list. Trunc to one element: menu={menu}")
        if menu == self.home_labels.LBL_LIVETV_SHORTCUT:
            self.goto_live_tv()
        else:
            if not self.is_strip_focus():
                self.screen.base.press_up()
            # loop_attempts = 0
            # while menu not in self.strip_list():
            #     self.screen.base.press_right()
            #     self.screen.refresh()
            #     loop_attempts += 1
            #     if loop_attempts > 10:
            #         break
            self.select_strip(menu)

    def nav_to_predictions_strip(self):
        """
            TODO
            Some refactoring needed for nav_to_predictions_strip method.
            Fails to access prediction strip after navigating to "notifications" menu option.
        """
        self.log.info("Navigating to Predictions...")
        self.back_to_home_short()
        loop_attempts = 0
        while not self.is_prediction_strip_focused():
            self.screen.base.press_down()
            self.screen.refresh()
            loop_attempts += 1
            if loop_attempts > 10:
                break

    def select_prediction_focus(self):
        if self.is_strip_focus():
            self.screen.base.press_enter(3000)
        self.screen.refresh()

    def go_to_search(self, tester):
        self.log.step("Launching search screen")
        self.back_to_home_short()
        self.select_menu_shortcut_num(tester, self.home_labels.LBL_SEARCH_SHORTCUT)
        self.wait_for_screen_ready("SearchMainScreen")

    def goto_prediction(self):
        self.log.step("Going to prediction strip")
        self.screen.base.press_down()
        self.screen.get_json()  # no screen transition here

    def nav_to_show_on_prediction_strip(self, show_name):
        self.log.step(f"seeking for {show_name} in prediction strip")
        counter = 0
        root = self.strip_focus()
        current = root
        while current != show_name:
            self.press_right_button()
            self.pause(2)  # no event for that
            self.screen.get_json()
            current = self.strip_focus()
            counter += 1
            if current == root or counter > 40:
                raise Exception(f"{show_name} wasn't found on prediction strip")
        self.press_enter()
        self.screen.refresh()

    def press_enter(self):
        self.screen.base.press_enter()

    def verify_wtw_secondary(self, tester):
        self.log.step("Verifying What to Watch secondary screen")
        self.wait_for_screen_ready(tester.home_labels.LBL_WTW_PRIMARY_SCREEN)
        self.screen.refresh()
        if not Settings.is_apple_tv() and not Settings.is_dev_host():
            self.screen.base.press_down()
        self.pause(1)
        tester.home_assertions.verify_w2w_preview_title()

    def trigger_EAS_validate_eas_response(self, tester, tsn):
        self.log.step("Triggering EAS")
        text = self.home_labels.LBL_EAS_MESSAGE
        self.service_api.get_EAS(tsn, text)
        tester.home_assertions.verify_EAS_screen()

    def wake_up(self):
        self.log.info("Waking up box by pressing Home Button")
        if Settings.is_unmanaged():
            self.screen.base.press_back()
        else:
            self.screen.base.press_home(time=3000)

    def voice_search(self, tester):
        self.screen.base.press_voice_search()
        self.screen.refresh()
        tester.home_assertions.verify_voice_search()

    def voice_button_available(self):
        self.log.step("Checking if Voice button is available or not")
        return self.screen.base.is_voice_button_available()

    def bookmark_from_prediction(self, tester):
        found = False
        self.press_info_button()
        self.wait_for_screen_ready(tester.watchvideo_labels.LBL_INFO_CARD)
        if Settings.hydra_branch() < Settings.hydra_branch("b-hydra-streamer-1-11"):
            self.select_menu_item("More Info")
        else:
            self.select_menu_item("Options")
            self.select_menu_item("See More Info")
        self.wait_for_screen_ready()
        self.screen.base.press_left()
        self.screen.refresh()
        self.select_menu_by_substring("Upcoming")
        self.pause(1)
        self.screen.base.press_enter(time=2000)
        self.screen.refresh()
        self.nav_to_menu_by_substring("OnePass")
        self.screen.refresh()
        self.wait_for_screen_ready()
        content = self.get_preview_panel()['title']
        self.screen.refresh()
        if self.is_in_strip("Bookmark", matcher_type="in"):
            found = True
            self.select_string_by_substring("Bookmark")
        else:
            found = False
        return content, found

    def press_info_button(self):
        self.screen.base.press_info()

    def select_menu_item(self, menu):
        self.screen.refresh()
        self.select_menu(menu)

    def create_one_pass(self, tester):
        title = self.screen.get_screen_dump_item('title')
        strip = self.strip_list()
        if tester.home_labels.LBL_CREATE_ONEPASS in strip:
            self.log.info(f"Creating One Pass for {title}")
            self.select_menu_shortcut(tester.home_labels.LBL_CREATE_ONEPASS)
            tester.my_shows_page.change_recording_or_onepass_options([tester.my_shows_labels.LBL_RECORD], False)
            self.select_menu_item(tester.home_labels.LBL_CREATE_ONEPASS_WITH_THESE_OPTIONS)
            self.verify_whisper_shown(tester.home_labels.LBL_ONEPASS_WHISPER)
        elif tester.home_labels.LBL_MODIFY_ONEPASS in strip:
            self.screen.base.press_back()
            self.log.info("One pass already exists for {}".format(title))
        else:
            raise AssertionError('One Pass Menu option is not available')
        return title

    def nav_to_next_menu_list_page(self):
        if self.is_menu_list() and self.is_menu_focus():
            menu = self.menu_list()
            last_menu_index = menu.index(menu[-1])
            current_focus_index = self.return_menu_focus_index()
            index_diff = current_focus_index - last_menu_index
            index_diff = index_diff * -1
            for i in range(index_diff):
                self.screen.base.press_down()
            self.wait_for_screen_ready()
            self.screen.refresh()
            next_page_menu_list = self.menu_list()
            if menu != next_page_menu_list:
                return next_page_menu_list
            else:
                self.log.info("Reached end of menu list")
                return False

    def nav_to_top_menuitem_in_list(self):
        limit = 0
        if self.is_menu_list() and self.is_menu_focus():
            self.screen.refresh()
            menu = self.menu_list()
            menu1 = []
            while menu1 != menu and limit < 10:
                menu = menu1
                for i in range(1, 14):
                    self.screen.base.press_up()
                self.screen.refresh()
                menu1 = self.menu_list()
                limit += 1
            self.log.info("Reached top of the menu list")

    def goto_livetv_short(self, tester):
        """
        Description:
            The same functionality as in guide.go_to_livetv() but without UI interactions on Android streamers
            and less interactions on AppleTV
        """
        if not Settings.is_apple_tv() and not Settings.is_dev_host():
            self.log.step("Navigating to LiveTV using 'LiveTV' button")
            self.press_livetv_button()
            if self.view_mode() != tester.liveTv_labels.LBL_LIVETV_VIEWMODE:
                self.press_button_function()
            if self.view_mode() != tester.liveTv_labels.LBL_LIVETV_VIEWMODE:
                raise Exception("LiveTV button didn't navigate to LiveTV.")
        else:
            self.log.step("Navigating to LiveTV by HOME menu")
            self.back_to_home_short()
            self.select_strip(tester.home_labels.LBL_WATCHVIDEO_SHORTCUT)
            self.wait_for_screen_ready()
            try:
                self.verify_view_mode(tester.liveTv_labels.LBL_LIVETV_VIEWMODE)
            except AssertionError as err:
                self.log.info("First try to get to LiveTV was failed. Fail err: {}".format(err))
                self.screen.base.press_up()
                self.wait_for_screen_ready(tester.liveTv_labels.LBL_ONELINE_GUIDE)
                self.screen.base.press_enter()
        self.screen.refresh()

    def goto_live_tv(self, channel_number=None, confirm=True, highlight_live_program=True):
        """
        Starting Live TV by opening currently airing program in the Guide, go to the Home screen first

        If highlighted program has been finished by the time the test entered the Guide,
        it search the currently airing live TV program by going to the right

        Args:
            channel_number (int): channel number to tune to; it does not tune to a channel if None
            confirm (bool):
            highlight_live_program (bool): True - calling self.guide_page.get_live_program_name() to highlight
                                                  currently airing program;
                                           False - skip self.guide_page.get_live_program_name() calling
        """
        self.log.info("Navigating to LIVE TV via Guide")
        self.back_to_home_short()
        self.select_menu_shortcut(self.home_labels.LBL_GUIDE_SHORTCUT)
        self.wait_for_screen_ready()
        self.screen.refresh()
        self.verify_screen_title(self.home_labels.LBL_GUIDE_SCREENTITLE)
        if channel_number:
            self.enter_channel_number(channel_number, confirm=confirm)
        self.pause(5)
        if highlight_live_program:
            # We do not need program name from a Guide Cell at this point, so no rasing errors if no text on the cell
            self.guide_page.get_live_program_name(self, raise_error_if_no_text=False)
        self.screen.base.press_enter()
        self.wait_for_screen_ready(self.home_labels.LBL_RECORD_OVERLAY)
        self.screen.refresh()
        if self.is_overlay_shown():
            self.log.info("Overlay displayed")
            menu_list = self.menu_list()
            if self.home_labels.LBL_CHANNEL_OPTIONS_WATCH_NOW in menu_list:
                self.select_menu_item(self.home_labels.LBL_CHANNEL_OPTIONS_WATCH_NOW)
            self.log.info(f"Selecting {self.home_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE} on Record Overlay")
            if self.home_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE in menu_list:
                self.select_menu_item(self.home_labels.LBL_PROGRAM_OPTIONS_WATCH_LIVE)

    def skip_ftux_animation(self):
        if self.is_ftux_animation_view_mode():
            self.screen.base.press_enter()
            self.screen.base.press_enter()
            self.screen.refresh()
        else:
            self.log.info("Not in FTUX Animation view mode. Current view mode - {}.".format(self.view_mode()))

    def ftux_onepass_selection_and_verification(self, tester, app_package, username):
        self.log.step("Launching One Pass Quick Select screen")
        if Settings.is_unmanaged():
            self.unamanged_sign_in(tester, app_package, username, Settings.password)
        self.skip_ftux(skip_animation=True, skip_onepass=False, skip_apps=False, skip_pcsetting=False)
        tester.home_assertions.verify_ftux_view_mode()
        self.log.info("Selecting and creating one passes")
        for i in range(3):
            self.press_enter()
            self.screen.base.press_left()
            tester.home_assertions.verify_ftux_one_pass_selections()
            self.screen.base.press_right()
        self.select_done(times=1, screenname=self.home_labels.LBL_STREAMINGAPPS_FTUX)

    def unamanged_sign_in(self, tester, app_package, username, password, wait_home=True):
        """
        Unmanaged Sign-In

        Args:
            wait_home (bool): True - waiting untill Home screen is shown, False - no waiting right after sign-in
        """
        self.log.info(f"Signing In with userid : {username} and password : {password}")
        self.screen.base.launch_application(app_package)
        self.screen.refresh()
        if self.is_overlay_shown():
            self.screen.base.press_enter()
        self.wait_for_screen_ready(tester.home_labels.LBL_SIGN_IN or tester.home_labels.LBL_LICENSE_PLATE)
        self.log.info("Waiting for Signin screen")
        self.wait_loading_indicator_disappear()
        self.wait_for_screen_ready(timeout=40000)
        self.screen.refresh()
        if self.screen_title():
            if "SIGN IN" in self.screen_title():
                self.log.info("Device... trying to sign in...{}".format(Settings.platform))
                self.sign_in(wait_home)
        if wait_home:
            self.wait_loading_indicator_disappear()
            self.wait_for_screen_ready(timeout=60000)
        if self.screen.base.get_foreground_package() != app_package:
            self.screen.base.launch_application(app_package)
            self.wait_for_screen_ready(timeout=40000)
            self.proceed_with_sign_in(wait_home)
        self.screen.refresh()
        if wait_home:
            if not self.is_home_screen_active():
                current_screen = self.view_mode()
                raise LookupError(f"After {2} retries still not at home screen. Current view:{current_screen}")

    def unamanged_sign_out(self, tester):
        self.log.info("Signing Out of the device")
        tester.home_assertions.verify_menu_item_available(self.home_labels.LBL_MENU_SHORTCUT)
        self.select_menu_shortcut(self.home_labels.LBL_MENU_SHORTCUT)
        self.nav_to_top_of_list()
        tester.menu_page.navigate_by_strip(self.home_labels.LBL_SYSTEM_AND_ACCOUNT)
        self.select_menu_by_substring(self.home_labels.LBL_SIGN_OUT)
        self.wait_for_screen_ready(self.home_labels.LBL_EXIT_APP_OVERLAY)
        self.select_menu_item(self.home_labels.LBL_OK)
        self.wait_for_screen_ready()

    def select_menu_shortcut_num(self, tester, shortcut, refresh=True):
        """
        Description:
        Used for fast navigating to home menu shortcuts with NUM by index. NUM shortcuts are the same for all devices.
        Decreases test-run time by exclusion of unnecessary refreshes.
        :param shortcut: str, index of shortcut
        :param refresh: bool, screen refresh
        """
        try:
            self.log.step(f"Getting num key for {shortcut}")
            shortcut_number = self.get_shortcut_key(tester, shortcut)
            shortcut_src = "MindAPI"
        except (TypeError, KeyError) as Err:
            self.log.info(f"Got exception {Err}, getting shortcut keys from labels file")
            shortcut_number = self.home_labels.LBL_SHORTCUTS_NUM.get(shortcut)
            shortcut_src = "Labels"
        self.log.step(f"Selecting shortcut in home menu: '{shortcut}'. "
                      f"Shortcut number: '{shortcut_number}' got from: {shortcut_src}")
        self.screen.base.type_number(shortcut_number)
        if refresh:
            self.pause(0.5)  # waiting for transitioning to start
            self.screen.refresh()

    def go_to_guide(self, tester):
        self.log.step("Navigating to Guide Screen")
        self.back_to_home_short()
        self.select_menu_shortcut_num(tester, self.home_labels.LBL_GUIDE_SHORTCUT)
        self.wait_for_screen_ready("GridGuide")

    def go_to_my_shows(self, tester):
        self.back_to_home_short()
        self.select_menu_shortcut_num(tester, self.home_labels.LBL_MYSHOWS_SHORTCUT)
        self.wait_for_screen_ready(tester.my_shows_labels.LBL_MYSHOWS_SCREEN)

    def nav_to_all_episodes_listview(self):
        self.screen.refresh()
        viewmode = self.screen.get_screen_dump_item('viewMode')
        self.log.info('Type of screen is {}:'.format(viewmode))
        self.pause(5)
        if viewmode == 'actions.series.SeriesScreenView':
            self.menu_navigate_left_right(1, 0)
            self.screen.refresh()
            print('menu:', self.menu_list())
            self.nav_to_menu_by_substring(self.home_labels.LBL_ALL_EPISODES)
            self.pause(5)
            self.screen.base.press_right()
        elif viewmode == 'action.series.EpisodesScreenView':
            self.nav_to_menu(self.home_labels.LBL_ALL_EPISODES)
            self.screen.base.press_left()
            self.screen.base.press_enter()
            self.wait_for_screen_ready('AllEpisodesList', timeout=20000)

    def get_OTT_icon_from_screen(self):
        self.screen.refresh()
        strip_dump = self.screen.get_screen_dump_item('stripitem')
        if strip_dump[0].get('availableOn') is None:
            availableOn = strip_dump[1].get('availableOn')
            if availableOn is None:
                return None
            elif isinstance(availableOn, list):
                for i in range(len(availableOn)):
                    if availableOn[i] is not None:
                        return availableOn[i]
            elif isinstance(availableOn, dict):
                return availableOn
        else:
            return strip_dump[0].get('availableOn')

    def verify_list_view_episode_screen(self, tester):
        # flags for identification of ott and tv item
        self.log.step("Verifying episode list view")
        self.wait_for_screen_ready(timeout=30000)
        flag_ott_item = 0
        flag_tv_item = 0
        right_selected = 0
        tv_verification_done = 0
        ott_verification_done = 0
        for item in range(10):
            # to get all the available source icons on screen
            strip_list_item = self.get_OTT_icon_from_screen()
            self.log.info('Icon found is :{}'.format(strip_list_item))
            if strip_list_item is None:
                self.screen.base.press_right()
                right_selected += 1
            else:
                icon_name = strip_list_item['imagename']
                self.log.info('Icon name is :{}'.format(icon_name))
                if isinstance(strip_list_item['imagename'], str):
                    icon_name = [strip_list_item['imagename']]
                for eachitem in icon_name:
                    if tester.home_labels.LBL_WHAT_TO_WATCH_TV_ICON in eachitem:
                        self.log.info('checking for TV icon')
                        flag_tv_item = 1
                for OTT_item in tester.home_labels.LBL_WTW_ICON_LIST_OTT:
                    for eachitem in icon_name:
                        if OTT_item in eachitem:
                            print('OTT item inside')
                            flag_ott_item = 1
                            break
                self.log.info('value of ott flag:{}'.format(flag_ott_item))
                self.log.info('value of tv flag:{}'.format(flag_tv_item))
                if flag_ott_item == 1 and flag_tv_item == 1:
                    self.log.info('Both OTT and Tv icons are present')
                    self.screen.base.press_enter()
                    self.nav_to_all_episodes_listview()
                    tester.home_assertions.verify_all_episodes_list_view('streaming_icon')
                    return
                elif flag_ott_item == 1 and ott_verification_done == 0:
                    # above loop is entered only when OTT icon is present and it is not verified before
                    # this is used inorder to avoid multiple checks for OTT
                    self.log.info('Only OTT icons are present')
                    self.screen.base.press_enter()
                    self.nav_to_all_episodes_listview()
                    ott_verification_done = 1
                    right_selected = item
                    tester.home_assertions.verify_all_episodes_list_view('streaming_icon')
                    self.screen.base.press_back()
                elif tv_verification_done == 0 and flag_tv_item == 1:
                    # above loop is entered only when TV icon is present and it is not verified before
                    # this is used inorder to avoid multiple checks for TV
                    self.log.info('Only Tv icons are present')
                    self.screen.base.press_enter()
                    self.nav_to_all_episodes_listview()
                    tester.home_assertions.verify_all_episodes_list_view()
                    tv_verification_done = 1
                    right_selected = item
                    self.screen.base.press_back()
                    self.screen.refresh()
                # for loop is needed because the focus will be shifted to very first item after episode screen validation
                # when returned to primary screen
                for i in range(right_selected + 1):
                    self.log.info('No of times right selection is done:{}'.format(right_selected))
                    self.screen.base.press_right()
        else:
            self.log.error("No Tv+OTT icons are present till the end of strip list")
            return False

    def go_to_what_to_watch(self, tester):
        self.log.info("Going to What to Watch screen")
        self.back_to_home_short()
        self.pause(30)
        self.select_menu_shortcut_num(tester, tester.home_labels.LBL_WHATTOWATCH_SHORTCUT)
        self.wait_for_screen_ready(tester.home_labels.LBL_WHATTOWATCH_SHORTCUT)
        self.screen.refresh()

    def go_to_watch_tv(self, tester):
        self.log.info("Going to Watch TV screen")
        self.back_to_home_short()
        self.pause(30)
        self.select_menu_shortcut_num(tester, tester.home_labels.LBL_LIVETV_SHORTCUT)
        self.wait_for_screen_ready(tester.home_labels.LBL_LIVETV_SHORTCUT)
        self.screen.refresh()

    def locate_socu_program_in_WTW(self, tester):
        self.log.step("Searching for SOCU offer in WTW screen")
        self.wait_for_screen_ready()
        for i in range(12):
            self.screen.base.press_enter()
            self.wait_for_screen_ready()
            if tester.my_shows_page.is_series_screen_view_mode(refresh=True):
                self.select_first_item_in_live_and_upcoming()
            tester.program_options_assertions.verify_action_view_mode(self)
            tester.program_options_assertions.verify_biaxial_screen()
            self.screen.refresh()
            if self.is_in_strip(tester.home_labels.LBL_WTW_SOCU_ICON):
                self.log.info("Program with SOCU icon found")
                return True
            self.screen.base.press_back()
            self.wait_for_screen_ready()
            self.screen.base.press_right()
            self.wait_for_screen_ready()

    def get_prediction_without_ott(self, tester):
        self.log.info("get prediction without ott")
        recordable_channels = tester.service_api.get_recordable_channels()
        shows = tester.service_api.get_feed_item_find_results("/predictions")
        for show in shows:
            providers = tester.service_api.get_onDemandAvailabilityList(show[1])
            if not providers and \
                    tester.service_api.is_prediction_from_recordable_channel(show[1], recordable_channels):
                self.log.step(show)
                return show
        return False

    def get_prediction_with_ott(self, tester):
        self.log.info("get prediction with ott")
        recordable_channels = tester.service_api.get_recordable_channels()
        shows = tester.service_api.get_feed_item_find_results("/predictions")
        for show in shows:
            providers = tester.service_api.get_onDemandAvailabilityList(show[1])
            if providers and \
                    tester.service_api.is_prediction_from_recordable_channel(show[1], recordable_channels):
                return show
        return False

    def get_recordable_prediction_content(self, tester):
        self.log.info("Get recordable content from prediction")
        recordable_channels = tester.service_api.get_recordable_channels()
        shows = tester.service_api.get_feed_item_find_results("/predictions")
        for show in shows:
            if tester.service_api.is_prediction_from_recordable_channel(show[1], recordable_channels):
                self.log.info("Show :{}".format(show))
                return self.convert_special_chars(show)
        return False

    def home_button_to_my_shows(self):
        """
        :description:
        Method which simulate pressing Home/TiVo button on RCU. Probably will be used only for
        test_105147819_pressing_home_to_my_shows
        :return:
        """
        self.screen.base.press_home(100)
        self.log.info("Home/TiVo button was pressed on Home screen")
        self.wait_for_screen_ready()
        self.screen.refresh()

    def get_shortcut_key(self, tester, menu_item):
        # TODO: getter MUST raise exeption if it cant get requested data. DO NOT RETURN None
        self.log.info("Getting HOME Shortcut key for menu item : {}".format(menu_item))
        shortcuts = self.service_api.get_quick_menu_instructions()
        if shortcuts is None:
            self.log.info("Unable to get HOME shortcut keys from service query")
            return None
        else:
            menu_shortcuts = dict((k.upper(), v) for k, v in shortcuts.items())
            self.log.info(f"Menu shortcuts: {menu_shortcuts}")
            if menu_item in menu_shortcuts.keys():
                num = menu_shortcuts[menu_item]
                num_key = num[-1]
                self.log.info("Obtained shortcut key for menu item {} is : {}".format(menu_item, num_key))
                return num_key
            elif menu_item.encode('iso-8859-1').decode() in menu_shortcuts.keys():
                num = menu_shortcuts[menu_item]
                num_key = num[-1]
                self.log.info("Obtained shortcut key for menu item {} is : {}".format(menu_item, num_key))
                return num_key
            else:
                self.log.info("Unable to get the shortcut key for menu item {}".format(menu_item))
                return None

    def wake_up_device_voice_search(self):
        self.log.step("Waking up the device using Tivo Voice/GA Voice search")
        if self.voice_button_available():
            self.screen.base.press_voice_search()
        else:
            self.screen.base.press_google_voice()

    def open_device_setting(self, text):
        self.log.step("Open Device settings using Google assistant")
        self.screen.base.tell_device_assistant(text)

    def goto_notification(self, tester):
        self.log.info("Navigating to NOTIFICATIONS")
        self.back_to_home_short()
        self.select_menu_shortcut(self.home_labels.LBL_NOTIFICATION_SHORTCUT)

    def verify_key_press_to_wake_up_device(self, tester):
        self.log.info("To verify the remote key press to wake up the device")
        self.press_home_and_verify_screen(tester)

    def launch_app_from_GA(self, tester, app):
        self.log.step("Open OTT app {}".format(app))
        tester.home_page.back_to_home_short()
        self.screen.base.tell_device_assistant(app)

    def jump_forward_by_minutes_using_GA(self, minutes):
        self.log.step("Jump forward by X minute while streaming content")
        self.screen.base.tell_device_assistant("Jump forward by " + str(minutes) + " minutes")

    def launch_series_voice_strip_tile(self, program):
        program = re.escape(program)
        self.log.step("Searching for {}".format(program))
        self.screen.base.tell_device_assistant(program)

    def dump_without_TTS_ON(self, tester, channel=None, myshows=False, guide=False, live=False, olg=False):
        self.log.step("Taking dump with TTS Off")
        self.screen.base.TTS_on_off()
        tester.menu_page.disable_closed_captioning(tester)
        if myshows:
            self.log.step("Launching My shows")
            tester.home_page.go_to_my_shows(tester)
            self.screen.refresh()
            dump = self.screen.get_screen_dump_item()
        elif guide:
            self.log.step("Launching Guide")
            tester.home_page.go_to_guide(tester)
            self.screen.refresh()
            dump = self.screen.get_screen_dump_item()
        elif live:
            self.log.step("Launching Live TV")
            tester.home_page.go_to_guide(tester)
            channel = tester.service_api.get_random_live_channel_rich_info(episodic=True, movie=False,
                                                                           channel_count=2,
                                                                           entitled=True,
                                                                           filter_channel=True)
            self.log.info(f"Channels returned from service: {channel}")
            if channel is None:
                pytest.fail("Could not find any episodic channel")
            tester.guide_page.enter_channel_number(channel[0][0])
            tester.guide_page.get_live_program_name(tester, diff=15)
            tester.guide_page.select_and_watch_program(tester)
            tester.guide_assertions.verify_live_playback()
            self.screen.base.press_info()
            self.screen.refresh()
            dump = self.screen.get_screen_dump_item()
            tester.home_page.go_to_guide(tester)
            tester.guide_page.enter_channel_number(channel[1][0])
            tester.guide_page.get_live_program_name(tester)
            tester.guide_page.select_and_watch_program(tester)
        else:
            self.log.step("Launching One Line Guide")
            tester.home_page.go_to_guide(tester)
            channel = tester.service_api.get_random_live_channel_rich_info(episodic=True, movie=False,
                                                                           channel_count=2,
                                                                           entitled=True,
                                                                           filter_channel=True)
            if channel is None:
                pytest.fail("Could not find any episodic channel")
            tester.guide_page.enter_channel_number(channel[0][0])
            tester.guide_page.get_live_program_name(tester, diff=15)
            tester.guide_page.select_and_watch_program(tester)
            tester.guide_assertions.verify_live_playback()
            self.open_olg()
            self.screen.refresh()
            dump = self.screen.get_screen_dump_item()
            tester.home_page.go_to_guide(tester)
            tester.guide_page.enter_channel_number(channel[1][0])
            tester.guide_page.get_live_program_name(tester)
            tester.guide_page.select_and_watch_program(tester)
        return dump, channel

    def dump_with_TTS_ON(self, tester, channel, myshows=False, guide=False, live=False, olg=False):
        self.log.step("Taking dump with TTS On")
        self.screen.base.TTS_on_off(tts=True)
        tester.menu_page.enable_closed_captioning(tester)
        if myshows:
            self.log.step("Launching My shows")
            tester.home_page.go_to_my_shows(tester)
        elif guide:
            self.log.step("Launching Guide")
            tester.home_page.go_to_guide(tester)
        elif live:
            self.log.step("Launching Live TV")
            tester.home_page.go_to_guide(tester)
            if channel is None:
                pytest.fail("Could not find any episodic channel")
            tester.guide_page.enter_channel_number(channel[0][0])
            tester.guide_page.get_live_program_name(tester)
            tester.guide_page.select_and_watch_program(tester)
            tester.guide_assertions.verify_live_playback()
            self.screen.base.press_info()
        else:
            self.log.step("Launching One Line Guide")
            tester.home_page.go_to_guide(tester)
            if channel is None:
                pytest.fail("Could not find any episodic channel")
            tester.guide_page.enter_channel_number(channel[0][0])
            tester.guide_page.get_live_program_name(tester)
            tester.guide_page.select_and_watch_program(tester)
            tester.guide_assertions.verify_live_playback()
            self.open_olg()
        self.screen.refresh()
        dump_with_tts_on = self.screen.get_screen_dump_item()
        return dump_with_tts_on

    def navigate_to_strip_item(self, menu):
        self.log.info("Navigating {} strip item".format(menu))
        self.navigate_by_strip(menu)

    def exit_ott_app_with_back_or_exit_button(self):
        self.log.step("Exit app by exit button")
        self.press_exit_button()

    def launch_app_from_GA_from_any_screen(self, tester, app):
        self.log.step("Open OTT app {}".format(app))
        self.screen.base.tell_device_assistant(app)

    def download_game_using_GA(self, gamename):
        self.log.step("Download game using GA")
        game = "Download " + str(gamename)
        self.screen.base.tell_device_assistant(game)
        self.pause(15)
        self.screen.base.press_right()
        self.pause(5)
        if self.screen.base.is_text_present(self.home_labels.LBL_GAME_INSTALL):
            self.screen.base.select_item_by_text(self.home_labels.LBL_GAME_INSTALL)
            self.pause(8)
            if self.screen.base.is_text_present(self.home_labels.LBL_CONNECT_GAMEPAD):
                self.screen.base.select_item_by_text(self.home_labels.LBL_CONTINUE)
                self.pause(8)
            if self.screen.base.is_text_present(self.home_labels.LBL_APP_PERMISSIONS):
                self.screen.base.select_item_by_text(self.home_labels.LBL_ACCEPT)
                self.pause(8)
            self.pause(60 * 2)
        else:
            self.log.info("The Game app should be already installed, Try launching App and verify")

    def exit_game_app_with_exit_or_home_button(self):
        self.log.step("Exit app by exit button")
        self.press_exit_button()

    def channel_change_in_olg(self, tester):
        tester.watchvideo_page.open_olg(refresh=True)
        self.screen.base.press_left()
        self.screen.base.press_up()
        self.screen.base.press_enter()
        self.wait_for_screen_ready()
        self.screen.base.press_enter()
        tester.watchvideo_assertions.verify_view_mode(tester.watchvideo_labels.LBL_LIVETV_VIEWMODE)

    def clear_cache_launch_hydra_app(self, package=Settings.app_package,
                                     username=Settings.username,
                                     password=Settings.password,
                                     skip_animation=True,
                                     skip_onepass=True,
                                     skip_apps=True,
                                     skip_pcsetting=True,
                                     stay_sign_in=False,
                                     accept_eula=True,
                                     restore_tcdui_test_conf=True,
                                     ):
        """
        This method will take care of app data clearing and grant storage access
        launch hydra app if unmanaged device sign process will take care.

        Args:
            package (str): app package name
            username (str): user name, usually email
            password (str): password
            accept_eula (bool): if accept all Legal Acceptance screens
            skip_animation (bool): if FTUX video animation should be skipped or not
            skip_onepass (bool): if OnePass Quick Select screen should be skipped
            skip_apps (bool): if Streaming Apps screen should be skipped
            skip_pcsetting (bool): If Parental Controls Settings screen should be skipped
            stay_sign_in (bool): if needed to stay in Sign In screen with enter credenitals fields or in sign-in screen
                                 with loading indicator for managed and unmanaged with licenseplate
            restore_tcdui_test_conf (bool): flag to control restoring tcdui_test.conf after clear data
        """
        self.log.info("******************* Clear app data and launch hydra app method start ***********************")
        pytest_current_test = os.getenv("PYTEST_CURRENT_TEST", "cd_temp_loc")
        tc_name = pytest_current_test.split(":")[-1]
        tc_name = re.sub(r'(?u)[^-\w.]', '', tc_name)
        tmp_tcdui_location = os.path.join(Settings.log_path,
                                          tc_name,
                                          "clear_cache_launch_hydra_app")
        try:
            shutil.rmtree(os.path.dirname(tmp_tcdui_location))
        except Exception as error:
            self.log.debug(f"Backup cleanup error {error}")
        os.makedirs(tmp_tcdui_location, exist_ok=True)
        is_tcdui_backup = True
        try:
            self.screen.base.pull_file(self.screen.base.driver.remote_tcdui_test_conf, tmp_tcdui_location)
        except Exception as error:
            is_tcdui_backup = False
            self.log.debug(f"While trying to backup tcdui_test.conf there was an error: {error}")
        self.clear_data()
        if restore_tcdui_test_conf and is_tcdui_backup:
            self.screen.base.push_file(f"{tmp_tcdui_location}/tcdui_test.conf",
                                       self.screen.base.driver.remote_tcdui_test_conf)
        self.screen.base.grant_app_permissions()
        self.screen.base.stop_app(Settings.app_package)
        self.handling_hydra_app_after_exit(Settings.app_package, is_wait_home=False)
        if Settings.is_unmanaged() and not self.service_api.get_authentication_license_plate_url(True):
            self.wait_for_sign_in_form()
        if not stay_sign_in:
            if Settings.is_unmanaged() and not self.service_api.get_authentication_license_plate_url(True):
                self.unamanged_sign_in(self, package, username, password, wait_home=False)
            self.skip_ftux(skip_animation, skip_onepass, skip_apps, skip_pcsetting, accept_eula)
        self.screen.base.verify_foreground_app(package)
        self.log.info("******************** Clear app data and launch hydra app method ends ******************")

    def is_ftux_animation_view_mode(self):
        """
        this method verify view mode of screen, detected then returns true else false
        :return: boolean
        """
        self.log.info("Checking if FTUX Opening Animation screen is shown")
        self.screen.refresh()
        if self.view_mode() == self.home_labels.LBL_FTUX_ANIMATION_VIEW_MODE:
            return True
        else:
            self.log.warning("FTUX Opening Animation is not detected; actual {}, expected {}"
                             .format(self.view_mode(), self.home_labels.LBL_FTUX_ANIMATION_VIEW_MODE))
            return False

    def update_test_conf_and_reboot(self, tcdui_src="device", fast=False, clear_data=False, skip_animation=True,
                                    skip_onepass=True, skip_apps=True, skip_pcsetting=True, accept_eula=True, **kwargs):
        """
        This method adds params given as **kwargs to tcdui_test.conf stored on device
        and after that clears cashe, grants permissions and reloads app to apply the changes

        Args:
            tcdui_src (str): source of tcdui template, golden and device are supported
            fast (bool): True - finishing when reached sign in screen (loading indicator for Managed and Licenseplate),
                         False - processing FTUX
            clear_data (bool): if True - clear app data, if False - just reboot the app;
                               !!! use True only when it's really needed e.g. when changing SAML_DOMAIN property,
                               most of the properties does not need clearing the app data
            accept_eula (bool): True - accept Legal Acceptance screens, False - staying in it
            skip_* params applicable if clear_data=True and fast=False
                skip_animation (bool): True - skip FTUX video, False - staying in it
                skip_onepass (bool): True - skip OnePass Quick Select, False - staying in it
                skip_apps (bool): True - skip Streaming Apps, False - staying in it
                skip_pcsetting (bool): True - skip PC Settings, False - staying in it

        Keyword Args:
            modifiers from tcdui_test.conf file e.g. DEBUGENV_LOGLEVEL=9
        """
        self.log.info(f"Updating tcdui_test.conf; fast = {fast}, clear_data = {clear_data}")
        self.screen.base.modify_tcdui_conf(tcdui_src, **kwargs)
        screen_name = self.home_labels.LBL_SIGN_IN if fast else None
        wait_screen = 30000 if fast else 120000
        stay_sign_in = True if fast else False
        if clear_data:
            self.clear_cache_launch_hydra_app(skip_animation=skip_animation, skip_onepass=skip_onepass,
                                              skip_apps=skip_apps, skip_pcsetting=skip_pcsetting,
                                              stay_sign_in=stay_sign_in, accept_eula=accept_eula)
        else:
            self.relaunch_hydra_app(screen_name=screen_name, wait_screen=wait_screen)

    def is_ftux_eula_view_mode(self):
        """
        this method verify TiVo FTUX EULA view mode of screen, detected then returns true else false
        :return: boolean
        """
        self.log.info("Checking if User Agreement Acceptance screen is shown")
        self.screen.refresh()
        if self.view_mode() == self.home_labels.LBL_FTUX_EULA:
            return True
        else:
            self.log.warning("FTUX User Agreement screen is not detected; actual {}, expected {}"
                             .format(self.view_mode(), self.home_labels.LBL_FTUX_EULA))
            return False

    def is_ftux_one_pass_quick_selection_view_mode(self):
        """
        this method verify view mode of screen, detected then returns true else false
        :return: boolean
        """
        self.log.info("Checking if OnePass Quick Select screen is shown")
        self.screen.refresh()
        if self.view_mode() and self.home_labels.LBL_ONEPASS_FTUX_VIEW_MODE in self.view_mode():
            return True
        else:
            self.log.warning("FTUX OnePass Quick Select screen is not detected; actual {}, expected {}"
                             .format(self.view_mode(), self.home_labels.LBL_ONEPASS_FTUX_VIEW_MODE))
            return False

    def is_ftux_streaming_apps_view_mode(self):
        """
        this method verify view mode of screen, detected then returns true else false
        :return: boolean
        """
        self.log.info("Checking if Streaming Apps screen is shown")
        self.screen.refresh()
        if self.view_mode() and self.home_labels.LBL_STREAMINGAPPS_FTUX_VIEW_MODE in self.view_mode():
            return True
        else:
            self.log.warning("FTUX Streaming Apps screen is not detected; actual {}, expected {}"
                             .format(self.view_mode(), self.home_labels.LBL_STREAMINGAPPS_FTUX_VIEW_MODE))
            return False

    def is_ftux_pc_settings_screen_view_mode(self):
        """
        this method verify view mode of screen, detected then returns true else false
        :return: boolean
        """
        self.log.info("Checking if PC Settings screen is shown")
        self.screen.refresh()
        if self.view_mode() and self.home_labels.LBL_PCSETTINGS_FTUX_VIEW_MODE in self.view_mode():
            return True
        else:
            self.log.warning("FTUX PC Settings screen is not detected; actual {}, expected {}"
                             .format(self.view_mode(), self.home_labels.LBL_PCSETTINGS_FTUX_VIEW_MODE))
            return False

    def change_bridge_state(self, state):
        self.wait_for_screen_ready()
        self.log.step("switching connection type")
        self.manage_network_change(state)

    def playback_for_sometime(self, tester, channel_number, time=5):
        self.pause(30)
        self.go_to_guide(tester)
        tester.guide_assertions.verify_guide_screen(tester)
        self.enter_channel_number(channel_number)
        self.guide_page.get_live_program_name(tester)
        self.guide_page.select_and_watch_program(tester, text="live")
        self.wait_for_screen_ready(tester.watchvideo_labels.LBL_LIVETV_SCREEN)
        self.pause(time)

    def resume_playback(self, tester):
        self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
        self.screen.refresh()
        if self.is_overlay_shown() and tester.vod_labels.LBL_ON_DEMAND in self.get_overlay_title():
            self.log.info("HD/SD selector overlay displayed")
            self.screen.refresh()
            self.select_menu_by_substring(tester.vod_labels.LBL_FREE)
        tester.home_assertions.verify_resume_overlay(tester)

    def get_eas_content(self):
        try:
            return self.screen.get_screen_dump_item('EASBody')
        except KeyError:
            try:
                return self.screen.get_screen_dump_item('EASText')
            except KeyError:
                return None

    def verify_onscreen_trickplay_overlay(self):
        if not self.is_overlay_shown():
            self.log.info("Overlay is not appeared.")
            overlay = False
        elif self.get_overlay_title() != self.home_labels.LBL_WHATS_NEW_OVERLAY:
            self.log.info("Whats New Overlay is not appeared.")
            overlay = False
        else:
            self.log.info("Whats New Overlay is appeared.")
            overlay = True

        return overlay

    def exit_error_overlay(self):
        if self.is_overlay_shown():
            self.log.info("overlay is displayed")
            self.screen.base.press_enter()
        else:
            self.log.info("Could not see any error overlay")

    def get_and_filter_out_zero_slots_from_api(self, tester, is_carousel=False):
        """
        goes to a zero slot with current action type and returns the ad
        :param bool is_carousel: True: using regexp to find Ads with URI that contains &carousel=
        :return: AD obj
        """
        self.log.info("go to zero slot in prediction")
        zero_slots = tester.service_api.get_zero_slots()
        if not zero_slots:
            pytest.skip("service_api.get_zero_slots() returns no zero_slots. Can't continue without zero_slots")
        self.log.debug("Zero slots returned from service_api.get_zero_slots(): {}".format(zero_slots))
        filtered_zero_slot_list = tester.service_api.filter_out_ui_navigation_ads_list(tester, zero_slots, is_carousel)
        self.log.debug("Zero slots after service_api.filter_out_ads_list(): {}".format(filtered_zero_slot_list))
        if not filtered_zero_slot_list:
            pytest.skip("This test should verify a zero slot ad with 'category' but\n"
                        "there are no zero slot ads with 'category'. Existing zero slots: {}".format(zero_slots))
        return filtered_zero_slot_list, len(zero_slots)

    def navigate_to_and_get_zero_slot_promotion(self, tester, filtered_zero_slot_list, count=10):
        """
        Find and navigate to prediction slot on home page that will match to ad from list
         If no matches were found then waiting 5 mins for rotation of ads and try to find again.
         will wait for rotation 10 times.
        :param filtered_zero_slot_list: list of prediction ads
        :return: AD obj
        """
        for i in range(count):
            self.goto_prediction()
            time_now = time.time()
            self.screen.base.press_left()
            self.screen.refresh()
            zero_slot = self.find_zero_slot(filtered_zero_slot_list)
            if zero_slot:
                self.log.debug("Zero slot found and focused: {}".format(zero_slot))
                return zero_slot
            # TODO: replace waiting with rotation backdoor combo when backdoor would be realized
            # ad's rotation backdoor combo for Linux STB UP-UP-DOWN-DOWN-LEFT-RIGHT-LEFT-RIGHT-SLOW-9-SLOW
                # but not realized for streamers
            self.log.info("We went through all strip items and didn't find expected zero slot item:'{}'\n"
                          "Waiting 5 mins, going out of home screen and coming back to rotate zero slot ad\n"
                          .format(filtered_zero_slot_list))
            waiting_time = int(300 - (time.time() - time_now))
            self.rotate_prediction_ads(tester, waiting_time)
        else:
            raise AssertionError("We got zero slot AD from API, tried to find it and did rotation of ADs for 10 times\n"
                                 "but expected zero slot's AD was not found in prediction. Seems it's a product BUG.\n"
                                 "Filtered Zero slots:{}".format(filtered_zero_slot_list))

    def find_zero_slot(self, filtered_zero_slot_list):
        """
        Method is going through all slots in prediction (can be 20 slots max) and looks
            if zero_slot ad's uiElementID is match to currently focused slot
        :param filtered_zero_slot_list: list of prediction ads
        :return: AD obj if currently focused slot's uiElementID matched to zero_slot from list
                None if no matches from whole prediction
        """
        # We can't use a length of prediction_strip_list because we have only visible amount of strips in screen_dump
        for i in range(20):
            zero_slot = self.get_ad_matches_to_zero_slot(filtered_zero_slot_list)
            if zero_slot:
                self.log.debug("Zero slot is found {}".format(zero_slot))
                return zero_slot
            self.log.info("Strip item does not match to the expected zero slot. \n"
                          "Pressing right to navigate to next strip item")
            self.screen.base.press_right()
        return None

    def get_ad_matches_to_zero_slot(self, filtered_zero_slot_list):
        """
        method can be used in home. Search a focused slot in prediction that will match to expected by uiElementID
        :params filtered_zero_slot_list: list of slots
        :return: ad that will match to a zero slot or None if no matches
        """
        zero_slot = None
        self.screen.refresh()
        strip_items = self.screen.get_screen_dump_item('stripitem')
        debug_strip_items_list = []
        debug_zero_slots_list = []
        for item in strip_items:
            debug_strip_items_list.append(item)
            for slot in filtered_zero_slot_list:
                debug_zero_slots_list.append(slot)
                if 'ad' in item.keys() and item['ad'] == 'true' \
                        and 'hasfocus' in item.keys() and item['hasfocus'] == 'true' \
                        and 'imagename' in item.keys() and slot['uiElementId'] in item['imagename']:
                    self.log.info("Current strip item: '{}' is matching to expected zero slot: '{}'".format(item, slot))
                    zero_slot = slot
                    return zero_slot
        self.log.debug("No one strip item is matching to zero slot.\n"
                       "All collected zero slots: '{}'\n"
                       "All collected strip items: '{}'".format(debug_zero_slots_list, debug_strip_items_list))
        return zero_slot

    def is_default_setting_upgrade_overlay(self):
        """
        Method to confirm OnePass and Recordings Default Settings Upgraded Overlay
        """
        reference_lbl = self.home_labels.LBL_UPGRADE_SETTINGS_OVERLAY_TITLE
        return self.is_overlay_shown() and self.get_overlay_title() == reference_lbl

    def proceed_with_sign_in(self, wait_home=True):
        """
        Proceeding with Sign-In

        Args:
            wait_home (bool): True - waiting untill Home screen is shown, False - no waiting right after sign-in
        """
        self.confirm_modal_ui_errors()
        if self.is_sign_in_foreground() or self.is_license_plate_foreground():
            try:
                self.sign_in(wait_home)
            except Exception as ex:
                self.log.error(f"Sign In Failure Observed: \n{ex}")
            if wait_home:
                self.confirm_modal_ui_errors()
                if self.is_sign_in_foreground() or self.is_license_plate_foreground():
                    self.relaunch_hydra_app(screen_name=self.home_labels.LBL_SIGN_IN, wait_screen=60000, reboot=True)
                    self.sign_in(wait_home)
                    self.confirm_modal_ui_errors(throw_error=True)

    def rotate_prediction_ads(self, tester, waiting_time=300):
        self.log.info("Wait for ad's timeout go to guide and back to home to refresh prediction's ad")
        if waiting_time > 0:
            self.pause(waiting_time)
        self.go_to_guide(tester)
        self.back_to_home_short()

    def check_predictions(self):
        self.screen.refresh()
        self.log.info("checking prediction strip exists")
        return self.is_strip_focus()

    def get_Slot0_ads(self, tester):
        self.log.info("go to zero slot in prediction")
        zero_slots = tester.service_api.get_zero_slots()
        if not zero_slots:
            pytest.skip("service_api.get_zero_slots() returns no zero_slots: {}.\n"
                        "Can't continue without zero_slots")
        self.log.debug("Zero slots returned from service_api.get_zero_slots(): {}".format(zero_slots))
        return zero_slots

    def navigate_to_destination_screen_for_no_action_ad(self, tester):
        self.log.info("On the basis of type of action, this ad will not be clickable")
        self.screen.base.press_enter()
        self.wait_for_screen_ready(tester.home_labels.LBL_HOME_SCREEN_NAME)
        self.screen.refresh()
        self.verify_screen_title(tester.home_labels.LBL_HOME_SCREENTITLE)

    def navigate_to_top_of_app_for_uiNavigateAction_action_type(self, tester, zero_slot):
        self.screen.base.press_enter()
        self.pause(10)
        slot_uri = zero_slot['action']['uri']
        tester.home_assertions.verify_foreground_package_matches_uri(slot_uri)

    def navigate_to_vod_program_screen_for_walledGardenBrowseUiAction_action_type(self, tester):
        self.screen.base.press_enter()
        self.pause(5)
        self.screen.refresh()
        self.verify_view_mode(tester.program_options_labels.LBL_ACTION_SCREEN_VIEW)

    def navigate_to_series_screen_for_collectionDetailUiAction_action_type(self, tester):
        self.screen.base.press_enter()
        self.pause(5)
        self.screen.refresh()
        self.verify_view_mode(tester.program_options_labels.LBL_SERIES_SCREEN_VIEW)

    def navigate_to_livetv_for_liveTvUiAction_action_type(self, tester):
        self.screen.base.press_enter()
        self.pause(5)
        tester.guide_assertions.verify_live_playback()

    def press_back_from_home_to_livetv(self, tester, view=None):
        self.log.info("To verify the press back navigate to livetv from Home screen")
        if view is None:
            view = tester.liveTv_labels.LBL_LIVETV_VIEWMODE
        self.screen.base.press_back()
        self.wait_for_screen_ready()
        self.screen.refresh()
        self.wait_loading_indicator_disappear()
        self.verify_view_mode(view)

    def navigate_to_program_in_OTT_app_for_uiNavigateAction_action_type(self, tester):
        self.screen.base.press_enter()
        self.pause(5)
        tester.home_assertions.verify_OTT_app_destination_screen()

    def update_drm_package_names_native(self, feature, package_type, is_add=True):
        """
        Adding/removing a DRM package in service
        pr1ProvDeviceAlaCarteUpdate

        Args:
            feature (str): part of package name representing the feature name
            is_add (bool): if True, we check package is present,
                           if False, we check package is absent
        """
        update = "Adding" if is_add else "Removing"
        self.log.info(f"{update} '{package_type}-{feature}' DRM package {'to' if is_add else 'from'} the account")
        if is_add:
            self.iptv_prov_api.fe_alacarte_add_package_native_drm(feature, package_type)
        else:
            self.iptv_prov_api.fe_alacarte_remove_package_native_drm(feature, package_type)

    def navigate_to_destination_screen_for_wtw_hero_no_action_ad(self, tester):
        self.log.info("On the basis of type of action, this ad will not be clickable")
        self.wait_for_screen_ready(tester.home_labels.LBL_WTW_PRIMARY_SCREEN, 30000)

    def get_live_tv_error_status(self, tester, code=None, channel=None):
        """
            This method is used to go to live tv and check if error displayed,
            if code parameter passed,than also checks if error has specified code.
            Args:
                tester:self, needed to access method from guide_page.
                code:str, code of error expected
        """
        self.log.info("Going to live tv and looking for error")
        if channel is None:
            self.goto_livetv_short(tester)
            self.screen.base.press_enter(2000)
        else:
            self.back_to_home_short()
            self.select_menu_shortcut(self.home_labels.LBL_GUIDE_SHORTCUT)
            tester.guide_page.enter_channel_number(channel)
            self.screen.base.press_enter(2000)
        self.log.info("Looking for error overlay")
        self.screen.refresh()
        if self.get_error_overlay_status():
            if code is not None:
                overlay_code = self.screen.get_screen_dump_item('overlayTitleText')
                if code not in overlay_code:
                    raise ValueError(f"Wrong overlay displayed expected {code} but got {overlay_code}")
            return True
        else:
            return False

    def wait_for_home_page_ds_error(self, expected_code, timeout=60):
        """
            This method is used to wait for error code in home screen's prediction strip,
            when triggered with overrides.

            Args:
                timeout:int, wait timeout in seconds.
                expected_code:str, code of error expected
        """
        self.screen.refresh()
        self.dismiss_popup_overlay(self)
        self.pause(5, reason="DS delay for stability on hydra launch")
        self.wait_for_condition_satisfied(self.is_prediction_bar_error_visible)
        error_text = self.get_prediction_bar_error()
        if expected_code not in error_text:
            raise LookupError(f"Unexpected error on home page, "
                              f"expected {expected_code}, but got {error_text}.")

    def is_prediction_bar_error_visible(self, refresh=True):
        """
            Checks if error is displayed on home screen prediction bar (f.e. C634).

            Args:
                refresh: bool, flag to control updating dump before check
        """
        if refresh:
            self.screen.refresh()
        return self.ui_element_exists("PredictionStripBodyText")

    def get_prediction_bar_error(self, refresh=False) -> str:
        """
        To get text of prediction bar error

        Args:
            refresh: bool, flag enable/disable refresh before getting the data

        Returns:
            str, text of error
        """
        if refresh:
            self.screen.refresh()
        return self.screen.get_screen_dump_item("PredictionStripBodyText")

    def get_error_overlay_status(self):
        self.screen.refresh()
        screen = self.screen.screen_dump['xml']
        if 'overlayTitleText' not in screen:
            return False
        else:
            return True

    def press_home_button_multiple_times(self, tester, no_of_times=1):
        self.screen.refresh()
        for i in range(no_of_times):
            self.press_home_and_verify_screen(tester)

    def is_disconnect(self, error_code=None, wait_disconnect=True):
        """
        Getting info if Hydra is in the disconnected state.
        Home screen should be displayed. No retries, just single check.
        Applicable as for Managed as for Unamanaged boxes.

        Args:
            error_code (str): applicable only for disconnected state, error code in an error message
                              shown instead of the Prediction bar on the Home screen,
                              if None, checking presence of any error in the bodyText of Home screen
            timeout (int): time to wait in seconds
            wait_disconnect (bool): True, checks if Hydra got to the disconnected state,
                                    False, checks if Hydra got to the connected state
        Returns:
            bool, True - Hydra is in the disconnected state, False - otherwise
        """
        self.log.info("Checking if Hydra got into the disconnected state by bodyText on the Home screen")
        is_lp_enabled = self.service_api.get_authentication_license_plate_url(True)  # if license plate is enabled
        self.screen.refresh()
        if self.home_labels.LBL_HOME_VIEW_MODE not in self.view_mode() and \
           (not wait_disconnect or Settings.is_managed() or is_lp_enabled):
            self.jump_to_home_xplatform(refresh=True)
        # Extra steps to display Error message
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15):
            self.press_down_button(refresh=False)
            self.press_up_button(refresh=True)
        # Hiding overlays if they appear
        if self.is_overlay_title() and self.is_in_menu(self.home_labels.LBL_REMIND_ME_LATER_OPTION):
            self.select_menu(self.home_labels.LBL_REMIND_ME_LATER_OPTION)
        # Disconnected Home screen is shown if bodyText is present on the screen dump of the Home screen
        body_text = self.screen.get_screen_dump_item("bodyText") if \
            "bodyText" in self.screen.screen_dump.get("xml").keys() else None
        if (Settings.is_managed() or is_lp_enabled) and \
           (not error_code and body_text or error_code and body_text and error_code in body_text):
            return True
        # Unmanaged with web log in shows NoNetworkConnection screen
        if self.screen_title() == self.home_labels.LBL_NO_NETWORK_OVERLAY_TITLE.upper():
            return True
        return False

    def wait_for_connected_disconnected_state(self, error_code=None, timeout=300, wait_disconnect=True, is_select=True):
        """
        Waiting for the conntected/disconnected state.
        Internet should be enabled/disabled and Home screen should be displayed before using this method.
        Applicable as for Managed as for Unamanaged boxes.

        Args:
            error_code (str): applicable only for disconnected state, error code in an error message
                              shown instead of the Prediction bar on the Home screen,
                              if None, checking presence of any error in the bodyText of Home screen
            timeout (int): time to wait in seconds
            wait_disconnect (bool): True, checks if Hydra got to the disconnected state,
                                    False, checks if Hydra got to the connected state
            is_select (bool): True - selecting menu shortcut on the Home screen so Hydra will make requests
                                     to get into connected/disconnected state faster;
                              False - no additional selecting of menu shortcuts on the Home screen
        """
        time_decrement = 20
        state = "Disconnected" if wait_disconnect else "Connected"
        err_code = error_code if error_code else "any error code"
        use_err_code = err_code if wait_disconnect else ""
        log_entry = f"Waiting for the {state} state {use_err_code}"
        self.log.info(f"{log_entry}; timeout {timeout}, wait_disconnect {wait_disconnect}, is_select {is_select}")
        retry_count = 1
        result = None
        estimated_time = timeout
        start_time = time.perf_counter()
        finish_time = start_time + timeout

        def _get_result(_error_code, _wait_disconnect):
            is_dis = self.is_disconnect(_error_code, _wait_disconnect)
            return _wait_disconnect and is_dis or not _wait_disconnect and not is_dis

        while estimated_time >= 0:
            self.press_up_button(refresh=False)  # in case if highlight got on a tile of the Prediction Bar
            if is_select:
                # It helps to get into the disconnected state faster
                self.select_menu_shortcut(self.home_labels.LBL_WHATTOWATCH_SHORTCUT)
            result = _get_result(error_code, wait_disconnect)
            if result:
                break  # reached needed state
            calculated_delay = time_decrement if estimated_time > time_decrement else estimated_time
            reason = f"Retry #{retry_count}, time left {estimated_time} sec, decrement {calculated_delay}. {log_entry}"
            self.pause(calculated_delay, reason)
            estimated_time = finish_time - time.perf_counter()
            retry_count += 1
        if result is None:
            result = _get_result(error_code, wait_disconnect)
        return result

    def wait_for_EAS_to_dismiss(self, timeout):
        self.log.info("Waiting for EAS screen to be dismissed")
        status = self.get_eas_content()
        while status and timeout > 0:
            self.pause(5)
            timeout -= 5
            status = self.get_eas_content()
        self.log.info("EAS screen is not visible")

    def bind_license(self, tester):
        self.wait_for_screen_ready(self.home_labels.LBL_LICENSE_PLATE, timeout=10000)
        self.screen.refresh()
        self.screen.base.press_enter()  # To get new code
        self.verify_screen_title(self.home_labels.LBL_LICENSE_PLATE)
        a_code = self.get_activation_code()
        if not Settings.specified_pcid:
            self.iptv_prov_api.bind_device_with_activation_code(
                a_code, Settings.pcid, self.service_api.get_mso_partner_id(Settings.tsn))
        else:
            self.iptv_prov_api.bind_device_with_activation_code(
                a_code, Settings.specified_pcid, self.service_api.get_mso_partner_id(Settings.tsn))
        self.wait_for_screen_ready(timeout=10000)
        self.iptv_prov_api.bind_device_with_activation_code(
            a_code, self.service_api.getPartnerCustomerId(Settings.tsn), self.service_api.get_mso_partner_id(Settings.tsn))
        self.pause(self.home_labels.LBL_FOOTER_ICON_IDLE_USER_TIMEOUT)
        self.skip_ftux()
        tester.home_assertions.verify_home_title(self.home_labels.LBL_HOME_SCREENTITLE)

    def verify_home_mode(self):
        self.log.step("Verifying if view mode is home screen or not")
        self.verify_view_mode(self.home_labels.LBL_HOME_SCREEN_MODE)

    def get_prediction_bar_shows(self, tester):
        shows = tester.service_api.get_feed_item_find_results("/predictions")
        self.log.info("Shows are {}".format(shows))
        return shows

    def create_and_publish_message(self, request, subject=None, message=None, expr_date=None,
                                   payload_type=RemoteCommands.DEVICE_MESSAGE, remove_message_id="-1"):
        """
        Creating and publishing a user message using messaging targeting system.
        Supported since Hydra v1.13.
        Messaging targeting system is supported by: Managed.

        Notes:
            request.config.cache.get("message_ids", None) is used in the cleanup fixture

        Args:
            request (function): pytest fixture
            subject (str): message subject, if None, default subject (set in UTAF IPTV API) is taken,
                           set only if payload_type=deviceMessage
            message (str): message text, if None, default text (set in UTAF IPTV API) is taken,
                           set only if payload_type=deviceMessage
            expr_date (str): message expiration date, in UTC e.g. 2021-12-31 23:59:59, set only if payload_type=deviceMessage
            p_type (str): payload type
            remove_message_id (str): message id to be removed, set it only if payload_type = removeMessage

        Returns:
            dict, created message data
        """
        self.log.info("Creating a new message and publishing it")
        if payload_type == RemoteCommands.DEVICE_MESSAGE:
            message_data_u = self.iptv_prov_api.get_message_data(subject=subject, message=message, expiration_date=expr_date)
        elif payload_type == RemoteCommands.REMOVE_MESSAGE:
            message_data_u = self.iptv_prov_api.get_message_data(payload_type=payload_type,
                                                                 remove_message_id=remove_message_id)
        elif payload_type == RemoteCommands.REMOVE_ALL_MESSAGES:
            message_data_u = self.iptv_prov_api.get_message_data(payload_type=payload_type)
        self.validate_fcm_nsr_mts_req_usage(NotificationSendReqTypes.MTS, message_data_u["payloadType"], False)
        message = self.iptv_prov_api.mts_message_store(self.service_api.get_mso_partner_id(Settings.tsn),
                                                       [Settings.hsn],
                                                       message_data=message_data_u)
        msgs = request.config.cache.get("message_ids", None)
        if msgs:
            msgs.append(message["messageId"])
            request.config.cache.set("message_ids", msgs)
        else:
            request.config.cache.set("message_ids", [message["messageId"]])
        self.iptv_prov_api.mts_message_state_update(message_id=message["messageId"])
        self.pause(5, "Waiting the box to receive the message sent by MTS")
        return message

    def validate_fcm_nsr_mts_req_usage(self, req_type, p_type, is_skip=False):
        """
        Note:
            Since messaging targeting system sends FCM requests, this method also is applicable for User Messaging feature

        Args:
            req_type (str): one of (NotificationSendReqTypes.MTS, NotificationSendReqTypes.FCM, NotificationSendReqTypes.NSR,
                                    NotificationSendReqTypes.NO_REQ),
                            MTS - messaging targeting system,
                            NO_REQ - test does not need to make FCM/NSR (may be applicable for old tests that use app restart)
            p_type (str): payload type, one of (RemoteCommands.DEVICE_MESSAGE, RemoteCommands.REMOVE_MESSAGE,
                                                RemoteCommands.REMOVE_ALL_MESSAGES, RemoteCommands.SERVICE_CALL,
                                                RemoteCommands.FEATURE_STATUS)
            is_skip (bool): True - skipping the test if request is not supported on the Hydra version
                                   (do it only if it's called in the setup fixture or as the 1st step in a test);
                            False - raising exception if request is not supported on the Hydra version;
                            None - just returning bool (if all conditions are met), no skipping or failing
        Returns:
            bool, False - means that FCM/NSR requests are not used by the test but param itself is needed to be passed
        """
        err_msg = None
        is_v1_13_or_higher = Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_13)
        is_v1_15_or_higher = Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15)
        is_v1_16_or_higher = Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_16)
        mts_payload_types = (RemoteCommands.DEVICE_MESSAGE, RemoteCommands.REMOVE_MESSAGE, RemoteCommands.REMOVE_ALL_MESSAGES)
        # MTS (service) makes FCM request
        fcm_unman_not_sup_msg = f"{req_type} requests are supported only by Managed boxes, for now"
        fcm_man_lower_v1_13_msg = f"{req_type} deviceMessage, removeMessage, removeAllMessage are supported since Hydra v1.13"
        fcm_man_lower_v1_15_msg = "FCM featureStatus, serviceCall are supported since Hydra v1.15"
        nsr_service_call_lower_v1_15_msg = "NSR serviceCall is supported since Hydra v1.15"
        nsr_feature_status_lower_v1_16_msg = "NSR featureStatus is supported since Hydra v1.16"
        if req_type == NotificationSendReqTypes.NO_REQ:
            return False  # sendng MTS/FCM/NSR is not needed
        if req_type not in (NotificationSendReqTypes.MTS, NotificationSendReqTypes.FCM, NotificationSendReqTypes.NSR):
            # Incorrect request type always fails the test
            raise ValueError(f"req_type {req_type} is not supported. Choose one of (MTS, FCM, NSR)")
        if Settings.is_unmanaged() and req_type in (NotificationSendReqTypes.MTS, NotificationSendReqTypes.FCM):
            err_msg = fcm_unman_not_sup_msg
        # FCM deviceMessage, removeMessage, and removeAllMessage are available for Managed boxes since Hydra 1.13
        if req_type in (NotificationSendReqTypes.MTS, NotificationSendReqTypes.FCM) and \
           p_type in mts_payload_types and not is_v1_13_or_higher:
            err_msg = fcm_man_lower_v1_13_msg
        # FCM featureStatus and serviceCall are available for Managed boxes since Hydra 1.15
        if req_type == NotificationSendReqTypes.FCM and \
           p_type in (RemoteCommands.FEATURE_STATUS, RemoteCommands.SERVICE_CALL) and not is_v1_15_or_higher:
            err_msg = fcm_man_lower_v1_15_msg
        # NSR serviceCall is available since Hydra 1.15 for both Managed and Unmanaged
        if req_type == NotificationSendReqTypes.NSR and p_type == RemoteCommands.SERVICE_CALL and not is_v1_15_or_higher:
            err_msg = nsr_service_call_lower_v1_15_msg
        # NSR featureStatus is available since Hydra 1.15 for both Managed and Unmanaged
        if req_type == NotificationSendReqTypes.NSR and p_type == RemoteCommands.FEATURE_STATUS and not is_v1_16_or_higher:
            err_msg = nsr_feature_status_lower_v1_16_msg
        if is_skip is False and err_msg:
            raise ValueError(err_msg)
        elif is_skip and err_msg:
            pytest.skip(err_msg)
        elif is_skip is None and err_msg:
            return False
        return True

    def send_fcm_or_nsr_notification(self, req_type, payload_type, message_data=[], remove_message_id="-1", is_retry=False):
        """
        Sending FCM/NSR depending on passed params.
        FCM is supported by: Managed.
        NSR is supported by: Managed and Unmanaged.
        NO_REQ means that no request will be made (may be applicable for old tests that use app restart)

        FCM: supported values for payload_type:
            - RemoteCommands.DEVICE_MESSAGE (Since Hydra v1.13)
            - RemoteCommands.REMOVE_MESSAGE (since Hydra v1.13)
            - RemoteCommands.FEATURE_STATUS (since Hydra v1.15)
            - RemoteCommands.SERVICE_CALL (since Hydra v1.15)
            - RemoteCommands.REMOVE_ALL_MESSAGES (since Hydra v1.13)

        NSR: supported values for payload_type:
            - RemoteCommands.FEATURE_STATUS (since Hydra v1.16)
            - RemoteCommands.SERVICE_CALL (since Hydra v1.15)

        Args:
            req_type (str): one of (NotificationSendReqTypes.FCM, NotificationSendReqTypes.NSR,
                                    NotificationSendReqTypes.NO_REQ)
            payload_type (str): one of (RemoteCommands.FEATURE_STATUS, RemoteCommands.SERVICE_CALL)
            message_data (list): list of message dict got from self.iptv_prov_api.get_message_data(),
                                 applicable only when payload type in (RemoteCommands.DEVICE_MESSAGE)
            remove_message_id (str): message id to be removed, set it only if payload_type = RemoteCommands.REMOVE_MESSAGE
            is_retry (bool): True - request is re-sent after failure, False - request is sent once,
                             applicable only to unmanaged devices
            is_skip (bool): True - skipping the test if request is not supported on the Hydra version
                                   (do it only if it's called in the setup fixture or as the 1st step in a test);
                            False - raising exception if request is not supported on the Hydra version
        """
        self.log.info(f"Sending {req_type} message to notify the box about making {payload_type}")
        if not self.validate_fcm_nsr_mts_req_usage(req_type, payload_type, False):
            return  # sendng FCM/NSR is not needed
        message_data_u = message_data
        cadid_hsn = Settings.hsn if Settings.is_managed() else Settings.ca_device_id
        id_type = "hsn" if Settings.is_managed() else "ca_device_id"
        anon_body_id = self.service_api.anonym_cadid_hsn_translate(cadid_hsn, id_type)["internalId"]
        if payload_type in (RemoteCommands.REMOVE_ALL_MESSAGES, RemoteCommands.FEATURE_STATUS, RemoteCommands.SERVICE_CALL):
            message_data_u = self.iptv_prov_api.get_message_data(payload_type=payload_type)
        elif payload_type == RemoteCommands.REMOVE_MESSAGE:
            message_data_u = self.iptv_prov_api.get_message_data(payload_type=payload_type,
                                                                 remove_message_id=remove_message_id)
        if req_type.upper() == NotificationSendReqTypes.FCM:
            self.iptv_prov_api.fcm_message_send(self.service_api.get_mso_partner_id(Settings.tsn),
                                                anon_body_id=anon_body_id, message_data=message_data_u)
        elif req_type.upper() == NotificationSendReqTypes.NSR:
            self.iptv_prov_api.nsr_message_send(self.service_api.get_mso_partner_id(Settings.tsn),
                                                anon_body_id=anon_body_id, message_data=message_data_u, is_retry=is_retry)
        else:
            raise ValueError(f"{req_type} request type is not supported")
        self.pause(5, f"Waiting the box to receive the {req_type} {payload_type} message")

    def goto_home_menu_items_from_prediction(self):
        if self.is_prediction_strip_focused():
            self.press_up_button()
            self.screen.get_json()

    def skip_ftux(self, skip_animation=True, skip_onepass=True, skip_apps=True, skip_pcsetting=True, accept_eula=True):
        """
        Skipping FTUX

        Args:
            skip_animation (bool): if FTUX video animation should be skipped or not
            skip_onepass (bool): if OnePass Quick Select screen should be skipped
            skip_apps (bool): if Streaming Apps screen should be skipped
            accept_eula (bool): if Legal Acceptance screens should be skipped
            skip_pcsetting (bool): If Parental Controls Settings screen should be skipped
        """
        param_values = f"skip_animation {skip_animation}, skip_onepass {skip_onepass}, skip_apps {skip_apps}, " \
            f"skip_pcsetting {skip_pcsetting}, accept_eula {accept_eula}"
        self.log.info("Skipping FTUX if shown; {}".format(param_values))
        self.screen.refresh()
        self.dismiss_popup_overlay(self)
        is_sign_in_screen = self.view_mode() == self.home_labels.LBL_SIGN_IN_SCREEN_VIEW_MODE
        is_legal_acceptance_screen = self.view_mode() in self.home_labels.LBL_LEGAL_ACCEPTANCE_SCREENS
        if is_sign_in_screen or is_legal_acceptance_screen or "ftux" in self.view_mode():
            if is_sign_in_screen:
                self.wait_for_screen_ready(timeout=20000)
            if accept_eula:
                self.accept_legal_acceptance_screens()
            if self.is_ftux_animation_view_mode() and skip_animation:
                self.skip_ftux_animation()
            if Settings.is_unmanaged():
                self.accept_legal_acceptance_screens()
            self.wait_for_screen_ready(timeout=20000)
            if self.is_ftux_one_pass_quick_selection_view_mode() and skip_onepass:
                self.select_done(times=1)
            if not Settings.is_fire_tv():
                self.wait_for_screen_ready(timeout=20000)
                if self.is_ftux_streaming_apps_view_mode() and skip_apps:
                    self.select_done(times=1)
            if self.is_ftux_pc_settings_screen_view_mode() and skip_pcsetting:
                self.select_skip_this_step_ftux_pcsetting_screen()
            self.wait_for_screen_ready()
        else:
            self.log.info("FTUX wasn't shown; current view: {}".format(self.view_mode()))

    def check_uncheck_ftux_streaming_apps_providers(self, provider_list=[], is_check=True, do_checking=True):
        """
        Smart checking/unchecking (only if tile is unchecked/checked appropriately) Video Provider titles
        on FTUX -> Streaming Apps screen.

        Args:
            provider_list (list): names of providers to check/uncheck e.g. ["NETFLIX", "STARZ"];
                                  Note: if empty, all providers are checked/unchecked, provider names can be taken from
                                        screen dump
            is_check (bool): True checking tiles, False - checking tiles
            do_checking (bool): True - check/uncheck video providers,
                                False - just return current status if providers are checked

        Returns:
            tuple, ([bool], not_matched_providers), if tile check/uncheck status match is_check and not matched providers
        """
        info_msg_part = "Checking" if is_check else "Unchecking"
        self.log.info(f"{info_msg_part} Video Providers on FTUX -> Streaming Apps screen; "
                      f"provider_list {provider_list}, is_check {is_check}, do_checking {do_checking}")
        self.screen.get_json()
        strip_focus = self.strip_focus()

        def check_uncheck_tiles(start_strip_item, providers=[], is_check=True, just_begun=False, do_checking=True):
            """
            Args:
                start_strip_item (str): initially focused tile checking/unchecking was started from
                providers (list): names of providers to check/uncheck e.g. ["NETFLIX", "STARZ"];
                                  Note: if empty, all providers are checked/unchecked, provider names can be taken from
                                        screen dump
                is_check (bool): True checking tiles, False - checking tiles
                just_begun (bool): True - continueing checking/unchecking when found initially focused tile
                                          (because checking/unchecking just started);
                                   False - stopping procedure when found initially focused tile
                do_checking (bool): True - check/uncheck video providers,
                                    False - just return current status if providers are checked

            Returns:
                tuple, ([bool], not_matched_providers), if tile check/uncheck status match is_check and not matched providers
            """
            if not just_begun:
                self.screen.get_json()
            strip_list = self.get_strip_list()
            found_focused = False
            result_list = []
            not_matched_providers = []
            for index in range(len(strip_list)):
                if "hasfocus" in strip_list[index]:
                    found_focused = True
                is_test_provider = True if providers and strip_list[index]["text"] in providers or not providers else False
                if found_focused:
                    if not just_begun and strip_list[index]["text"] == start_strip_item:
                        return result_list, not_matched_providers
                    if is_test_provider:
                        if strip_list[index]["is_checked"] == "true" and not is_check or \
                           strip_list[index]["is_checked"] == "false" and is_check:
                            result_list.append(False)
                            not_matched_providers.append(strip_list[index]["text"])
                            if do_checking:
                                self.press_ok_button(refresh=False)
                        else:
                            result_list.append(True)
                            self.press_right_button(refresh=False)
                    if not do_checking or not is_test_provider:
                        self.press_right_button(refresh=False)
                    if index == len(strip_list) - 1:
                        res_tmp, not_matched_tmp = check_uncheck_tiles(start_strip_item, providers,
                                                                       is_check, False, do_checking)
                        result_list.extend(res_tmp)
                        not_matched_providers.extend(not_matched_tmp)
            return result_list, not_matched_providers

        result = check_uncheck_tiles(strip_focus, provider_list, is_check, True, do_checking)
        return result

    def get_internal_disk_data(self):
        disk_data = self.screen.base.get_device_memory_info(partition='/data')
        data = list(disk_data.values())[0].get('Avail', None)
        if not data:
            raise AssertionError("Available memory is not present")
        return data

    def get_data_in_mb(self):
        data = self.get_internal_disk_data()
        if 'M' not in data:
            data1 = float(data.replace('G', '')) * 1000
            return data1
        return data.replace('M', '')

    def get_overlay_code(self):
        self.screen.refresh()
        overlay_code = self.screen.get_screen_dump_item('overlayTitleText')
        return overlay_code

    def check_drmtype(self, tester, request, actual_drmtype, expected_drmtype, feature, set_drmtype):
        """
        actual_drmtype: Actual drm type present on box
        expected_drmtype: Expected drm type on box
        feature: Feature to check & update
        set_drmtype: drm package to set
        """
        current_drmtype = ""
        if 'trioSodiDirect' in actual_drmtype.keys():
            current_drmtype = actual_drmtype['trioSodiDirect']
        elif 'trioSodi' in actual_drmtype.keys():
            current_drmtype = actual_drmtype['trioSodi']
        if current_drmtype != expected_drmtype:
            self.log.info(f"DRM type is not as expected so changing from {current_drmtype} to {expected_drmtype}")
            request.getfixturevalue(self.home_labels.LBL_DRM_PRESERVE_PACKAGE)
            request.getfixturevalue(self.home_labels.LBL_DRM_REMOVE_PACKAGE)
            tester.home_page.update_drm_package_names_native(feature, set_drmtype)
            tester.home_assertions.verify_drm_package_names_native(feature, set_drmtype)
            tester.home_page.relaunch_hydra_app()
        else:
            self.log.info(f"DRM type is {expected_drmtype} as expected")

    def is_legal_acceptance_screen(self):
        self.log.info("Check if is on Legal Acceptance screen.")
        self.screen.get_json()
        return self.view_mode() in self.home_labels.LBL_LEGAL_ACCEPTANCE_SCREENS

    def accept_legal_acceptance_screens(self):
        """
        This method is used to accept EULA and allow Personalized Ads and Data Sharing
        Used between Sign In and FTUX screens
        Before streamer-1-16 release only unmanaged devices had EULA
        """
        if self.is_legal_acceptance_screen():
            self.log.info("Accepting User Agreement.")
            self.select_menu(self.home_labels.LBL_ACCEPT)
            self.wait_for_screen_ready(self.home_labels.LBL_INTRODUCTORY_SCREEN)
            self.log.info("Skipping Introduction screen.")
            self.press_ok_button()
            self.wait_for_screen_ready(self.home_labels.LBL_PERSONALIZED_ADS_SCREEN)
            self.log.info("Allowing personalized Ads.")
            self.select_menu(self.home_labels.LBL_ALLOW_PERSONALIZED_ADS)
            self.wait_for_screen_ready(self.home_labels.LBL_DATA_SHARING_SCREEN)
            self.log.info("Allowing personal Data Sharing.")
            self.select_menu(self.home_labels.LBL_ALLOW_DATA_SHARING)
            self.wait_for_screen_ready(self.home_labels.LBL_FTUX_ANIMATION_SCREEN)
        elif self.view_mode() == self.home_labels.LBL_FTUX_EULA:
            self.log.info("In FtuxUserAgreement screen. Skipping ...")
            self.select_menu(self.home_labels.LBL_ACCEPT)
            self.wait_for_screen_ready(self.home_labels.LBL_FTUX_ANIMATION_SCREEN)
        else:
            self.log.info("Legal Acceptance screens were not shown. Current view: {}".format(self.view_mode()))

    def update_test_conf_and_reboot_to_eula(self):
        self.update_test_conf_and_reboot("device", clear_data=True, skip_animation=False, skip_onepass=False,
                                         skip_apps=False, skip_pcsetting=False, SKIP_FTUX="false", accept_eula=False)

    def get_tivoservice_url(self, sls=False, endpoint=None):
        """
        This method is used to get TiVo Service url
        """
        if sls:
            url = UrlResolver(Settings).get_endpoints(endpoint)
            self.log.info("url dict:{}".format(url))
            pattern = re.compile(r"\/(\w+.*.com)")
            domain = pattern.search(url)
            if domain:
                return domain.group(1)
        else:
            tivoservice_url = {
                MindEnvList.STAGING: SharedUrls.STAGING_TIVOSERVICE_URL,
                MindEnvList.USQE_1: SharedUrls.USQE1_TIVOSERVICE_URL,
                MindEnvList.CDVRQE_1: SharedUrls.CDVRQE1_TIVOSERVICE_URL,
            }
            url = tivoservice_url.get(Settings.test_environment)
            if not url:
                raise ValueError("Required url: {}, is not listed in: {}".format(Settings.test_environment,
                                                                                 tivoservice_url.keys()))
            else:
                return url

    def select_skip_this_step(self, tester, times=1, screenname=EXM_SCREEN_NAME):
        self.log.step("Ftux screen detected foreground, calling routine to skip it")
        for _ in range(times):
            self.screen.base.press_down()
            self.screen.base.press_right()
            self.screen.refresh()
            screen_dump = self.screen.get_screen_dump_item()
            tester.home_assertions.verify_skip_this_step_option(screen_dump)
            self.press_enter()
        self.wait_for_screen_ready(screenname, timeout=15000)
        self.screen.refresh()

    def force_stop_app_from_UI(self):
        # TODO move this method to set_top_box.client_api.system.page
        self.log.info("Force stop through UI..")
        app_name = self.home_labels.LBL_APP_NAME_FOR_MSO.get(Settings.mso)
        if not app_name:
            raise AssertionError(f"App name is not defined for mso {Settings.mso}")
        if self.screen.base.is_text_present("Apps"):
            self.screen.base.select_item_by_text("Apps")
            self.pause(5)
            if self.screen.base.is_text_present(app_name):
                self.screen.base.select_item_by_text(app_name)
                self.pause(5)
                if self.screen.base.is_text_present("Force stop"):
                    self.screen.base.select_item_by_text("Force stop")
                    self.pause(5)
                    if self.screen.base.is_text_present("OK"):
                        self.pause(5)
                        self.screen.base.press_down()
                        self.pause(3)
                        self.screen.base.press_up()
                        self.pause(3)
                        self.press_enter()
                        self.log.info("Force stop through UI and waiting..")
                        self.pause(5)
                    else:
                        raise AssertionError("Unable to select OK")
                else:
                    raise AssertionError("Unable to select Force stop")
            else:
                raise AssertionError("unable to select Cableco11")
        elif self.screen.base.is_text_present("Force stop"):
            self.screen.base.select_item_by_text("Force stop")
            self.pause(5)
            if self.screen.base.is_text_present("OK"):
                self.screen.base.press_down()
                self.pause(3)
                self.screen.base.press_up()
                self.pause(3)
                self.press_enter()
                self.log.info("Force stop through UI and waiting.. in elif block")
                self.pause(5)
            else:
                raise AssertionError("Unable to select OK")
        else:
            raise AssertionError("launching settings taking time. add delay")

    def launch_app_through_UI(self):
        # TODO move this method to set_top_box.client_api.system.page
        self.log.info("Launch App through UI..")
        if self.screen.base.is_text_present("Open"):
            self.screen.base.press_up()
            self.pause(1)
            self.screen.base.press_up()
            self.pause(1)
            self.press_enter()
        else:
            raise AssertionError("Unable to select Open")

    def exit_unmanaged_app(self, tester):
        self.log.info("Navigating to Exit Option")
        tester.home_assertions.verify_menu_item_available(self.home_labels.LBL_MENU_SHORTCUT)
        self.select_menu_shortcut(self.home_labels.LBL_MENU_SHORTCUT)
        self.nav_to_top_of_list()
        tester.menu_page.navigate_by_strip(self.home_labels.LBL_SYSTEM_AND_ACCOUNT)
        self.select_menu_by_substring(self.home_labels.LBL_EXIT)
        self.wait_for_screen_ready()

    def go_to_app_permission(self):
        self.log.info("Getting MSO from device")
        app_name = self.home_labels.LBL_APP_NAME_FOR_MSO.get(Settings.mso)
        if not app_name:
            raise AssertionError(f"App name is not defined for mso {Settings.mso}")
        self.pause(self.home_labels.LBL_SLEEP_TIME)
        if self.screen.base.is_text_present("Apps"):
            self.screen.base.select_item_by_text("Apps")
            self.log.info("Selected Apps")
            self.pause(self.home_labels.LBL_SLEEP_TIME)
            if self.screen.base.is_text_present(app_name):
                self.screen.base.select_item_by_text(app_name)
                self.log.info("Selected App name")
                self.pause(self.home_labels.LBL_SLEEP_TIME)
                self.log.info("Scrolling down to select permissions")
                for options in range(9):
                    self.screen.base.press_down()
                    self.pause(self.home_labels.LBL_SLEEP_TIME)
                if self.screen.base.is_text_present("Permission"):
                    self.screen.base.select_item_by_text("Permission")
                    self.log.info("Selected Permission")
                    self.pause(self.home_labels.LBL_SLEEP_TIME)
                elif self.screen.base.is_text_present("Permissions"):
                    self.screen.base.select_item_by_text("Permissions")
                    self.log.info("Selected Permissions")
                    self.pause(self.home_labels.LBL_SLEEP_TIME)
                else:
                    raise AssertionError("Unable to select Permission")
            else:
                raise AssertionError("Unable to select MSO")
        else:
            raise AssertionError("Unable to launch settings")

    def storage_enable_or_disable(self):
        time.sleep(self.home_labels.LBL_SLEEP_TIME)
        self.go_to_app_permission()
        if self.screen.base.is_text_present("Storage"):
            storage_value = self.screen.base.select_item_by_text("Storage")
            if storage_value:
                self.press_home_button()
                self.relaunch_hydra_app(reboot=True)
                self.log.info("Launching device settings screen")
                self.screen.base.launch_device_settings_screen()
                time.sleep(self.home_labels.LBL_SLEEP_TIME)
                self.go_to_app_permission()
                if self.screen.base.is_text_present("Storage"):
                    storage_value = self.screen.base.select_item_by_text("Storage")
                    if storage_value:
                        self.press_home_button()
                        time.sleep(self.home_labels.LBL_SLEEP_TIME)
                    else:
                        raise AssertionError("Not able to toggle storage permissions")
                else:
                    raise AssertionError("Storage option is not seen")
            else:
                raise AssertionError("Not able to toggle storage permissions")
        else:
            raise AssertionError("Storage value not returned")

    def drm_update(self, tester, request, feature, set_drmtype):
        request.getfixturevalue(self.home_labels.LBL_DRM_PRESERVE_PACKAGE)
        request.getfixturevalue(self.home_labels.LBL_DRM_REMOVE_PACKAGE)
        tester.home_page.update_drm_package_names_native(feature, set_drmtype)
        tester.home_assertions.verify_drm_package_names_native(feature, set_drmtype)
        tester.home_page.relaunch_hydra_app()

    def primary_branding_check(self, tester):
        for i in self.home_labels.LBL_SHORTCUTS_NUM:
            if i == self.home_labels.LBL_WATCHVIDEO_SHORTCUT:
                continue
            elif i == self.home_labels.LBL_GUIDE_SHORTCUT:
                continue
            elif i == self.home_labels.LBL_NOTIFICATION_SHORTCUT:
                continue
            self.back_to_home_short()
            self.select_menu_shortcut_num(tester, i)
            tester.home_assertions.verify_primary_branding_icon()

    def change_tivo_service_connection(self, enable=False, url=None):
        """"
        Method to change TiVo Service (Mind) state
        Args:
            enable (bool): TiVo Service to enable or disable
        """
        if enable:
            self.log.info("Enable TiVo Service.")
            self.relax_bandwidth_restrictions()
        else:
            self.log.info("Disable TiVo Service.")
            block_url = self.get_tivoservice_url() if not url else url
            self.set_download_limit_with_ip(ip_addr=block_url, speed=0)

    def nav_wtw_upto_overlay(self):
        iter = 0
        while iter < 50:
            if not self.is_overlay_shown():
                self.screen.get_json()
                self.screen.base.press_left(time=2000)
                iter += 1
            else:
                break
        else:
            raise AssertionError("What to watch side panel wasn't appear after 50 iteration")

    def get_text_from_current_screen(self):
        self.log.info("Getting text from current screen")
        img_path = self.screen.base.driver.dump_screen_cap_img()
        self.log.info(f"Image Path: {img_path}")
        frame = Image.open(f"{img_path}")
        text = self.convert_special_chars(pytesseract.image_to_string(frame))
        return text

    def check_for_non_hydra_screen_and_select(self, tester):
        limit = 7
        while limit > 0:
            text = self.get_text_from_current_screen()
            self.log.info(f"check_for_non_hydra_screen_and_select: {text}")
            if tester.home_labels.LBL_WANTS_TO_OPEN in text.lower():
                self.screen.base.native_key_press('select')
                self.pause(10, "Trying to open OTT App")
                limit -= 1
            elif tester.home_labels.LBL_APPLE_TV_UPDATE in text.lower():
                self.screen.base.native_key_press('down')
                self.screen.base.native_key_press('down')
                self.screen.base.native_key_press('select')
                self.pause(10, "pressed 2 times down and selected Update later")
                limit -= 1
            else:
                break
        else:
            text1 = self.get_text_from_current_screen()
            active_pkg = self.screen.base.get_foreground_package(get_all_active_pkg=True)
            self.home_page.log.info(f"Active package list: {active_pkg}")
            raise AssertionError(f"After 7 retries, script has not launched ott app. Current screen {text1}")

    def launch_hydra_when_script_is_on_ott(self):
        self.log.info("launch hydra when script is on ott")
        hydra_pkg = Settings.app_package
        for _ in range(2):
            fg_package = self.screen.base.get_foreground_package()
            if fg_package != hydra_pkg:
                self.screen.base.driver.launch_app(hydra_pkg)
                self.pause(30, "waiting for home screen to appear.")

    def is_privacy_optin_screen_view_mode(self):
        self.log.info("Checking if privacy optin screen displayed")
        self.screen.refresh()
        if self.view_mode() and self.home_labels.LBL_PRYVACY_OPTIN_VIEW_MODE in self.view_mode():
            return True
        else:
            self.log.warning("privacy optin is not displayed; actual {}, expected {}"
                             .format(self.view_mode(), self.home_labels.LBL_PRYVACY_OPTIN_VIEW_MODE))
            return False

    def select_accept(self, times):
        self.log.step("Selecting accept to get selling screen")
        for _ in range(times):
            self.screen.base.press_down()
            self.press_enter()
        self.wait_for_screen_ready(timeout=15000)
