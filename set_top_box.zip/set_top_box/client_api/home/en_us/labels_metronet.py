

class MetronetHomeLabels:
    def __init__(self):
        super().__init__()
        if self.LBL_ONDEMAND_SHORTCUT in self.LBL_HOME_MENU_ITEMS:
            self.LBL_HOME_MENU_ITEMS.remove(self.LBL_ONDEMAND_SHORTCUT)
