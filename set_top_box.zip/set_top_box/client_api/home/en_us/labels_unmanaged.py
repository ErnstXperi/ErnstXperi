from set_top_box.client_api.home.en_us.labels import HomeLabels as BaseHomeLbls


class UnmanagedHomeLabels(BaseHomeLbls):
    LBL_C228_BODYTEXT = "This box is no longer connected to the Internet. (C228) If you can't connect to the " \
                        "Internet from another device in your network, you may want to reboot your router. " \
                        "If you continue to experience this problem, contact CableCo11."
    LBL_RESTART_THE_BOX_NDVR = "Close the app"  # option on the nDVR enabled/disabled overlay
    # serviceCall overlay elements
    LBL_RESTART_NOW = "Exit now"
    LBL_RESTART_TO_APPLY_UPDATES_OVERLAY = "Exit & restart to apply updates"
    LBL_BODY_RESTART_TO_APPLY_UPDATES = "Your app has received an update that requires a restart to take effect. " \
                                        "Press Exit now' to exit, then restart the app. If you wish to apply " \
                                        "these updates at a later date, " \
                                        "press Remind me later."
    LBL_WANTS_TO_OPEN = "wants to open"
    LBL_APPLE_TV_UPDATE = "apple tv update"

    def __init__(self):
        super().__init__()
        self.LBL_HOME_MENU_ITEMS = [self.LBL_MENU_SHORTCUT,
                                    self.LBL_LIVETV_SHORTCUT,
                                    self.LBL_MYSHOWS_SHORTCUT,
                                    self.LBL_WHATTOWATCH_SHORTCUT,
                                    self.LBL_GUIDE_SHORTCUT,
                                    self.LBL_ONDEMAND_SHORTCUT,
                                    self.LBL_SEARCH_SHORTCUT,
                                    ]
        self.LBL_HOME_MENU_ITEMS_SHORTCUTS = [self.LBL_MENU_SHORTCUT,
                                              self.LBL_LIVETV_SHORTCUT,
                                              self.LBL_MYSHOWS_SHORTCUT,
                                              self.LBL_WHATTOWATCH_SHORTCUT,
                                              self.LBL_GUIDE_SHORTCUT,
                                              self.LBL_ONDEMAND_SHORTCUT,
                                              self.LBL_SEARCH_SHORTCUT,
                                              ]
