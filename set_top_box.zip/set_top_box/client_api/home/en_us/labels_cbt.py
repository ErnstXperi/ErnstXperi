from .labels import HomeLabels


class CBTHomeLabels(HomeLabels):
    LBL_WTW_SOCU_ICON = "http://i.tivo.com/images-static/bravo/providers/altav2_fioptics_image_socu_branding_live_tv_50x50.png"

    def __init__(self):
        super().__init__()
        self.LBL_HOME_MENU_ITEMS = [self.LBL_MENU_SHORTCUT, self.LBL_LIVETV_SHORTCUT, self.LBL_GUIDE_SHORTCUT,
                                    self.LBL_MYSHOWS_SHORTCUT, self.LBL_WHATTOWATCH_SHORTCUT,
                                    self.LBL_APPSANDGAME_SHORTCUT, self.LBL_ONDEMAND_SHORTCUT,
                                    self.LBL_SEARCH_SHORTCUT]
        self.LBL_SHORTCUTS_NUM = {self.LBL_MENU_SHORTCUT: '0',
                                  self.LBL_WATCHVIDEO_SHORTCUT: '1',
                                  self.LBL_LIVETV_SHORTCUT: '1',
                                  self.LBL_GUIDE_SHORTCUT: '2',
                                  self.LBL_MYSHOWS_SHORTCUT: '3',
                                  self.LBL_WHATTOWATCH_SHORTCUT: '4',
                                  self.LBL_APPSANDGAME_SHORTCUT: '5',
                                  self.LBL_ONDEMAND_SHORTCUT: '6',
                                  self.LBL_SEARCH_SHORTCUT: '7',
                                  self.LBL_NOTIFICATION_SHORTCUT: '9'
                                  }
