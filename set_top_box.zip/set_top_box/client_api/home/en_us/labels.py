from set_top_box.test_settings import Settings
from set_top_box.conf_constants import HydraBranches


class HomeLabels:
    LBL_WELCOME_SCREEN = "welcomesplash.WelcomeSplashScreenView"
    LBL_DIMMING_SCREEN_VIEW_MODE = "dimming.DimmingScreenView"
    LBL_DIMMING_OSD_LOGO = "hydra_streamer_image_primary_branding_live_tv.png" \
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_13) \
        else "hydra_image_primary_branding_live_tv.png"
    LBL_DIMMING_OSD_TEXT = "Press OK/SELECT to return to TiVo." \
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15) \
        else "Press OK to return to TiVo."
    LBL_HOME_SCREENTITLE = "HOME"
    LBL_HOME_MENUITEMS = ["NOTIFICATIONS", "MENU", "LIVE TV", "MY SHOWS", "WHAT TO WATCH", "GUIDE", "APPS & GAMES",
                          "ON DEMAND", "SEARCH"]
    LBL_MENU_LOCK_SHORTCUT_ICON = "com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_strip_lock_active.png"
    LBL_MENU_UNLOCK_SHORTCUT_ICON = "com/tivo/applib/ResAppLibImages/" \
                                    "applib/images/hydra/hydra_icon_strip_unlock_active.png"
    LBL_MENU_SHORTCUT = "MENU"
    LBL_MENU_SCREENTITLE = "MENU"
    LBL_WATCHVIDEO_SHORTCUT = "WATCH TV"
    LBL_GUIDE_SHORTCUT = "GUIDE"
    LBL_GUIDE_SCREENTITLE = "GUIDE"
    LBL_MYSHOWS_SHORTCUT = "MY SHOWS"
    LBL_SEARCH_SHORTCUT = "SEARCH"
    LBL_WHATTOWATCH_SHORTCUT = "WHAT TO WATCH"
    LBL_LIVETV_SHORTCUT = "WATCH TV"
    LBL_NOTIFICATION_SHORTCUT = "NOTIFICATIONS"
    LBL_APPSANDGAME_SHORTCUT = "APPS & GAMES"
    LBL_ONDEMAND_SHORTCUT = "ON DEMAND"
    LBL_ONDEMAND_SCREENTITLE = "ON DEMAND"
    LBL_CREATE_ONEPASS = "Create OnePass"
    LBL_FTUX_TITLE = "FIRST TIME UX"
    LBL_FTUX_ANIMATION = "ftux.FtuxOpeningAnimationScreenView"
    LBL_FTUX_EULA = "privacy.UserAgreementScreenView"
    LBL_FTUX_EULA_SCREENTITLE = "TiVo User Agreement & Privacy Policy"
    LBL_FTUX_VIEW_MODE = "ftux.FtuxOnePassScreenView"
    LBL_VIEW_USER_AGREEMENT = 'View TiVo User Agreement'
    LBL_VIEW_PRIVACY_POLICY = 'View TiVo Privacy Policy'
    LBL_LICENSE_PLATE = "LICENSE PLATE"
    LBL_LICENSE_PLATE_VIEW = "signin.licenseplate.LicensePlateScreenView"
    LBL_LICENSE_PLATE_SCREEN = "LicensePlateScreen"
    LBL_CREATE_ONEPASS_WITH_THESE_OPTIONS = "Create OnePass with these options"
    LBL_ONEPASS_WHISPER = "A OnePass has been created."
    LBL_ONEPASS_WHISPER_CANCEL = 'This series will not record.'
    TURN_SCREEN_READER_ON = "Turn Screen Reader ON"
    # What to Watch lables
    LBL_ON_TV_TODAY = "On TV Today"
    LBL_HOME = "Home"
    LBL_COLLECTIONS = "Collections"
    LBL_SPORTS = "Sports"
    LBL_MOVIES = "Movies"
    LBL_TV_SERIES = "TV Series"
    LBL_KIDS = "Kids"
    LBL_LIVE_TV = "Live TV"
    LBL_MODIFY_ONEPASS = "Modify OnePass"
    LBL_HOME_SCREEN_NAME = "HomeMainScreen"
    LBL_ONEPASS_FTUX = "OnePassQuickSelectScreen"
    LBL_HOME_SCREEN_MODE = "home.HomeScreenView"
    LBL_WTW_SCREEN_MODE = "whattowatch2.WTWScreenView"  # What to Watch screen mode
    LBL_EAS_VIEW = "eam.EamScreenView"
    LBL_CANADIAN_EAS_VIEW = "eam.EamCanadaScreenView"
    LBL_FLOATING_EAS_VIEW = "eam.EamFloatingScreenView"
    LBL_GOING_TO_LIVE_TV_OSD = "Going to Live TV"
    LBL_WTW_PRIMARY_SCREEN = "W2WPrimaryScreen"
    LBL_WTW_SIDE_PANEL = "W2WSidePanelScreen"
    # IBC
    # LBL_HOME_SCREENTITLE = "HOME"
    # LBL_MENU_SHORTCUT = "Menu"
    # LBL_GUIDE_SHORTCUT = "Guide"
    # LBL_MYSHOWS_SHORTCUT = "My Shows"
    # LBL_SEARCH_SHORTCUT = "Search"
    # LBL_WHATTOWATCH_SHORTCUT = "What to Watch"
    LBL_STREAMINGAPPS_FTUX = "StreamingAppsScreen"
    LBL_PCSETTINGS_FTUX = "OptionalParentalControlsScreen"
    LBL_PCSETTINGS_FTUX_VIEW_MODE = "ftux.FtuxParentalControlsScreenView"
    LBL_STREAMINGAPPS_FTUX_VIEW_MODE = "ftux.FtuxStreamingAppsScreenView"
    LBL_ONEPASS_ICON_FTUX = "hydra_icon_status_onepass.png"
    LBL_SIGN_IN = "SamlSignInScreen"
    LBL_PRYVACY_OPTIN_VIEW_MODE = "privacy.PrivacyCommonScreenView"
    LBL_SIGN_IN_SCREEN_VIEW_MODE = "signin.saml.SamlSigninScreenView"
    LBL_FTUX_ANIMATION_SCREEN = "OpeningAnimationScreen"
    LBL_SYSTEM_AND_ACCOUNT = "SYSTEM & ACCOUNT"
    LBL_SIGN_OUT = "Sign Out & Exit"
    LBL_SIGN_IN_TITLE = "SIGN IN"
    LBL_EXIT_APP_OVERLAY = "ExitAppConfirmationOverlay"
    LBL_OK = "OK"
    LBL_WHAT_TO_WATCH_TV_ICON = "hydra_icon_source_tv_C0.png"
    LBL_STREAMING_VIDEO_ICON = "hydra_icon_source_streaming_video.png"
    LBL_WHAT_TO_WATCH_NETFLIX_ICON = "hydra_icon_source_Netflix_C0_32x32.png"
    LBL_WHAT_TO_WATCH_VUDU_ICON = "hydra_icon_source_vudu_C0_32x32.png"
    LBL_WHAT_TO_WATCH_VUDU_FANDANGO_ICON = "Vudu_Fandango_48x48.png"
    LBL_WHAT_TO_WATCH_AMAZON_ICON = "hydra_icon_source_AmazonCS_C0_48x48.png"
    LBL_WHAT_TO_WATCH_STARZ_ICON = "hydra_icon_source_starz_C0_32x32.png"
    LBL_WHAT_TO_WATCH_HULU_ICON = "hydra_icon_source_hulu_C0_32x32.png"
    LBL_WHAT_TO_WATCH_GOOGLE_PLAY_ICON = "hydra_icon_source_Google_Play_C0_32x32.png"
    LBL_WTW_GOOGLE_PLAY_ICON = "Google_Play_Movies_TV_icon_source_C0_32x32"
    LBL_WHAT_TO_WATCH_HBO_ICON = "HBOGO_C0_32x32.png"
    LBL_WTW_EPISODESCREEN = "EpisodeScreen"
    LBL_WTW_ALLEPISODES_LIST = "AllEpisodesList"
    LBL_PERSON_ICON = "hydra_icon_person.png"
    LBL_EPISODIC = "Episodic"
    LBL_NON_EPISODIC = "Non-Episodic"
    LBL_PERSON = "Person"
    LBL_WTW_SOCU_ICON = "http://i.tivo.com/images-static/bravo/providers/hydra_icon_source_socu_50x50.png"
    LBL_SOCU_ICON = "hydra_icon_source_socu"
    LBL_DEVICE_SETTINGS_TITLE = "Settings"
    LBL_SUGGESTIONS = "Suggestions"
    LBL_GOOGLE = "Google"
    LBL_REMOVE_ACCOUNT = "Remove account"
    LBL_NOTIFICATIONS = "Notifications"
    LBL_YOUTUBE = "Youtube"
    LBL_NETFLIX = "Netflix"
    LBL_GAME_NAME = "Red ball 4"
    GAME_APP_PACKAGE = "com.FDGEntertainment.redball4.gp"
    LBL_GAME_INSTALL = "Install"
    LBL_LIST_OF_APP_NAMES = ["BombSquad", "Real Racing 3",
                             "Crossy Road", "Red ball 4", "Hungry Shark Evolution", "ESPN",
                             "BADLAND", "FITE", "MotoGP Racing '20", "Spotify", "Learn English Today",
                             "TED", "VUDU", "Red Bull TV", "MX Player", "ZEE5", "YouTube Kids",
                             "Asphalt 8 - Car Racing Game", "Magic Rampage", "Prime Video", "DAZN", "NBC", "PBS KIDS Video",
                             "Peacock TV", "Pluto TV", "PBS Video"]
    LBL_LIST_OF_PACKAGE_NAMES = ['com.google.android.youtube.tvkids', 'com.learn_english_today', 'com.graymatrix.did',
                                 'com.mxtech.videoplayer.ad', 'com.yodo1.crossyroad', 'com.FDGEntertainment.redball4.gp',
                                 'com.fgol.HungrySharkEvolution', 'com.hyperkani.bomberfriends', 'com.frogmind.badland',
                                 'net.froemling.bombsquad', 'com.ea.games.r3_row',
                                 'com.flipps.fitetv', 'com.spotify.tv.android', 'com.ted.android.tv', 'com.dazn',
                                 'com.asanteegames.magicrampage', 'com.gameloft.android.ANMP.GloftA8HM', 'com.pbs.video',
                                 'com.espn.score_center', 'com.mxtech.videoplayer.television', 'org.pbskids.video',
                                 'com.peacocktv.peacockandroid', 'tv.pluto.android', 'air.com.vudu.air.DownloaderTablet',
                                 'com.ea.games.r3_na', 'com.nousguide.android.rbtv']
    LBL_MINIMUM_MEMORY = 480
    LBL_INSUFFICIENT_STORAGE = 'Insufficient storage'
    LBL_NOT_ENOUGH_STORAGE = 'Not enough space to install'
    LBL_CANCEL = 'CANCEL'
    LBL_ACCEPT = 'Accept'
    LBL_CONTINUE = 'Continue'
    LBL_CONNECT_GAMEPAD = 'Connect a gamepad'
    LBL_APP_PERMISSIONS = 'App permissions'
    LBL_EXIT_VIDEO_OVERLAY = "Are You Sure You Want to Exit?"
    LBL_KEEP_TRYING = "Keep trying"
    LBL_EXIT_VIDEO = "Exit video"
    LBL_GO_TO_HOME = "Go to Home"
    LBL_GO_TO_GUIDE = "Go to Guide"
    LBL_FTUX_ANIMATION_VIEW_MODE = "ftux.FtuxOpeningAnimationScreenView"
    LBL_ONEPASS_FTUX_VIEW_MODE = "ftux.FtuxOnePassScreenView"
    LBL_SET_BRIDGE_UP = "set up"
    LBL_SET_BRIDGE_DOWN = "set down"
    LBL_BRIDGE_STATUS_UP = "up"
    LOC_SAML_USERNAME = {"resourceId": "username"}
    LOC_SAML_PASSWORD = {"resourceId": "password"}
    LOC_SAML_SIGN_IN = {"text": "Sign In"}
    LBL_BRIDGE_STATUS_DOWN = "down"
    LBL_QUICK_TOUR = "Quick Tour"
    LBL_EAS_MESSAGE = "A broadcast or cable system has issued A CHILD ABDUCTION EMERGENCY for the following" \
                      " counties or areas: Alameda, Alpine, Butte, Message from KTIVO/FM"
    LBL_FLOATING_EAS_MESSAGE = "This is test message for FLOATING EAS to verify it is scrolled twice and disappears"
    LBL_FLOATING_EAS_MESSAGE_ANCHOR = 'EMERGENCY ALERT'
    LBL_FLOAT_EAS_LIVE_VIDEO_URL = "http://live1.nokia.tivo.com/ktvuplus/vxfmt=dp/playlist.m3u8?device_profile=hlsclr"
    LBL_EAS_MESSAGE_CRAWLING_ANCHOR_BROADCAST = 'broadcast'
    LBL_EAS_MESSAGE_CRAWLING_ANCHOR_CHILD = 'CHILD'
    LBL_REGULAR_EAS_BODY = "Press BACK to dismiss"
    LBL_REGULAR_EAS_BODY_APPLE = "Press MENU to dismiss"
    LBL_DISCONNECTED_WHISPER_TEXT = "Something went wrong. Some features may not be available. Press OK for more \
information.(C806)" \
        if Settings.hydra_branch() >= Settings.hydra_branch(HydraBranches.STREAMER_1_15) \
        else "Your box is not connected to the Internet. Some features may not be available. \
Press OK for more information."
    LBL_NO_NETWORK_OVERLAY_TITLE = "No Network Connection"
    LBL_NO_NETWORK_OVERLAY_BODYTEXT = "The device needs an Internet connection. Go to your device's network \
settings to restore your connection."
    LBL_C228_BODYTEXT = "This box is no longer connected to the Internet. (C228) If you can't connect to the Internet " \
                        "from another device in your network, you may want to reboot your router. If you continue to" \
                        " experience this problem, contact CableCo11."
    LBL_ERROR_CODE_C228 = "C228"
    LBL_ERROR_CODE_C219 = "C219"
    LBL_ERROR_CODE_C601 = "C601"
    LBL_ERROR_CODE_C627 = "C627"
    LBL_ERROR_CODE_C229 = "C229"
    LBL_GET_ACTIVATION_CODE = "Get a new activation code"
    LBL_C601_BODYTEXT = ["There was a problem signing in to your account. (C601) Please try again in a few \
minutes. If you continue to experience this problem, contact your operator for support.", "There was a problem \
signing in to your account. (C601) Please try again in a few minutes. If you continue to experience this problem, \
contact CableCo11 Customer Support at 1-800-CABLECO."]
    LBL_C606_OVERLAY = ['Account Error', 'There is a problem connecting to your CableCo11 Service account. \
Contact CableCo11 Customer Support at 1-800-CABLECO.', 'C606', 'There is a problem connecting to your account. \
Contact your operator for support.']
    LBL_ACCOUNT_LOCKED_OVERLAY = ['Account Error', 'There is a problem connecting to your CableCo3 Service \
account. Contact CableCo Customer Support at 1-888 234-5678.', 'C613']
    LBL_PCID = ''

    # emergency alerts labels
    LBL_EMERGENCY_ALERT_FRENCH = 'ALERTE D\'URGENCE'
    LBL_EMERGENCY_ALERT_ENG_US = 'EMERGENCY ALERT'

    # intersection with Guide
    LBL_RECORD_OVERLAY = "RecordOverlay"
    LBL_CHANNEL_OPTIONS_WATCH_NOW = "Watch now"
    LBL_WATCH_FROM_CATCH_UP = 'Catch Up'
    LBL_PROGRAM_OPTIONS_WATCH_LIVE = "Watch live"
    LBL_ALL_EPISODES = "All Episodes"
    LBL_HD = "HD"
    LBL_TRY_AGAIN_SCREEN = "TryAgainLaterOverlay"
    LBL_SOCU_PLAYBACK_SCREEN = "TvWatchStreamingVideoScreen"
    LBL_UPGRADE_SETTINGS_OVERLAY_TITLE = "OnePass and Recordings Default Settings Upgraded"
    LBL_UPDATED_SETTINGS_OVERLAY_TITLE = "OnePass and Recordings Default Settings Updated"
    LBL_ENABLE_SYSTEM_NOTIFICATIONS = "Enable System Notifications"
    LBL_CANT_PLAY_OVERLAY_TITLE = "Can't Play"
    LBL_AUTHORIZATION_REQUIRED_OVERLAY_TITLE = "Authorization Required"
    LBL_PTCM_REC_DISABLED_TITLE = "Recording Feature Disabled"
    LBL_PTCM_REC_ENABLED_TITLE = "Recording Feature Enabled"
    LBL_APP_DATA_CLEARED_OVERLAY_TITLE = 'Your App Data Has Been Cleared'
    LBL_UNKNOWN_USER_AGREEMENT = "UNKNOWN User Agreement & Privacy Policy"
    LBL_POPUP_OVERLAYS = [LBL_UPGRADE_SETTINGS_OVERLAY_TITLE, LBL_UPDATED_SETTINGS_OVERLAY_TITLE,
                          LBL_ENABLE_SYSTEM_NOTIFICATIONS, LBL_CANT_PLAY_OVERLAY_TITLE,
                          LBL_AUTHORIZATION_REQUIRED_OVERLAY_TITLE, LBL_PTCM_REC_DISABLED_TITLE,
                          LBL_PTCM_REC_ENABLED_TITLE, LBL_APP_DATA_CLEARED_OVERLAY_TITLE, LBL_UNKNOWN_USER_AGREEMENT]

    # restart reason labels
    LBL_CLEAR_DATA_RESULT = "FirstStart"
    LBL_FORCE_STOP = "Am_App_Force_Stop"
    LBL_SIGNOUT_RESULT = "Haxe_App_SignOut"
    LBL_EXIT_RESULT = "Haxe_Ui_User_Exit"
    LBL_EXIT = "Exit App"
    LBL_STORAGE_PERMISSIONS = "Am_App_Kill"
    LBL_REBOOT_REASON = "OS_Restart: Cold"
    LBL_CHANGE_LANG = "Device_Language_Change"
    LBL_HOME_SCREENTITLE_SPANISH = "INICIO"

    # label for device feature search query response
    LBL_DEVICE_FEATURE_SEARCH_RESPONSE = "handleDeviceFeatureSearchQueryResponse()"
    LBL_LOGCONTROL_OPERATIONAL_3rd_PARTY_LOGS = "LogControl"
    LBL_OPERATIONAL_3rd_PARTY_LOGS = "log3rdparty"
    LBL_NEWVALUE = "newValue"
    LBL_OLDVALUE = "previousValue"
    LBL_DIAGNOSTICS_FEATURE_ATTRIBUTE_MODEL = "FeatureAttributeModel"
    LBL_FORCEBACKHAUL = "forceBackhaul"

    # tts labels
    LBL_TTS_NAVIGATION = 'press down for'

    LBL_HOME_VIEW_MODE = "home.HomeScreenView"

    LBL_LANGUAGE_NOT_SUPPORTED_OVERLAY_TITLE = "Language Not Supported"
    LBL_LANGUAGE_NOT_SUPPORTED_BODY_TEXT = "The box does not support the selected language. " \
                                           "Supported languages currently include English, Spanish"
    LBL_WHATS_NEW_OVERLAY = "What's New"
    LBL_ACCOUNT_LOCKED_SCREEN_TITLE = "ACCOUNT LOCKED"
    LBL_NETFLIX_SHORTCUT = "NETFLIX"
    LBL_PREDICTIONS_ADS = "/predictions"
    LBL_AD_ACTION_UI_NAVIGATE = 'uiNavigateAction'
    LBL_AD_ACTION_NO_OP_UI = 'noOpUiAction'
    LBL_AD_ACTION_LIVETV_UI = 'liveTvUiAction'
    LBL_AD_ACTION_WALLED_GARDEN = 'walledGardenBrowseUiAction'
    LBL_AD_ACTION_COLLECTION_DETAIL_UI = 'collectionDetailUiAction'
    KEY_DRM_ANDROID_NATIVE = "widevine"
    KEY_DRM_ANDROID_DEFAULT = "verimatrix"
    KEY_DRM_APPLETV_NATIVE = "fairPlay"
    KEY_DRM_APPLETV_DEFAULT = "verimatrix"
    KEY_IPLINEAR_SESSIONMANAGERTYPE = "trioSodi"
    KEY_NPVR_SESSIONMANAGERTYPE = "sodi"
    KEY_SOCU_SESSIONMANAGERTYPE = "trioSodi"
    KEY_CUBIVOD_SESSIONMANAGERTYPE = "trioSodiCubiAuth"
    LBL_DRM_PRESERVE_PACKAGE = "preserve_initial_package_state"
    LBL_DRM_REMOVE_PACKAGE = "remove_packages_if_present_before_test"
    LBL_HOME_PAGE_ERRORS = ['601', '219', '210', '218']
    LBL_C628 = "C628"
    LBL_C605 = "C605"
    LBL_C608 = "C608"
    LBL_C630 = "C630"
    LBL_C629 = "C629"
    LBL_C631 = "C631"
    LBL_C634 = "C634"
    LBL_FOOTER_ICON_ACTIVE_USER_ANIMATION_TIME = 10
    LBL_FOOTER_ICON_IDLE_USER_TIMEOUT = 25
    LBL_FOOTER_ICON_IDLE_USER_ANIMATION_TIME = 16
    LBL_FOOTER_ICON_ANIMATION_TIME_PAUSE = 4
    LBL_AUTOMATION_PAUSE_TIME = 180
    LBL_SLEEP_TIME = 10

    LBL_RECORDING_DISABLED = "Recording Feature Disabled"  # nDVR overlay
    LBL_RECORDING_ENABLED = "Recording Feature Enabled"  # nDVR overlay
    LBL_RESTART_THE_BOX_NDVR = "Restart the TiVo box"  # option on the nDVR enabled/disabled overlay
    LBL_ERROR_MSG_276 = "Show Unavailable for This Provider"

    # Messaging (custom messages)
    LBL_REMIND_ME_LATER_OVERLAY = "Remind Me Later"
    LBL_REMIND_ME_LATER_OPTION = "Remind me later"
    LBL_DELETE_THIS_MESSAGE_OPTION = "Delete this message"
    LBL_RESTART_NOW = "Restart now"
    LBL_RESTART_TO_APPLY_UPDATES_OVERLAY = "Restart your device to apply updates"
    LBL_BODY_RESTART_TO_APPLY_UPDATES = "Your device has received an update which requires a restart. " \
        "Press 'Restart now' to restart your device. If you wish to restart your device at a later date, " \
        "press Remind me later."
    LBL_DEFAUL_SUBJECT = "UTAF"
    LBL_DEFAULT_TEXT = "This message was sent from UTAF"
    LBL_SUBJECT_MESSAGE_1 = "Message #1"
    LBL_SUBJECT_MESSAGE_2 = "Message #2"
    LBL_SUBJECT_MESSAGE_3 = "Message #3"
    LBL_GLOBAL_ASSIST_TRIGGERING = "com.google.android.feature.GLOBAL_ASSIST_TRIGGERING"
    LBL_KATNISS = 'com.google.android.katniss'
    LBL_NETFLIX_SOURCE_11 = '"NETFLIX_SOURCE_TYPE":"11"'
    LBL_NETFLIX_SOURCE_4 = '"NETFLIX_SOURCE_TYPE":"4"'
    LBL_NETFLIX_SOURCE_21 = '"NETFLIX_SOURCE_TYPE":"21"'
    LBL_NETFLIX_SOURCE_18 = '"NETFLIX_SOURCE_TYPE":"18"'
    LBL_NETFLIX_SOURCE_17 = '"NETFLIX_SOURCE_TYPE":"17"'
    LBL_NETFLIX_SOURCE_9 = '"NETFLIX_SOURCE_TYPE":"9"'
    LBL_NETFLIX_SOURCE_3 = '"NETFLIX_SOURCE_TYPE":"3"'
    LBL_DREAM = "dream"

    # MDRM provisioning info search feature type
    LBL_IPLINEAR_PROVISIONING_INFO_SEARCH = "ipLinearConfiguration"
    LBL_NDVR_PROVISIONING_INFO_SEARCH = "npvrConfiguration"
    LBL_VOD_PROVISIONING_INFO_SEARCH = "ipVodConfiguration"

    # Legal Acceptance screens
    LBL_INTRODUCTORY_SCREEN = "OperatorIntroductoryScreen"
    LBL_LEGAL_EULA_SCREEN = "OperatorUserAgreementScreen"
    LBL_PERSONALIZED_ADS_SCREEN = "OperatorPersonalizedAdsScreen"
    LBL_DATA_SHARING_SCREEN = "OperatorViewershipDataScreen"
    LBL_INTRODUCTORY_VIEW = "privacy.OperatorIntroductoryScreenView"
    LBL_PRIVACY_SCREENS_VIEW = "privacy.PrivacyCommonScreenView"
    LBL_INTRODUCTORY_SCREEN_TITLE = "Introductory"
    LBL_LEGAL_EULA_SCREEN_TITLE = Settings.mso + " User Agreement & Privacy Policy"
    LBL_PERSONALIZED_ADS_SCREEN_TITLE = "Personalized Ads"
    LBL_DATA_SHARING_SCREEN_TITLE = "Viewership Data Sharing"
    LBL_LEGAL_ACCEPTANCE_SCREENS = [LBL_INTRODUCTORY_VIEW, LBL_PRIVACY_SCREENS_VIEW]
    LBL_ALLOW_PERSONALIZED_ADS = "Allow Tracking for Personalized Ads"
    LBL_DO_NOT_ALLOW_PERSONALIZED_ADS = "Do Not Allow Tracking for Personalized Ads"
    LBL_ALLOW_DATA_SHARING = "Allow Sharing of My Viewership Data"
    LBL_DO_NOT_ALLOW_DATA_SHARING = "Do Not Allow Sharing of My Viewership Data"
    LBL_APP_NAME_FOR_MSO = {"cableco3": "Cableco3", "cableco11": "Cableco11", "llacr": "Liberty CAR",
                            "llagd": "Liberty CAR", "midco": "Midco", "cableco5": "Cableco5",
                            "astound": "Astound TV+", "blueridge": "Blue Ridge", "tds": "TDS"}
    LBL_LIST_OF_ENVIRONMENTS = ["staging", "cdvrqe1", "latam_staging", "preprod", "prod", "latam_prod", "usqe3a"]
    # OpenAPI SLS
    LBL_SLS_ENDPOINTS_REQUEST = "https://production-canary.sls.prod.tivoservice.com:443/serviceEndpoints"
    LBL_SLS_ENDPOINTS_FILE = "SLS_ENDPOINTS"
    LBL_PIN_OVERLAY_MARKER = "Press OK/SELECT to enter your PIN"
    LBL_CRASH_MARKER = ['appRestartReason.*crashSignature.*CI:', 'AndroidRuntime.*tivo', 'EXTERNAL ASSERT',
                        'Fatal signal.*tivo', 'Assert.*Observed']
    LBL_ISSUE_GUIDE = "There is an issue with the guide"
    LBL_ON_DEMAND_SRC_ICON = "icon_source_D0"

    def __init__(self):
        self.LBL_HOME_MENU_ITEMS = [self.LBL_MENU_SHORTCUT, self.LBL_LIVETV_SHORTCUT, self.LBL_MYSHOWS_SHORTCUT,
                                    self.LBL_WHATTOWATCH_SHORTCUT, self.LBL_GUIDE_SHORTCUT,
                                    self.LBL_APPSANDGAME_SHORTCUT,
                                    self.LBL_ONDEMAND_SHORTCUT, self.LBL_SEARCH_SHORTCUT]
        self.LBL_SHORTCUTS_NUM = {self.LBL_MENU_SHORTCUT: '0',
                                  self.LBL_WATCHVIDEO_SHORTCUT: '1',
                                  self.LBL_LIVETV_SHORTCUT: '1',
                                  self.LBL_MYSHOWS_SHORTCUT: '2',
                                  self.LBL_WHATTOWATCH_SHORTCUT: '3',
                                  self.LBL_GUIDE_SHORTCUT: '4',
                                  self.LBL_APPSANDGAME_SHORTCUT: '5',
                                  self.LBL_ONDEMAND_SHORTCUT: '7',
                                  self.LBL_SEARCH_SHORTCUT: '8',
                                  self.LBL_NOTIFICATION_SHORTCUT: '9'
                                  }

        self.LBL_WTW_MENU_LIST = [self.LBL_ON_TV_TODAY, self.LBL_COLLECTIONS, self.LBL_SPORTS, self.LBL_MOVIES,
                                  self.LBL_TV_SERIES, self.LBL_KIDS]
        self.LBL_MENU_LOCK_SHORTCUT = [self.LBL_MENU_SHORTCUT, self.LBL_MENU_LOCK_SHORTCUT_ICON]
        self.LBL_MENU_UNLOCK_SHORTCUT = [self.LBL_MENU_SHORTCUT, self.LBL_MENU_UNLOCK_SHORTCUT_ICON]
        self.LBL_WTW_ICON_LIST_OTT = [self.LBL_WHAT_TO_WATCH_NETFLIX_ICON, self.LBL_WHAT_TO_WATCH_VUDU_ICON,
                                      self.LBL_WHAT_TO_WATCH_HULU_ICON,
                                      self.LBL_WHAT_TO_WATCH_GOOGLE_PLAY_ICON]
        self.LBL_HOME_MENU_ITEMS_SHORTCUTS = [self.LBL_MENU_SHORTCUT,
                                              self.LBL_LIVETV_SHORTCUT,
                                              self.LBL_MYSHOWS_SHORTCUT,
                                              self.LBL_WHATTOWATCH_SHORTCUT,
                                              self.LBL_GUIDE_SHORTCUT,
                                              self.LBL_APPSANDGAME_SHORTCUT,
                                              self.LBL_ONDEMAND_SHORTCUT,
                                              self.LBL_SEARCH_SHORTCUT,
                                              self.LBL_NOTIFICATION_SHORTCUT,
                                              ]
        self.LBL_PLAY_OPTIONS_LIST_SEARCH = [self.LBL_WHAT_TO_WATCH_TV_ICON,
                                             self.LBL_SOCU_ICON,
                                             self.LBL_ON_DEMAND_SRC_ICON]

    LBL_GK_ENDPOINTS_OVERRIDE = "bridge-keeper,api-tivo-lambda-wtwn-dsantha.dev.tivoservice.com,443"
    LBL_GK_LOGS_VERIFY = "The gatekeeper returned with timestamp <= 0, allowing service connection."
    LBL_ENABLE_SYSTEM_NOTIFICATIONS = "Enable System Notifications"
    LBL_ESM_BODY_TEXT = "We have detected that your System Notifications have been disabled. While this " \
                        "feature is off, you will not receive any messages about Android TV system. "\
                        "To provide the best experience, Google requires that System Notifications be enabled."
    LBL_HELP = "Help"
    LBL_CLOSE = "Close"
