class EastlinkHomeLabels():
    LBL_WTW_SOCU_ICON = "eastlink_icon_source_socu"
    LBL_EAS_VIEW = "eam.EamCanadaScreenView"
