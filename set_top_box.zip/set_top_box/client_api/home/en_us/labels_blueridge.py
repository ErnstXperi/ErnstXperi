from .labels import HomeLabels


class BLUERIDGEHomeLabels(HomeLabels):
    LBL_ONDEMAND_SHORTCUT = "BLUE RIDGE ON DEMAND"
    LBL_ONEPASS_WHISPER_CANCEL = 'This series will not record.'
