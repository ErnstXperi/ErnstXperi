class MillicomHomeLabels:
    LBL_SPORTS = "Deportes"
    LBL_MOVIES = "Peliculas"
    LBL_KIDS = "Infantil"
    LBL_EAS_VIEW = "eam.EamFloatingScreenView"
