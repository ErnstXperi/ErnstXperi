class MediacomHomeLabels():
    LBL_ONDEMAND_SHORTCUT = "XTREAM ON DEMAND"
