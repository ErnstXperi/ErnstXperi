from set_top_box.shared_context import ExecutionContext
from set_top_box.test_settings import Settings


class Loki_HomeLabels():

    def __init__(self):
        self.LBL_WTW_LABEL = 'WHAT_TO_WATCH_TITLE'
        self.LBL_MYSHOWS_LABEL = 'MY_SHOWS_TITLE'
        self.LBL_NOTIFICATIONS = 'FALLBACK_SHORTCUT_NOTIFICATIONS_NAME'
        self.LBL_MENU = 'MENU_TITLE'
        self.LBL_WATCH_TV = 'FALLBACK_SHORTCUT_WATCH_VIDEO_NAME'
        self.LBL_GUIDE = 'GUIDE_TITLE'
        self.LBL_APPS_GAMES = 'APPS_AND_GAMES_TITLE'
        self.LBL_ON_DEMAND = 'WATCHED_CONTENT_LABEL_VOD'
        self.LBL_SEARCH = 'SEARCH_TITLE'

        for k in vars(self).keys():
            if k.startswith('LBL'):
                vars(self)[k] = ExecutionContext.loki_labels.get_label_from_loki(vars(self)[k])
