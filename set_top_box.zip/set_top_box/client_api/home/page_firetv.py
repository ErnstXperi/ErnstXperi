from set_top_box.client_api.home.page_unmanaged import UnmanagedHomePage as DefaultHomePg
from tools.logger.logger import Logger
from set_top_box.test_settings import Settings


class FireTvHomePage(DefaultHomePg):
    __logger = Logger(__name__)

    def sign_in(self, wait_home=True):
        """
        Method to sign in to hydra app

        Args:
            wait_home (bool): True - waiting untill Home screen is shown, False - no waiting right after sign-in
        """
        self.wait_loading_indicator_disappear()
        self.wait_for_screen_ready("Screen", timeout=120000)
        self.screen.refresh()
        if self.is_license_plate_foreground():
            self.log.step("LP Sign In...")
            self.issue_activation_code()
            a_code = self.get_activation_code()
            self.iptv_prov_api.bind_device_with_activation_code(
                a_code, self.service_api.getPartnerCustomerId(Settings.tsn), self.service_api.get_mso_partner_id(Settings.tsn))
            self.wait_loading_indicator_disappear()
            self.screen.refresh()
            return
        if self.is_sign_in_foreground():
            self.verify_ui_element_on_screen(self.home_labels.LOC_SAML_USERNAME, 180000)
            if self.screen.base.is_text_present(self.home_labels.LOC_SAML_USERNAME):
                self.log.step("SAML Sign In... FireTv")
                self.screen.base.clear_text_by_locator(self.home_labels.LOC_SAML_USERNAME)
                self.screen.base.clear_text_by_locator(self.home_labels.LOC_SAML_PASSWORD)
                self.screen.base.click_by_locator(self.home_labels.LOC_SAML_USERNAME)
                self.pause(2)  # wait native keyboard load
                self.screen.base.type_text(Settings.username)
                self.screen.base.press_playpause()
                self.screen.base.type_text(Settings.password)
                self.screen.base.press_playpause()
                self.wait_for_screen_ready(timeout=30000)
                self.screen.get_json()
                if self.is_sign_in_foreground() and \
                        not self.screen.base.is_text_present(self.home_labels.LOC_SAML_SIGN_IN):
                    self.press_back_button()
                    self.pause(1)
                    self.screen.base.click_by_locator(self.home_labels.LOC_SAML_SIGN_IN)
                if wait_home:
                    self.wait_for_screen_ready(self.EXM_SCREEN_NAME, timeout=90000)
                self.screen.refresh()
