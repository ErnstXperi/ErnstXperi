'''
Created on Feb 19, 2020

@author: artur.kovalenko@tivo.com
'''

import os

import pytest

from core_api.stb.assertions import CoreAssertions
from set_top_box.test_settings import Settings
from tools.logger.logger import Logger
from set_top_box.client_api.home.page import HomePage as DefaultHomePg


class UnmanagedHomePage(DefaultHomePg):
    __logger = Logger(__name__)

    def back_to_home_short(self):
        self.__logger.step("Back to Home short... (unmanaged)")
        # Unmanaged SAML sign in

        max_retries = 6
        for i in range(max_retries):
            self.screen.refresh()  # we must be sure about initial state.
            self.dismiss_popup_overlay(self)
            if self.is_overlay_shown():
                if self.get_error_overlay_status() and self.get_overlay_code() == \
                   self.home_labels.LBL_REMIND_ME_LATER_OVERLAY:
                    self.log.info("Remind Me Later Overlay is displayed.")
                    self.screen.base.press_down()
                    self.screen.base.press_enter()
            if self.is_overlay_shown():
                if self.get_error_overlay_status():
                    overlay_code = self.screen.get_screen_dump_item('overlayTitleText')
                    if overlay_code == self.home_labels.LBL_KEEP_TRYING:
                        self.exit_video_overlay()
            if not self.is_home_screen_active():
                self.screen.base.press_back(100)
                self.wait_for_screen_ready()
            elif self.is_home_screen_active() and self.is_overlay_shown():
                self.screen.base.press_back(100)
                self.wait_for_screen_ready()
            else:
                break
        else:
            current_screen = self.view_mode()
            if self.get_error_overlay_status():
                overlay_code = self.screen.get_screen_dump_item('overlayTitleText')
                raise LookupError(f"Error overlay displayed after home screen retries. "
                                  f"Overlay code:{overlay_code} Current view:{current_screen}")
            raise LookupError(f"After {max_retries} retries still not at home screen. Screen title expected "
                              f"{self.home_labels.LBL_HOME_SCREENTITLE}, actual is {self.screen_title()}"
                              f"\nExpected 'HomeScreen' in view_mode, actual view_mode is {self.view_mode()}."
                              f"\nVerifying foreground app {Settings.app_package}"
                              f" - {self.screen.base.verify_foreground_app(Settings.app_package)}")

        self.wait_for_ui_element_exists('stripitem')
        # set focus to main strip if focus on prediction strip
        if self.is_prediction_strip_focused():
            self.press_up_button()
            self.screen.get_json()

        # move focus to first position (left)
        if not self.is_in_strip(self.home_labels.LBL_MENU_SHORTCUT):
            steps_to_move = 10
        else:
            strip = self.get_strip_array()
            steps_to_move = self.get_focus_index(strip)
        if steps_to_move:
            for i in range(steps_to_move):
                self.press_left_button()
            self.screen.get_json()

    def select_menu_shortcut(self, menu):
        self.log.info("Selecting {} shortcut".format(menu))
        if isinstance(menu, list):
            menu = menu[0]
            self.log.info(f"Select_menu_shortcut() received a list. Trunc to one element: menu={menu}")
        if menu == self.home_labels.LBL_LIVETV_SHORTCUT:
            self.log.info("Navigating to LIVE TV via Guide")
            self.goto_live_tv()
        else:
            if not self.is_strip_focus():
                self.screen.base.press_up()
            for _ in range(10):
                try:
                    for item in self.strip_list():
                        if item in menu:
                            menu = item
                            raise StopIteration
                except StopIteration:
                    break
                self.screen.base.press_right()
                self.screen.refresh()
            self.select_strip(menu)
        self.screen.refresh()

    def verify_key_press_to_wake_up_device(self, tester):
        self.log.info("To verify the remote key press to wake up the device")
        self.screen.base.press_back()
        self.pause(15)
        tester.home_assertions.verify_home_title()

    def exit_ott_app_with_back_or_exit_button(self):
        self.log.step("Exit app by back button")
        self.exit_ott_app_with_back_button()

    def exit_game_app_with_exit_or_home_button(self):
        self.log.step("Exit app by pressing Homebutton and launch tivo app")
        self.screen.base.press_home(2000)
        self.screen.base.launch_application(Settings.app_package)
        self.pause(5)

    def press_back_from_home_to_livetv(self, tester, view=None):
        self.log.info("To verify the navigation to livetv from Home screen")
        tester.home_page.goto_livetv_short(tester)
        view = tester.liveTv_labels.LBL_LIVETV_VIEWMODE
        self.verify_view_mode(view)
