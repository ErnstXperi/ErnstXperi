from set_top_box.client_api.home.page_unmanaged import UnmanagedHomePage as DefaultHomePg
from tools.key_event_server_if import KeyEventServerIf
from tools.logger.logger import Logger
from set_top_box.test_settings import Settings


class AppleTvHomePage(DefaultHomePg):
    __logger = Logger(__name__)
    initial_interaction = True

    def wake_up_box(self):
        """
        Wait initial app load and make sure that it ready for test
        """
        if AppleTvHomePage.initial_interaction:
            self.wait_for_screen_ready(self.home_labels.LBL_HOME_SCREEN_NAME, 40000)
            AppleTvHomePage.initial_interaction = False

        alive = KeyEventServerIf(Settings.device_ip, 12345).is_keyserver_available()
        if alive:
            for i in range(2):
                self.screen.base.press_up()
                self.pause(3)
        else:
            self.__logger.error("KeyEventServer is down")

    def sign_in(self):
        if self.is_license_plate_foreground():
            self.issue_activation_code()
            code = self.get_activation_code()
            self.iptv_prov_api.bind_device_with_activation_code(
                code, self.service_api.getPartnerCustomerId(Settings.tsn), self.service_api.get_mso_partner_id(Settings.tsn))
        self.wait_for_screen_ready(self.home_labels.LBL_HOME_SCREEN_NAME, 40000)
        self.screen.refresh()

    def is_home_screen_active(self):
        """
        Method to detect is current screen is home screen. It bases on screen title and view mode
        Returns:
        """
        if self.screen_title() and self.home_labels.LBL_HOME_SCREENTITLE in self.screen_title() and \
                self.view_mode() and "HomeScreen" in self.view_mode():
            active = True
        else:
            active = False
        self.log.debug("Home screen visibility status:{}. ViewMode: '{}', Title: '{}'".format(active,
                                                                                              self.view_mode(),
                                                                                              self.screen_title()))
        return active
