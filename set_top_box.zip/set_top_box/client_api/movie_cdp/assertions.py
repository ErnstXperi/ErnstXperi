from hamcrest import *
from set_top_box.client_api.movie_cdp.page import MovieCDPage


class MovieCDPAssertions(MovieCDPage):

    def verify_screen_title(self):
        screen_title = self.remove_service_symbols(self.screen_title())
        preview_title = self.remove_service_symbols(self.screen_title_text())
        assert_that(screen_title, contains_string(preview_title.upper()))

    def verify_screen_title_cast(self, cast):
        assert_that(self.screen_title(), equal_to(cast.upper()))

    def movie_screen_validation(self, tester):
        self.wait_for_screen_ready()
        self.log.info("Validation for screen type is biaxial or not with Navigation list")
        self.screen.refresh()
        value = tester.vod_page.is_biaxial_screen()
        assert value, "Movie screen type is not biaxial and no navigation list available"
        self.log.info("Validation for movie screen title displays with title and year")
        tester.movie_cdp_assertions.verify_screen_title()
        tester.guide_assertions.verify_year_in_title(converse=True)
        self.log.info("Preview pane display")
        assert_that(self.get_preview_panel(), not_none(), "No preview pane items available")
        self.log.info("Atmospheric Image display validation if available")
        image = self.get_atmospheric_image()
        atmospheric = tester.movie_cdp_labels.LBL_ATMOSPHERIC_IMAGE
        if image:
            if atmospheric not in image:
                raise AssertionError("Atmospheric Image is not available")
        self.log.info("Validation of title with Middle Word Truncation to display year")
        screentitle = self.screen_title()
        year = screentitle[-6:]
        truncatedTitle = screentitle.split(year)
        if year in truncatedTitle:
            raise AssertionError("Title not uses Middle Word Truncation to display movie year")
