class MovieCDPLabels(object):
    LBL_MOVIE_CDP_MAIN_STRIP_LIST = [u'On TV Today', u'My Shows', u'Sports', u'Movies', u'TV Series', u'Kids', u'Collections']
    LBL_ATMOSPHERIC_IMAGE = "atmospheric"
