from core_api.stb.assertions import CoreAssertions


class MovieCDPage(CoreAssertions):
    def screen_title_text(self):
        '''
        :return: Screen title from preview
        '''
        menu = (self.screen.get_screen_dump_item('previewPane'))
        screen_title_preview = menu['title']
        return screen_title_preview

    def get_cast_name(self):
        '''
        :return: return cast from strip
        '''
        self.nav_to_menu("Cast")
        self.screen.refresh()
        cast_name = self.strip_focus()
        self.screen.base.press_enter()
        self.screen.refresh()
        return cast_name
