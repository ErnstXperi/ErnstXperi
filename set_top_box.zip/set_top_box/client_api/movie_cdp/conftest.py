import pytest

from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.wtw.assertions import WhatToWatchAssertions
from set_top_box.client_api.movie_cdp.assertions import MovieCDPAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.client_api.guide.assertions import GuideAssertions
from tools.logger.logger import Logger
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from set_top_box.test_settings import Settings


@pytest.fixture(autouse=True, scope="class")
def setup_movie_cdp(request):
    """
    Configure steps to be executed before the test cases run
    :param request:
    :return:
    """
    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_assertions = HomeAssertions(request.cls.screen)
    request.cls.home_labels = LabelFactory("home", Settings)

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)

    request.cls.movie_cdp_page = PageFactory("movie_cdp", Settings, request.cls.screen)
    request.cls.movie_cdp_labels = LabelFactory("movie_cdp", Settings)
    request.cls.movie_cdp_assertions = MovieCDPAssertions(request.cls.screen)

    request.cls.wtw_page = PageFactory("wtw", Settings, request.cls.screen)
    request.cls.wtw_assertions = WhatToWatchAssertions(request.cls.screen)
    request.cls.wtw_assertions.wtw_page = request.cls.wtw_page
    request.cls.wtw_labels = LabelFactory("wtw", Settings)
    request.cls.wtw_page.wtw_labels = request.cls.wtw_labels
    request.cls.wtw_assertions.wtw_labels = request.cls.wtw_labels
    request.cls.wtw_page.home_labels = request.cls.home_labels
    request.cls.wtw_assertions.home_labels = request.cls.home_labels

    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)

    request.cls.my_shows_page = PageFactory("my_shows", Settings, request.cls.screen)
    request.cls.my_shows_labels = LabelFactory("my_shows", Settings)

    request.cls.vod_page = PageFactory("VOD", Settings, request.cls.screen)
    request.getfixturevalue('clean_ftux_and_sign_in')
    request.getfixturevalue('disable_parental_controls')
    request.cls.log = Logger(__name__)
