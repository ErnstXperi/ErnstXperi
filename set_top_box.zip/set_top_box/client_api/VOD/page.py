"""
Created on Aug 1, 2017

@author: sghosh
"""

import time
import re

import pytest

from core_api.stb.assertions import CoreAssertions
from tools.logger.logger import Logger
from set_top_box.test_settings import Settings
from set_top_box.conf_constants import PlatformList, VodPackageType
from set_top_box.client_api.VOD.en_us.labels import VODLabels


class VODPage(CoreAssertions):

    log = Logger(__name__)
    vod_labels = VODLabels()
    EXM_SCREEN_NAME = vod_labels.LBL_VOD_SCREEN

    def __init__(self, screen):
        super().__init__(screen)
        self.android_driver = None

    def extract_entryPoint(self, result):
        entry_point = None
        # the log wont bring any clearance for understanding a bug - must be INFO level
        self.log.info("Extracting entrypoint from result")
        if result is not None:
            if 'parentMix' in result:
                if 'childMix' in result['parentMix']:
                    entry_point = result['parentMix']['childMix']['entryPoint']
            entry_point = self.convert_special_chars(entry_point)
            self.log.info("Entry point :{}".format(entry_point))
            return entry_point
        else:
            pytest.skip("The content is not available on VOD catlog.")

    def extract_mixID(self, result):
        mixID = None
        self.log.info("Extracting Mix Id from result")
        if 'parentMix' in result:
            if 'childMix' in result['parentMix']:
                mixID = result['parentMix']['childMix']['mixId']
            self.log.info("Mix ID:{}".format(mixID))
        return mixID

    def extract_parentMixID(self, result):
        if 'parentMix' in result:
            if 'childMix' in result['parentMix']:
                return result['parentMix']['parentMixId']

    def extract_contentId(self, result):
        contentId = None
        self.log.info("Extracting Content ID from result")
        try:
            contentId = result['offer'].content_id
        except Exception:
            self.log.info("Content ID is not available for the offer")
            contentId = None
        if contentId is None:
            pytest.skip("Content ID is not available")
        else:
            self.log.info("Content ID:{}".format(contentId))
            return contentId

    def extract_collectionId(self, result):
        collectionId = None
        self.log.info("Extracting Collection ID from result")
        collectionId = result['offer'].collection_id
        self.log.info("Collection ID:{}".format(collectionId))
        return collectionId

    def extract_offerId(self, result):
        offerId = None
        self.log.info("Extracting offerId from result")
        offerId = result['offer'].offer_id
        self.log.info("offer ID:{}".format(offerId))
        return offerId

    def extract_title(self, result):
        self.log.info("Extracting title from result")
        try:
            title = result['offer'].title
            self.log.info("Title :{}".format(title))
        except KeyError:
            self.log.warning("Can't extract title, possible navigation issue")
            title = ""
        return self.remove_service_symbols(title)

    def extract_entitlement(self, result):
        entitlement = None
        self.log.info("Extracting entitlement from result")
        entitlement = result['offer'].entitlement
        self.log.info("Entitlement :{}".format(entitlement))
        return entitlement

    def extract_subtitle(self, result):
        title = None
        title = result['offer'].subtitle
        return title

    def extract_duration(self, result):
        duration = None
        duration = result['offer'].duration
        self.log.info("The asset playback duration is {}".format(duration))
        return duration

    def extract_season_episode(self, result):
        se = None
        season = 'S' + str(result['offer'].seasonNumber)
        episode = 'E' + str(result['offer'].episode_num)
        se = season + ' ' + episode
        return se

    def episodic(self, result):
        if result['offer'].episodic:
            return True
        else:
            return False

    def create_path_from_entryPoint(self, entry_point):
        self.log.info("Creating path using entry_point")
        entry_point = entry_point[1:]
        path = entry_point.split("/")
        self.log.info("Path from entrypoint: {}".format(path))
        return path

    def goto_section(self, path, tester):
        section = path
        self.log.info("Navigating to {}".format(section))
        limit = 0
        self.screen.refresh()
        while not self.is_in_menu(section):
            if limit > 5:
                break
            for i in range(5):
                if self.screen_view() == tester.vod_labels.LBL_BIAXIAL_SCREEN_VIEW_MODE:
                    self.screen.base.press_down(time=300)
                elif self.screen_view() == tester.vod_labels.LBL_GALLERY_SCREEN_VIEW_MODE:
                    self.screen.base.press_right(time=300)
            self.screen.refresh()
            limit += 1
        if self.screen_view() == tester.vod_labels.LBL_BIAXIAL_SCREEN_VIEW_MODE:
            self.log.warning("section contains {} ".format(section))
            self.log.info("menulist contains {}".format(str(self.menu_list())))
            self.nav_to_menu(section)
        elif self.screen_view() == tester.vod_labels.LBL_GALLERY_SCREEN_VIEW_MODE:
            self.log.warning("section horizontal contains {}".format(section))
            self.log.info("menulist horizontal contains {}".format(str(self.menu_list())))
            self.nav_to_menu_horizontal(section.upper())
            self.select_item()

    def goto_section_strip(self, path):
        section = path
        self.log.info("Navigating to stripitem: {}".format(section))
        limit = 0
        self.screen.refresh()
        while not self.is_in_strip(section):
            self.log.info("In While Loop")
            self.log.info(limit)
            if limit > 5:
                break
            for i in range(3):
                self.screen.base.press_right(time=300)
            self.screen.refresh()
            limit = limit + 1
        self.log.info(section)
        self.log.info("is in strip. selecting strip")
        self.select_strip(section, True)

    def is_biaxial_screen(self):
        return self.is_strip_list() and self.is_menu_list()

    def is_gallery_screen(self):
        return self.screen_view() == self.vod_labels.LBL_GALLERY_SCREEN_VIEW_MODE

    def navigate_to_entryPoint_v2(self, entry_point, *args):
        """
        The method is for navigation by biaxial screen. It will navigate by vertical menu, then by horizontal strip
        according to entry_point path. Also any additional matching will be used (*args) for each step
        number of steps is equal to length of entry_point
        Args:
            entry_point: str, path to destination point separated by '/'. Must contain 1-3 elements
            *args: str, any additional matchers (mixid, parentmixid, etc)

        Returns:
            None
        """
        entry_point_path = self.create_path_from_entryPoint(entry_point)
        entry_point_path = entry_point_path[1:]  # remove first element as in not useful
        markers = list(args)
        # extend markers with entry_point path to match by imagename and text. First element will be used for vertical
        # navigation accross menu and all other for navigation by strip and gallery
        strict_markers = entry_point_path[1:]  # entry pint must uses strict matching ref: CA-3245
        markers_re = self.convert_markers_list_to_regex(markers, strict=strict_markers)
        self.log.step("EP: Navigating to VOD entrypoint: '{}'".format(markers))
        # first step - go to vertical menu item according to entry_point_path (all elements will be used for matching)
        self.navigate_by_vod_menus(self.convert_markers_list_to_regex([], strict=entry_point_path[0:1]), max_scrolls=5)
        # if path contains more than 2 elements, will select subfolders in strip
        for step, folder in enumerate(entry_point_path[1:]):
            # second step - select horizontal item in stip
            # (for matching will bve used entry_point_path + all additional markers)
            self.log.step("EP: Selecting VOD folder: '{}'. Step#{}".format(folder, step))
            if self.is_strip_list():
                # for navigation by a strip in biaxial screen (step2)
                self.navigate_by_strip(markers_re, matcher_type="re", max_scrolls=40)
            elif self.is_menu_list():
                # for cases when we got into gallery screen (EP path length 3 or more)
                self.navigate_by_vod_menus(markers_re, max_scrolls=15)
            else:
                raise LookupError("Current screen doesn't contain not strip nor menu."
                                  " DUMP: {}".format(self.screen.screen_dump))
            self.select_item()

    def convert_markers_list_to_regex(self, markers, **kwargs):
        """
        Method to convert list of string to RegEx: '(.*marker1.*)|(.*marker2.*)|(.*markerN.*) '
        Args:
            markers: list, tuple, of markers to convert to a formatted str for Re
            strict: list, tuple, of marker which should be compared strict eg == with ignorecase

        Returns:
            str
        """
        filtred_markers = []
        total_re_list = []
        for marker in markers:
            if not marker or not isinstance(marker, str):
                self.log.warning("Only strings can be used for markers. Current {}:{}".format(type(marker), marker))
            elif marker in str(filtred_markers):
                self.log.warning(f"Marker: '{marker}', overlapping with some of exisiting: '{filtred_markers}'")
            else:
                filtred_markers.append(r'(.*{}.*)'.format(re.escape(marker)))
        if filtred_markers:
            total_re_list.append("|".join(filtred_markers))
        elif kwargs.get("strict"):
            pass
        else:
            raise ValueError("Didn't get any supported markers: '{}'".format(markers))
        strict_markers = kwargs.get("strict")
        if strict_markers:
            total_re_list.append("|".join([f"({re.escape(strict_marker)}$)" for strict_marker in strict_markers]))
        total_re = "(?i){}".format("|".join(total_re_list))  # add ignore case
        return total_re

    def select_vod_v2(self, *args):
        """
        TODO: one of the select_vod_v2() or select_vod() mast be removed. Current under stabilization
        Method to navigate and select VOD according to markers. will be navigated by RegEx of markers.
        Unlimited number of markers can be used. But be careful is resources consuming operation.
        Args:
            *args: all markers for path matching (strings)

        Returns:
            None
        """
        self.log.step("SelectVOD: Going to navigate and select VOD: '{}'".format(args))
        # get all available markers for matching and adapt to RegEx
        regex_for_target = self.convert_markers_list_to_regex(args)
        max_navigation_nesting = 5
        self.screen.refresh()
        for step in range(max_navigation_nesting):
            if "actions" in self.view_mode():
                # actions screen is a destination point!
                self.log.info("SelectVOD: destination is reached: '{}'".format(self.screen_title()))
                if self.view_mode() == self.vod_labels.LBL_ACTIONS_SCREEN:
                    if not self.is_in_menu(self.vod_labels.LBL_WATCH_NOW):
                        raise AssertionError(f"{self.vod_labels.LBL_WATCH_NOW} menu option is not available")
                break
            if self.is_biaxial_screen():
                self.log.debug("SelectVOD: navigation by biaxial screen")
                self.navigate_by_strip(regex_for_target, matcher_type="ignore_case_re", max_scrolls=40)
            else:
                self.log.info("SelectVOD: navigation by gallery screen")
                self.navigate_by_vod_menus(regex_for_target)
            self.log.info("SelectVOD: selecting focused item")
            self.press_ok()  # to avoid double dumping
            self.screen.refresh()
        else:
            raise LookupError("MAX VOD depth is achieved: '{}'".format(max_navigation_nesting))

    def select_vod(self, *args):
        # stub
        # TODO: must be removed after testing
        self.select_vod_v2(*args)

    def navigate_to_entryPoint(self, tester, entry_point, mixID, parentMixId=None):
        # stub for testing
        # TODO: must be removed after testing
        self.navigate_to_entryPoint_v2(entry_point, mixID, parentMixId)

    def navigate_by_vod_menus(self, target, max_scrolls=10):
        """
        The method navigates by Biaxial ang gallery screen
        method to navigate by VOD menus (assets and folders). If there is no visible target then screen will be scrolled
        a few times (max_scrolls)
        Args:
            target: str, marker according to which menu's item will be selected
            max_scrolls: int, max scrooll count

        Returns:
            None
        """
        self.log.info("Selecting '{}' in VOD menu".format(target))
        all_shown_items_ids = set()
        all_shown_items = []
        # workaround to be able navigate across vertical menu and matrix menu
        if self.is_biaxial_screen():
            axis = "Y"
        elif self.is_gallery_screen():
            axis = "X"
        else:
            axis = "X"
            self.log.warning("The method navigates only by VOD biaxial screen od gallery. All other not stable."
                             " Current screen {}".format(self.screen_view()))
        # main logic
        for curr_scroll in range(max_scrolls):
            menu = self.get_menu_item_array()
            menu_ids = [menu_item['id'] for menu_item in menu]
            if self.is_item_in_obj_array(menu, target, matcher_type="re"):
                self.log.info("Target item is found:'{}'".format(target))
                self.navigate_by_menu_XY(target, axis, matcher_type="re")
                self.screen.get_json()
                break
            elif not all_shown_items_ids.issuperset(menu_ids):  # check not started again
                self.log.info("Scroll to the next VOD menu page")
                all_shown_items_ids.update(menu_ids)
                all_shown_items.extend(menu)
                self.navigate_by_XY(len(menu), axis)
                self.screen.get_json()
            else:
                obj_repr = [item.get("text") or item.get("imagename") for item in all_shown_items]
                raise LookupError("Current screen doesn't contain expression: '{}'. "
                                  "But all shown: '{}'. Scrolls: '{}'".format(target, obj_repr, curr_scroll))
        # get focused element for finish verification
        current = self.get_focused_item(self.get_menu_item_array())
        self.log.info("Focused menu item after navigation: '{}'".format(current))
        if not self.is_item_matched(current, target, matcher_type="re"):
            raise LookupError("After navigation focused item doesnt correspond to target."
                              "target: '{}', but focused '{}'".format(target, current))

    def select_first_item_from_strip(self):
        self.screen.refresh()
        self.screen.base.press_enter()

    def select_watch_now(self, tester, retries: int = 3):
        """
        Select watch now in menuitem

        Args:
            tester:
            retries: tries to get the menu item if the UI is not updated immediately.
        """
        for retry in range(retries):
            try:
                self.screen.refresh()
                focused_menu_item = self.menu_focus()
                if focused_menu_item == "Watch Now":
                    self.log.info("Clicking {}".format(focused_menu_item))
                    self.screen.base.press_enter()
                    resumescreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESUME_OVERLAY)
                    if resumescreen is True:
                        self.screen.base.press_enter(time=2000)
                        time.sleep(5)
                    resolutionscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
                    if resolutionscreen is True:
                        self.select_menu_by_substring(tester.vod_labels.LBL_FREE)
                        time.sleep(5)
                    else:
                        self.log.info("Overlay not displayed. Asset should already be playing.")
                else:
                    self.log.info("Watch Now not found")
                break
            except Exception as e:
                if retry + 1 == retries:
                    raise e
                self.log.error(f"{e}\n Going to retry after 3 seconds...")
                self.pause(3)
                continue

    def verify_resume_overlay_is_displayed(self):
        self.log.info("Checking resume overlay is displayed or not..")
        self.wait_for_screen_ready(self.vod_labels.LBL_RESUME_OVERLAY, timeout=10000)
        self.screen.refresh()
        dump = self.screen.get_screen_dump_item()
        if dump.get('overlayTitleText') == self.vod_labels.LBL_RESUME_PLAYING:
            self.screen.base.press_enter()
            time.sleep(5)
            self.screen.refresh()
        else:
            self.log.info("Resume overlay is not displayed..")

    def select_start_over_or_resume(self, option):
        self.screen.refresh()
        screen = self.screen.screen_dump['xml']
        actionscreen = "actions.ActionsScreenView"
        seriesscreen = "actions.series.SeriesScreenView"
        if "viewMode" in screen.keys() and screen['viewMode'] == actionscreen or screen['viewMode'] == seriesscreen:
            menu = self.menu_list()
            if option in menu:
                self.select_watch_now_overlay_option(option)
        self.verify_resume_overlay_is_displayed()

    def set_closed_captioning_on(self, option):
        self.log.step(f"Set {option}")
        if Settings.is_unmanaged():
            self.screen.base.press_down()
        else:
            self.screen.base.press_info()
        self.screen.refresh()
        if not self.is_strip_focus():
            self.log.info("Focus is not on strip. Pressing UP")
            self.screen.base.press_up()
        stripList = self.strip_list()
        if "Turn Closed Captions OFF" in stripList:
            self.log.info("Closed Captions were already ON")
        else:
            loop_attempts = 0
            while option not in stripList:
                self.screen.base.press_right()
                self.screen.refresh()
                loop_attempts += 1
                if loop_attempts > 10:
                    break
            self.select_strip(option)
            self.screen.base.press_info()
        self.screen.refresh()

    def select_watch_now_overlay_option(self, option):
        self.screen.refresh()
        if not self.is_menu_focus():
            loop_attempts = 0
            while not self.is_menu_focus():
                self.screen.base.press_up()
                self.screen.refresh()
                loop_attempts += 1
                if loop_attempts > 10:
                    break
        self.select_menu(option)

    def play_rented_content(self, tester, result, platform, purchaseon):
        self.log.step("Starting playback of rented content")
        if self.screen.get_screen_dump_item('viewMode') == tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            self.log.info("In series screen")
            try:
                self.log.info("Trying to select using subtitle")
                subtitle = result['offer'].subtitle
                self.select_menu_by_substring(subtitle)
            except Exception:
                self.log.info("No subtitle available for the content")
                self.select_item()
            time.sleep(5)
        else:
            self.log.info("Selecting Watch Now from programscreen")
            self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
            self.screen.refresh()
            time.sleep(5)

        resolutionscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
        if resolutionscreen:
            self.log.info("HD/SD selector overlay displayed")
            rent = tester.vod_labels.LBL_TVOD_RENT
            if platform.lower() in PlatformList.UNMANAGED_STREAMERS_LIST:
                self.matchandselect(self, tester.vod_labels.LBL_TVOD_NOT_RENTABLE)
                tester.vod_assertions.validate_not_rentableoverlay(tester)
                return
            else:
                self.matchandselect(self, rent)
            self.screen.refresh()
            time.sleep(5)

        rent_not_allowed = self.wait_for_screen_ready(tester.vod_labels.LBL_VOD_ERROR_OVERLAY)
        if rent_not_allowed and platform.lower() in PlatformList.UNMANAGED_STREAMERS_LIST:
            self.log.info("Unmanaged device. verifying Rentals not allowed overlay is displayed or not")
            tester.vod_assertions.validate_not_rentableoverlay(tester)
            return

        self.wait_for_screen_ready(tester.vod_labels.LBL_ENTER_PIN_OVERLAY)
        if purchaseon == "on":
            if self.is_overlay_shown():
                self.log.info("Enter pin overlay displayed")
                tester.menu_page.enter_default_parental_control_password(tester)
                self.wait_for_screen_ready(tester.vod_labels.LBL_ENTER_PIN_OVERLAY)
            if self.is_overlay_shown():
                self.log.info("Enter pin overlay displayed again")
                tester.menu_page.enter_default_parental_control_password(tester)
        self.verify_resume_overlay_is_displayed()

    def play_rented_available_content(self, tester, result):
        self.screen.refresh()
        if self.screen.get_screen_dump_item('viewMode') == tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            try:
                subtitle = result['offer'].subtitle
                self.select_menu_by_substring(subtitle)
            except Exception as e:
                self.log.info("No subtitle available for the content, error is:{}".format(e))
                self.select_item()
            time.sleep(5)
        else:
            self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
        self.screen.refresh()
        time.sleep(5)
        vodplayback = self.wait_for_screen_ready(tester.vod_labels.LBL_VOD_PLAYBACK)
        if vodplayback:
            self.log.info("Vod content started to playback")
            return
        resolutionscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
        if resolutionscreen:
            available = tester.vod_labels.LBL_TVOD_AVAILABLE
            self.matchandselect(self, available)
            time.sleep(5)
        resumescreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESUME_OVERLAY)
        if resumescreen:
            self.screen.base.press_down()
            self.screen.base.press_enter(time=2000)
            time.sleep(5)
        else:
            self.log.info("overlay not displayed. Asset should already be playing")

    def play_confirmrented_content(self, tester, results, confirm=True):
        self.log.step("Starting playback for Rented TVOD asset")
        self.screen.get_json()
        if self.screen.get_screen_dump_item('viewMode') == tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            subtitle = results['offer'].subtitle
            self.log.info("In Series Screen, selecting {}".format(subtitle))
            self.select_menu_by_substring(subtitle)
            time.sleep(5)
        else:
            self.log.info("In program screen, selecting Watch Now")
            self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
            self.screen.refresh()
            time.sleep(5)
        resolutionscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
        self.screen.get_json()
        time.sleep(5)
        if resolutionscreen is True:
            self.log.info("HD/SD resolution selector overlay displayed")
            rent = tester.vod_labels.LBL_TVOD_RENT
            self.matchandselect(self, rent)
            self.screen.refresh()
            time.sleep(5)
        confirmrentalscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_CONFIRM_RENTAL_OVERLAY)
        if confirmrentalscreen is True:
            self.log.info("Confirm Rental overlay displayed")
            self.screen.base.press_up()
            time.sleep(5)
            self.screen.screen_dump['xml']
            self.select_menu_by_substring(tester.vod_labels.LBL_CONFIRM_RENTAL_TVOD, confirm=confirm)
            if confirm:
                self.screen.refresh()
                time.sleep(5)
        self.verify_resume_overlay_is_displayed()

    def play_confirmrented_content_with_enter_pin(self, tester):
        self.screen.refresh()
        self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
        self.screen.refresh()
        time.sleep(5)

        resolutionscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
        if resolutionscreen is True:
            rent = tester.vod_labels.LBL_TVOD_RENT
            self.matchandselect(self, rent)
            self.screen.refresh()
            time.sleep(5)
        self.wait_for_screen_ready(tester.vod_labels.LBL_ENTER_PIN_OVERLAY)
        self.screen.refresh()
        tester.vod_assertions.verify_pin_overlay()
        self.enter_pin_in_overlay(tester)
        self.screen.refresh()
        time.sleep(5)
        confirmrentalscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_CONFIRM_RENTAL_OVERLAY)
        if confirmrentalscreen is True:
            self.screen.base.press_up()
            time.sleep(5)
            # screen = self.screen.screen_dump['xml'] comenting line as it is never used
            self.select_menu_by_substring(tester.vod_labels.LBL_CONFIRM_RENTAL_TVOD)
            self.screen.refresh()
            time.sleep(5)

    def play_asset_from_watch_now_strip_any_vod_status(self, tester, availability_type="tvod", is_rent_over_available=False,
                                                       is_pc_pin=False, is_purchase_pin=False, is_start_resume=False,
                                                       is_resume=False, is_res_selector=False):
        """
        Program Screen with Watch Now option should be displayed before calling this method
        TVOD can be played as rented as non-rented, also ZVOD/FVOD and SVOD can be processed

        Note:
            Use availability_type = "svod" for SOCU

        Args:
            tester (TestClassInstance): a class a test method is called from
            availability_type (str): VOD entitlemnet (package type), can be tvod, svod, zvod, fvod, etc.
            is_rent_over_available (bool): True - select not yet rented offer,
                                           False - selects already rented offer,
                                           param applicable only for tvod offers
            is_pc_pin (bool): if Parental Controls PIN check is required
            is_purchase_pin (bool): if Purchase Controls PIN check is required
            is_start_resume (bool): True = selects resume playing in the Resume Playing overlay;
                                    False = selects start from beginning
            is_resume (bool): True = test will fail if VODResumeStartOverOverlay wasn't found;
                              False = test will just handle VODResumeStartOverOverlay
                              if it was found and go further if it wasn't found
            is_res_selector (bool): True = test will fail if ResolutionSelectorOverlay wasn't found;
                                    False = test will just handle ResolutionSelectorOverlay
                                    if it was found and go further if it wasn't found
        """
        self.log.step("Selecting the Watch Now option in the Program Screen to start VOD playback")
        self.screen.refresh()
        if availability_type == VodPackageType.TVOD:
            self.log.step("Handling a TVOD asset")
            is_tvod_rented_preview_pane = tester.vod_labels.LBL_TVOD_RENTED_PREVIEW_PANE in \
                self.get_preview_panel()["entitlementStatus"]
            self.log.error("manage_launched_playback: is_rent_over_available = {}".format(is_rent_over_available))
            if not is_rent_over_available and is_tvod_rented_preview_pane:
                self.log.info("TVOD is rented and has not expired")
                self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
                self.manage_launched_playback(tester=tester, availability_type=availability_type,
                                              is_rented=True, is_pc_pin=is_pc_pin, is_purchase_pin=is_purchase_pin)
            else:
                self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
                self.manage_launched_playback(tester=tester, availability_type=availability_type,
                                              is_rented=False, is_pc_pin=is_pc_pin, is_purchase_pin=is_purchase_pin)
        else:
            self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
            self.manage_launched_playback(tester=tester, availability_type=availability_type,
                                          is_rented=False, is_pc_pin=is_pc_pin, is_purchase_pin=is_purchase_pin)
        self.verify_resume_overlay_is_displayed()

    def manage_launched_playback(self, tester, availability_type="tvod", is_rented=False,
                                 is_pc_pin=False, is_purchase_pin=False, is_start_resume=False,
                                 is_resume=False, is_res_selector=False):
        """
        This method can be used right after starting the VOD playback to handle futher steps.
        The method makes next checks (some of them may be omitted):
            - Resolution Selector overlay (is_res_selector param);
            - Parental Controls PIN (only if is_pc_pin == True);
            - Resume playing/Start over from beginning overlay (is_resume param);
            - Confirm Rental overlay (only if availability_type = "tvod");
            - Purchase PIN (only if is_purchase_pin == True).
        Playback should be started before calling this method

        Note:
            Use availability_type = "svod" for SOCU

        Args:
            tester (TestClassInstance): a class a test method is called from
            availability_type (str): VOD entitlemnet (package type), can be tvod, svod, zvod, fvod, etc.;
                                     value is needed for ResolutionSelectorOverlay
            is_rented (bool): if selecting a rented VOD asset
            is_pc_pin (bool): if Parental Controls PIN check is required
            is_purchase_pin (bool): if Purchase Controls PIN check is required
            is_start_resume (bool): True = selects resume playing in the Resume Playing overlay;
                                    False = selects start from beginning
            is_resume (bool): True = test will fail if VODResumeStartOverOverlay wasn't found;
                              False = test will just handle VODResumeStartOverOverlay
                              if it was found and go further if it wasn't found
            is_res_selector (bool): True = test will fail if ResolutionSelectorOverlay wasn't found;
                                    False = test will just handle ResolutionSelectorOverlay
                                    if it was found and go further if it wasn't found
        """
        self.log.step("Handling just launched playback")
        is_tvod = availability_type.lower() == VodPackageType.TVOD
        is_svod = availability_type.lower() == VodPackageType.SVOD
        is_free_vod = availability_type.lower() in VodPackageType.FREE_VOD_LIST
        if not is_tvod and not is_svod and not is_free_vod:
            self.log.error("Not yet supported entitlement - {}".format(availability_type))
        else:
            self.log.debug("availability_type = {}, is_rented = {}, is_pc_pin = {}, is_purchase_pin = {}"
                           .format(availability_type, is_rented, is_pc_pin, is_purchase_pin))
        resolution_screen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY, timeout=50000)
        self.log.info("Resolution screen is : {}".format(resolution_screen))
        self.screen.refresh()
        if is_res_selector and not resolution_screen:
            raise AssertionError("ResolutionSelectorOverlay did not appear")
        elif is_res_selector or resolution_screen:
            tester.vod_assertions.verify_overlay_shown()
        # Managing the Resolution Selection overlay for TVOD
        if is_tvod and is_rented and resolution_screen:
            self.log.info("Resolution Selector overlay for TVOD Available (asset was rented)")
            self.matchandselect(self, tester.vod_labels.LBL_TVOD_AVAILABLE)
        elif is_tvod and not is_rented and resolution_screen:
            self.log.info("Resolution Selector overlay for TVOD to Rent (asset was NOT rented)")
            self.matchandselect(self, tester.vod_labels.LBL_TVOD_RENT)
        # Managing the Resolution Selection overlay for SVOD
        if is_svod and resolution_screen:
            self.log.info("Resolution Screen for SVOD asset (Included with your subscription)")
            self.matchandselect(self, tester.vod_labels.LBL_SVOD_ASSET)
        # Managing the Resolution Selection overlay for ZVOD
        if is_free_vod and resolution_screen:
            self.log.info("Resolution Selector overlay for ZVOD asset (Free)")
            self.matchandselect(self, tester.vod_labels.LBL_ZVOD_ASSET)
        # Managing the Parental Controls PIN overlay
        if is_pc_pin:
            self.log.info("Managing the Parental Controls PIN overlay")
            self.wait_for_screen_ready(tester.vod_labels.LBL_ENTER_PIN_OVERLAY)
            tester.vod_assertions.verify_pin_overlay()
            self.enter_pin_in_overlay(tester)
        # Managing the Resume playing/Start over from beginning overlay
        self.log.info("Managing the Resume overlay")
        resume_overlay = self.wait_for_screen_ready(tester.vod_labels.LBL_RESUME_OVERLAY)
        if is_resume and not resume_overlay:
            raise AssertionError("VODResumeStartOverOverlay did not appear")
        elif is_resume or resume_overlay:
            tester.vod_assertions.verify_overlay_shown()
            if is_start_resume:
                self.matchandselect(self, tester.vod_labels.LBL_RESUME_PLAYING)
            else:
                self.matchandselect(self, tester.vod_labels.LBL_START_OVER_FROM_BEGINNING)
        # Managing the Confirm Rental overlay
        if is_tvod and not is_purchase_pin and not is_rented:
            self.log.info("Managing the Confirm Rental overlay")
            self.wait_for_screen_ready(tester.vod_labels.LBL_CONFIRM_RENTAL_OVERLAY)
            tester.vod_assertions.verify_overlay_shown()
            self.matchandselect(self, tester.vod_labels.LBL_CONFIRM_RENTAL_TVOD)
        # Managing the Purchase PIN overlay
        if is_tvod and is_purchase_pin and not is_rented:
            self.log.info("Managing the Purchase PIN overlay")
            self.wait_for_screen_ready(tester.vod_labels.LBL_ENTER_PIN_OVERLAY)
            tester.vod_assertions.verify_pin_overlay()
            self.enter_pin_in_overlay(tester)

    def matchandselect(self, tester, substring_text):
        self.log.info(f"Matching {substring_text} and selecting it")
        self.screen.refresh()
        self.select_menu_by_substring(substring_text)

    def screen_view(self):
        self.screen.refresh()
        screen_type = self.screen.screen_dump['xml']
        return screen_type.get("viewMode")

    def play_svod_content(self, tester, results):
        self.log.step("Starting playback of SVOD content")
        # screen_dump = self.screen.get_json() -->commenting as this is nowhere used in the function
        if self.screen.get_screen_dump_item('viewMode') == tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            try:
                subtitle = results['offer'].subtitle
                self.select_menu_by_substring(subtitle)
            except Exception as e:
                self.log.info("No subtitle available for the content with error:{}".format(e))
                self.select_item()
            time.sleep(5)
        else:
            self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
        self.screen.refresh()
        time.sleep(5)
        vodplayback = self.wait_for_screen_ready(tester.vod_labels.LBL_VOD_PLAYBACK)
        if vodplayback:
            self.log.info("Vod content started to playback")
            return
        resolutionscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
        if resolutionscreen:
            self.log.info("HD/SD selector overlay displayed")
            svod = tester.vod_labels.LBL_SVOD_ASSET
            tester.vod_page.matchandselect(self, svod)
            self.screen.refresh()
            time.sleep(5)
        resumescreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESUME_OVERLAY)
        if resumescreen:
            self.log.info("Resume playing overlay displayed")
            self.screen.base.press_down()
            self.screen.base.press_enter(time=1000)
            time.sleep(5)
        else:
            self.log.info("overlay not displayed. Asset should already be playing")
        self.log.info("Playback successful")

    def play_free_svod_content(self, tester):
        self.screen.refresh()
        if self.screen.get_screen_dump_item('viewMode') == tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            self.select_item()
        else:
            self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
        time.sleep(4)
        self.screen.refresh()
        if self.screen.get_screen_dump_item('viewMode') != tester.vod_labels.LBL_WATCHVOD:
            menuitem = self.screen.get_screen_dump_item('menuitem')
            if self.screen.get_screen_dump_item('overlayMode') and menuitem != tester.vod_labels.LBL_STARTOVER_OVERLAY:
                self.select_menu_by_substring(tester.vod_labels.LBL_FREE)
                time.sleep(4)
                self.screen.refresh()
            else:
                if self.screen.get_screen_dump_item('overlayMode') and menuitem != tester.vod_labels.LBL_STARTOVER_OVERLAY:
                    self.select_watch_now_overlay_option(tester.vod_labels.LBL_START_OVER_FROM_BEGINNING)
                else:
                    pass
                self.select_watch_now_overlay_option(tester.vod_labels.LBL_START_OVER_FROM_BEGINNING)
        else:
            self.log.info("overlay not displayed. Asset should already be playing")

    def select_menu_by_substring_for_OnePass(self, menu_item_substring):
        """
        Function to select the OnePass option for uni episode contents
        :param menu_item_substring:
        :return:
        """
        menu = self.menu_list()
        current_focus_index = menu.index(self.menu_focus())
        menu_item_index = self.substring_index(menu, menu_item_substring)
        index_diff = current_focus_index - menu_item_index
        if (index_diff > 0):
            for i in range(index_diff):
                self.screen.base.press_up()
        else:
            index_diff = index_diff * -1
            for i in range(index_diff):
                self.screen.base.press_down()

        self.screen.refresh()

    def create_onepass_SVOD(self, tester):
        """
        Function to create the OnePass for the selected show
        :return:
        """
        if self.is_in_menu(tester.vod_labels.LBL_CREATE_ONEPASS):
            self.select_menu_by_substring(tester.vod_labels.LBL_CREATE_ONEPASS)
            self.screen.refresh()

    def modify_onepass_SVOD(self, tester, record):
        self.log.info("Modifying onepass and recording options: ")
        if record:
            self.nav_to_menu(tester.guide_labels.LBL_RECORD_MENU)
            tester.menu_page.nav_to_item_option(record)

    def check_onepass_SVOD(self, tester, menu_item_tocheck="Get This Show", record=None):
        """
        The function checks and creates OnePass for SVOD shows.
            - Handles cases for both single episode shows as well as multi episode shows
        :param tester:
        :param menu_item_tocheck:
        :param record:
        :return:
        """
        self.log.step("Creating One pass and verifying creation")
        self.wait_for_screen_ready()
        self.screen.refresh()
        if self.screen.get_screen_dump_item('viewMode') == tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            self.log.step("Creating one pass in Series screen")
            tester.vod_assertions.validate_series_screen_view(tester)
            self.menu_navigate_left_right(1, 0)
            self.wait_for_screen_ready()
            self.screen.refresh()
            if self.is_in_menu(menu_item_tocheck):
                tester.guide_assertions.verify_menu_has_option(menu_item_tocheck)
                self.select_menu_by_substring(menu_item_tocheck)
                self.wait_for_screen_ready()
                self.screen.base.press_enter(time=2000)
                self.screen.refresh()
                tester.guide_assertions.verify_menu_has_option(tester.vod_labels.LBL_CREATE)
                if record:
                    self.modify_onepass_SVOD(tester, record=record)
                self.create_onepass_SVOD(tester)
            elif self.is_in_menu(tester.vod_labels.LBL_ONEPASS_OPTIONS):
                tester.guide_assertions.verify_menu_has_option(tester.vod_labels.LBL_ONEPASS_OPTIONS)
                self.select_menu_by_substring_for_OnePass(tester.vod_labels.LBL_ONEPASS_OPTIONS)
                tester.guide_assertions.verify_menu_has_option(tester.vod_labels.LBL_CREATE)
                if self.is_strip_list():
                    self.select_strip(tester.vod_labels.LBL_CREATE_ONEPASS_ONLY)
                    self.screen.refresh()
                    tester.guide_assertions.verify_menu_has_option(tester.vod_labels.LBL_CREATE)
                    if record:
                        self.modify_onepass_SVOD(tester, record=record)
                    self.create_onepass_SVOD(tester)
        else:
            self.log.step("Creating one pass in Action screen")
            self.screen.refresh()
            self.select_menu_by_substring_for_OnePass(tester.vod_labels.LBL_ONEPASS_OPTIONS)
            if self.is_strip_list():
                self.select_strip(tester.vod_labels.LBL_CREATE_ONEPASS_ONLY)
                self.screen.refresh()
                tester.guide_assertions.verify_menu_has_option(tester.vod_labels.LBL_CREATE)
                if record:
                    self.modify_onepass_SVOD(tester, record=record)
                self.create_onepass_SVOD(tester)
        tester.guide_assertions.verify_whisper_shown(tester.guide_labels.LBL_ONEPASS_WHISPER_TEXT)

    def get_vod_press(self):
        """
        The function is used to trigger a VOD shell request
        :return:
        """
        self.log.step("Pressing VOD button to launch VOD screen")
        self.screen.base.launch_vod()
        self.screen.refresh()

    def enter_pin_in_overlay(self, tester):
        """
        Default Pin is 9999
        :return:
        """
        pin = tester.menu_page.get_default_pin(tester)
        screen = self.screen.screen_dump['xml']
        if "overlayMode" in screen.keys():
            mode = screen['overlayMode']
            if mode == "pinchallenge.PinEntryOverlayView":
                self.screen.base.typeTextByKey(pin)
                time.sleep(2)
            elif mode == "pinchallenge.SpinnerPinEntryOverlayView":
                for i in range(4):
                    if pin[i] == 0:
                        self.screen.base.press_enter()
                        self.pause(1)
                    else:
                        for j in range(int(pin[i])):
                            self.screen.base.press_up()
                            self.pause(1)
                        self.screen.base.press_enter()
                        self.pause(1)

    def press_forward(self):
        self.log.info("Pressing Forward")
        self.screen.base.press_right()  # Bringing up trickplay

    def press_reverse(self):
        self.log.info("Pressing Rewind")
        self.screen.base.press_left()  # reversing the playback

    def press_play(self):
        self.log.info("Playing ")
        self.screen.base.press_enter()  # Playing the playback

    def press_ok(self):
        self.log.info("Pressing enter")
        self.screen.base.press_enter()  # pausing the playback

    def select_view_all(self):
        self.log.info("Selecting View all option")
        self.pause(4)
        self.press_reverse()
        self.press_ok()

    def select_menu_item(self, menu):
        self.screen.refresh()
        self.select_menu(menu)
        self.screen.refresh()

    def play_tvod_preview_content(self, tester):
        self.log.step("Starting Preview playback")
        self.screen.refresh()
        self.select_menu(tester.vod_labels.LBL_WATCH_PREVIEW)
        self.screen.refresh()
        xml = self.screen.screen_dump['xml']
        if 'overlayMode' in xml:
            self.screen.base.press_enter(time=2000)
            self.screen.refresh()
        else:
            self.log.info("overlay not displayed. Asset should already be playing")

    def navigate_to_vod_show(self, tester, vod_offer):
        """
        :description:
            The function goes to on demand screen and selects desired offer
        :params:
            tester         - a class a test method is called from
            vod_offer      - vod offer to be selected
        """
        self.log.info("Extracting paths and navigating to program screen")
        ep = self.convert_special_chars(self.extract_entryPoint(vod_offer))
        mix_id = self.convert_special_chars(self.extract_mixID(vod_offer))
        content_id = self.convert_special_chars(self.extract_contentId(vod_offer))
        collection_id = self.convert_special_chars(self.extract_collectionId(vod_offer))
        title = self.convert_special_chars(self.extract_title(vod_offer))
        self.log.step("Navigate to VOD show using GUI."
                      " IDs: EP={}, mixID={}, contentID={}, collectionID={}, title={}".format(ep,
                                                                                              mix_id,
                                                                                              content_id,
                                                                                              collection_id,
                                                                                              title))
        tester.home_page.back_to_home_short()
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_ONDEMAND_SHORTCUT)
        self.navigate_to_entryPoint(tester, ep, mix_id)
        self.select_vod(tester, collection_id, content_id, title)
        self.wait_for_screen_ready()

    def wait(self, time):
        self.pause(time)

    def get_entitlement_status(self):
        try:
            return self.get_preview_panel()['entitlementStatus']
        except Exception as e:
            self.log.info("No pane or entitlement status on dump, error is {}".format(e))

    def extract_movie_year(self, result):
        movieYear = None
        self.log.step("Extracting Movie Year")
        try:
            movieYear = result['offer'].movie_year
        except Exception:
            self.log.info("Movie Year is not available for the offer")
            movieYear = None
        self.log.info("Movie Year:{}".format(movieYear))
        return movieYear

    def verify_vod_movie_screen(self, tester, title, movieyear):
        self.log.step("Verifying VOD movie screen")
        self.screen.refresh()
        if self.is_biaxial_screen():
            movie = f"{title} ({movieyear})"
            self.verify_primary_branding_icon()
            self.verify_screen_title(movie.upper())
            menu = self.menu_list()
            more_info = tester.menu_page.get_more_info_name(tester, vod_labels=True)
            expected_strip_order = tester.vod_labels.LBL_MOVIE_SCREEN_VOD_STRIPS_ORDER
            expected_strip_order[-1] = more_info
            strip_order = tester.guide_page.check_menu_availability(menu, expected_strip_order)
            tester.guide_assertions.verify_strip_order(strip_order, menu)
            tester.vod_assertions.verify_preview_pane_entitlement_and_description()
        else:
            self.log.info("Not in biaxial screen")
            raise AssertionError

    def validate_resume_playing(self, tester, results):
        entitlement = self.extract_entitlement(results)
        self.screen.refresh()
        time.sleep(3)
        menu = self.menu_focus()
        if menu == self.vod_labels.LBL_WATCH_NOW:
            self.select_menu(self.vod_labels.LBL_WATCH_NOW)
        if self.screen.get_screen_dump_item('viewMode') == tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            self.select_item()
        resolutionscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
        if resolutionscreen is True:
            self.screen.refresh()
            if entitlement in tester.vod_labels.LBL_FREE_ENTITLEMENT:
                self.select_menu_by_substring(tester.vod_labels.LBL_FREE)
            elif entitlement in tester.vod_labels.LBL_ENTITLEDSUBSCRIBED_ENTITLEMENT:
                svod = tester.vod_labels.LBL_SVOD_ASSET
                tester.vod_page.matchandselect(self, svod)
            elif entitlement in tester.vod_labels.LBL_ENTITLEDRENTED_ENTITLEMENT:
                available = tester.vod_labels.LBL_TVOD_AVAILABLE
                self.matchandselect(self, available)
            elif entitlement in tester.vod_labels.LBL_NOTRENTED_ENTITLEMENT:
                available = tester.vod_labels.LBL_TVOD_AVAILABLE
                self.matchandselect(self, available)
            else:
                self.log.info("The entitlement returned is not an playable content :{}".format(entitlement))
            time.sleep(5)
        resumescreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESUME_OVERLAY)
        if resumescreen is True:
            self.screen.base.press_enter(time=1000)
            time.sleep(5)
        else:
            self.log.info("overlay not displayed. Asset should already be playing")

    def validate_resume_overlay(self, tester):
        resumesscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESUME_OVERLAY)
        if resumesscreen:
            return True
        else:
            return False

    def validate_enterpin_overlay_streamvod(self, tester, results):
        self.log.step("Validate enter pin overlay")
        entitlement = self.extract_entitlement(results)
        time.sleep(3)
        resolutionscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
        if resolutionscreen is True:
            self.log.info("SD/HD selector overlay displayed")
            self.screen.refresh()
            if entitlement in tester.vod_labels.LBL_FREE_ENTITLEMENT:
                self.select_menu_by_substring(tester.vod_labels.LBL_FREE)
            elif entitlement in tester.vod_labels.LBL_ENTITLEDSUBSCRIBED_ENTITLEMENT:
                svod = tester.vod_labels.LBL_SVOD_ASSET
                tester.vod_page.matchandselect(self, svod)
            elif entitlement in tester.vod_labels.LBL_ENTITLEDRENTED_ENTITLEMENT:
                available = tester.vod_labels.LBL_TVOD_AVAILABLE
                self.matchandselect(self, available)
            else:
                self.log.info("The entitlement returned is not an playable content :{}".format(entitlement))
            time.sleep(5)
        self.screen.refresh()
        tester.menu_assertions.verify_enter_PIN_overlay()
        tester.menu_page.enter_default_parental_control_password(tester)
        time.sleep(3)
        self.log.info("To handle resume start over ovlerlay")
        if self.validate_resume_overlay(tester) is True:
            self.screen.base.press_enter(time=1000)
            time.sleep(5)
        else:
            time.sleep(5)
            self.log.info("overlay not displayed. Asset should already be playing")

    def validate_incorrectpin_overlay(self, tester, results):
        self.log.step("Validate incorrect pin overlay")
        entitlement = self.extract_entitlement(results)
        self.screen.base.press_enter(time=5000)
        resolutionscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
        if resolutionscreen is True:
            self.screen.refresh()
            if entitlement in tester.vod_labels.LBL_FREE_ENTITLEMENT:
                self.select_menu_by_substring(tester.vod_labels.LBL_FREE)
            elif entitlement in tester.vod_labels.LBL_ENTITLEDSUBSCRIBED_ENTITLEMENT:
                svod = tester.vod_labels.LBL_SVOD_ASSET
                tester.vod_page.matchandselect(self, svod)
            elif entitlement in tester.vod_labels.LBL_ENTITLEDRENTED_ENTITLEMENT:
                available = tester.vod_labels.LBL_TVOD_AVAILABLE
                self.matchandselect(self, available)
            else:
                self.log.info("The entitlement returned is not an playable content :{}".format(entitlement))
            time.sleep(5)
        self.screen.refresh()
        tester.menu_assertions.verify_enter_PIN_overlay()
        tester.menu_page.enter_wrong_pc_password(self)
        time.sleep(5)
        tester.menu_assertions.verify_wrong_PIN_overlay()

    def play_free_vod_content(self, result={}, resume=False, subtitle=''):
        """
        To play any free VOD asset with ability to resume or start from beginning
        'result' or 'subtitle argument should be used
        :param result:dict, result of vod_api search
        :param resume: bool
        :param subtitle: str
        :return:
        """
        if not subtitle:
            if self.episodic(result):
                subtitle = self.extract_season_episode(result)
            else:
                subtitle = self.extract_title(result)
        subtitle = self.convert_special_chars(subtitle)
        self.screen.refresh()
        if self.view_mode() == self.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            self.navigate_to_on_demand_episodes(select=True)
            self.select_menu_by_substring(subtitle)
            self.wait_for_screen_ready()
        elif self.view_mode() == self.vod_labels.LBL_ACTIONS_SCREEN and \
                self.is_in_menu(self.vod_labels.LBL_ON_DEMAND_EPISODES):
            self.navigate_to_on_demand_episodes(select=True)
            self.select_menu_by_substring(subtitle)
            self.select_menu(self.vod_labels.LBL_WATCH_NOW)
        else:
            self.select_menu(self.vod_labels.LBL_WATCH_NOW)
        self.screen.refresh()
        if self.is_resolution_overlay(self):
            self.log.info("Select VOD resolution")
            self.select_menu_by_substring(self.vod_labels.LBL_FREE)
            self.screen.refresh()
        if self.is_startover_overlay(self):
            if resume:
                self.select_watch_now_overlay_option(self.vod_labels.LBL_RESUME_PLAYING)
            else:
                self.select_watch_now_overlay_option(self.vod_labels.LBL_START_OVER_FROM_BEGINNING)
            self.screen.refresh()
        if self.is_overlay_shown():
            self.log.info(f"After selecting VOD: {self.get_overlay_title()} : {self.get_overlay_body()} was shown.")
            pytest.skip("Vod content not available {}".format(self.get_overlay_body()))

    def launch_episode_list_view(self, tester, stripname):
        self.log.step("Launching episode list view")
        self.screen.refresh()
        viewmode = self.view_mode()
        if viewmode == tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            self.log.info("In Series Screen")
            self.menu_navigate_left_right(1, 0)
            self.screen.refresh()
            if stripname not in self.menu_list():
                self.log.error(f"strip {stripname} not found in menulist")
                return True
            self.select_menu(stripname)
        else:
            self.log.info("In program screen")
            if viewmode == tester.vod_labels.LBL_ACTIONS_SCREEN:
                return True

    def validate_speed_fastforward_1(self, tester, results, refresh=True):
        self.log.step("Verifying FF1 for current asset playback")
        duration = self.extract_duration(results)
        self.screen.base.press_right()
        self.screen.base.press_enter()
        self.verify_trickplay_bar_shown()
        tester.vod_assertions.verify_press_forward_trick_play(tester.vod_labels.LBL_FWDX1)
        sleepduration = duration / 3 - 300
        if sleepduration > 0:
            self.log.info("Sleeping for duration:{}".format(sleepduration))
            time.sleep(sleepduration)
        if refresh:
            self.screen.refresh()
        view_mode = (self.screen.get_screen_dump_item('viewMode'))
        if view_mode == tester.vod_labels.LBL_WATCHVOD:
            if self.get_video_playback_mode() != tester.vod_labels.LBL_PLAY_NORMAL:
                tester.vod_assertions.verify_press_forward_trick_play(tester.vod_labels.LBL_FWDX1)

    def get_episode_list_from_screen(self):
        """
        To get list of ON DEMAND episodes from SERIES or EPISODE screen
        :return: list, [subtitle, season-episode]
        """
        self.log.info("Getting episode list.")
        menu = {}
        episode_list = []
        if self.screen.get_screen_dump_item('viewMode') == self.vod_labels.LBL_ACTIONS_SCREEN:
            self.navigate_to_on_demand_episodes(select=True)
            menu = self.screen.get_json()['xml']['menuitem']
        elif self.screen.get_screen_dump_item('viewMode') == self.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            self.navigate_to_on_demand_episodes()
            menu = self.screen.get_json()['xml']['unfocusedmenuitem']
        if not isinstance(menu, list):
            menu = [menu, ]
        for item in menu:
            episode_list.append(item.get('text'))
        if self.screen.get_screen_dump_item('viewMode') == self.vod_labels.LBL_EPISODE_SCREEN_VIEW_MODE:
            self.press_back_button()
            self.screen.refresh()
        return episode_list

    def navigate_to_on_demand_episodes(self, select=False):
        """
        Navigates 'On Demand Episodes' menu at SERIES or EPISODES screen
        :param select: bool, if True - selects menu
        """
        if self.screen.get_json()['xml']['viewMode'] == self.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            while self.vod_labels.LBL_ON_DEMAND_EPISODES not in str(self.screen.get_json()['xml']['menuitem']):
                self.press_left_button()
                continue
            self.nav_to_menu(self.vod_labels.LBL_ON_DEMAND_EPISODES)
            if select is True:
                self.select_menu(self.vod_labels.LBL_ON_DEMAND_EPISODES)
        else:
            if self.vod_labels.LBL_ON_DEMAND_EPISODES not in self.menu_list():
                pytest.skip("Episode is not available to validate playnextbanner, Hence skipped")
            self.nav_to_menu(self.vod_labels.LBL_ON_DEMAND_EPISODES)
            self.screen.refresh()
            self.select_string_by_substring(self.vod_labels.LBL_VIEW_ALL)

    def go_to_vod(self, tester):
        tester.home_page.back_to_home_short()
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_ONDEMAND_SHORTCUT)

    def navigate_to_vod_gallery_screen(self):
        self.log.step("checking if screen view is Gallery view or not")
        if not self.is_gallery_screen():
            self.log.info("Not on gallery screen. Trying to select VIEW ALL")
            for i in range(10):
                strip_items = self.get_strip_array()
                self.log.info("strip items :{}".format(strip_items))
                current = self.get_focused_item(strip_items)
                if current.get('text', None) and self.vod_labels.LBL_VIEW_ALL in current['text']:
                    self.log.info("Reached VIEW ALL tile")
                    self.log.info("Selecting VIEW ALL")
                    self.screen.base.press_enter()
                    self.wait_for_screen_ready()
                    return
                else:
                    self.screen.base.press_left()
                    self.screen.refresh()

    def extract_playback_duration(self, result):
        duration = None
        duration = result['offer'].duration
        return duration

    def extract_rental_duration(self, result):
        rental_duration = None
        rental_duration = result['offer'].transport[0]['rentalDuration']
        return rental_duration

    def wait_to_launch_graceful_overlay(self, tester, playbackDuration, rentalDuration, result):
        # adding extra wait time of 5 min in case if the playback duration is more than 10 min
        self.log.step("Waiting before starting playback to launch graceful end overlay")
        add_time = 300
        if playbackDuration <= 600:
            self.log.info("playback duration is less than 10 minutes")
            # adding extra wait time of 2 min in case if the playback is less than 10 min
            add_time = 120
        # Waiting for more than 80% of rental duration time to start the playback of asset
        sleeptime = rentalDuration + add_time - playbackDuration
        self.log.info(f"Sleeping for {sleeptime} seconds of rental duration: {rentalDuration}")
        self.pause(sleeptime)
        self.play_confirmrented_content(tester, result)
        self.wait_for_LiveTVPlayback(status="PLAYING")
        # sleeping for remaining rental duration time before launching Graceful end overlay with and additional 30 secs
        sleeptime_after_playback = playbackDuration - add_time + 60
        self.log.info(f"Sleeping for {sleeptime_after_playback} seconds after starting playback")
        self.pause(sleeptime_after_playback)
        self.log.info("Pressing BACK now to see if Grace full end overlay is launched or not")
        self.screen.base.press_back()
        self.wait_for_screen_ready()
        self.screen.refresh()
        self.is_overlay_shown()

    def check_vod_launch_browse_stability_unmanaged_devices(self, tester, vod_asset1, vod_asset2):
        if vod_asset1 is None:
            vod_asset1 = vod_asset2
        elif vod_asset2 is None:
            vod_asset2 = vod_asset1
        assetresult = []
        assetresult.append(vod_asset1)
        assetresult.append(vod_asset2)
        for assetitem in assetresult:
            self.navigate_to_vod_show(tester, assetitem)
            self.screen.base.press_back()
            self.wait_for_screen_ready(timeout=10000)
            self.screen.refresh()
            viewmode = self.screen.get_screen_dump_item('viewMode')
            tester.vod_assertions.verify_view_mode_check(viewmode)

    def check_vod_launch_browse_stability_managed_specific_devices(self, tester, vod_asset1, vod_asset2):
        if vod_asset1 is None:
            vod_asset1 = vod_asset2
        elif vod_asset2 is None:
            vod_asset2 = vod_asset1
        # verifying guide button functionality twice
        tester.home_page.press_guide_button()
        tester.guide_assertions.verify_guide_title()
        tester.home_page.press_guide_button()
        self.verify_view_mode(tester.liveTv_labels.LBL_LIVETV_VIEWMODE)
        # some button functionality not working , To be added later
        buttonfunction1 = {'APPS': 'Pressing Apps button', 'VOD': 'Pressing Vod button'}
        buttonfunction2 = {'EXIT': 'Pressing exit button', 'INFO': 'Pressing info button'}
        for eachbutton in buttonfunction1.keys():
            self.navigate_to_vod_show(tester, vod_asset1)
            if eachbutton == 'VOD':
                self.press_vod_and_verify_screen(tester)
            elif eachbutton == 'APPS':
                self.press_apps_and_verify_screen(tester)
        for eachbutton in buttonfunction2.keys():
            self.navigate_to_vod_show(tester, vod_asset2)
            if eachbutton == 'EXIT':
                self.press_exit_and_verify_screen(tester)
            elif eachbutton == 'INFO':
                self.verify_info_button_and_screen()

    def check_vod_launch_browse_stability_managed_devices(self, tester, vod_asset1, vod_asset2):
        if vod_asset1 is None:
            vod_asset1 = vod_asset2
        elif vod_asset2 is None:
            vod_asset2 = vod_asset1
        # some button functionality not working , To be added later
        buttonfunction1 = {'YOUTUBE': 'Pressing YOUTUBE button', 'BACK': 'Pressing back button'}
        buttonfunction2 = {'NETFLIX': 'Pressing NETFLIX button', 'HOME': 'Pressing home button'}
        for eachbutton in buttonfunction1.keys():
            self.navigate_to_vod_show(tester, vod_asset1)
            if eachbutton.lower() == tester.home_labels.LBL_YOUTUBE.lower():
                self.press_youtube_and_verify_screen(tester)
            elif eachbutton == 'BACK':
                self.screen.base.press_back()
                self.wait_for_screen_ready(timeout=10000)
                self.screen.refresh()
                viewmode = self.screen.get_screen_dump_item('viewMode')
                tester.vod_assertions.verify_view_mode_check(viewmode)
        for eachbutton in buttonfunction2.keys():
            self.navigate_to_vod_show(tester, vod_asset2)
            if eachbutton.lower() == tester.home_labels.LBL_NETFLIX.lower() and Settings.is_netflix_supported():
                self.press_netflix_and_verify_screen(tester)
            elif eachbutton == 'HOME':
                self.screen.base.press_home()
                tester.home_assertions.verify_home_title()

    def resume_socu_playback(self, tester):
        self.log.step("Resuming SOCU playback")
        if self.validate_resume_overlay(tester) is True:
            self.screen.base.press_enter()
        else:
            self.log.info("overlay not displayed. socu content is already playing")

    def extract_entryPoint_title(self, result):
        entry_point_title = None
        self.log.step("Extracting entrypoint title from result")
        if result is not None:
            if 'parentMix' in result:
                if 'childMix' in result['parentMix']:
                    entry_point_title = result['parentMix']['childMix']['title']
            self.log.info("Entry point title :{}".format(entry_point_title))
            return entry_point_title
        else:
            pytest.skip("The content is not available on VOD catlog.")

    def is_asset_unmapped(self, result):
        contentID = self.extract_contentId(result)
        unmapped = re.compile('.ts.')
        value = unmapped.search(contentID)
        self.log.step("Selected asset unmapping state: {}, asset: {}".format(value, result))
        if value is not None:
            self.log.info("Selected asset is not unmapped")
            return True
        else:
            self.log.info("Selected asset is unmapped")
            return False

    def check_next_episode_available(self, episode):
        self.log.step("Check next episode is available while current episode is playing and to get playnextbanner")
        series = re.compile(r'S\d{1,3} E\d{1,3}')
        value = series.search(episode)
        if value is None:
            pytest.skip("Next episode is not available for the season, Hence skipping the playnextbanner validation")

    def play_any_playable_vod_content(self, tester, results, confirm=True):
        entitlement = self.extract_entitlement(results)
        entitlements = [tester.vod_labels.LBL_FREE_ENTITLEMENT, tester.vod_labels.LBL_ENTITLEDSUBSCRIBED_ENTITLEMENT,
                        tester.vod_labels.LBL_ENTITLEDRENTED_ENTITLEMENT, VodPackageType.CUBI_ZVOD]
        if entitlement in entitlements:
            self.play_vod_entitled_content(tester, results=results, confirm=confirm)
        elif entitlement in tester.vod_labels.LBL_NOTRENTED_ENTITLEMENT:
            self.play_confirmrented_content(tester, results=results, confirm=confirm)
        else:
            self.log.info("The entitlement returned is not an playable content :{}".format(entitlement))

    def goto_vodoffer_program_screen(self, tester, result, through_clientui=True):
        self.log.step("Navigating to VOD Program Screen by service uinavigate API. {}".format(result))
        offerId = self.extract_offerId(result)
        vod_navigate = tester.vod_api.navigate_to_vod_offer(offerId)
        if not vod_navigate:
            # uinavigate fix can't integrate to 1.11 branch CA-9993
            if Settings.hydra_branch() <= Settings.hydra_branch("b-hydra-streamer-1-11"):
                through_clientui = True
            if through_clientui:
                self.log.step("Navigating to VOD Program Screen by client UI selection")
                self.navigate_to_vod_show(tester, result)
                return
            else:
                raise AssertionError("uiNavigate service API query failed")
        self.wait_for_screen_ready()
        self.screen.refresh()
        if vod_navigate:
            self.log.step("Wait time if navigated directly from Home to VOD program screen by UI Navigate service call")
            limit = 10
            while tester.home_page.is_home_screen_active():
                self.wait_for_screen_ready()
                self.screen.refresh()
                limit -= 1
                if limit < 0:
                    break
        if self.view_mode() == self.vod_labels.LBL_ACTIONS_SCREEN:
            tester.menu_assertions.verify_item_option_focus(tester.vod_labels.LBL_WATCH_NOW)
        else:
            self.log.info("Not in Action screen, current screen is{}".format(self.view_mode()))

    def _get_resolutionscreen_element(self, entitlement):
        """
        method to get proper label to select on the resolution screen
        Args:
            entitlement: dict, Mind response with entitlement

        Returns:
            str, label to select
        """
        if entitlement in self.vod_labels.LBL_FREE_ENTITLEMENT:
            element = self.vod_labels.LBL_FREE
        elif entitlement in self.vod_labels.LBL_ENTITLEDSUBSCRIBED_ENTITLEMENT:
            element = self.vod_labels.LBL_SVOD_ASSET
        elif entitlement in self.vod_labels.LBL_ENTITLEDRENTED_ENTITLEMENT:
            element = self.vod_labels.LBL_TVOD_AVAILABLE
        elif entitlement in self.vod_labels.LBL_NOTRENTED_ENTITLEMENT:
            element = self.vod_labels.LBL_TVOD_AVAILABLE
        else:
            raise LookupError("The entitlement returned is not an playable content :{}".format(entitlement))
        return element

    def play_vod_entitled_content(self, tester, results, resume=False, confirm=True):
        # TODO: documentation and XML wrappers
        entitlement = self.extract_entitlement(results)
        self.log.step("Starting playback of VOD asset: {}".format(entitlement))
        self.screen.refresh()
        menu = self.menu_focus()
        if menu == self.vod_labels.LBL_WATCH_NOW:
            self.select_menu(self.vod_labels.LBL_WATCH_NOW)
        if self.screen.get_screen_dump_item('viewMode') == tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            try:
                self.log.info("Trying to select using subtitle")
                subtitle = results['offer'].subtitle
                self.select_menu_by_substring(subtitle)
            except Exception:
                self.log.info("No subtitle available for the content")
                self.select_item()
            time.sleep(5)
        vodplayback = self.wait_for_screen_ready(tester.vod_labels.LBL_VOD_PLAYBACK)
        if vodplayback:
            self.log.info("Vod content started to playback")
            return
        resolutionscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
        if resolutionscreen:
            self.log.info("HD/SD resolution selector overlay displayed")
            self.screen.refresh()
            to_select = self._get_resolutionscreen_element(entitlement)
            self.select_menu_by_substring(to_select)
            time.sleep(5)
        resumescreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESUME_OVERLAY)
        if not resumescreen:
            self.screen.refresh()
            if self.is_startover_overlay(self):
                resumescreen = True
        if resumescreen:
            self.log.info("Resume playing overlay displayed")
            if not resume:
                self.screen.base.press_down()
                if confirm:
                    self.screen.base.press_enter(time=1000)
                    time.sleep(5)
            else:
                self.log.step("Resume playing selected")
                self.select_menu_by_substring(tester.vod_labels.LBL_RESUME_PLAYING, confirm=confirm)
        else:
            self.log.info("overlay not displayed. Asset should already be playing")
        self.log.info("Playback started")

    def get_content_available_from_both_vod_and_ott(self, tester):
        status, partnerid, querycount = tester.vod_api._getVodPartnerId()
        if status != "SUCCESS":
            pytest.skip("_getVodPartnerId failed. Unable to proceed.")
        self.log.info(f"VOD PartnerID obtained is: {partnerid}")
        feed_list = tester.wtw_page.get_feed_name(feedtype="TV")
        vod_program = None
        for feed in feed_list:
            self.log.info("feed : {}".format(feed))
            if feed is not None:
                vod_program = tester.service_api.get_show_available_from_OTT(feedName=feed, count=-1,
                                                                             partnerid=partnerid)
                if len(vod_program) > 0:
                    break
        if not vod_program:
            pytest.skip("Get Vod program failed. Unable to proceed.")
        self.log.info("Obtained VOD contents: {}".format(str(vod_program)))
        programs = tester.service_api.get_show_available_from_OTT(feedName=feed, count=-1)
        if not programs:
            pytest.skip("Get Vod program failed. Unable to proceed.")
        self.log.info("All contents available from OTT: {}".format(str(programs)))

    def get_vod_error_status(self, tester):
        self.go_to_vod(tester)
        return tester.home_page.get_error_overlay_status()

    def navigate_to_action_screen_from_series_screen(self):
        self.log.step("Navigate to action screen from series screen")
        self.wait_for_screen_ready()
        self.screen.refresh()
        viewmode = self.view_mode()
        if viewmode == self.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            self.navigate_to_on_demand_episodes(select=True)
            self.screen.base.press_right()
            time.sleep(2)
            self.screen.base.press_enter()
            self.wait_for_screen_ready()
            self.verify_view_mode(self.vod_labels.LBL_ACTIONS_SCREEN)
        else:
            self.log.info("Not in series screen: {}".format(viewmode))

    def back_to_vod_main_screen(self, mid, count=10):
        self.log.step("Navigating back to VOD main screen: {}".format(count))
        if mid == "managed":
            self.log.info("Managed device. Pressing home button")
            self.screen.base.press_home(100)
        else:
            while str(self.screen_title()) != self.vod_labels.LBL_ON_DEMAND.upper() and count > 0:
                self.screen.base.press_back()
                self.wait_for_screen_ready()
                self.screen.refresh()
                self.log.info("Current view mode: {}".format(self.view_mode()))
                count -= 1

    def check_if_current_pos_near_to_end(self, current_pos_sec, duration):
        status = False
        if current_pos_sec < duration - 180:
            status = False
        else:
            status = True
        self.log.info("Status is {}".format(status))
        return status

    def get_can_not_watch_show_overlay_visibility(self):
        self.log.info("Getting visibility of 'can't watch show ' overlay.")
        self.screen.refresh()
        if self.is_overlay_shown() and self.get_overlay_title() == \
                self.vod_labels.LBL_CAN_NOT_WATCH_OVERLAY_SHOW_TITLE:
            return True
        else:
            return False

    def get_overlay_body_text(self):
        self.log.info("Getting overlay body text.")
        screen = self.screen.screen_dump['xml']
        if 'bodytext' in screen.keys():
            return screen['bodytext']

    def get_vod_show_duration(self):
        """
        This API will get the currently playing VOD show duration
        Args:
            none
        Returns:
            Total duration of the currently playing VOD
        """
        self.log.info("Getting VOD show duration from trickplay bar")
        vod_show_duration = self.get_trickplay()['duration']
        self.log.info(f"vod_show_duration {vod_show_duration}")
        return vod_show_duration

    def covert_show_length_from_precentage_to_secs(self, percentage):
        """
        This API is used to get the duration of the show when percentage of the show is given
        Args:
            percentage: How much percentage of the show need to be coverted into duration of the show
        Returns:
            Corresponding duration of the show in seconds
        """
        full_show_duration = self.get_vod_show_duration()
        duration_of_the_show_in_sec = self.convert_time_to_sec(full_show_duration)
        show_time = round((duration_of_the_show_in_sec / 100) * percentage)
        self.log.info(f"{percentage}% of shows time in seconds is {show_time}")
        return show_time

    def go_to_series_content_screen_of_on_demand_episode(self, tester):
        """
        This API is used to find on demand series and go to series content screen of the same
        Args:
            None
        Returns:
            none
        """
        status, result = tester.vod_api.get_collection_type_series()
        ep = self.extract_entryPoint(result)
        mix_id = self.extract_mixID(result)
        content_id = self.extract_contentId(result)
        collection_id = self.extract_collectionId(result)
        title = self.extract_title(result)
        self.go_to_vod(tester)
        self.navigate_to_entryPoint(tester, ep, mix_id)
        self.select_vod(tester, collection_id, content_id, title)
        self.launch_episode_list_view(self, self.vod_labels.LBL_ON_DEMAND_EPISODES)

    def get_list_of_already_watched_episodes(self, already_watched=True):
        """
        This API is used to find "already watched/yet to watch" on demand episodes in the series content screen
        Args:
            Boolean - already_watched
        Returns:
            list of episode list
            If already_watched is True then it will return already watched episode list
            If already_watched is False then it will return not yet watched episode list
        """
        episodelist = []
        menu_item = self.get_menu_item()
        if already_watched:
            for item in menu_item:
                if item['progressbar']['visible'] == 'true':
                    episodelist.append(item['text'])
            self.log.info(f"Here is the list of episodes that are already watched {episodelist}")
        else:
            for item in menu_item:
                if item['progressbar']['visible'] == 'false':
                    episodelist.append(item['text'])
            self.log.info(f"Here is the list of episodes that are not yet watched {episodelist}")
        return episodelist

    def get_watched_progress_bar_position_of_episode_in_series_content_screen(self, episode_name):
        """
        This API is used to get the position of watched progress bar of the show(Episode)
        Args:
        Returns:
            None - If the episode don't have watched position
            watchedposition - If the episode have watched position
            return Type: X and Y co-ordinates
        ToDo: Basic testing is done. Need to test E2E flow after feature implementation
        """
        if self.is_in_menu(episode_name):
            menu_list = self.get_menu_item()
            for item in menu_list:
                if item['text'][0] == episode_name:
                    if item['progressbar']['visible'] == "false":
                        watchedposition = None
                    else:
                        watchedposition = item['progressbar']['watchedposition']
            self.log.info(f"watched position of the episode {episode_name} is {watchedposition} ")
            return watchedposition
        else:
            pytest.skip(f"This episode {episode_name} is unavailable on series content screen")

    def get_list_of_partially_or_completely_watched_episodes(self, is_partial=True):
        """
        This API is used to find "partially or completely watched" on demand episodes in the series content screen
        Args:
            Boolean - is_partial
        Returns:
            list of episode list
            If is_partial is True then it will return partially watched episode list
            If is_partial is False then it will return completely watched episode list
        ToDo: Basic testing is done. Need to test E2E flow after feature implementation
        """
        partially_watched_episodelist = []
        completely_watched_episodelist = []
        menu_item = self.get_menu_item()
        already_watched_episode_list = self.get_list_of_already_watched_episodes(already_watched=True)
        if not already_watched_episode_list:
            self.log.info("No episodes that are already watched for this series")
            return None
        for item in menu_item:
            if item['text'][0] in already_watched_episode_list and item['progressbar']['watchedposition'] < 100:
                partially_watched_episodelist.append(item['text'])
            else:
                completely_watched_episodelist.append(item['text'])
        if is_partial:
            self.log.info(f"Here is the partially watched episode list {partially_watched_episodelist}")
            return partially_watched_episodelist
        else:
            self.log.info(f"Here is the completely watched episode list {completely_watched_episodelist}")
            return completely_watched_episodelist

    def get_highlighted_episode_name_in_series_content_screen(self):
        """
        This API is used to find the episode name of highlighted show in series content screen
        Args:None
        Returns: Str - name of the highlighted episode
        """
        episode_name = self.menu_item_option_focus()[0]
        return episode_name
