import pytest

from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.client_api.guide.assertions import GuideAssertions
from set_top_box.client_api.VOD.assertions import VODAssertions
from set_top_box.client_api.my_shows.assertions import MyShowsAssertions
from set_top_box.client_api.text_search.assertions import TextSearchAssertions
from set_top_box.client_api.wtw.assertions import WhatToWatchAssertions
from set_top_box.client_api.program_options.assertions import ProgramOptionsAssertions
from set_top_box.test_settings import Settings
from core_api.stb.base import StreamerBase
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.client_api.apps_and_games.assertions import AppsAndGamesAssertions
from set_top_box.client_api.account_locked.assertions import AccountLockedAssertions
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from tools.logger.logger import Logger
from set_top_box.conf_constants import HydraBranches, MindEnvList, MsoList, NotificationSendReqTypes, \
    RemoteCommands
from set_top_box.conftest import get_actual_tsn


__log = Logger(__name__)


@pytest.fixture(autouse=True, scope="class")
def setup_vod(request):
    """
    Configure steps to be executed before the test cases run
    :param request:
    :return:
    """
    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_labels = request.cls.home_page.home_labels = LabelFactory("home", Settings)
    request.cls.home_assertions = HomeAssertions(request.cls.screen)
    request.cls.home_assertions.home_page = request.cls.home_page
    request.cls.home_assertions.home_labels = request.cls.home_labels
    request.cls.home_page.home_labels = request.cls.home_labels

    request.cls.program_options_page = PageFactory("program_options", Settings, request.cls.screen)
    request.cls.program_options_labels = LabelFactory("program_options", Settings)
    request.cls.program_options_assertions = ProgramOptionsAssertions(request.cls.screen)

    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)
    request.cls.menu_labels = request.cls.menu_page.menu_labels = LabelFactory("Menu", Settings)

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)
    request.cls.guide_page.guide_labels = request.cls.guide_assertions.guide_labels = request.cls.guide_labels
    request.cls.home_page.guide_page = request.cls.guide_page

    request.cls.vod_page = PageFactory("VOD", Settings, request.cls.screen)
    request.cls.vod_assertions = VODAssertions(request.cls.screen)
    request.cls.vod_labels = request.cls.vod_page.vod_labels = LabelFactory("VOD", Settings)

    request.cls.my_shows_labels = LabelFactory("my_shows", Settings)
    request.cls.my_shows_page = PageFactory("my_shows", Settings, request.cls.screen)
    request.cls.my_shows_assertions = MyShowsAssertions(request.cls.screen)

    request.cls.watchvideo_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.watchvideo_assertions = WatchVideoAssertions(request.cls.screen)
    request.cls.watchvideo_labels = request.cls.liveTv_labels = LabelFactory("watchvideo", Settings)
    request.cls.watchvideo_assertions.watchvideo_labels = request.cls.watchvideo_labels

    request.cls.apps_and_games_labels = LabelFactory("apps_and_games", Settings)
    request.cls.apps_and_games_assertions = AppsAndGamesAssertions(request.cls.screen)
    request.cls.apps_and_games_page = PageFactory("apps_and_games", Settings, request.cls.screen)

    request.cls.wtw_page = PageFactory("wtw", Settings, request.cls.screen)
    request.cls.wtw_assertions = WhatToWatchAssertions(request.cls.screen)
    request.cls.wtw_labels = LabelFactory("wtw", Settings)

    request.cls.text_search_labels = LabelFactory("text_search", Settings)
    request.cls.text_search_page = PageFactory("text_search", Settings, request.cls.screen)
    request.cls.text_search_page.text_search_labels = request.cls.text_search_labels
    request.cls.text_search_assertions = TextSearchAssertions(request.cls.screen)

    request.cls.acc_locked_labels = LabelFactory("account_locked", Settings)
    request.cls.acc_locked_page = PageFactory("account_locked", Settings, request.cls.screen)
    request.cls.acc_locked_assertions = AccountLockedAssertions(request.cls.screen)
    request.cls.acc_locked_page.acc_locked_labels = request.cls.acc_locked_labels
    request.cls.acc_locked_assertions.acc_locked_labels = request.cls.acc_locked_labels
    request.cls.acc_locked_assertions.acc_locked_page = request.cls.acc_locked_page

    request.cls.core_api_base = StreamerBase(request.cls.screen)
    request.getfixturevalue('clean_ftux_and_sign_in')
    request.getfixturevalue('disable_parental_controls')


@pytest.fixture(autouse=False, scope="function")
def setup_clear_subscriptions(request):
    if Settings.is_ndvr_applicable():
        request.cls.api.delete_all_subscriptions()
        request.cls.api.delete_recordings_from_myshows()


def __check_if_service_or_pps_has_passed_values_and_set_default_values_if_failed(request, dd_dict, mso_env, req_type,
                                                                                 set_default_val):
    """
    Checking if serviceTier and vodSiteId do not have values that are being planned to be set and
    fixing service and PPS in case of incorrect serviceTier and/or vodSiteId values.
    Args:
        dd_dict (dict): passed values for serviceTier and vodSiteId to check
        mso_env (str): string in format - Settings.mso.lower() + " " + Settings.test_environment.lower()
        req_type (str): one of (NotificationSendReqTypes.FCM, NotificationSendReqTypes.NSR)
        set_default_val (bool): True - set default vodSiteId and serviceTier when
                                      setup failed (service and/or PPS already have passed values),
                                False - leave values as they are
    """
    # Default values may come in handy when serviceTier and vodSiteId have new values in the beginning of the test
    # which means that initial values were overridden and not got back
    default1 = {
        MsoList.CC11 + " " + MindEnvList.STAGING: {"serviceTier": "CABLECO11_SOFT_CC11_ATV_STAGING",
                                                                  "vodSiteId": "cableco11_510"},
        MsoList.CC3 + " " + MindEnvList.STAGING: {"serviceTier": "CABLECO3_UNMAN_VP4_LAB1_STAGING",
                                                                 "vodSiteId": "cableco3_620"},
        MsoList.CC3 + " " + MindEnvList.USQE_1: {"serviceTier": "CABLECO3_SOFT_ITV_VP3_Q", "vodSiteId": "cableco3_610"}}
    dd_pps = request.cls.pps_api_helper.get_device_details(Settings.ca_device_id)[0]
    device_info = request.cls.iptv_prov_api.device_info_search(
        request.cls.service_api.getPartnerCustomerId(Settings.tsn),
        request.cls.service_api.get_mso_partner_id(Settings.tsn),
        request.cls.service_api.get_device_type())["deviceInfo"]
    err_msg = ""
    warn_msg = "\n!!! Note: service and PPS values are fixed. Please investigate how they got corrupted !!!" if \
        set_default_val else ""
    # Checking if device info does not have passed serviceTier and vodSiteId
    if device_info["tier"] == dd_dict["serviceTier"] or device_info["siteId"] == dd_dict["vodSiteId"]:
        err_msg += "Setup failed (deviceInfoSearch): vodSiteId ({cur_site_id}) and/or serviceTier " \
            "({cur_tier}) already contain passed values; {mso} {test_env} (passed values: {passed_dict}). " \
            "{warn_msg}\n\n".format(
                cur_site_id=device_info["siteId"], cur_tier=device_info["tier"], mso=Settings.mso.lower(),
                test_env=Settings.test_environment.lower(), passed_dict=dd_dict, warn_msg=warn_msg)
    # Checking if device details in PPS does not have passed serviceTier and vodSiteId
    if dd_pps["serviceTier"] == dd_dict["serviceTier"] or dd_pps["vodSiteId"] == dd_dict["vodSiteId"]:
        err_msg += "Setup failed (PPS): vodSiteId ({cur_site_id}) and/or serviceTier ({cur_tier}) " \
            "already contain passed values; {mso} {test_env} (passed values: {passed_dict}). {warn_msg}\n\n".format(
                cur_site_id=dd_pps["vodSiteId"], cur_tier=dd_pps["serviceTier"], mso=Settings.mso.lower(),
                test_env=Settings.test_environment.lower(), passed_dict=dd_dict, warn_msg=warn_msg)
    if set_default_val and err_msg:
        __log.info("Setting default values for vodSiteId and serviceTier")
        request.cls.pps_api_helper.update_device_details(Settings.ca_device_id, default1[mso_env])
        request.cls.iptv_prov_api.device_info_store(
            request.cls.service_api.getPartnerCustomerId(Settings.tsn),
            request.cls.service_api.get_mso_partner_id(Settings.tsn),
            request.cls.service_api.get_device_type(),
            request.cls.service_api.fe_device_mso_service_id_get()["msoServiceId"],
            site_id=default1[mso_env]["vodSiteId"], tier=default1[mso_env]["serviceTier"])
        request.cls.home_page.send_fcm_or_nsr_notification(req_type, RemoteCommands.SERVICE_CALL)
        request.cls.home_page.relaunch_hydra_app()
    if err_msg:
        raise AssertionError(err_msg)


def __update_tier_and_site_id(request, dd_dict, mso_env, req_type, is_setup, is_make_dis, is_pps_lite_expected,
                              is_pps_lite_actually_on, set_default_val):
    """
    Args:
        dd_dict (dict): device details params with new values for changing
        mso_env (str): string in format - Settings.mso.lower() + " " + Settings.test_environment.lower()
        req_type (str): one of (NotificationSendReqTypes.FCM, NotificationSendReqTypes.NSR)
        is_setup (bool): True - selecting Remind me later option on the RemoteCommands.SERVICE_CALL overlay
                         False - selecting Restart now/Exit now option
        is_make_dis (bool): True - make deviceInfoStore request, False - no deviceInfoStore request
        is_pps_lite_expected (bool): True - test will be run only if PPS-Lite is ON and updating params
                                            in PPS and making deviceInfoStore
                                     False - test will adapt to PPS-Lite feature state e.g.
                                             sending RemoteCommands.SERVICE_CALL request
                                             after updating PPS if PPS-Lite feature is OFF
        is_pps_lite_actually_on (bool): True - make deviceInfoStore request, False - no deviceInfoStore request
        set_default_val (bool): True - set default vodSiteId and serviceTier when value check failed,
                                False - no default value setting when value check falied
    """
    if is_setup:
        request.cls.home_page.validate_fcm_nsr_mts_req_usage(req_type, RemoteCommands.SERVICE_CALL, True)
        if is_pps_lite_expected and not is_pps_lite_actually_on:
            skip_pps_lite_is_off_mes = f"PPS-Lite feature is not enabled on {Settings.test_environment} environment"
            __log.warning(skip_pps_lite_is_off_mes)
            pytest.skip(skip_pps_lite_is_off_mes)
        __check_if_service_or_pps_has_passed_values_and_set_default_values_if_failed(
            request, dd_dict, mso_env, req_type, set_default_val)
        request.cls.home_page.back_to_home_short()
        request.cls.home_page.select_menu_shortcut_num(request.cls, request.cls.home_labels.LBL_ONDEMAND_SHORTCUT)
        # There should not be any error overlay over while opening the VOD Browse Main screen
        request.cls.vod_assertions.verify_overlay_shown(expected=False)
        # Preserving shown VOD strip names in list
        request.config.cache.set("vod_strip_name_list", request.cls.vod_page.menu_list())
    else:
        # Cleanup fixture enters here
        request.cls.home_page.screen.get_json()
        overlay = request.cls.home_page.get_overlay_title(raise_error=False)
        if isinstance(overlay, str) and request.cls.home_labels.LBL_RESTART_TO_APPLY_UPDATES_OVERLAY in overlay:
            request.cls.home_page.select_menu(request.cls.home_labels.LBL_REMIND_ME_LATER_OPTION)
            request.cls.home_page.select_menu_shortcut_num(request.cls, request.cls.home_labels.LBL_ONDEMAND_SHORTCUT)
        elif request.cls.home_labels.LBL_HOME_VIEW_MODE in request.cls.home_page.view_mode():
            request.cls.home_page.back_to_home_short()
            request.cls.home_page.select_menu_shortcut_num(request.cls, request.cls.home_labels.LBL_ONDEMAND_SHORTCUT)
        request.config.cache.set("vod_strip_name_list", None)  # resetting value
    request.cls.pps_api_helper.update_device_details(Settings.ca_device_id, dd_dict)
    if not is_setup or is_make_dis:
        # This step is required when running cleanup fixture
        request.cls.iptv_prov_api.device_info_store(
            request.cls.service_api.getPartnerCustomerId(Settings.tsn),
            request.cls.service_api.get_mso_partner_id(Settings.tsn),
            request.cls.service_api.get_device_type(),
            request.cls.service_api.fe_device_mso_service_id_get()["msoServiceId"],
            site_id=dd_dict["vodSiteId"], tier=dd_dict["serviceTier"])
    # Separate sending of RemoteCommands.SERVICE_CALL notification is needed only when PPS-Lite feature is off
    if not is_pps_lite_expected and not is_pps_lite_actually_on:
        request.cls.home_page.send_fcm_or_nsr_notification(req_type, RemoteCommands.SERVICE_CALL)
    # Handling RemoteCommands.SERVICE_CALL overlay
    request.cls.home_page.press_back_button(refresh=False)
    request.cls.home_assertions.verify_overlay_title(request.cls.home_labels.LBL_RESTART_TO_APPLY_UPDATES_OVERLAY)
    if is_setup:
        request.cls.home_page.select_menu(request.cls.home_labels.LBL_REMIND_ME_LATER_OPTION)
    else:
        request.cls.home_page.relaunch_hydra_app()


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_set_tier_and_site_id(request, is_pps_lite, is_make_dis):
    """
     1. Preserves VOD Browse Main screen's strip name list
     2. Checks if PPS-Lite feature is on
        2.1. If PPS-Lite is on, send deviceInfoStore
        2.2. If PPS-Lite is off, send RemoteCommands.SERVICE_CALL request
     3. Update serviceTier and vodSiteId in PPS
     4. Handle RemoteCommands.SERVICE_CALL overlay on the Home screen:
        4.1. If running before test, select Remind me later option
        4.2. If running after test, select Restart now/Exit now option and restart Hydra app

    Note:
        Use request.config.cache.get("vod_strip_name_list", None) for comparing of VOD Browse Main catalog.
        Use request.config.cache.get("new_site_id_and_service_id", None) for getting
            new values for vodSiteId and msoServiceId.

    Args:
        request (function): pytest fixture
        is_pps_lite (bool): True - updating params in PPS and making deviceInfoStore, also test will be run
                                   only if PPS-Lite feature is ON
                                   (this param doesn't mean that PPS-Lite is ON/OFF, it just tells us what we need)
                            False - test will adapt to PPS-Lite feature state e.g. sending RemoteCommands.SERVICE_CALL
                                    request after updating PPS if PPS-Lite feature is OFF;
                            @pytest.mark.parametrize("is_pps_lite", True)
        is_make_dis (bool): True - make deviceInfoStore request, False - no deviceInfoStore request
                            @pytest.mark.parametrize("is_make_dis", True)
    """
    req_type = NotificationSendReqTypes.FCM if Settings.is_managed() else NotificationSendReqTypes.NSR
    set_default_site_id_and_tier = True  # if default serviceTier and vodSiteId should be set when values got corrupted
    # Environments where PPS-Lite feature is actually activated
    pps_lite_supported_on = {MindEnvList.STAGING: [MsoList.CC3],
                             MindEnvList.USQE_1: [MsoList.CC3]}
    # Checking actual state of PPS-Lite feature (service side feature)
    is_ppslite_on = True if Settings.test_environment.lower() in pps_lite_supported_on.keys() and \
        Settings.mso.lower() in pps_lite_supported_on[Settings.test_environment.lower()] else False
    # New values to be set for serviceTier and vodSiteId
    new1 = {
        MsoList.CC11 + " " + MindEnvList.STAGING: {"serviceTier": "CABLECO11_MAN_ATV_VP11_STAGING",
                                                                  "vodSiteId": "cableco11_610"},
        MsoList.CC3 + " " + MindEnvList.STAGING: {"serviceTier": "CABLECO3_UNMAN_ATV_VP9_STAGING",
                                                                 "vodSiteId": "cableco3_670"},
        MsoList.CC3 + " " + MindEnvList.USQE_1: {"serviceTier": "CABLECO3_SOFT_ITV_VP6_Q", "vodSiteId": "cableco3_640"}}
    if not is_pps_lite and Settings.hydra_branch() < Settings.hydra_branch(HydraBranches.STREAMER_1_15):
        skip_hydra_vers_mes = "Service Login and Config Update feature is not supported on older Hydra versions"
        __log.warning(skip_hydra_vers_mes)
        pytest.skip(skip_hydra_vers_mes)
    elif Settings.mso.lower() + " " + Settings.test_environment.lower() not in new1.keys():
        skip_no_tier_site_id_mes = f"No prepared pairs serviceTier and vodSiteId for {Settings.mso.lower()} " \
            f"{Settings.test_environment.lower()}"
        __log.warning(skip_no_tier_site_id_mes)
        pytest.skip(skip_no_tier_site_id_mes)
    request.config.cache.set("new_site_id_and_service_id", new1)
    mso_env = Settings.mso.lower() + " " + Settings.test_environment.lower()
    backup = {}
    device_details = request.cls.pps_api_helper.get_device_details(Settings.ca_device_id)[0]
    # Preserving initial values for serviceTier and vodSiteId params
    backup["serviceTier"] = device_details["serviceTier"]
    backup["vodSiteId"] = device_details["vodSiteId"]

    __log.info("Setup. Updating Settings.tsn value since TSN changes after cancelling and re-activating account")
    # TSN changing is detected for licenseplate
    setattr(Settings, "tsn", get_actual_tsn())

    __log.info("Setup. Setting serviceTier and vodSiteId to PPS")
    __update_tier_and_site_id(request, new1[mso_env], mso_env, req_type, True, is_make_dis, is_pps_lite, is_ppslite_on,
                              set_default_site_id_and_tier)

    def tear_down():
        __log.info("Cleanup. Getting back backed up serviceTier and vodSiteId to PPS")
        __update_tier_and_site_id(request, backup, mso_env, req_type, False, is_make_dis, is_pps_lite, is_ppslite_on,
                                  set_default_site_id_and_tier)
    request.addfinalizer(tear_down)
