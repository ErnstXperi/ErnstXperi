from .labels import VODLabels


class LLACRVODLabels(VODLabels):
    LBL_MY_RENTALS = "Mis alquileres"
    LBL_MY_ADULT_RENTALS = "Mis alquileres de adulto"
