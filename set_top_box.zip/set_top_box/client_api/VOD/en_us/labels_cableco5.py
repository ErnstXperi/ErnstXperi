from .labels import VODLabels


class Cableco5VODLabels(VODLabels):
    LBL_VTP_VOD_OFFERID = "tivo:of.ts.1519620032"
    LBL_SUBTITLE_VOD_PROGRAM_NEW = "Six Subtitles"
    LBL_VP15_ON_DEMAND = "VP15 On Demand"
