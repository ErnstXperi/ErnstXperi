from .labels import VODLabels


class BlueridgeVODLabels(VODLabels):
    LBL_MY_RENTALS = "My Saved Programs"
