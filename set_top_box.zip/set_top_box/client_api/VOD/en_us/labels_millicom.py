from .labels import VODLabels


class MILLICOMVODLabels(VODLabels):
    LBL_MY_RENTALS = "Mis alquileres"
