from .labels import VODLabels


class Cableco3VODLabels(VODLabels):
    LBL_ON_DEMAND = "CableCo3VOD On Demand"
