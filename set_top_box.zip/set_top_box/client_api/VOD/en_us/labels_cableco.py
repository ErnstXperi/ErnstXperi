

class CablecoVODLabels:
    LBL_MY_RENTALS = "My On Demand"
    LBL_MY_ADULT_RENTALS = "My Adult On Demand"
