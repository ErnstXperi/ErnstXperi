from .labels import VODLabels


class ASTOUNDVODLabels(VODLabels):
    LBL_MY_ADULT_RENTALS = "Adult My Rentals"
