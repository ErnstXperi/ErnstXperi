from .labels import VODLabels


class TdsVODLabels(VODLabels):
    LBL_MY_RENTALS = "Recently Watched"
