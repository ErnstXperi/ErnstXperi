class HotwireVODLabels:
    LBL_MY_ADULT_RENTALS = "My Rentals"
