from .labels import VODLabels


class MediacomVODLabels(VODLabels):
    LBL_MY_RENTALS = "RECENTLY VIEWED"
