from .labels import VODLabels


class Cableco11VODLabels(VODLabels):
    LBL_VTP_VOD_EP = "/Loc1/QE/TRICKPLAY/VTP"
    LBL_VTP_VOD_COLLECTIONID = "tivo:cl.ts.83589302"
    LBL_VTP_VOD_PROGRAM = "Asset asset_20220524045009"
