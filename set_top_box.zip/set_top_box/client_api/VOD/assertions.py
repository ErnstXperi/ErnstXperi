from hamcrest import assert_that, has_items, not_none, equal_to, contains, less_than_or_equal_to, \
    greater_than_or_equal_to, contains_string, is_not, is_in
from hamcrest import equal_to_ignoring_case, matches_regexp
from hamcrest import is_
from set_top_box.client_api.VOD.page import VODPage
import time
import re
import pytest

from tools.logger.logger import Logger


class VODAssertions(VODPage):
    log = Logger(__name__)

    def verify_closed_captioning(self, option):
        self.log.step(f"verifying {option}")
        assert_that(self.is_in_strip(option), "Current strip: {}".format(self.screen.get_screen_dump_item('stripitem')))

    def verify_screen_title(self, title):
        screentitle = (self.screen.get_screen_dump_item('screentitle')).lower()
        title = title.lower()
        to_assert = title in screentitle or screentitle in title
        assert_that(to_assert, "Expected Screen Title : {} and Actual Screen Title : {}".format(title, screentitle))

    def verify_view_mode(self, view, dump=True):
        self.log.step(f"Verifying view mode {view}")
        for i in range(0, 3):
            if dump:
                self.screen.refresh()
            view_mode = self.view_mode()
            if view_mode == view:
                return
            else:
                dump = True
        error = self.get_ui_error()
        if error:
            raise AssertionError("Encountered the following error : {}".format(error))
        assert_that(view_mode, equal_to(view))

    def verify_svod_upsell_overlay(self, tester, results):
        self.log.step("Verifying unsubscribed SVOD upsell overlay")
        # screen_dump = self.screen.get_json() --> commenting as this is nowhere used in funtion
        if self.screen.get_screen_dump_item('viewMode') == tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            try:
                subtitle = results['offer'].subtitle
                self.select_menu_by_substring(subtitle)
            except Exception:
                self.log.info("No subtitle available for the content")
                self.select_item()
            time.sleep(5)
        else:
            self.select_menu(tester.vod_labels.LBL_WATCH_NOW)
            self.screen.refresh()
            time.sleep(5)
        self.screen.refresh()
        resolutionscreen = self.wait_for_screen_ready(tester.vod_labels.LBL_RESOLUTION_OVERLAY)
        if resolutionscreen:
            self.log.info("HD/SD selector overlay displayed")
            svod = tester.vod_labels.LBL_UNSUBSCRIBED_SVOD
            tester.vod_page.matchandselect(self, svod)
            self.screen.refresh()
            time.sleep(5)
        if self.screen.get_screen_dump_item('bodytext') and re.search(tester.vod_labels.LBL_VOD_UPSELL_BODY_TEXT,
                                                                      self.screen.get_screen_dump_item('bodytext')):
            self.log.info("SVOD upsell overlay displayed")
            assert True
        else:
            self.log.info("VOD upsell overlay is not displayed")
            assert False

    def verify_vod_playback(self, tester):
        self.log.step("Verifying playback was successful or not")
        self.wait_for_screen_ready(tester.vod_labels.LBL_VOD_PLAYBACK)
        self.screen.refresh()
        assert_that(self.screen.get_screen_dump_item('viewMode'), is_(tester.vod_labels.LBL_WATCHVOD))
        tester.watchvideo_assertions.verify_playback_play(tivo_plus_channel=True)  # To catch error overlay
        tester.guide_assertions.verify_play_normal()

    def verify_pin_overlay(self):
        mode = self.screen.get_screen_dump_item('overlayMode')
        if mode == "pinchallenge.PinEntryOverlayView" or mode == "pinchallenge.SpinnerPinEntryOverlayView":
            self.log.info("Pin entry Overlay present")
        else:
            assert False, "Pin entry overlay Not present"

    def verify_video_streaming(self, refresh=False):
        self.log.info("Verifying video window visibility")
        if refresh:
            self.screen.refresh()
        time.sleep(5)
        if self.is_video_window() and self.get_video_window_status():
            self.log.info("Video is Streaming")
        else:
            assert False, "Seems video is not streaming. \n" \
                          "Video window is not available or not visible: {}".format(self.screen.screen_dump['xml'])

    def verify_press_forward_trick_play(self, status):
        self.log.info(f"verifying Trickplay {status} action")
        self.screen.refresh()
        trickplay = self.screen.get_screen_dump_item('trick-play')
        if "play-status" in trickplay and trickplay['play-status'] == status:
            self.log.info("{} is enabled".format(status))
        else:
            assert False, status + " cannot be found"

    def verify_trick_play_available(self, status):
        self.log.step("Checking if trickplay is available or not")
        time.sleep(10)
        self.screen.refresh()
        trickplay = self.screen.get_screen_dump_item('trick-play')
        if 'trick-play-enabled' in trickplay.keys() and trickplay['trick-play-enabled'] == "true":
            self.log.info("Trick-Play-Enabled")
            if 'play-status' in trickplay.keys() and trickplay['play-status'] == status:
                self.log.info("{} is enabled".format(status))
            else:
                assert False, status + " is not Available"
        else:
            assert False, "Trick-Play is not Available"

    def verify_press_reverse_trick_play(self, status):
        self.log.info(f"verifying Trickplay {status} action")
        self.screen.refresh()
        trickplay = self.screen.get_screen_dump_item('trick-play')
        if "play-status" in trickplay and trickplay['play-status'] == status:
            self.log.info("{} is enabled".format(status))
        else:
            assert False, status + " cannot be found"

    def verify_pause_mode(self, icon):
        self.log.info("Verifying if Video was paused or not")
        self.screen.refresh()
        player = self.screen.get_screen_dump_item('playerinfo')
        self.log.info(player)
        if 'imagename' in player.keys() and icon in player['imagename'][0]:
            self.log.info("pause icon found")
        else:
            assert False, "Pause icon not found"

    def verify_my_rentals(self, tester, title, strip):
        self.screen.refresh()
        try:
            self.log.step(f"Verifying {title} availability under My Rentals")
            previewtitle = self.get_preview_panel()['title']
            programtitle = re.sub('[^A-Za-z]+', '', title)
            previewtitle = re.sub('[^A-Za-z]+', '', previewtitle)
            if programtitle not in previewtitle:
                assert False, title + " is not listed in my rentals menu"
        except AssertionError:
            tester.guide_page.move_or_select_view_all_in_biaxial_screen_strip(tester,
                                                                              strip,
                                                                              select_view_all=True)
            self.screen.refresh()
            menulist = self.menu_list()
            self.log.info("Menulist: {}".format(menulist))
            result = any(title.lower() in menu.lower() for menu in menulist)
            if not result:
                raise AssertionError("{} not in list {}".format(title, menulist))

    def verify_trickplay_restriction_message_shown(self, message):
        self.screen.get_json()
        screen = self.screen.screen_dump['xml']
        if 'stripItemSubtitle' in screen.keys() and screen['stripItemSubtitle'] == message:
            self.log.info("Message is shown.")
        else:
            assert False, "Message is not shown!!!"

    def verify_episode_screen(self, tester, title):
        self.log.step("Verifying episode screen layout")
        self.verify_screen_title(title)
        self.verify_primary_branding_icon()
        self.verify_biaxial_screen()
        self.verify_menu(tester)
        self.verify_entitlement_status()

    def verify_my_adult_rentals(self, tester):
        self.wait_for_screen_ready()
        self.screen.refresh()
        assert_that(self.screen_title(), equal_to_ignoring_case(tester.vod_labels.LBL_MY_ADULT_RENTALS), "Screen title Wrong")
        assert_that(self.get_menu_item(), not_none(), "Rental list empty")

    def verify_menu(self, tester):
        self.log.info("Verifying menu list in current screen")
        assert_that(self.menu_list(), has_items(tester.vod_labels.LBL_WATCH_NOW,
                    tester.menu_page.get_more_info_name(tester, vod_labels=True)), "Menu lack of items")

    def verify_entitlement_status(self):
        self.log.info("Verifying Asset entitlement status")
        assert_that(self.get_entitlement_status, not_none(), "No entitlement status exist")

    def validate_series_screen_view(self, tester):
        self.screen.refresh()
        if self.screen.get_screen_dump_item('viewMode') != tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
            assert False, "Not in series screen"
        else:
            self.log.info("Inside the series screen")

    def select_more_info_and_verify(self, tester):
        more_info = tester.menu_page.get_more_info_name(tester, vod_labels=True)
        self.select_menu_item(more_info)
        self.wait_for_screen_ready()
        self.screen.refresh()
        self.verify_view_mode(tester.my_shows_labels.LBL_ACTION_SCREEN_VIEW)

    def verify_preview_pane_entitlement_and_description(self):
        previewpane = self.get_preview_panel()
        if not previewpane['entitlementStatus'] or previewpane['entitlementStatus'] is None:
            assert_that(False, "Either Entilement status is not available or it is empty")

        if not previewpane['description'] or previewpane['description'] is None:
            assert_that(False, "Either description is not available or it is empty")

        assert True

    def verify_collapsed_offers(self, title):
        self.screen.base.press_back(time=5000)
        self.wait_for_screen_ready()
        self.screen.refresh()
        menu = self.menu_focus()
        menu_image = self.menu_item_image_focus()
        if isinstance(menu_image, list):
            menu_image = menu_image[0]
        self.log.info("To handle vod content available in strip/menu item")
        if menu:
            current_focus_index = menu.index(menu)
        elif menu_image:
            current_focus_index = menu_image.index(menu_image)
        else:
            strip = self.strip_focus()
            current_focus_index = strip.index(strip)  # noqa: F821
        self.screen.base.press_right(time=5000)
        self.screen.refresh()
        menu = self.menu_focus()
        menu_image = self.menu_item_image_focus()
        if isinstance(menu_image, list):
            menu_image = menu_image[0]
        if menu:
            right_focus_index = menu.index(menu)
        elif menu_image:
            right_focus_index = menu_image.index(menu_image)
        else:
            strip = self.strip_focus()
            right_focus_index = strip.index(strip)  # noqa: F821
        if right_focus_index == current_focus_index + 1:
            self.log.info("Comparing screen title with the next vod content available in the catalog")
            previewtitle = self.preview_panel()['title']
            program = re.sub('[^A-Za-z]+', '', title)
            program1 = re.sub('[^A-Za-z]+', '', previewtitle)
            if program == program1:
                assert False, "collapsed offers are displayed multiple times"
        assert True

    def validate_not_rentableoverlay(self, tester):
        self.screen.refresh()
        if tester.guide_page.get_overlay_title() == tester.vod_labels.LBL_RENT_NOT_ALLOWED_TITLE:
            assert True
        else:
            assert False

    def verify_episode_list_view(self, tester):
        self.screen.refresh()
        pattern = r"S\d+ E\d+"
        pattern_season = r"S\d+"
        length = 5
        index = 1
        menuitem = self.screen.get_screen_dump_item('menuitem')
        if isinstance(menuitem, dict):
            menuitem = [menuitem]
            if len(menuitem) < 5:
                length = len(menuitem)
            if self.view_mode() == tester.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE:
                index = 2
            for i in range(length):
                if menuitem[i].__contains__('hasfocus'):
                    if not menuitem[i]['text'][0] is None:
                        menu = menuitem[i]['text'][index]
                        if not re.match(pattern, menu) and not re.match(pattern_season, menu):
                            assert False, "Series or Episode pattern does not match"
                    else:
                        assert False, "Menu item returned is None"
                else:
                    if not menuitem[i]['text'][0] is None:
                        menu = menuitem[i]['text'][1]
                        if not re.match(pattern, menu) and not re.match(pattern_season, menu):
                            assert False, "Series or Episode pattern does not match"
                    else:
                        assert False, "Menu item returned is None"
        else:
            pytest.skip("Multiple episode not available to validate episodic guide view screen")

    def verify_vod_browse_gallery_screen(self):
        self.log.step("Verifying Gallery screen view")
        self.screen.refresh()
        if self.view_mode() == self.vod_labels.LBL_GALLERY_SCREEN_VIEW_MODE:
            if self.screen_title() is None:
                assert_that(False, "Screen title is empty or not available")
            self.log.info("Screen title is verified")
            assert_that(self.screen.get_screen_dump_item('columnCount'), 3)
            self.log.info("Gallery preview verified")
            previewpane = self.get_preview_panel()
            if previewpane is None:
                assert_that(False, "Preview Pane is empty or not available")
            self.log.info("PreviewPane is verified")
            pig = self.screen.get_screen_dump_item('videowindow')
            if "visible" not in pig.keys():
                assert False, "Video window unavailable."
            self.log.info("Video Window is verified")
            self.verify_primary_branding_icon()
            self.log.info("Branding Icon is verified")
        else:
            pytest.skip("Test is skipped because gallery screen is not available for the fetched VOD asset")

    def verify_vod_main_screen(self, tester):
        self.log.step("Verifying VOD Main Screen")
        self.screen.refresh()
        tester.vod_assertions.verify_screen_title(tester.home_labels.LBL_ONDEMAND_SCREENTITLE)
        self.log.info("Screen title is verified")
        self.verify_primary_branding_icon()
        self.log.info("Branding Icon is verified")
        do_not_traverse_list = [tester.vod_labels.LBL_MY_RENTALS, tester.vod_labels.LBL_MY_ADULT_RENTALS,
                                tester.vod_labels.LBL_MY_ADULT_ON_DEMAND, tester.vod_labels.LBL_ADULT,
                                tester.vod_labels.LBL_MY_ON_DEMAND, tester.vod_labels.LBL_MY_VIDEOS,
                                tester.vod_labels.LBL_MY_ADULT_VIDEOS]
        vod_screen_menus = self.menu_list()
        self.log.info(f'vod_screen_menus: {vod_screen_menus}')
        traverse_list = [value for value in vod_screen_menus if value not in do_not_traverse_list]
        for item in traverse_list:
            self.screen.refresh()
            menu = self.menu_focus()
            self.log.info('focused Menu:{}'.format(menu))
            self.nav_to_menu(item)
            found = self.validate_preview_pane()
            if found:
                self.log.info("Preview Pane is verified")
                return

    def verify_preview_pane(self):
        self.screen.refresh()
        dump = self.screen.get_screen_dump_item()
        if 'previewPane' in dump.keys():
            previewpane = self.get_preview_panel()
        else:
            previewpane = None
        return previewpane

    def validate_preview_pane(self):
        found = False
        index = 1
        for i in range(12):
            self.screen.refresh()
            strip_items = self.screen.get_screen_dump_item('stripitem')
            self.log.info("strip items :{}".format(strip_items))
            if len(strip_items) < 4:
                index = 0
            if strip_items[index].__contains__('text') and self.vod_labels.LBL_VIEW_ALL in strip_items[index]['text'] \
                    and strip_items[index].__contains__('hasfocus'):
                self.log.info("Reached 'VIEW ALL' tile")
                break
            previewpane = self.verify_preview_pane()
            if previewpane is not None:
                found = True
            else:
                self.screen.base.press_right()
            return found

    def assert_graceful_end_overlay(self, tester):
        self.screen.refresh()
        dump = self.screen.screen_dump['xml']
        if not dump.__contains__('overlayTitle'):
            raise AssertionError("Failed to launch graceful end overlay")
        if dump['overlayTitle'] != self.vod_labels.LBL_GRACEFUL_END_OVERLAY_TITLE and \
                dump['bodytext'] != self.vod_labels.LBL_GRACEFUL_END_OVERLAY_BODY_TEXT:
            raise AssertionError("Either overlay is not displayed or Overlay displayed is incorrect")
        menu = self.menu_list()
        if self.vod_labels.LBL_GRACEFUL_END_MENU_1 not in menu and self.vod_labels.LBL_GRACEFUL_END_MENU_2 not in menu:
            raise AssertionError("One of the menuitems is missing from the Gracefulend overlay")

    def verify_view_mode_check(self, viewmode):
        if viewmode == self.vod_labels.LBL_BIAXIAL_SCREEN_VIEW_MODE or \
                viewmode == self.vod_labels.LBL_GALLERY_SCREEN_VIEW_MODE:
            assert True
        else:
            assert False

    def validate_jump_forward(self, intialsec, currentsec, second):
        self.log.step("Verifying the jump forward")
        expectedjump = intialsec + second
        if currentsec in range(expectedjump, expectedjump + 60):
            self.log.info("Jump forward succeeded")
            return
        else:
            assert_that(False, "Jump forward failed")

    def verify_advance_blocked_when_ff_restricted(self):
        self.wait_for_screen_ready()
        self.screen.refresh()
        playerinfo = self.screen.get_screen_dump_item('playerinfo')
        if 'text' in playerinfo.keys():
            infolist = playerinfo['text']
            if self.vod_labels.LBL_ADVANCE_BLOCKED in infolist:
                self.log.step("Verified that " + self.vod_labels.LBL_ADVANCE_BLOCKED)
            else:
                assert False, "Couldn't verify that ADVANCE is blocked"
        else:
            assert False, "Couldn't fetch playerinfo"

    def verify_scroll_8seconds_backward(self, initialsec, currentsec):
        self.log.step("Verifying '-8s' button scrolls 8 seconds backward")
        assert_that(initialsec - currentsec, less_than_or_equal_to(8) and greater_than_or_equal_to(0),
                    "'-8s' button didn't scroll 8 seconds backward")

    def verify_startover_of_the_video(self, current_pos):
        self.log.step("Verifying that current trickplay position is 30 seconds or less before end of video")
        trickplay = self.screen.get_screen_dump_item('trick-play', 'replay-start')
        startpos = self.convert_time_to_sec(trickplay)
        assert_that(current_pos - startpos, less_than_or_equal_to(15),
                    "'Start Over' button didn't start video from beginning")

    def verify_scroll_30seconds_forward(self, initialsec, currentsec):
        self.log.step("Verifying '+30s' button scrolls 30 seconds forward")
        assert_that(currentsec - initialsec, greater_than_or_equal_to(30) and less_than_or_equal_to(45),
                    "'+30s' button didn't scroll 30 seconds forward")

    def verify_30seconds_to_end_of_video(self, current_pos):
        self.log.step("Verifying that current trickplay position is 30 seconds or less before end of video")
        trickplay = self.screen.get_screen_dump_item('trick-play', 'duration')
        duration = self.convert_time_to_sec(trickplay)
        assert_that(duration - current_pos, less_than_or_equal_to(30),
                    "'Go to End' button didn't navigate to the end of video")

    def verify_scroll_forward(self, initialsec, currentsec, skipspeed):
        self.log.step("Verifying scrolls forward")
        self.log.info("initialsec: {}, currentsec{}, skipspeed{}".format(initialsec, currentsec, skipspeed))
        expectedskipspeed = initialsec + skipspeed
        if currentsec > expectedskipspeed:
            self.log.info("Trickplay forward scroll validation succeed")
            return
        else:
            assert_that(False, "Failed to validate Trickplay forward scroll")

    def verify_scroll_backward(self, initialsec, currentsec, skipspeed):
        self.log.step("Verifying scrolls backward")
        self.log.info("initialsec: {}, currentsec{}, skipspeed{}".format(initialsec, currentsec, skipspeed))
        expectedskipspeed = currentsec + skipspeed
        if expectedskipspeed < initialsec:
            self.log.info("Trickplay rewind scroll backward validation succeed")
            return
        else:
            assert_that(False, "Failed to validate Trickplay rewind scroll backward")

    def verify_video_blanking_status(self, state):
        self.log.step("Verifying video blanking status")
        status = self.wait_for_video_blanking(state)
        if status:
            return True
        else:
            raise AssertionError("Video window is not on mute")

    def get_vod_menu_contents(self):
        full_array = []
        previous_list = []
        for i in range(5):
            self.screen.refresh()
            menu_array = self.menu_list()
            menu_list_length = len(menu_array)
            self.log.info("menu_list_length {}".format(menu_list_length))
            self.log.info("menu_list_items {}".format(menu_array))
            self.log.info("previous_list contents {}".format(previous_list))
            if i != 0:
                self.log.info("previous_list last element{}".format(previous_list[-1]))
                self.log.info("menu array last element {}".format(menu_array[-1]))
                if previous_list[-1] == menu_array[-1]:
                    self.log.info("all items are traversed")
                    break
            for item in range(len(menu_array)):
                if menu_array[item] not in full_array:
                    full_array.append(menu_array[item])
            for i in range(menu_list_length):
                self.screen.base.press_down()
            previous_list = menu_array
        return full_array

    def verify_item_in_array(self, array_to_checked, item_to_be_checked):
        self.log.info("inside verify item present")
        for element in range(len(array_to_checked)):
            if array_to_checked[element] in item_to_be_checked:
                assert False, "Adult menu label is found in the vod menu list"

    def verify_play_position(self, value, value1, rewind=True):
        self.log.step("Verifying play position")
        if rewind:
            self.log.step("Verifying play position after rewind")
            if value1 < value:
                self.log.info("play position is changed.")
                return
            else:
                assert_that(False, "play position is not changed")
        else:
            self.log.step("Verifying play position after fastforward")
            if value1 > value:
                self.log.info("play position is changed.")
                return
            else:
                assert_that(False, "play position is not changed")

    def verify_program_name_under_adult_on_demand(self, program_title):
        previewpane = self.get_preview_panel()
        if program_title != previewpane.get('title'):
            assert_that(False, "program title mismatched")

    def verify_vod_series_or_action_screen_view_mode(self):
        self.log.step("Verifying series or action screen view mode")
        self.wait_for_screen_ready()
        self.screen.refresh()
        viewmode = self.view_mode()
        if viewmode == self.vod_labels.LBL_SERIES_SCREEN_VIEW_MODE or self.vod_labels.LBL_ACTIONS_SCREEN:
            self.log.info("In series or action screen view mode: {}".format(viewmode))
        else:
            raise AssertionError("Currently not in the vod series or action screen view mode : {}".format(viewmode))

    def verify_can_not_watch_show_overlay_shown(self):
        self.log.info("Verifying 'can't watch show' overlay.")
        assert_that(self.get_can_not_watch_show_overlay_visibility(),
                    "{} wasn't displayed".format(self.vod_labels.LBL_CAN_NOT_WATCH_OVERLAY_SHOW_TITLE))
        assert_that(self.get_overlay_body_text(),
                    matches_regexp(self.vod_labels.LBL_PLAYBACK_IS_PROHIBITED_OVERLAY_BODY_TEXT))

    def verify_currency_value_on_action_screen(self):
        self.log.info("Verifying Currency is displayed on action screen")
        if not self.get_preview_panel()['entitlementStatus']:
            raise AssertionError("Currency value is not present")

    def verify_currency_value_rental_confirm_overlay(self):
        self.log.info("Verifying currency value on rental confirmation overlay")
        self.select_item()
        currency_value = self.screen.get_screen_dump_item('overlayTitleText')['font']['#text']
        if not currency_value:
            raise AssertionError("Currency value is not present")

    def verify_fallback_to_default_image(self, tester, poster_color, asset_type):
        image = self.get_menu_item()
        if 'hasfocus' in image:
            defaultimage = image['imagename']
            assert_that(defaultimage, contains_string(tester.wtw_labels.LBL_DEFAULT_IMAGE),
                        "default image not displayed")
            if poster_color and asset_type:
                if poster_color == "black" and asset_type == "series":
                    default_poster_black = re.compile('.tv_6.')
                    poster = default_poster_black.search(image['imagename'])
                    assert_that(poster, contains_string(defaultimage), " default poster in black color not displayed")
                if poster_color == "notblack" and asset_type == "series":
                    assert_that(defaultimage, contains_string(tester.wtw_labels.LBL_DEFAULT_IMAGE),
                                "default image not displayed")

    def verify_watched_progress_bar_position_updating_backward_forward(self, position1, position2, is_forward=True):
        """
        This API verifies the watched progress bar position is
        updating forward/backward according to the direction of the show user watches the show.
        Args:
            position1 - position of watched progress bar before playing the show
            position2 - position of watched progress bar after playing the show
            Boolean : is_forward
            True - Watched the show forward
            False - Watched the show backward
        ToDo: Basic testing is done. Need to test E2E flow after feature implementation
        """
        if is_forward:
            assert_that(position2, less_than_or_equal_to(
                position1), "Watched progress bar didn't update forward after watching the show forward")
        else:
            assert_that(position1, less_than_or_equal_to(
                position2), "Watched progress bar didn't update backward after watching the show backward")

    def verify_watched_progress_bar_is_full(self, position):
        """
        This API verifies the watched progress bar is full or not
        Args:
            position - current position of the watched progress bar
        ToDo: Basic testing is done. Need to test E2E flow after feature implementation
        """
        assert_that(position, is_not(100), "Progress bar is not full")

    def verify_watched_progress_bar_is_partial(self, position):
        """
        This API verifies the watched progress bar is partial or not
        Args:
            position - current position of the watched progress bar
        ToDo: Basic testing is done. Need to test E2E flow after feature implementation
        """
        assert_that(position, is_not(is_in(range(1, 99))), "Progress bar is not partial")
