class AccountLockedLabels:

    # Account Locked overlay elements
    LBL_EXIT_HYDRA_APP = "Exit CableCo11 App"
