import re
import time
import shutil
import os.path
import subprocess
import datetime as dt
from pathlib import Path

from core_api.stb.assertions import CoreAssertions

from fuzzywuzzy import fuzz

from hamcrest import assert_that, equal_to, greater_than_or_equal_to

import imutils

from set_top_box.client_api.vision_tester.locators import VTtweaks
from set_top_box.test_settings import Settings

from tools.clients.HLSLoader.hls import HLSLoader
from tools.clients.Splunk.splunk_client import SplunkClient
from tools.keychain import UTAFKeychain
from tools.logger.logger import Logger, PerfLogger
from tools.video_handler.hw_interface import FileVideoIf
from tools.video_qualty.vqat import VideoQAT

from vision_tester import VisionTester


class VisionTesterPage(CoreAssertions):
    locators = VTtweaks()

    def __init__(self, screen, vision: VisionTester):
        super().__init__(screen)
        self.__vision = vision
        self.__log = Logger(__name__)
        self.logger = PerfLogger(Settings)
        self.logger.run_name = self.get_current_tc_name()
        self.__vqat = VideoQAT()
        self.__hlstool = HLSLoader()

    def verify_av_playback(self, expected=True, timeout=40, status=None, result=None, url=None, audio_check=True):
        self.log.info("Verifying video state")
        cur_state = self.__vision.wait_for_motion(region=self.locators.LIVE_TV_PLAYBACK_REGION, timeout=timeout)
        self.__log.debug("Playback state is: {}".format(cur_state))
        details = {"status": status, "result": result, "url": url}
        assert_details = "Expected playback: {}, but actual {}".format(expected, cur_state)
        for key, value in details.items():
            if value:
                assert_details += "\n{}: {}".format(key, value)
        assert bool(cur_state) is expected, assert_details
        if Settings.vt_audio_device != "disabled" and audio_check:
            self.log.info("Verifying audio state")
            self.verify_audio_state(expected=expected, time_to_verify=20)

    def prepare_videos_full_reference_video_quality_score(self,
                                                          channel_details,
                                                          time_offset: int = None,
                                                          duration: int = 30,
                                                          quality: str = "fullhd"
                                                          ):
        """
        Prepare reference video and captured (distorted) from device (VMAF)

        Args:
            channel_details: ChannelInfo, channel name, stream_url, drm_type, media_format
            duration: int, target duration of the video, by default = 30
            time_offset: int, offset time in seconds to record video segments, by default = -50
            quality: str, quality of the reference video

        Returns:
            dict, reference and distorted video files
        """
        tc_name = os.environ.get('PYTEST_CURRENT_TEST', "video_quality_score").split(':')[-1].split(' ')[0]
        ref_video_path = f"{tc_name}_VQT_ref_{time.strftime('%d%m%Y%H%M%S')}.mp4"
        dist_video_path = f"{tc_name}_VQT_dist_{time.strftime('%d%m%Y%H%M%S')}.mp4"
        ref_recorded_video_path = os.path.join(Settings.log_path, ref_video_path)
        dist_recorded_video_path = os.path.join(Settings.log_path, dist_video_path)
        record_dir = self.__hlstool.download(
            Settings.log_path, channel_details.streaming_url, channel_details.channel,
            channel_details.drm_type, channel_details.media_format, duration, time_offset=time_offset)
        self.__vision.record_device_video(location=dist_recorded_video_path, duration=duration, )
        time.sleep(60)
        ref_recorded_video_path = self.__hlstool.get_mp4(record_dir, ref_recorded_video_path, quality=quality)
        assert os.path.isfile(ref_recorded_video_path), f"Reference video '{ref_recorded_video_path}' doesn't exists."
        assert os.path.isfile(dist_recorded_video_path), f"Distorted video '{dist_recorded_video_path}' doesn't exists."
        path_to_videos = {"reference": ref_recorded_video_path,
                          "distorted": dist_recorded_video_path}
        return path_to_videos

    def prepare_videos_full_reference_vqa_m3u8(self,
                                               m3u8_src,
                                               duration: int = 30,
                                               ):
        """
        Prepare reference video and captured (distorted) from device (VMAF)

        Args:
            m3u8_src: str, url to download reference video directly. (yukon f.e.)
            duration: int, target duration of the video, by default = 30

        Returns:
            dict, reference and distorted video files
        """
        tc_name = os.environ.get('PYTEST_CURRENT_TEST', "video_quality_score").split(':')[-1].split(' ')[0]
        ref_video_path = f"{tc_name}_VQT_ref_{time.strftime('%d%m%Y%H%M%S')}.mp4"
        dist_video_path = f"{tc_name}_VQT_dist_{time.strftime('%d%m%Y%H%M%S')}.mp4"
        ref_recorded_video_path = os.path.join(Settings.log_path, ref_video_path)
        dist_recorded_video_path = os.path.join(Settings.log_path, dist_video_path)
        self.__vision.record_device_video(location=dist_recorded_video_path, duration=duration, )
        time.sleep(60)
        self.__hlstool.direct_download(ref_recorded_video_path, m3u8_src)
        assert os.path.isfile(ref_recorded_video_path), f"Reference video '{ref_recorded_video_path}' doesn't exists."
        assert os.path.isfile(dist_recorded_video_path), f"Distorted video '{dist_recorded_video_path}' doesn't exists."
        path_to_videos = {"reference": ref_recorded_video_path,
                          "distorted": dist_recorded_video_path}
        return path_to_videos

    def get_full_reference_video_quality_score(self, path_to_video: dict, sync_window: int = 20,
                                               model_type: str = 'HD'):
        """
        Get full reference video quality score (VMAF)

        :param path_to_video: path to the reference/distorted videos
        :param sync_window: should be 70% from the duration of the video
        :param model_type: model video quality (HD, 4K)
        :return: dict
        """
        vmaf_result = self.__vqat.full_reference_assessment(path_to_video['reference'], path_to_video['distorted'],
                                                            sync_window=sync_window, model_type=model_type)
        return vmaf_result

    def prepare_videos_non_reference_video_quality_score(self, duration: int):
        """
        Record video from the device (MITSU)

        Args:
            duration: int, target video duration

        Returns:
            str, path to captured video from DUT
        """
        tc_name = self.get_current_tc_name(default="video_quality_score")
        recorded_video_path = os.path.join(Settings.log_path, f"{tc_name}_dutcap.mp4")
        if os.path.isfile(recorded_video_path):
            os.remove(recorded_video_path)
        self.__vision.record_device_video(location=recorded_video_path, duration=duration, )
        assert os.path.isfile(recorded_video_path), f"Recorded video '{recorded_video_path}' doesn't exists."
        return recorded_video_path

    def get_non_reference_video_quality_score(self, recorded_video_path: str):
        """
        Get non reference video quality score (MITSU)

        :param recorded_video_path: str, path to the video
        :return: dict
        """
        report = self.__vqat.non_reference_assessment(recorded_video_path)
        summary_report = report.get("summary")
        if summary_report is None:
            self.__log.error(f"Failed to calculate VQT score. Report:{report}")
        return summary_report

    def get_mixed_video_quality_score(self,
                                      channel_details,
                                      time_offset: int = None,
                                      duration: int = 30,
                                      sync_window: int = 20,
                                      model_type: str = 'HD',
                                      ):
        """
        The method is a wrapper for recording video and evaluating quality with fail-save behaviour.
        By default, Full-reference VQAT works, but in case of failure - non-reference

        Args:
            channel_details: ChannelInfo, channel name, stream_url, drm_type, media_format
            time_offset: int, offset time in seconds to record video segments, by default = -50
            duration: int, duration of video track to be recorded and analyzed
            sync_window: int, should be 70% from the duration of the video. How much time tool will search common point
            model_type: str, model video quality (HD, 4K)

        Returns:
            dict, vqt_score
        """
        mos_threshold = self.locators.MITSU_SCORE_TRHLD
        tc_name = os.environ.get('PYTEST_CURRENT_TEST', "video_quality_score").split(':')[-1].split(' ')[0]
        ref_video_path = f"{tc_name}_VQT_ref_{time.strftime('%d%m%Y%H%M%S')}.mp4"
        dist_video_path = f"{tc_name}_VQT_dist_{time.strftime('%d%m%Y%H%M%S')}.mp4"
        ref_recorded_video_path = os.path.join(Settings.log_path, ref_video_path)
        dist_recorded_video_path = os.path.join(Settings.log_path, dist_video_path)
        try:
            record_dir = self.__hlstool.download(
                Settings.log_path, channel_details.streaming_url, channel_details.channel,
                channel_details.drm_type, channel_details.media_format, duration, time_offset=time_offset)
        except Exception as err:
            self.__log.warning(f"Unable to capture HLS stream. Error:{err}")
            record_dir = ""
        timestamp = time.strftime('%j-%H:%M:%S')
        self.__vision.record_device_video(location=dist_recorded_video_path, duration=duration, )
        time.sleep(60)  # give time to close hls session
        try:
            ref_recorded_video_path = self.__hlstool.get_mp4(record_dir, ref_recorded_video_path, quality="fullhd")
        except Exception as err:
            ref_recorded_video_path = ""
            self.__log.warning(f"Unable to get mp4 video using HLS. Error:{err}")

        assert os.path.isfile(dist_recorded_video_path), f"Distorted video '{dist_recorded_video_path}' doesn't exists."
        if ref_recorded_video_path:
            path_to_videos = {"reference": ref_recorded_video_path,
                              "distorted": dist_recorded_video_path}
            try:
                vqt_score = self.get_full_reference_video_quality_score(path_to_videos, sync_window, model_type)
            except AssertionError:
                self.__log.debug("Executing fallback behavior, running non reference video quality score.")
                vqt_score = self.get_non_reference_video_quality_score(dist_recorded_video_path)
        else:
            report = dict()
            vqt_score = self.get_non_reference_video_quality_score(dist_recorded_video_path)
            mos = vqt_score.get('vqt_score')
            if mos <= mos_threshold:
                # save video trace in case of failure
                video_artifact = dist_recorded_video_path.replace(".mp4", f"_trace_{timestamp}_{int(mos)}.mp4")
                self.__log.debug(f"{timestamp} video has issues. MOS:{mos}<={mos_threshold}"
                                 f"Trace: {Path(video_artifact).name}")
                shutil.move(dist_recorded_video_path, video_artifact)
                report.update(self.__get_video_trace_url(video_artifact))
            else:
                os.remove(dist_recorded_video_path)
            report.update(vqt_score)
            self.__send_to_splunk(report, mos, dist_recorded_video_path, timestamp)
        return vqt_score

    def verify_video_quality_score(self, summary_score: dict, **kwargs):
        """
        Verify vqt score by threshold value
        :param kwargs: video quality tool algorithm
        :param summary_score: video quality tool score
        :return:
        """
        if summary_score.get("vmaf_4k") or summary_score.get("vmaf_hd"):
            vqt_type = "VMAF"
            score = summary_score.get("vmaf_hd", {}) or summary_score.get("vmaf_4k", {})
            score = score.get('mean')
            threshold = self.locators.VMAF_SCORE_TRHLD
            if score <= threshold:
                self.create_vqt_report_in_logs(summary_score, vqt_type)
        else:
            vqt_type = "MITSU"
            score = summary_score.get('vqt_score')
            threshold = self.locators.MITSU_SCORE_TRHLD
            if score <= threshold:
                self.create_vqt_report_in_logs(summary_score, vqt_type)
        assert_that(score, greater_than_or_equal_to(threshold),
                    f"Expected VQT score : {threshold} or greater, but actual {summary_score}")

    def live_stream_video_assessment(self,
                                     vqat_session_duration=3600,
                                     test_chunk_duration=15,
                                     probation_period=None,
                                     mos_threshold=None,
                                     stop_on_low_score=False,
                                     ext_assertion_func=None,
                                     ext_assertion_args: tuple = None,
                                     ext_assertion_fail=True,
                                     video_availability_check=True,
                                     audio_availability_check=True,
                                     av_check_fail=False,
                                     **kwargs
                                     ):
        """
        Method for continues monitoring of video stream and send data to Splunk or(and) Assert
        Supported features:
            - Video quality KPIs (Non-reference assessment based on MITSU)
            - Audio/Video availability
            - Any other external check (XML dump based or other)

        Workflow:
            the analysis is performed in a loop. Loop duration and probation period are defined by input parameters.
            Every iteration are preformed 1 quality check, 1 AV check and 1 external check.
            If stop is allowed then in case of low VQ MOS or ext check then tests interrupts else only data is pushing

        Args:
            vqat_session_duration: int, duration of analysis session in seconds
            test_chunk_duration: int, duration in seconds of video asset to evaluate VQuality, values more than 60s are
                                dangerous because uses more space and increase processing time.
                                for example 15 sec video is processed during ~1min
            probation_period: int, time between checks in seconds. If video processing time > probation_period then the
                                value is skipping
            mos_threshold: int, minimal level of MOS (0..100). Is using for assertion and saving artifacts
            stop_on_low_score: bool, enable/disable MOS assertion
            ext_assertion_func: link, external function to preform checks in the main loop
            ext_assertion_args: tuple, tuple of arguments for external check function
            ext_assertion_fail: bool, if True then test execution stops if assertions fails
            video_availability_check: bool, enable/disable video check
            audio_availability_check: bool, enable/disable audio check
            av_check_fail: bool, enable/disable TC failure in case of Audio/Video assertion
            **kwargs:

        Returns:
            None
        """
        if not mos_threshold:
            mos_threshold = self.locators.MITSU_SCORE_TRHLD
        start_timer = time.perf_counter()
        while time.perf_counter() - start_timer < vqat_session_duration:
            report = dict()
            processing_time = time.perf_counter()
            report.update(self.__run_ext_check(ext_assertion_func, ext_assertion_args, ext_assertion_fail))
            report.update(self.__run_video_check(video_availability_check, av_check_fail))
            timestamp = time.strftime('%j-%H:%M:%S')
            captured_video = self.prepare_videos_non_reference_video_quality_score(test_chunk_duration)

            report.update(self.__run_audio_check(audio_availability_check, av_check_fail, captured_video))
            vqat_score = self.get_non_reference_video_quality_score(captured_video)
            mos = vqat_score.get('vqt_score') or vqat_score.get('mean')
            all_checks_result_succeeded = all((report.get('audio_check', True),
                                               report.get('video_check', True),
                                               report.get('video_check', True),
                                               report.get('ext_check', {}).get('passed', True)
                                               ))
            if mos <= mos_threshold or not all_checks_result_succeeded:
                # save video trace in case of failure
                video_artifact = captured_video.replace(".mp4", f"_trace_{timestamp}_{int(mos)}.mp4")
                self.__log.debug(f"{timestamp} video has issues. MOS:{mos}<={mos_threshold}"
                                 f"Checks: {all_checks_result_succeeded},"
                                 f"Trace: {Path(video_artifact).name}")
                shutil.move(captured_video, video_artifact)
                report.update(self.__get_video_trace_url(video_artifact))
            else:
                os.remove(captured_video)
            report.update(vqat_score)
            self.__send_to_splunk(report, mos, captured_video, timestamp)
            if stop_on_low_score:
                assert_that(vqat_score, greater_than_or_equal_to(mos_threshold), "VQAT score failure")
            if probation_period and probation_period > processing_time:
                self.pause(probation_period - processing_time, reason="Maintain VQAT frequency")

    def __get_video_trace_url(self, src):
        """
        convert file path to jenkins artifact URL and add to report
        Args:
            src: str, file path to convert

        Returns:
            dict
        """
        root_artifacts = Path(Settings.root_log_path or Settings.log_path)
        video_trace_file = Path(src).relative_to(root_artifacts)
        report = {'v_trace': f"artifact/artifact/{video_trace_file}"}
        return report

    def __run_ext_check(self, ext_func, arguments, ext_assertion_fail) -> dict:
        """
        function-satellite for live_stream_video_assessment
        Args:
            ext_func: link
            arguments: tuple of arguments - optional
            ext_assertion_fail: bool

        Returns:
            dict, report
        """
        if not ext_func:
            return {}
        self.__log.info("Video analysis is extended by external check: {}".format(ext_func))
        args = arguments or []
        report = {"ext_check": {"passed": True}}
        if ext_assertion_fail:
            ext_func(*args)
        else:
            try:
                ext_func(*args)
            except Exception as err:
                report['ext_check'] = {"passed": False,
                                       "error": err,
                                       "ext_func_name": f"{ext_func}"
                                       }
        return report

    def __run_video_check(self, av_check_enabled=True, fail_allowed=False):
        """
        function-satellite for live_stream_video_assessment
        Returns:
            dict, report
        """
        if not av_check_enabled:
            return {}
        if fail_allowed:
            self.verify_av_playback(audio_check=False)
            report = {"video_check": True}
        else:
            try:
                self.verify_av_playback(audio_check=False)
                report = {"video_check": True}
            except Exception as err:
                report = {"video_check": False}
                self.__log.info(f"Video check failed with error: {err}")
        return report

    def __run_audio_check(self, audio_availability_check=True, fail_allowed=False, captured_mp4=None):
        """
        function-satellite for live_stream_video_assessment
        Returns:
            dict, report
        """
        if not audio_availability_check:
            # No audio check is required
            return {}
        if fail_allowed:
            self.verify_audio_state(from_file=captured_mp4)
            report = {"audio_check": True}
        else:
            try:
                cur_state = self.__vision.is_audio_playing(8, from_file=captured_mp4)
            except TypeError as err:
                self.__log.debug(f"Unable to analyze audio. Err: {err}")
                cur_state = None
            self.__log.debug("Audio state is: {}".format(cur_state))
            report = {"audio_check": cur_state}
        return report

    def __send_to_splunk(self, report, mos, video_for_testing, timestamp):
        """
        function-satellite for live_stream_video_assessment
        Args:
            report: dict, data to push to splunk
            mos: MOS score for logging
            video_for_testing: str, path of evaluated file
            timestamp: str, time when file created

        Returns:
            None
        """
        vqat_splunk_client = SplunkClient(uri=Settings.splunk_hec_url,
                                          token=UTAFKeychain("UTAFSplunkToken"),
                                          source="vqat"
                                          )
        try:
            self.__log.info(f"VQAT score={mos}, file={os.path.basename(video_for_testing)} timestamp={timestamp}")
            tc_name = os.environ.get('PYTEST_CURRENT_TEST', "video_quality_score").split(':')[-1].split(' ')[0]
            data = {"JENKINS_URL": os.getenv("BUILD_URL"), "TC_Name": tc_name, "timestamp": timestamp}
            data.update(report)
            vqat_splunk_client.send_events(data)
        except Exception as err:
            self.__log.info("Failed to sent event to splunk with error: {}".format(err))

    def verify_frame_resolution(self, expected_height=2160, expected_width=3840):
        frame = self.__vision.get_frame()
        height, width = frame.shape[:2]
        assert_that((width, height), equal_to((expected_width, expected_height)))

    def verify_pig_video_playback(self, expected=True):
        """
        Method verifies if there is a video motion on screen in specified `PIG` area on GUIDE page
        """
        curr_state = self.__vision.wait_for_motion(region=self.locators.PIG_PLAYBACK_REGION)
        self.__log.debug(f"Playback state is: {curr_state}")
        assert bool(curr_state) is expected, f"Expected playback: {expected}, but actual is {curr_state}"

    def verify_low_contrast_playback(self, timeout=10, level=3, expected=True):
        curr_state = self.__vision.is_motion(timeout=timeout, level=level)
        self.__log.info(f'Playback state is: {curr_state}')
        assert bool(curr_state) is expected, f"Expected playback: {expected}, but actual is {curr_state}"

    def verify_video_playbak_in_area(self, area, expected=True, timeout=40):
        curr_state = self.__vision.wait_for_motion(region=area, timeout=timeout)
        self.__log.debug(f"Playback state is: {curr_state}")
        assert bool(curr_state) is expected, f"Expected playback: {expected}, but actual is {curr_state}"

    def verify_audio_state(self, expected=True, time_to_verify=8, from_file: str = None):
        if "blackmagic" in Settings.vt_hardware:
            self.__vision.close_session()
            self.pause(2)
        cur_state = self.__vision.is_audio_playing(time_to_verify, from_file=from_file)
        if "blackmagic" in Settings.vt_hardware:
            self.__vision.setup_session()
            self.pause(1)
        self.__log.debug("Audio state is: {}".format(cur_state))
        assert bool(cur_state) is expected, "Expected audio: {}, but actual {}".format(expected, cur_state)

    def verify_screen_is_black(self, expected=True):
        cur_state = self.__vision.is_screen_black(threshold=self.locators.LIVE_TV_BLK_TRHLD)
        self.__log.debug("Video state is: {}".format(cur_state))
        assert bool(cur_state) is expected, "Expected black screen: {}, but actual {}".format(expected, cur_state)

    def verify_playback_area_is_black(self, expected=True):
        cur_state = self.__vision.is_screen_black(threshold=self.locators.LIVE_TV_BLK_TRHLD,
                                                  region=self.locators.LIVE_TV_PLAYBACK_REGION)
        self.__log.debug("Video state is: {}".format(cur_state))
        assert bool(cur_state) is expected, "Expected black screen in playback area: {}, " \
                                            "but actual {}".format(expected, cur_state)

    def verify_cc_visible(self, expected=True):
        text_on_screen = self.__vision.get_text_from_screen(ocr_engine="stbt")
        assert bool(text_on_screen) is expected, "Expected CC state: {}, but actual {}".format(expected, text_on_screen)

    def verify_screen_contains_text(self, expected_text: str, region=None, lang='eng', similarity_threshold=90,
                                    frame=None):
        self.__log.info(f"Verifying if screen contains text: {expected_text} in region: {region}")
        if frame is None:
            frame = self.__vision.get_frame()
        text_similarity = 0
        for filter in [None, 'CLAHE', 'BW']:
            text_from_img = self.__vision.get_text_from_screen(frame, region, preprocessing=filter, lang=lang)
            if expected_text.upper() in text_from_img.upper():
                text_similarity = 100
            else:
                text_similarity = fuzz.partial_ratio(expected_text.lower(), text_from_img.lower())
            self.__log.debug(f"Found similarity with filter '{filter}' =  {text_similarity}")
            if text_similarity >= similarity_threshold:
                break
        else:
            tc_name = os.environ.get('PYTEST_CURRENT_TEST').split(':')[-1].split(' ')[0]
            timestamp = dt.datetime.now().strftime("%Y%m%d_%H_%M_%S")
            file_name = f"{Settings.log_path}/FAILURE_OCR_{tc_name}_{timestamp}.png"
            self.__vision.dump_png(frame, file_name)
            raise Exception(f"Expected text '{expected_text}' was not found in current screen: {file_name}")

    def verify_screen_contains_text_by_color(self, pattern: str, color: tuple, lang: str):
        text = self.__vision.get_text_from_screen(lang=lang, color=color, text_color_threshold=30)
        similarity_score = fuzz.partial_ratio(pattern, text)
        assert similarity_score > 90, f"Expected {pattern} is not on screen text: {text}, ratio is - {similarity_score}"

    def verify_eas_full_screen(self, *colors, threshold_filling=0.9):
        perimeter = 0
        frame = self.__vision.get_frame()
        mask = self.__vision.get_frames_mask_by_color(frame, *colors)
        contours, hierarchy = self.__vision.get_contours_by_mask(mask)
        for i in range(len(contours)):  # get perimeter of the red screen
            contour_perimeter = self.__vision.get_area_square(contours[i])
            if contour_perimeter > perimeter:
                perimeter = contour_perimeter
        frames_perimeter = self.__vision.get_frames_area_square(frame)
        self.__log.debug(f"Contour perimeter: {perimeter}. Frame perimeter: {frames_perimeter}.")
        assert perimeter / frames_perimeter > threshold_filling, "Unexpectedly canadian EAS message covers < 90% of screen"

    def verify_eas_upper_part_of_screen(self, pattern: str):
        time.sleep(2)
        text_on_screen = self.__vision.get_text_from_screen(ocr_engine="stbt", region=self.locators.EAS_US_REGION)
        assert pattern.upper() in text_on_screen.upper(), \
            f"Expected `{pattern}` is not on screen text: {text_on_screen}"

    def verify_eas_bottom_part_of_screen(self, eas_text, presented_on_screen=True):
        time.sleep(2)
        text_on_screen = self.__vision.get_text_from_screen(region=self.locators.EAS_FLOAT)
        self.__log.info(f"Text founded by vision tester: '{text_on_screen}'")
        if presented_on_screen:
            assert eas_text.upper() in text_on_screen.upper(), \
                "Expected founded text: {} to be part of eas message text: {}".format(text_on_screen, eas_text)
        else:
            assert text_on_screen.upper() != eas_text.upper(), \
                "Expected founded text: {} is not a part of eas message text: {}".format(text_on_screen, eas_text)

    def is_text_crawls_left(self, text, iterations=3):
        positions = []
        self.__log.info(f'Start text position localise for {text}')
        for _ in range(iterations):
            start_position, whole_recognition = self.__vision.get_text_position(pattern=text, timeout=25)
            self.__log.info(f'Current text position is {start_position}')
            self.__log.info(f'Whole capture is {whole_recognition}')
            positions.append(start_position)
            self.pause(1.2)

        for iteration in range(iterations - 1):
            assert positions[iteration] > positions[iteration + 1], \
                f"Unexpectedly did not found text crawling. Actual state of coordinates list is: {positions}"

    def match_template(self, template, matching_score=0.5, timeout=40, resize=None, **kwargs):
        matching = 0
        curr_frame = self.__vision.get_frame()
        template = self.__vision.convert_to_gray(self.__vision.image_open(template))

        if resize:
            template = self.__vision.adjust_image_size_(template, size=resize)
        if 'mp4' not in self.__vision.config.source_pipeline:
            curr_frame = self.__vision.convert_to_gray(curr_frame)
            matching = self.__vision.match_image_template(curr_frame, template)
        elif 'mp4' in self.__vision.config.source_pipeline:
            start = time.time()
            while time.time() < start + timeout:
                for frame in curr_frame:
                    frame = self.__vision.convert_to_gray(frame)
                    if kwargs.get('rotate', None):
                        frame = imutils.rotate(frame, kwargs.get('rotate'))
                    matching = self.__vision.match_image_template(frame, template)
                    if matching[1] > matching_score:
                        break
                break
        assert matching[1] > matching_score, f'Matching score is lower than expected: actual - {matching[1]}, ' \
                                             f'expected {matching_score}'
        return matching

    def match_bootup_logo(self, template, level=0.8, timeout=60):
        score = self.__vision.match_in_motion(self.__vision.image_open(template), level=level, timeout=timeout)
        assert score > level, f"Current - {score} score of matching an image is less than expected - {level}"

    def verify_carousel_images_moves(self, start_pos, finish_pos):
        assert start_pos < finish_pos, f'Expected start position to be lower than finish position: ' \
                                       f'start is {start_pos}, finish position is {finish_pos}'

    def recognize_speech(self, duration=10, lang='en-US'):
        return self.__vision.speech_recognize(duration=duration, lang=lang)

    def verify_transition(self, expected=True, region=None, timeout=4, stable=2):
        result = self.__vision.wait_for_transition_to_end(region=region, timeout=timeout, stable=stable)
        if result.animation_duration and result.animation_duration != 0:
            self.logger.perf_log("animation_duration_vt", "{:.4f}".format(result.animation_duration))
        assert_that(bool(result) is expected, "Expected transition state: {}, but actual {}".format(expected, result))
        return result

    def get_screen_text(self):
        time.sleep(10)
        text_on_screen = self.__vision.get_text_from_screen(ocr_engine="pytesseract")
        self.log.info("Printing current screen text on the screen {}".format(text_on_screen))
        return text_on_screen

    def verify_playback_status_after_returning_from_other_apps(self):
        self.__log.info("Verifying playback status after returning from other apps")
        cur_state = self.__vision.wait_for_motion(region=self.locators.LIVE_TV_PLAYBACK_REGION, timeout=40)
        self.log.info("Current status of playback {}".format(cur_state))
        if not cur_state:
            self.__log.info("Pressing Enter to play if video is paused")
            self.screen.base.press_enter()
            time.sleep(5)
            self.verify_av_playback()
        else:
            self.verify_av_playback()

    def get_motion_detection_sensitivity(self, sensitivity_level):
        """ Get consecutive_frames value from the sensitivity_level value """
        SENSITIVITY_LEVEL_LIST = {
            6: "5/60",
            5: "15/60",
            4: "25/60",
            3: "35/60",
            2: "45/60",
            1: "55/60",
        }
        if sensitivity_level not in SENSITIVITY_LEVEL_LIST:
            raise ValueError(f"Wrong sensitivity_level value - {sensitivity_level}."
                             f"Please, choose value between 1 (low sensitivity) and 6 (high sensitivity).")
        consecutive_frames = SENSITIVITY_LEVEL_LIST.get(sensitivity_level)
        self.__log.info(f"Current motion detection sensitivity level is {sensitivity_level}."
                        f"consecutive_frames - {consecutive_frames}")
        return consecutive_frames

    def measure_playback_starting(self, region=None, timeout=20, black_screen_expected=True,
                                  noise_threshold=1, **kwargs):
        """
        Get playback starting duration
        @param region: Region, Only analyse the specified region of the video frame.
        @param timeout: wait until playback starts in seconds
        @param black_screen_expected: bool,
                True - If during opening playback animation black screen is expected.
                       It can be the first opening of a channel/program or a change of channel/program;
                False - If during opening playback animation black screen is not expected. This could be re-opening
                       a playback that was recently opened and plays in background, in this case the play opens quickly.
        @param noise_threshold: float, 0..1 (default is on 0.84), changed to 1 so it will not ignore any different pixel.
        @param sensitivity_level: int, a value from 1 to 6. Where 1 - low sensitivity and 6 - high sensitivity
        @return:
        duration: float or tuple,
            if float - time_to_playback: flaat, duration from first motion to playback;
            if tuple - time_to_black_screen: float, duration from first motion to black screen frame.
                       time_to_playback: flaat, duration from black screen frame to playback.
        """
        sensitivity_level = kwargs.get("sensitivity_level", 2)
        # Convert sensitivity_level to consecutive_frames
        consecutive_frames = self.get_motion_detection_sensitivity(sensitivity_level)
        # Measure playback starting duration
        duration = self.__vision.get_playback_performance_measure(
            region, timeout, consecutive_frames, black_screen_expected, threshold=noise_threshold)
        if isinstance(duration, float):
            self.logger.perf_log("animation_duration_vt", "{:.4f}".format(duration))
        elif isinstance(duration, tuple):
            self.logger.perf_log("animation_duration_vt_first_motion_to_black_screen", "{:.4f}".format(duration[0]))
            self.logger.perf_log("animation_duration_vt_black_screen_to_playback", "{:.4f}".format(duration[1]))

    def get_current_frame(self):
        return self.__vision.get_frame()

    def check_audio_starting_point(self, audio_file, segmentation=10, loudness_threshold=10):
        """
        param audio_file: audio file to check audio starting point
        param segmentation: number of audio segments per second
        :return: second (float) where audio was first detected
        """
        from mosqito.utils import load as mosq_load
        from mosqito.sq_metrics import loudness_zwst_perseg
        import numpy as np

        sig, fs = mosq_load(audio_file, wav_calib=2 * 2 ** 0.5)
        nr_seg = int(fs / segmentation)
        nr_over = int(fs / (segmentation * 4))
        # calculate loudness per segment
        loudness_segments, *__ = loudness_zwst_perseg(sig, fs, nperseg=nr_seg, noverlap=nr_over)
        # where function returns ([indexes], data_type), we want the first index where loudness is > threshold
        loudness_detected = np.where(loudness_segments > loudness_threshold)[0][0]
        loudness_point_in_seconds = loudness_detected / nr_over
        self.__log.debug(f'For file {audio_file}, audio detected at second {loudness_point_in_seconds}')
        return loudness_point_in_seconds

    def check_for_playback_freeze(self, timeout, consecutive_frames=20):
        """
        Method to check for playback freezes
        :param timeout: time in seconds to check for freezes
        :param consecutive_frames: define freeze as a number of consecutive static frames
        :return:
        """
        self.__vision.detect_freeze(timeout=timeout, region=self.locators.LIVE_TV_PLAYBACK_REGION,
                                    consecutive_frames=consecutive_frames)

    def check_and_dismiss_pair_remote_overlay(self):
        screen_info = self.get_screen_text()
        if "remote" in screen_info and "simultaneously" in screen_info and "Fire TV" not in screen_info:
            self.log.info("Handling remote control overlay. Press exit button.")
            self.screen.base.press_exit_button()
        elif "remote" in screen_info:
            self.log.info("Handling remote control overlay. Press enter button.")
            self.screen.base.press_exit_button()

    def create_vqt_report_in_logs(self, summary_score: dict, vqt_type: str):
        if vqt_type == "VMAF":
            threshold = self.locators.VMAF_SCORE_TRHLD
            score = summary_score.get("vmaf_hd", {}) or summary_score.get("vmaf_4k", {})
            score = score.get('mean')
            error_details = f"Expected VMAF video quality score - {threshold} or greater, " \
                            f"but actual score is {score:.1f}."
            if summary_score.get("video_anomaly_time"):
                video_anomaly_time = summary_score.get("video_anomaly_time")
                for metric, anomaly_time in video_anomaly_time.items():
                    error_details += f"\nExpected '{metric}' mean value greater than 0.95 but get " \
                                     f"{summary_score.get(metric).get('min')} at {anomaly_time} second(s)."
        elif vqt_type == "MITSU":
            # Get thresholds.
            threshold = self.locators.MITSU_SCORE_TRHLD
            expected_blur = self.locators.MITSU_BLUR_TRHLD
            expected_noise = self.locators.MITSU_NOISE_TRHLD
            expected_blockloss = self.locators.MITSU_BLOCKLOSS_TRHLD
            expected_blockiness = self.locators.MITSU_BLOCKINESS_TRHLD
            # Get actual results.
            try:
                score = summary_score.get('vqt_score')
                actual_blur = summary_score.get('blur').get("max")
                actual_noise = summary_score.get('noise').get("max")
                actual_blockloss = summary_score.get('blockloss').get("max")
                actual_blockiness = summary_score.get('blockiness').get("min")
            except AttributeError as e:
                raise LookupError(f"{e}.\nsummary_score - {summary_score}")
            # Time of anomaly.
            video_anomaly_time = summary_score.get('video_anomaly_time')
            blur_anomaly_at = video_anomaly_time.get('max_blur')
            noise_anomaly_at = video_anomaly_time.get('max_noise')
            blockloss_anomaly_at = video_anomaly_time.get('max_blockloss')
            blockiness_anomaly_at = video_anomaly_time.get('min_blockiness')
            # Create error message with details if VQT score is low.
            error_details = f"Expected MITSU video quality score - {threshold} or greater, " \
                            f"but actual score is {score:.1f}."
            if (actual_blur > expected_blur) and blur_anomaly_at:
                error_details += f"\nExpected blur is {expected_blur} or lower " \
                                 f"but get {actual_blur} at {blur_anomaly_at:.1f} second(s) of the video."
            if (actual_noise > expected_noise) and noise_anomaly_at:
                error_details += f"\nExpected noise is {expected_noise} or lower " \
                                 f"but get {actual_noise} at {noise_anomaly_at:.1f} second(s) of the video."
            if (actual_blockloss > expected_blockloss) and blockloss_anomaly_at:
                error_details += f"\nExpected blockloss is {expected_blockloss} or lower " \
                                 f"but get {actual_blockloss} at {blockloss_anomaly_at:.1f} second(s) of the  video."
            if (actual_blockiness < expected_blockiness) and blockiness_anomaly_at:
                error_details += f"\nExpected blockiness is {expected_blockiness} or greater " \
                                 f"but get {actual_blockiness} at {blockiness_anomaly_at:.1f} second(s) of the video."
        error_details += "\nCheck confluence page with VQT details: " \
                         "https://confluence.corp.xperi.com/pages/viewpage.action?pageId=525637231 "
        self.__log.error(error_details)

    def background_recording(self, duration: int = 10):
        """
        Record video of the test case in the background for "duration" seconds.

        @param duration: recording duration.
        @return: recording process, recorded_video_path
        """
        self.__log.info("Going to record video in the background")
        tc_name = os.environ.get('PYTEST_CURRENT_TEST', "vt_performance").split(':')[-1].split(' ')[0]
        recorded_video_name = f"{tc_name}_{time.strftime('%d%m%Y%H%M%S')}.mp4"
        recorded_video_path = os.path.join(Settings.log_path, recorded_video_name)
        recording_process = self.__vision.record_device_video(location=recorded_video_path,
                                                              duration=duration, blocked_process=False)
        self.__log.debug(f"Background recording started to the file {recorded_video_path}."
                         f"Recording process - {recording_process}")
        return recording_process, recorded_video_path

    def verify_recording_process_succeed(self, recording_process, recorded_video_path, duration: int = 10):
        """ Verify if background recording was success

        @param recording_process: recoeding process
        @param recorded_video_path: path ot the recorded video
        @param duration: duration to wait till process will close.
        @return:
        """
        try:
            outs, errs = recording_process.communicate(timeout=int(duration * 1.8))
            self.__log.debug(f"Recording result: Output: {outs}, Error: {errs}")
            if b'resource busy' in outs:
                self.__log.error("Unable to capture video. Resource is busy")
            elif b'ERROR:' in outs:
                self.__log.error("Unable to capture video. GST pipeline failed")
        except subprocess.TimeoutExpired as e:
            self.__log.error(f"Error: process taking too long to complete--terminating: {e}")
            recording_process.kill()
        time.sleep(1)
        check_release_cmd = "ps -ax | grep '{}' || exit 0".format(os.path.basename(recorded_video_path))
        output = subprocess.check_output(check_release_cmd, shell=True, stderr=subprocess.STDOUT)
        self.__log.debug("Check if GST released. Output: {}".format(output))

    def measure_playback_starting_from_video(self, video_path, region=None, timeout=20, black_screen_expected=True, **kwargs):
        """
        Method to get animation duration from the recorded video.

        @param video_path: path to the recorded video
        @param region: region of the recorded video to catch motion
        @param timeout: int, time to motion detection
        @param black_screen_expected: bool,
                True - If during opening playback animation black screen is expected.
                       It can be the first opening of a channel/program or a change of channel/program;
                False - If during opening playback animation black screen is not expected. This could be re-opening
                       a playback that was recently opened and plays in background, in this case the play opens quickly.
        @param kwargs:
        @return:
        """
        self.__log.info("Measure playback starting from the recorded video")
        # Close and save current session
        self.__log.info("Close VT session")
        self.__vision.close_session()
        # Initialize a new session with the recorded video file
        video_interface = FileVideoIf()
        video_interface.select_input(video_path)
        source_pipeline = video_interface.get_source_pipeline()
        captured_motion_video = video_path.replace(".mp4", "_captured_motion.webm")
        self.__log.info("Initialize a new VT session with recorded video")
        self.__vision = VisionTester(source_pipeline=source_pipeline,
                                     log_path=Settings.log_path,
                                     verbose=Settings.dbg_verbose_mode,
                                     save_video=captured_motion_video)
        # Start session and measure playback duration
        retries = 3
        for retry in range(retries):
            try:
                self.__vision.setup_session()
                self.measure_playback_starting(region, timeout, black_screen_expected, noise_threshold=.98, **kwargs)
                self.__vision.close_session()
                break
            except Exception as e:
                if retry < retries - 1:
                    self.__log.error(f"Error: {e}.\nGoing to retry...")
                    self.pause(3)
                    continue
                else:
                    raise e
