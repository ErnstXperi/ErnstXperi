

class ColorsRange:

    # HSV values
    WHITE_COLOR_RANGE = ([0, 0, 230], [255, 255, 255])
    GRAY_HOME_SCREEN_TITLE = ([0, 0, 70], [255, 255, 255])
    START_RED_COLOR_RANGE = ([160, 100, 20], [179, 255, 255])
    END_RED_COLOR_RANGE = ([0, 120, 70], [10, 255, 255])

    # BGR values
    WHITE_COLOR = (240, 240, 240)
