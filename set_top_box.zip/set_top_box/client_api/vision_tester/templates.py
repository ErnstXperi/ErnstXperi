from set_top_box.test_settings import Settings


class Template:
    __folder = "vt_hd_radio_support"

    HYDRA_BACKGROUND = f"{Settings.TEST_DATA}/hydra_image_atmospheric_default.png"
    BOOT_LOGO = f"{Settings.TEST_DATA}/bootup_logo.png"

    # RADIO COVERS
