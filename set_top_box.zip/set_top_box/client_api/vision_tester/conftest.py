import os
import re
import time
import pytest
import datetime as dt

from tools.sys_commands import Commands
from tools.logger.logger import Logger
from tools.logger.logger import PerfLogger
from set_top_box.test_settings import Settings
from set_top_box.conftest import hard_device_reboot

from tools.video_handler.video_handler import VideoInputHandler
from core_api.hardwaredriver.driverfactory import InfraHardwareError
from set_top_box.conftest import clean_up_png


def vt_start_session(request):
    from vision_tester import VisionTester
    from set_top_box.client_api.vision_tester.page import VisionTesterPage
    from set_top_box.client_api.vision_tester.locators import VTtweaks
    from set_top_box.client_api.vision_tester.colors import ColorsRange
    from set_top_box.client_api.vision_tester.templates import Template
    request.cls.log = Logger(__name__)
    # generate configuration for VT
    # if not Settings.is_vision_tester_enabled():
    #     pytest.skip(f"VisionTester not configured: hw={Settings.vt_hardware}, input={Settings.vt_video_input}")
    name = request.node.name
    video_log = os.path.join(Settings.log_path, f"av_capture_{name}_{dt.datetime.now().strftime('%m_%d_%y_%H_%M_%S')}")
    video_interface = VideoInputHandler(Settings)
    video_interface.select_input(Settings.vt_video_input)
    source_pipeline = video_interface.get_source_pipeline()
    audio_device = video_interface.selected_input.audio_device or Settings.vt_audio_device
    cap_pipeline = video_interface.get_capture_pipeline(audio_input=audio_device)
    # setup VisualTester
    request.cls.vision = VisionTester(save_video=video_log,
                                      source_pipeline=source_pipeline,
                                      audio_device=audio_device,
                                      log_path=Settings.log_path,
                                      vt_save_audio=Settings.vt_save_audio,
                                      cap_pipeline=cap_pipeline,
                                      verbose=Settings.dbg_verbose_mode,
                                      )
    request.cls.vision.setup_session()
    request.cls.vision_page = VisionTesterPage(request.cls.screen, request.cls.vision)
    request.cls.vision_page.locators = VTtweaks()
    request.cls.vision_page.colors_range = ColorsRange()
    request.cls.vision_page.templates = Template()
    request.cls.vision_page.video_interface = video_interface


@pytest.fixture(scope="function")
def setup_vision_tester(request):
    # VT imports under fixture to avoid import errors for NON VT runs
    vt_start_session(request)
    yield setup_vision_tester
    request.cls.vision.close_session()


@pytest.fixture(scope="function")
def setup_perf_log(request, setup_vision_tester):
    tc_name = request.node.name
    request.cls.vision_page.logger = PerfLogger(Settings)
    request.cls.vision_page.logger.run_name = tc_name
    yield
    request.cls.home_page.stop_events_capturing()


@pytest.fixture(scope="function")
def cleanup_vqt_tmp(request):
    yuv_file_pattern = os.path.join(Settings.log_path, "*.yuv")
    Commands().rm_rf(yuv_file_pattern)


def check_hdmi_signal_is_present(request):
    # check status of hdmi signal before proceeding to vision tester tests execution
    request.cls.log.info("===PRECONDITION=== Perform tests only if Video Signal is present")
    signal_input_state = "--"
    # Retry mechanism
    max_retry = 3
    counter = 0
    while counter < max_retry:
        time.sleep(2 * counter)
        request.cls.log.debug(f"Try {counter} / {max_retry}")
        signal_input_state = request.cls.vision_page.video_interface.selected_input.signal_status
        if signal_input_state == "Valid":
            request.cls.log.debug(f"Video Signal detected: signal_input_state={signal_input_state}")
            return
        request.cls.log.warning(f"Video Signal not detected: signal_input_state={signal_input_state}.")
        counter += 1

    request.cls.log.debug(f"Video Signal still not detected after {max_retry-1} retries. Try now with a Reboot...")
    hard_device_reboot(Settings.device_ip)
    for _try in range(max_retry):
        video_interface = VideoInputHandler(Settings)
        video_interface.select_input(Settings.vt_video_input)
        signal_input_state = video_interface.selected_input.signal_status
        if signal_input_state == "Valid":
            request.cls.vision_page.video_interface = video_interface
            return
        else:
            try:
                request.cls.vision.dump_png(request.cls.vision.get_frame(),
                                            f"{Settings.log_path}/NO_SIGNAL_{request.node.name}.png")
                cmd = "mwcap-info --info-all {}".format(video_interface.selected_input.device_path)
                output = Commands().issue_sys_command_sync_output(cmd)
                request.cls.log.debug(f"Full info for device: {output}")
            except Exception as err:
                request.cls.log.debug(f"Unable to get signal details: {err}")
            time.sleep(15 + 8 ** _try)
    raise InfraHardwareError(f"No signal detected at capture card input: signal_input_state={signal_input_state}")


@pytest.fixture(autouse=False, scope="class")
def check_hdmi_adb_connected_to_same_device(request, retries=3):
    request.cls.log.info("===PRECONDITION=== Perform tests only if adb and hdmi are connected to the same box")
    vt_start_session(request)
    device_sn = Settings.device_serial_no or Settings.hsn
    request.cls.log.info(f"IP: {Settings.device_ip}; HSN: {Settings.hsn}; serial_no: {Settings.device_serial_no}")
    args_dict = {
        'request': request,
        'text': [Settings.device_ip, device_sn.replace('O', '0')],
        'region': None,
        'replace_o': True
    }
    request.cls.vision_page.verify_screen_is_black(expected=False)
    success = None
    for i in range(0, retries):
        request.cls.system_page.open_system_settings_about()
        status, text = check_hsn_ip_present_on_screen(**args_dict)
        if status:
            success = True
            break
        elif len(text) < 5:
            raise InfraHardwareError("No text on screen, check video input.")
    if not success:
        text_matches = [match for match in ['guide', 'notification', 'demand'] if match in text.lower()]
        if text_matches:
            raise InfraHardwareError("Still in home screen, adb commands didn't work. "
                                     "Check if device port mapping in dms matches actual device port.")
        elif not handle_eventual_overlay_screen(request, args_dict):
            raise InfraHardwareError(f"Failed to confirm device, current text in screen: {text}. "
                                     f"Check if device port mapping in dms matches actual device port.")
    request.cls.log.debug("Device under test is confirmed to be the same with the one connected to the HDMI")
    clean_up_png(Settings.log_path, "test_mandatory_test_vision_tester", extension="jpg")
    request.cls.screen.base.press_back()
    request.cls.vision.close_session()


@pytest.fixture(autouse=False, scope="class")
def device_wakeup(request):
    request.cls.log = Logger(__name__)
    request.cls.log.debug("== wakeup device if is needed ==")
    for i in range(3):
        (current_focus, focus_app) = request.cls.driver.driver.get_current_focused_app()
        request.cls.log.debug(f"mFocusedApp: {focus_app} mCurrentFocus:{current_focus}")
        pattern = "com..*/"
        x1 = re.search(pattern, current_focus)
        x2 = re.search(pattern, focus_app)
        if x1 is not None and x2 is not None:
            if x1.group() == x2.group():
                break
        request.cls.log.debug("Device is sleeping.. Waking Up")
        request.cls.screen.base.press_wakeup()
        if Settings.is_unmanaged():
            time.sleep(0.5)
            request.cls.screen.base.press_right()
        time.sleep(2 * i + 1)
    else:
        raise InfraHardwareError("Device cannot be woken up.")
    request.cls.log.debug("== device is awake ==")


@pytest.fixture(autouse=False, scope="class")
def vt_precondition(request):
    Logger(__name__).info("Start fixture: vt_precondition")
    # VT precondition should run only if VT is enabled
    if Settings.is_vision_tester_enabled():
        vt_start_session(request)
        check_hdmi_signal_is_present(request)
        request.cls.vision.close_session()


def check_hsn_ip_present_on_screen(request, text: list, region=None, replace_o=False, retries=3):
    preprocessing_list = ['CLAHE', 'Contrast', 'BW']
    for i in range(0, retries):
        frame = request.cls.vision_page.get_current_frame()
        for preprocessing in preprocessing_list:
            if region:
                text_from_screen = request.cls.vision.get_text_from_screen(frame=frame, region=region,
                                                                           preprocessing=preprocessing)
            else:
                text_from_screen = request.cls.vision.get_text_from_screen(frame=frame, preprocessing=preprocessing)
            if replace_o:
                text_from_screen = text_from_screen.replace('O', '0')
            for text_piece in text:
                if text_piece in text_from_screen:
                    return True, ""
        time.sleep(1)
    return False, text_from_screen


def handle_eventual_overlay_screen(request, args_dict: dict, max_back_press=5):
    for i in range(0, max_back_press):
        request.cls.screen.base.press_back()
        time.sleep(1)
        status, text = check_hsn_ip_present_on_screen(**args_dict)
        text_matches = [match for match in ['guide', 'notification', 'demand'] if match in text.lower()]
        if text_matches:
            return False
        if status:
            return True
    return False
