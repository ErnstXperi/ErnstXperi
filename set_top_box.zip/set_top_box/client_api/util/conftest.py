import pytest

from tools.logger.logger import Logger
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.test_settings import Settings
from set_top_box.factory.page_factory import PageFactory
from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.factory.label_factory import LabelFactory
from set_top_box.client_api.guide.assertions import GuideAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions


@pytest.fixture(scope="class")
def setup_util(request):
    request.cls.log = Logger(__name__)

    request.cls.watchvideo_assertions = WatchVideoAssertions(request.cls.screen)
    request.cls.watchvideo_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.liveTv_labels = request.cls.watchvideo_labels = \
        request.cls.watchvideo_page.liveTv_labels = LabelFactory("watchvideo", Settings)

    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_labels = request.cls.home_page.home_labels = LabelFactory("home", Settings)
    request.cls.home_assertions = HomeAssertions(request.cls.screen)

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_labels = request.cls.guide_page.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)

    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)
    request.cls.menu_labels = request.cls.menu_page.menu_labels = LabelFactory("Menu", Settings)
