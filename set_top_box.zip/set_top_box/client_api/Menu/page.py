import time

import pytest

from tools.logger.logger import Logger
from core_api.stb.assertions import CoreAssertions
from set_top_box.client_api.Menu.en_us.labels import MenuLabels
from set_top_box.test_settings import Settings
from set_top_box.conf_constants import PlatformList
from mind_api.middle_mind.field import socu_partner_id


class MenuPage(CoreAssertions):
    __logger = Logger(__name__)
    menu_labels = MenuLabels()

    def menu_press_back(self):
        self.log.step("Returning one screen before")
        self.screen.base.press_back()
        self.screen.refresh()

    def select_menu_category(self, category):
        self.log.info("Selecting : {}".format(category))
        self.screen.refresh()
        if not self.is_strip_focus():
            self.__logger.info("No Strip Present")
            retries = 3
            while not self.is_strip_focus():
                self.nav_to_top_of_list()
                self.screen.refresh()
                retries -= 1
                if retries <= 0:
                    raise LookupError("Unable to get to strip")
        else:
            self.__logger.info("Strip Present")
        self.select_strip(category, refresh=False)
        self.screen.refresh()

    def select_menu_items(self, menu):
        self.log.step("Selecting menu item : {}".format(menu))
        self.screen.refresh()
        if menu not in self.menu_list():
            loop_attempts = 0
            while menu not in self.menu_list():
                self.screen.base.press_up()
                self.screen.refresh()
                loop_attempts += 1
                if loop_attempts > 10:
                    break
        self.select_menu(menu)
        self.log.info("Selection of menu : {} SUCCEEDED".format(menu))

    def select_menu_items_and_exit(self, menu):
        if not self.is_menu_focus():
            loop_attempts = 0
            while not self.is_menu_focus():
                self.screen.base.press_up()
                self.screen.refresh()
                loop_attempts += 1
                if loop_attempts > 10:
                    break
        self.select_menu(menu)
        self.screen.base.press_back()
        self.screen.refresh()

    def go_to_settings(self, tester):
        self.go_to_menu_screen(tester)
        self.navigate_by_strip(tester.menu_labels.LBL_SETTINGS_SHORTCUT)

    def go_to_autoplay_next_episode(self):
        self.log.step("Going to sub menu Autoplay Next Episode")
        self.select_menu_items(self.menu_labels.LBL_AUTOPLAY_NEXTEPSD)

    def go_to_to_do_list(self, tester):
        self.log.info("Going to TO DO LIST")
        self.go_to_settings(tester)
        self.select_menu_items(self.menu_labels.LBL_TODO_LIST)
        self.screen.refresh()

    def go_to_favorite_channels(self):
        self.select_menu_items(self.menu_labels.LBL_FAVOURITE_CHANNELS)

    def go_to_accessibility(self, tester):
        self.log.step("Going to Settings->Accessibility")
        self.go_to_settings(tester)
        self.select_menu_items(tester.menu_labels.LBL_ACCESSIBILITY)

    def go_to_set_rating_limit(self, tester):
        self.log.step("Going to Set Rating Limits from parental controls screen")
        self.select_menu(tester.menu_labels.LBL_SET_RATING_LIMITS)
        self.wait_for_screen_ready(self.menu_labels.LBL_SET_RATING_LIMITS_SCREEN)

    def go_to_closed_captioning(self, tester):
        self.log.step("Go to CC sub menu")
        if "b-hydra-streamer-1-7" in Settings.branch.lower():
            self.select_menu_items(tester.menu_labels.LBL_CLOSED_CAPTIONING_MENU)
        else:
            self.select_menu_items(tester.menu_labels.LBL_CLOSED_CAPTIONING)

    def go_to_system_info_screen(self, tester, press_enter=False):
        self.log.step("Going to System & Account")
        self.go_to_menu_screen(tester)
        self.navigate_by_strip(tester.menu_labels.LBL_SYSTEM_AND_ACCOUNT)
        if press_enter:
            self.screen.base.press_enter()

    def get_option_value_from_system_information(self, option):
        """
        Getiing opion value from the System Information screen (it already should be displayed for getting value)

        Args:
            option (str): option name to get value for

        Returns:
            str, option value
        """
        self.log.info(f"Getting '{option}' option value from the System Information screen")
        self.verify_view_mode(self.menu_labels.LBL_SYSTEM_INFORMATION_SCRN_VIEW_MODE)
        attempts = 3
        for i in range(attempts):
            menu_items = self.screen.get_screen_dump_item('menuitem')
            for item in menu_items:
                if item['text'] == option:
                    return item['option']['text']
            self.press_down_button(refresh=True)
        raise AssertionError(f"Failed to get option value in {attempts} attempts")

    def go_to_video_providers(self, tester):
        self.log.step("Going to Settings->User Preferences->My Video Providers")
        self.go_to_user_preferences(tester)
        self.select_menu_items(tester.menu_labels.LBL_MY_VIDEO_PROVIDERS)

    def change_autoplay_option(self, tester):
        self.log.info("Changing AutoPlay options")
        self.return_menu_focus_index()
        self.screen.refresh()
        opp = self.menu_focus()
        if opp == tester.menu_labels.LBL_AUTOPLAY_SWTICHEDOFF:
            self.log.info("Selecting {}".format(opp))
            self.menu_navigate_up_down(1, 0)
            self.select_item(delay=2)
        else:
            self.log.info("Selecting {}".format(opp))
            self.menu_navigate_up_down(0, 1)
            self.select_item(delay=2)
        self.screen.refresh()

    def find_first_unchecked(self, unchecked):
        self.log.step("Find first unchecked option")
        self.screen.refresh()
        menu = (self.screen.get_screen_dump_item('menuitem'))
        index = 0
        for item in menu:
            if unchecked in item['imagename']:
                return index
            index += 1
        return -1

    def cancel_one_pass(self, content):
        """
            Cancel this OnePass
            :param content: show name
        """
        self.log.step("Cancel one pass: {}".format(content))
        self.nav_to_menu_by_substring(content)
        self.screen.base.press_clear()
        self.screen.refresh()
        if self.is_overlay_shown():
            self.select_menu_by_substring(self.menu_labels.LBL_CONFIRM_CANCEL_ONEPASS)

    def checkbox_option_in_focus(self, tester):
        self.screen.refresh()
        image = self.menu_item_image_focus()
        self.log.step("Check {}".format(image))
        if isinstance(image, list):
            if tester.menu_labels.LBL_CHECKED not in image:
                self.screen.base.press_enter()
            return
        elif tester.menu_labels.LBL_CHECKED not in image:
            self.screen.base.press_enter()

    def nav_to_item_option(self, option):
        """
        method to navigate by horizontal looped menus. It will press right until specifed option will be focused
        if after 15 presses or if the option appears again the method rise error
        Args:
            option: str, text of target option

        Returns:
            None

        """
        self.nav_to_item_option_horizontally(option)

    def is_parental_control_enabled(self):
        return bool(self.get_overlay_title())

    def get_current_pin_value(self):
        if Settings.mso.lower() == "llapr":
            pin_value = "9999"
        elif Settings.is_managed():
            pin_value = "9999"
        elif Settings.is_unmanaged():
            pin_value = "0000"
        else:
            pin_value = "0000"

        return pin_value

    def enter_pin(self, pin_value):
        self.log.step("Entering pin: {}".format(pin_value))
        self.screen.base.typeTextByKey(pin_value)

    def enter_parental_control_password(self):
        pin_value = self.get_current_pin_value()
        self.enter_pin(pin_value)
        self.wait_for_screen_ready()
        self.screen.refresh()

    def get_default_pin(self, tester):
        self.log.info("Getting pin from branding ui")
        branding_value = {}
        try:
            branding_value = self.service_api.branding_ui()
        except Exception:
            self.log.info("Error retrieving PC pin from branding ui")
        if branding_value and branding_value.default_pc_pin:
            # get password published in branding bundle
            default_pc_pin = branding_value.default_pc_pin
        else:
            # pin will be 9999 by default if we have not published it in branding bundle
            default_pc_pin = '9999'
        return default_pc_pin

    def enter_pin_handler(self, tester, default_pc_pin=None):
        mode = None
        title = None
        state = True
        attempt = -1
        if default_pc_pin is None:
            default_pc_pin = self.get_default_pin(tester)
        triage_pin = ['0000', '9999', '1111']
        if default_pc_pin in triage_pin:
            index = triage_pin.index(default_pc_pin)
            triage_pin.pop(index)
        self.log.info("Pin triage list: {}".format(triage_pin))
        self.log.info("Entering pin {}".format(default_pc_pin))
        while state and attempt < len(triage_pin):
            self.device_type_pin_entry(pin=default_pc_pin)
            self.wait_for_screen_ready()
            self.pause(10)
            self.screen.refresh()
            if self.is_overlay_shown():
                mode = self.get_overlay_mode()
                title = self.get_overlay_title()
                if mode is not None and title == self.menu_labels.LBL_INCORRECT_PIN:
                    self.wait_for_screen_ready()
                    self.log.info("{} Overlay is displayed with pin - {}".format(title, default_pc_pin))
                    default_pc_pin = triage_pin[attempt]
                    attempt += 1
                    self.log.info("Attempting again to unlock with pin - {}".format(default_pc_pin))
                else:
                    self.log.info("No incorrect pin overlay shown, hence ending the loop")
                    state = False
                    break
            else:
                self.log.info("Unlocked PC successfully with pin {}".format(default_pc_pin))
                state = False
                break
        if state:
            self.log.warning("Failed to enable/disable PC")
            if self.is_overlay_shown():
                self.screen.base.press_back()

    def enter_default_parental_control_password(self, tester, pc_pin=None):
        self.screen.refresh()
        title = self.get_overlay_title()
        if title == self.menu_labels.LBL_CREATE_PIN:
            self.log.info("Setting PC PIN")
            if pc_pin is None:
                pc_pin = self.get_default_pin(tester)
                self.menu_labels.LBL_PIN = pc_pin
            else:
                self.menu_labels.LBL_PIN = pc_pin
            self.log.info("Setting PC PIN {}".format(pc_pin))
            self.log.info("PIN label set to {}".format(self.menu_labels.LBL_PIN))
            self.device_type_pin_entry(pin=pc_pin)
        elif title == self.menu_labels.LBL_CONFIRM_PIN:
            self.confirm_pin(tester)
        elif title == self.menu_labels.LBL_ENTER_PIN or title == self.menu_labels.LBL_DISABLE_PARENTAL_CONTROLS:
            if not self.menu_labels.LBL_PIN:
                pc_pin = self.get_default_pin(tester)
            self.enter_pin_handler(tester, default_pc_pin=pc_pin)
        else:
            self.log.info("{} pin overlay observed. Entering pin".format(title))
            self.enter_pin_handler(tester, default_pc_pin=pc_pin)

    def confirm_pin(self, tester):
        if not self.menu_labels.LBL_PIN:
            self.log.info("Label seems to be empty: {}".format(self.menu_labels.LBL_PIN))
            pin = self.get_default_pin(tester)
        else:
            self.log.info("Getting pin from label: {}".format(self.menu_labels.LBL_PIN))
            pin = self.menu_labels.LBL_PIN
        self.log.info("Confirm PIN: {}".format(pin))
        self.device_type_pin_entry(pin)
        self.wait_for_screen_ready(tester.menu_labels.LBL_PARENTAL_AND_PURCHASE_CONTROLS_SCREEN)
        self.screen.refresh()

    def device_type_pin_entry(self, pin=None):
        if Settings.is_unmanaged():
            self.handle_spinner_overlay(pin)
        else:
            self.screen.base.typeTextByKey(pin)
        self.pause(3)  # Delay after entering pin

    def handle_spinner_overlay(self, pin):
        for i in range(4):
            if pin[i] == 0:
                self.screen.base.press_enter()
                self.pause(1)
            else:
                for j in range(int(pin[i])):
                    self.screen.base.press_up()
                    self.pause(1)
                self.screen.base.press_enter()
                self.pause(1)

    def enter_wrong_pc_password(self, tester):
        self.log.step("Entering wrong parental control password")
        default_pc_pin = self.get_default_pin(tester)
        incorrect_pc_pin = '2468'
        if incorrect_pc_pin == default_pc_pin:
            incorrect_pc_pin = str(int(incorrect_pc_pin) + 2)
        self.log.info("Entering wrong PC Pin - {}".format(incorrect_pc_pin))
        if Settings.is_unmanaged():
            self.handle_spinner_overlay(incorrect_pc_pin)
        else:
            self.screen.base.typeTextByKey(incorrect_pc_pin)
        self.screen.refresh()

    def get_parental_controls_menu_item_label(self):
        """
        :description:
            Get Parental Controls menu item label
            To use this method, SETTINGS screen should be opened
            How it works: test checks which of PC labels is currenly displayed
            on the screen, compares it with one of 2 existing variants (PC / P&PC)
            and returns matched label
        :return:
            Label of Parental Controls menu option
        """
        self.log.info("Fetching parental control menu name")
        self.screen.refresh()
        menu_item_list = str(self.screen.screen_dump['xml']["menuitem"])
        is_parental_controls_label = self.menu_labels.LBL_PARENTAL_CONTROLS_SHORTCUT in menu_item_list
        is_parental_and_purchase_controls_label = self.menu_labels.LBL_PARENTAL_AND_PURCHASE_CONTROLS_SHORTCUT in \
            menu_item_list
        if is_parental_and_purchase_controls_label:
            self.log.info(f"Menu name: {self.menu_labels.LBL_PARENTAL_AND_PURCHASE_CONTROLS_SHORTCUT}")
            return self.menu_labels.LBL_PARENTAL_AND_PURCHASE_CONTROLS_SHORTCUT
        elif is_parental_controls_label:
            self.log.info(f"Menu name: {self.menu_labels.LBL_PARENTAL_CONTROLS_SHORTCUT}")
            return self.menu_labels.LBL_PARENTAL_CONTROLS_SHORTCUT
        else:
            self.__logger.error("Neither Parental Controls nor Parental & Purchase Controls label is found")
            return None

    def set_rating_limits(self, rated_movie, rated_tv_show, unrated_tv_show, unrated_movie):
        """
        :description:
            Set Rating Limits screen in the Parental Controls should be opened before setting values
        :params:
            rated_movie = Highest alowed movie rating
            rated_tv_show = Highest allowed TV rating
            unrated_tv_show = Unrated TV shows
            unrated_movie = Unrated movies
        :return:
        """
        self.log.info("Modifying rating limit options for rated/unrated TV/Movies")

        def get_current_state():
            ret = {}
            for item in self.get_menu_item():
                ret[item["text"]] = item["option"]['text']
            return ret

        expected_values = {self.menu_labels.LBL_HIGHEST_ALLOWED_MOVIE_RATING: rated_movie,
                           self.menu_labels.LBL_HIGHEST_ALLOWED_TV_RATING: rated_tv_show,
                           self.menu_labels.LBL_UNRATED_TV_SHOWS: unrated_tv_show,
                           self.menu_labels.LBL_UNRATED_MOVIES: unrated_movie}
        self.log.step("Setting rating limit options to {}".format(expected_values))
        try:
            state = get_current_state()
            for k, v in expected_values.items():
                self.log.info(f"Setting {k} to value {v}")
                if v in state[k]:
                    self.log.info("Value {} already setted for option {}".format(v, k))
                    continue
                self.nav_to_menu(k)
                self.screen.refresh()
                self.nav_to_item_option(v)
            self.log.info("Changed all options")
        except Exception:
            # TODO Remove if new realization stable
            self.log.info("Smth went wrong setting rating limits")
            self.nav_to_menu(self.menu_labels.LBL_HIGHEST_ALLOWED_MOVIE_RATING)
            self.nav_to_item_option(rated_movie)
            self.nav_to_menu(MenuLabels.LBL_HIGHEST_ALLOWED_TV_RATING)
            self.screen.refresh()
            self.nav_to_item_option(rated_tv_show)
            self.nav_to_menu(MenuLabels.LBL_UNRATED_TV_SHOWS)
            self.screen.refresh()
            self.nav_to_item_option(unrated_tv_show)
            self.nav_to_menu(MenuLabels.LBL_UNRATED_MOVIES)
            self.screen.refresh()
            self.nav_to_item_option(unrated_movie)

    def __is_menu_option_having_expected_value(self, option, expected_value):
        """
        :description:
            Checks if a menu option has expected value
        :params:
            option - a menu option
            expected_value - the value the option is expected to have
        :return:
            bolean
        """
        if self.is_in_menu(option):
            self.nav_to_menu(option)
            self.screen.refresh()
            value = self.menu_item_option_focus()
            if value == expected_value:
                return True
            else:
                return False
        else:
            # e.g. Purchase Controls menu option may not be present depending on the MSO
            self.__logger.warning("Menu option was not found in the menu list - '{}'".format(option))
            return False

    def is_purchase_controls_on(self):
        """
        :description:
            Checks if Purhcase Controls is ON
            Parental Controls screen with options should be displayed to use this method
        :return:
            bolean
        """
        return self.__is_menu_option_having_expected_value(MenuLabels.LBL_PURCHASE_CONTROLS,
                                                           MenuLabels.LBL_OPTION_VALUE_ON)

    def is_hide_adult_content_on(self):
        """
        :description:
            Checks if Hide Adult Content is ON
            Parental Controls screen with options should be displayed to use this method
        :return:
            bolean
        """
        return self.__is_menu_option_having_expected_value(MenuLabels.LBL_HIDE_ADULT_CONTENT,
                                                           MenuLabels.LBL_OPTION_VALUE_ON)

    def turn_off_hide_adult(self):
        if self.is_hide_adult_content_on():
            self.select_menu_items(self.menu_labels.LBL_HIDE_ADULT_CONTENT)
            self.select_menu_items(self.menu_labels.LBL_DONT_HIDE_ADULT_CONTENT)

    def get_highest_movie_rating(self):
        if self.is_hide_adult_content_on():
            highest_movie_rating = self.menu_labels.LBL_ALLOW_ALL_HIGHEST_ALLOWED_MOVIE_RATING_EXCEPT_ADULT
        else:
            # check to validate highest allowed rating with allow all value till we get correct values from service API
            if Settings.is_dev_host():
                self.log.info("To handle hightest allowed rating limit with Allow all option")
                highest_movie_rating = self.menu_labels.LBL_ALLOW_ALL_HIGHEST_ALLOWED_RATING
            else:
                highest_movie_rating = self.get_movie_rating()
        self.log.info("Highest allowed MOVIE rating is {}".format(highest_movie_rating))
        return highest_movie_rating

    def get_highest_tv_rating(self):
        if self.is_hide_adult_content_on():
            highest_tv_rating = self.menu_labels.LBL_ALLOW_ALL_HIGHEST_ALLOWED_TV_RATING_EXCEPT_ADULT

        else:
            # check to validate highest allowed rating with allow all value till we get correct values from service API
            if Settings.is_dev_host():
                self.log.info("To handle hightest allowed rating limit with Allow all option")
                highest_tv_rating = self.menu_labels.LBL_ALLOW_ALL_HIGHEST_ALLOWED_RATING
            else:
                highest_tv_rating = self.get_tv_rating()

        self.log.info("Highest allowed TV rating is {}".format(highest_tv_rating))
        return highest_tv_rating

    def toggle_hide_adult_content(self, ON=True):
        self.log.info("Hiding adult content {}".format(ON))
        lbl = self.menu_labels
        self.select_menu_items(lbl.LBL_HIDE_ADULT_CONTENT)
        self.select_menu_items(lbl.LBL_HIDE_ADULT_CONTENT.capitalize() if ON else lbl.LBL_DONT_HIDE_ADULT_CONTENT)

    def turnonpcsettings(self, tester, parentalon, purchaseon):
        self.log.step(f"Turning {parentalon} parental and turning {purchaseon} purchase controls")
        tester.home_page.back_to_home_short()
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_MENU_SHORTCUT)
        self.wait_for_screen_ready()
        tester.home_assertions.verify_screen_title(tester.home_labels.LBL_MENU_SCREENTITLE)
        self.nav_to_top_of_list()
        self.select_menu_category(tester.menu_labels.LBL_SETTINGS_SHORTCUT)
        self.select_menu_items(self.get_parental_controls_menu_item_label())
        if parentalon == "on":
            self.log.info("Turning on Parental controls")
            self.select_menu_items(tester.menu_labels.LBL_PARENTAL_CONTROLS_MENUITEM)
            self.enter_default_parental_control_password(tester)
            time.sleep(3)
            self.enter_default_parental_control_password(tester)
            time.sleep(3)
            self.nav_to_menu(tester.menu_labels.LBL_PARENTAL_CONTROLS_MENUITEM)
            time.sleep(3)

        if purchaseon == "on":
            self.log.info("Turning on Purchase controls")
            self.select_menu_items(tester.menu_labels.LBL_PURCHASE_CONTROLS)
            self.select_menu_items(tester.menu_labels.LBL_PURCHASE_WITHPIN_MENU)
            time.sleep(2)
            self.enter_default_parental_control_password(tester)
            time.sleep(2)
            # one more time for confirmation
            self.enter_default_parental_control_password(tester)
            time.sleep(2)
            self.nav_to_menu(tester.menu_labels.LBL_PURCHASE_CONTROLS)
            time.sleep(2)
            tester.menu_assertions.verify_item_option_focus(tester.menu_labels.LBL_OPTION_VALUE_ON)

    def check_myshows_options(self, tester):
        self.log.info("Checking My Shows Options")
        self.screen.refresh()
        opp = self.menu_focus()
        if opp == tester.menu_labels.LBL_MYSHOWS_SORTBYNAME:
            self.log.info("selecting {}".format(opp))
            self.menu_navigate_up_down(1, 0)
            self.select_item(delay=2)
        else:
            self.log.info("selecting {}".format(opp))
            self.menu_navigate_up_down(0, 1)
            self.select_item(delay=2)
        self.screen.refresh()

    def go_to_parental_controls(self, tester):
        self.go_to_settings(tester)
        self.select_menu(self.get_parental_controls_menu_item_label())

    def set_tv_rating_limits(self, tv_rating):
        self.log.step(f"Setting TV rating limit option to {tv_rating}")
        self.nav_to_menu(MenuLabels.LBL_HIGHEST_ALLOWED_TV_RATING)
        self.screen.get_json()
        self.nav_to_item_option(tv_rating)

    def set_movie_rating_limits(self, movie_rating):
        self.nav_to_menu(MenuLabels.LBL_HIGHEST_ALLOWED_MOVIE_RATING)
        self.screen.get_json()
        self.nav_to_item_option(movie_rating)
        self.select_menu_items(self.get_parental_controls_menu_item_label())

    def select_and_verify_branding(self, menu_list, title_validation=False):
        """
            :description:
                select each item and verify branding icon near screen title
            :param menu_list: List of menu items
                   title_validation: Flag for title validation
            :return:
        """
        self.log.info('Verifying the menu item:{}'.format(self.menu_labels.LBL_SETTINGS_SHORTCUT))
        # to remove "Device Settings" from the menu list
        if self.menu_labels.LBL_DEVICE_SETTINGS in menu_list:
            menu_list.remove(self.menu_labels.LBL_DEVICE_SETTINGS)
        for item in menu_list:
            self.log.info("Selecting : {}".format(item))
            self.select_menu(item)
            self.wait_for_screen_ready()
            self.log.info("Verifying Branding Icon on Screen : {}".format(item))
            # need refresh here to verify branding icon & title on new screen
            self.screen.refresh()
            self.verify_primary_branding_icon()
            self.log.info("Branding Icon Validation Succeeded on Screen : {} ".format(item))
            if title_validation:
                self.log.info("Verifying Screen Title on Screen : {}".format(item))
                if item != self.menu_labels.LBL_REMOTE_SETTINGS:
                    self.verify_screen_title(str(item).upper())
                else:
                    self.verify_screen_title(self.menu_labels.LBL_REMOTE_SETTINGS_SCREEN_TITLE)
                self.log.info("Screen Title Validation Succeeded on Screen : {}".format(item))
            self.screen.base.press_back()
            # need refresh here to select menu item after moving back
            self.screen.refresh()

    def apply_option(self, option_item, option_value):
        """
        :description:
               Select needed value for option item and apply it
        :param option_item: Option item label
               option_value: option value
        :return:
        """
        self.log.info(f"Modifying {option_item} value to {option_value}")
        self.select_menu_items(option_item)
        self.nav_to_item_option(option_value)

    def go_to_video_background_settings(self, tester):
        """
        :description:
            Goes to 'Video Window & Background' screen
        :param tester: object instance of calling test
        :return:
        """
        self.go_to_user_preferences(tester)
        tester.menu_assertions.verify_user_pref_screen_title()
        self.select_menu_items(tester.menu_labels.LBL_VIDEO_BACKGROUND)

    def enable_full_screen_video_on_home(self, tester):
        """
        :description:
            Goes to 'Video Window & Background' screen and enables full screen video on home screen background
        :param tester: object instance of calling test
        :return:
        """
        self.log.step("Setting home screen background to Full screen video")
        self.go_to_video_background_settings(tester)
        self.apply_option(tester.menu_labels.LBL_DISPLAY_VIDEO, tester.menu_labels.LBL_YES)
        self.apply_option(tester.menu_labels.LBL_VIDEO_ON_HOME, tester.menu_labels.LBL_FULL_SCREEN)

    def disable_full_screen_video_on_home(self, tester):
        """
        :description:
            Goes to 'Display Video' screen and disable full screen video on home screen background
        :param tester: object instance of calling test
        :return:
        """
        self.log.step("Setting home screen background to off")
        self.go_to_video_background_settings(tester)
        self.apply_option(tester.menu_labels.LBL_DISPLAY_VIDEO, tester.menu_labels.LBL_NO)

    def enable_top_right_video_window_on_home_page(self, tester):
        """
        :description:
            Goes to 'Video Window & Background' screen and enables video window on home screen on right top
        :param tester: object instance of calling test
        :return:
        """
        self.log.step('Setting home screen to top right video window')
        self.go_to_video_background_settings(tester)
        self.apply_option(tester.menu_labels.LBL_DISPLAY_VIDEO, tester.menu_labels.LBL_YES)
        self.apply_option(tester.menu_labels.LBL_VIDEO_ON_HOME, tester.menu_labels.LBL_VIDEO_WINDOW_TOP_RIGHT)

    def enable_background_atmospheric_image(self, tester):
        """
        Method to enable image on home background
        """
        self.log.step("Setting home screen to display background atmospheric image")
        self.go_to_video_background_settings(tester)
        self.apply_option(tester.menu_labels.LBL_DISPLAY_VIDEO, tester.menu_labels.LBL_NO)
        self.apply_option(tester.menu_labels.LBL_DISPLAY_BACKGROUND_IMAGES, tester.menu_labels.LBL_YES)

    def go_to_one_pass_manager(self, tester):
        """
        :description:
            Goes to 'OnePass Manager' screen
        :param tester: object instance of calling test
        :return:
        """
        self.log.info("Navigate to one pass manager")
        self.go_to_settings(tester)
        self.select_menu_items(tester.menu_labels.LBL_ONEPASS_MANAGER)

    def turn_parental_control(self, tester, turn=''):
        """
        Turns parental controls to 'On - Locked' or 'On - Unlocked' state. Calls from Parental Controls screen
        :param turn: str
        :return:
        """
        self.log.step("Turning pc to {}".format(turn))
        self.nav_to_menu(tester.menu_labels.LBL_PARENTAL_CONTROLS_MENUITEM)
        self.screen.get_json()
        if turn == "On - Locked":
            if self.menu_item_option_focus() != tester.menu_labels.LBL_PARENTAL_CONTROLS_VALUE_ONLOCKED:
                self.select_menu_items(tester.menu_labels.LBL_PARENTAL_CONTROLS_MENUITEM)
                tester.menu_assertions.verify_item_option_focus(tester.menu_labels.LBL_PARENTAL_CONTROLS_VALUE_ONLOCKED)
            else:
                self.log.info(f"Parental control is already '{turn}'")
        elif turn == 'On - Unlocked':
            if self.menu_item_option_focus() != tester.menu_labels.LBL_PARENTAL_CONTROLS_VALUE_ONUNLOCK:
                self.select_menu_items(tester.menu_labels.LBL_PARENTAL_CONTROLS_MENUITEM)
                self.enter_default_parental_control_password(tester)
                tester.menu_assertions.verify_item_option_focus(tester.menu_labels.LBL_PARENTAL_CONTROLS_VALUE_ONUNLOCK)
            else:
                self.log.info(f"Parental control is already '{turn}'")

    def enter_PIN_overlay_visibility(self, tester):
        self.log.info("Getting PIN overlay visibility.")
        screen = self.screen.get_json()['xml']
        if 'overlayMode' in screen.keys() and screen['overlayMode'] in tester.menu_labels.LBL_PIN_OVERLAY:
            return True
        else:
            return False

    def get_settings_menu_items_list(self):
        """
        Creates list of menus in SETTINGS page. Calls from MENU screen
        Common menus for all devices: Accessibility, OnePass Manager, To Do List, User Preferences, Audio Settings
        Managed devices have additional: Remote Settings, Device Settings
        parental_control used to determine 'Parental Controls' or 'Parental & Purchase Controls' is in settings
        Note: 'To Do List' menu will not be shown if nDVR is disabled
        :return: list
        """
        if Settings.is_ndvr_applicable():
            settings_menu_list = [self.menu_labels.LBL_ACCESSIBILITY,
                                  self.menu_labels.LBL_ONEPASS_MANAGER,
                                  self.menu_labels.LBL_TODO_LIST,
                                  self.menu_labels.LBL_USER_PREFERENCES,
                                  self.menu_labels.LBL_AUDIO_SETTINGS]
        else:
            settings_menu_list = [self.menu_labels.LBL_ACCESSIBILITY,
                                  self.menu_labels.LBL_ONEPASS_MANAGER,
                                  self.menu_labels.LBL_USER_PREFERENCES,
                                  self.menu_labels.LBL_AUDIO_SETTINGS]
        menus_managed = [self.menu_labels.LBL_REMOTE_SETTINGS,
                         self.menu_labels.LBL_DEVICE_SETTINGS]
        parental_control = self.get_parental_controls_menu_item_label()
        settings_menu_list.append(parental_control)
        if Settings.is_managed():
            settings_menu_list.extend(menus_managed)
        return settings_menu_list

    def checked_option(self, option):
        self.nav_to_menu(option)
        if self.menu_labels.LBL_CHECKED not in self.menu_item_image_focus():
            self.screen.base.press_enter()

    def unchecked_option(self, option):
        self.log.step("Uncheck {}".format(option))
        self.nav_to_menu(option)
        if self.menu_labels.LBL_CHECKED in self.menu_item_image_focus():
            self.screen.base.press_enter()

    def lock_pc_with_ratings(self, tester, rated_movie=None,
                             rated_tv_show=None,
                             unrated_tv_show=menu_labels.LBL_ALLOW_ALL_UNRATED,
                             unrated_movie=menu_labels.LBL_ALLOW_ALL_UNRATED):
        if not rated_movie:
            rated_movie = self.get_movie_rating()
        if not rated_tv_show:
            rated_tv_show = self.get_tv_rating()
        self.log.step("Changing rating limit options for parental controls")
        self.turnonpcsettings(tester, "on", "off")
        self.go_to_set_rating_limit(self)
        self.set_rating_limits(rated_movie=rated_movie, rated_tv_show=rated_tv_show,
                               unrated_tv_show=unrated_tv_show, unrated_movie=unrated_movie)
        self.menu_press_back()
        self.select_menu_items(self.menu_labels.LBL_PARENTAL_CONTROLS)

    def verify_the_streaming_only_option_item_details(self, tester, title):
        """
        :description:
            Goes to 'OnePass Manager' screen and verify the menu item details
        :return:
        """
        self.log.info("Verifying streaming only option item details")
        self.nav_to_menu_by_substring(title)
        self.screen.refresh()
        pane = self.get_preview_panel()
        if 'includeValue' in pane.keys():
            value = pane.get('includeValue')
            if value != tester.guide_labels.LBL_STREAMING_VIDEO_ONLY:
                raise AssertionError("Streaming Videos option is not found in previewPane")

    def go_to_menu_screen(self, tester):
        self.log.step("Navigating to Menu Sceen")
        tester.home_page.back_to_home_short()
        tester.home_page.select_menu_shortcut_num(tester, tester.home_labels.LBL_MENU_SHORTCUT)
        self.screen.refresh()
        tester.menu_assertions.verify_menu_screen_title()

    def go_to_audio_settings(self, tester):
        self.log.step("Launching audio settings screen")
        self.go_to_menu_screen(tester)
        self.select_menu(tester.menu_labels.LBL_AUDIO_SETTINGS)

    def change_and_verify_audio_languages(self, tester):
        self.log.step("Changing audio track language")
        language = self.screen.get_screen_dump_item('menuitem')[0]['option']['text']
        self.select_menu(self.menu_labels.LBL_LANGUAGE_AND_AUDIO_DESCRIPTION)
        self.wait_for_screen_ready()
        menulist = self.menu_list()
        tester.menu_assertions.verify_selected_audio_language_options(language, menulist)
        self.select_menu(menulist[0])

    def navigate_and_select_wtw_side_panel_category(self, tester, category, check=False):
        self.log.step(f"Select WTW category {category}")
        tester.home_page.back_to_home_short()
        tester.home_assertions.verify_menu_item_available(tester.home_labels.LBL_WHATTOWATCH_SHORTCUT)
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_WHATTOWATCH_SHORTCUT)
        tester.my_shows_page.wait_for_screen_ready(tester.home_labels.LBL_WTW_PRIMARY_SCREEN, 30000)
        self.menu_navigate_left_right(1, 0)
        tester.my_shows_page.wait_for_screen_ready(tester.home_labels.LBL_WTW_SIDE_PANEL, 30000)
        self.select_menu_items(category)
        if check:
            tester.home_page.nav_wtw_upto_overlay()
        self.wait_for_screen_ready(tester.home_labels.LBL_WTW_PRIMARY_SCREEN, 30000)
        self.screen.refresh()

    def check_enter_pin_overlay_first_spinner_box_and_values(self):
        self.log.step("Checking enter pin overlay box values")
        overlay = self.screen.get_screen_dump_item('pinentry')
        for item in overlay:
            if item['hasfocus'] == 'true':
                image = item.get('imagename')
                if image != self.menu_labels.LBL_PIN_OVERLAY_IMAGE:
                    self.log.error("Image values are not same as expected")
                    return False
            break
        for i in range(0, 2):
            overlay = self.screen.get_screen_dump_item('pinentry')
            value = ['0', '9']
            for item in overlay:
                if item['text'] != value[i]:
                    self.log.error("text value is not same as expected")
                    return False
                elif i != 1:
                    for i in range(0, 9):
                        self.screen.base.press_up()
                    self.screen.refresh()
                    break
                else:
                    self.screen.base.press_up()
                    break
        for i in range(0, 2):
            self.screen.refresh()
            overlay = self.screen.get_screen_dump_item('pinentry')
            value = ['0', '1']
            for item in overlay:
                if item['text'] != value[i]:
                    self.log.error("text value is not same as expected")
                    return False
                elif i != 1:
                    for i in range(0, 9):
                        self.screen.base.press_down()
                    self.screen.refresh()
                    break
                else:
                    self.screen.base.press_down()
                    break
        return True

    def autoplay_next_episode_settings(self, tester, value):
        self.log.info("Going to Settings->User Preferences->Autoplay Next Episode")
        self.go_to_user_preferences(tester)
        self.go_to_autoplay_next_episode()
        self.select_menu_items(value)

    def disable_closed_captioning(self, tester):
        """
        Disable Closed Captioning
        """
        self.log.info("Turning off closed captioning")
        self.go_to_accessibility(tester)
        self.go_to_closed_captioning(tester)
        menuitem = self.get_menu_item()
        for item in menuitem:
            if self.menu_labels.LBL_OFF in item['text']:
                self.select_menu_items(self.menu_labels.LBL_OFF)
        self.log.info("Closed Captioning is set to OFF")

    def go_to_device_settings(self, tester):
        self.go_to_settings(tester)
        self.select_menu_items(tester.menu_labels.LBL_DEVICE_SETTINGS)

    def enable_closed_captioning(self, tester):
        """
        Enable Closed Captioning
        """
        self.log.info("Turning on closed captioning")
        self.go_to_accessibility(tester)
        self.go_to_closed_captioning(tester)
        menuitem = self.get_menu_item()
        for item in menuitem:
            if self.menu_labels.LBL_ON in item['text']:
                self.select_menu_items(self.menu_labels.LBL_ON)
        self.log.info("Closed Captioning is set to ON")

    def check_or_uncheck_all_menu_items(self, uncheck=False):
        menu_items_scrolled_to_end = True
        iteration = 0
        while iteration < 9 and menu_items_scrolled_to_end:
            menu_item_list = []
            for menu in self.menu_list():
                menu_item_list.append(menu)
                if uncheck:
                    if self.menu_labels.LBL_CHECKED in self.menu_item_image_focus():
                        self.screen.base.press_enter()
                else:
                    if self.menu_labels.LBL_CHECKED not in self.menu_item_image_focus():
                        self.screen.base.press_enter()
                self.screen.base.press_down()
            self.screen.refresh()
            menu_list = self.menu_list()
            if menu_item_list[-1] == menu_list[-1]:
                break
            iteration += 1

    def go_to_user_preferences(self, tester):
        self.log.step("Navigating to user Preferences")
        self.go_to_settings(tester)
        self.select_menu_items(self.menu_labels.LBL_USER_PREFERENCES)

    def go_to_set_rating_limit_screen(self):
        self.select_menu(self.menu_labels.LBL_SET_RATING_LIMITS)
        self.wait_for_screen_ready(self.menu_labels.LBL_SET_RATING_LIMITS_SCREEN)

    def is_movie_rating_block_all(self):
        return self.__is_menu_option_having_expected_value(self.menu_labels.LBL_HIGHEST_ALLOWED_MOVIE_RATING,
                                                           self.menu_labels.LBL_BLOCK_ALL_RATED)

    def is_tv_rating_block_all(self):
        return self.__is_menu_option_having_expected_value(self.menu_labels.LBL_HIGHEST_ALLOWED_TV_RATING,
                                                           self.menu_labels.LBL_BLOCK_ALL_RATED)

    def is_tv_rating_allow_all_except_adult(self):
        return self.__is_menu_option_having_expected_value(
            self.menu_labels.LBL_HIGHEST_ALLOWED_TV_RATING,
            self.menu_labels.LBL_ALLOW_ALL_HIGHEST_ALLOWED_TV_RATING_EXCEPT_ADULT)

    def is_movie_rating_allow_all_except_adult(self):
        return self.__is_menu_option_having_expected_value(
            self.menu_labels.LBL_HIGHEST_ALLOWED_MOVIE_RATING,
            self.menu_labels.LBL_ALLOW_ALL_HIGHEST_ALLOWED_MOVIE_RATING_EXCEPT_ADULT)

    def enable_video_window(self, tester):
        self.log.step("Turning Video window on")
        if not self.get_video_window_status():
            self.go_to_user_preferences(tester)
            self.select_menu(self.menu_labels.LBL_VIDEO_BACKGROUND)
            self.nav_to_menu(self.menu_labels.LBL_DISPLAY_VIDEO)
            self.nav_to_item_option(self.menu_labels.LBL_YES)
        else:
            self.log.step("Video Window is already turned on")

    def get_remote_type(self):
        """
        Should be called from REMOTE SETUP screen
        :return: str
        """
        self.log.step("Getting remote type.")
        remote_type = self.screen.get_screen_dump_item('menuitem', 'text')
        return remote_type

    def launch_quick_tour_from_help(self, tester):
        """
        To launch FTUX from MENU -> SYSTEM & ACCOUNT -> Help -> Quick Tour, you need
        SKIP_FTUX=false in tcdui_test.conf (or just remote this property from the file)
        """
        self.log.step("Launching quick tour")
        self.go_to_system_info_screen(tester)
        self.select_menu_items(self.menu_labels.LBL_HELP)
        self.wait_for_screen_ready()
        self.select_menu_items(tester.home_labels.LBL_QUICK_TOUR)

    def go_to_disable_parental_controls_screen(self):
        self.select_menu(self.menu_labels.LBL_DISABLE_PARENTAL_CONTROLS)
        self.wait_for_screen_ready(self.menu_labels.LBL_DISABLE_PARENTAL_CONTROLS)

    def change_pin_from_usersettings(self, tester):
        self.select_menu(self.menu_labels.LBL_CHANGE_PIN)
        tester.menu_assertions.verify_current_PIN_overlay()
        self.enter_default_parental_control_password(tester)
        tester.menu_assertions.verify_new_PIN_overlay()
        self.enter_parental_control_password()
        tester.menu_assertions.verify_confirm_PIN_overlay()
        self.enter_parental_control_password()

    def navigate_to_subtitles_and_closed_captioning_language(self):
        self.log.step("Navigate to closed captioning language menu")
        self.nav_to_menu(self.menu_labels.LBL_SUBTITLE_CLOSED_CAPTION_LANGUAGE)

    def get_preview_text(self, refresh=False):
        actual_preview_text = self.get_preview_panel()['text']
        return actual_preview_text

    def is_always_require_pin_on(self):
        """
        :description:
            Checks if Always Require Pin is ON
            Parental Controls screen with options should be displayed to use this method
        :return:
            boolean
        """
        return self.__is_menu_option_having_expected_value(MenuLabels.LBL_ALWAYS_REQUIRE_PIN,
                                                           MenuLabels.LBL_OPTION_VALUE_ON)

    def toggle_always_require_pin(self, ON=True):
        self.log.info("always require pin {}".format(ON))
        self.select_menu_items(self.menu_labels.LBL_ALWAYS_REQUIRE_PIN)
        self.select_menu_items(self.menu_labels.LBL_ON if ON else self.menu_labels.LBL_OFF)

    def get_movie_rating(self):
        option_name = None
        if Settings.hydra_branch() > Settings.hydra_branch("b-hydra-streamer-1-11"):
            option_name = self.menu_labels.LBL_ALLOW_ALL_HIGHEST_ALLOWED_RATING
        else:
            option_name = self.menu_labels.LBL_ALLOW_ALL_HIGHEST_ALLOWED_MOVIE_RATING
        return option_name

    def get_tv_rating(self):
        option_name = None
        if Settings.hydra_branch() > Settings.hydra_branch("b-hydra-streamer-1-11"):
            option_name = self.menu_labels.LBL_ALLOW_ALL_HIGHEST_ALLOWED_RATING
        else:
            option_name = self.menu_labels.LBL_ALLOW_ALL_HIGHEST_ALLOWED_TV_RATING
        return option_name

    def go_to_subtitles_and_closed_captioning_language(self):
        self.log.step("Selecting closed captioning language menu")
        self.navigate_to_subtitles_and_closed_captioning_language()
        self.screen.base.press_enter()
        self.log.step("Selected closed captioning language menu successfully")

    def change_subtitle_language(self, language, refresh=False):
        self.go_to_subtitles_and_closed_captioning_language()
        self.wait_for_screen_ready()
        if refresh:
            self.screen.refresh()
        menuitem = self.get_menu_item()
        for item in menuitem:
            if language in item['text']:
                self.select_menu_items(language)
        self.log.info("Language is set to {}".format(language))

    def get_onepass_option_name(self, tester):
        option_name = None
        if not Settings.is_ndvr_applicable():
            option_name = tester.my_shows_labels.LBL_ONEPASS_OPTIONS
            return option_name
        if Settings.hydra_branch() > Settings.hydra_branch("b-hydra-streamer-1-9"):
            option_name = tester.my_shows_labels.LBL_ONEPASS_AND_RECORDING_OPTIONS
        else:
            option_name = tester.my_shows_labels.LBL_ONEPASS_OPTIONS
        return option_name

    def get_more_info_name(self, tester, vod_labels=False):
        option_name = None
        if Settings.hydra_branch() > Settings.hydra_branch("b-hydra-streamer-1-11"):
            option_name = tester.vod_labels.LBL_SEE_MORE_INFO
        elif vod_labels:
            option_name = tester.vod_labels.LBL_MORE_INFO
        else:
            option_name = tester.guide_labels.LBL_PROGRAM_OPTIONS_MORE_INFO
        return option_name

    def update_favorite_channels_list(self, tester):
        """
        Need to update favorite channels list after add/remove using API
        """
        self.go_to_user_preferences(tester)
        self.go_to_favorite_channels()

    def go_to_operator_features(self, tester):
        """
        This menu item is available 1.13 branch onwards.
        :param tester:
        :return:
        """
        self.log.step("Going to Settings->User Preferences-> Operator Features")
        self.go_to_user_preferences(tester)
        self.wait_for_screen_ready()
        self.select_menu(self.menu_labels.LBL_OPERATOR_FEATURES)

    def get_parental_control_menu_item_status(self, tester, item):
        self.log.info("going to parental control and check if {} option is available ".format(item))
        self.go_to_parental_controls(tester)
        default_pc_pin = self.get_default_pin(tester)
        self.screen.base.typeTextByKey(default_pc_pin)
        self.screen.refresh()
        menuitems = self.get_menu_item()
        for option in menuitems:
            if option['text'] == item:
                return True
        return False

    def check_uncheck_app(self, tester, app_list, check):
        self.go_to_video_providers(tester)
        if check:
            for app in app_list:
                self.checked_option(app)
        else:
            for app in app_list:
                if self.check_ott_text_in_dump(app):
                    self.unchecked_option(app)

    def go_to_help_stb(self, tester):
        self.log.step("Navigating to Help in STB")
        self.go_to_menu_screen(tester)
        self.select_menu_category(tester.menu_labels.LBL_HELP_SHORTCUT)
        self.screen.base.press_up()

    def go_to_account_system_info_stb(self, tester):
        self.log.step("Navigating to account & system info in STB")
        self.go_to_help_stb(tester)
        self.select_menu_items(self.menu_labels.LBL_ACCOUNT_SYSTEM_INFO_STB)

    def go_to_system_information_stb(self, tester):
        self.log.step("Navigating to system information in STB")
        self.go_to_account_system_info_stb(tester)
        self.select_menu_items(self.menu_labels.LBL_SYSTEM_INFORMATION)

    def go_to_system_information_in_system_and_account(self, tester):
        self.log.step("Navigating to Menu -> System & Account -> System Info -> System Information")
        self.go_to_system_info_screen(tester)
        self.go_to_system_info(tester)
        self.select_menu_items(tester.menu_labels.LBL_SYSTEM_INFORMATION)

    def go_to_channel_settings_stb(self, tester):
        device_mode = self.get_stb_mode(tester)
        if Settings.is_smartbox() and device_mode == "Mini":
            pytest.skip("Smartbox mini mode won't have channel settings option")
        else:
            self.log.step("Navigating to channel settings in STB")
            self.go_to_settings(tester)
            self.select_menu_items(self.menu_labels.LBL_CHANNEL_SETTINGS_STB)
            tester.menu_assertions.verify_channel_settings_screen_title_stb(self)

    def get_stb_mode(self, tester):
        self.log.info("Fetching Device mode")
        self.go_to_system_information_stb(tester)
        self.screen.refresh()
        mode = ""
        menuitem = self.screen.get_screen_dump_item('menuitem')
        for item in menuitem:
            if item['text'] == "Device Mode:":
                mode = item['option']['text']
        self.log.info(f"Device is in {mode} mode")
        return mode

    def go_to_remote_devices_conditionalaccess_cableCARD(self, tester, device_mode):
        self.go_to_settings(tester)
        if Settings.is_smartbox():
            self.log.info("Box is smartbox")
            if device_mode == "IP-STB" or "Mini":
                self.select_menu_items(self.menu_labels.LBL_REMOTE_DEVICES)
            else:
                self.select_menu_items(self.menu_labels.LBL_REMOTE_DEVICES_CONDITIONALACCESS_STB)
        elif Settings.is_topaz():
            self.log.info("Box is Topaz")
            if device_mode == "IP-STB":
                self.select_menu_items(self.menu_labels.LBL_REMOTE_DEVICES)
            else:
                self.select_menu_items(self.menu_labels.LBL_REMOTE_CABLECARD_DEVICE_STB)
        else:
            self.log.info("Box is dvr and not TOPAZ/SMARTBOX")
            self.select_menu_items(self.menu_labels.LBL_REMOTE_CABLECARD_DEVICE_STB)

    def go_to_system_diagnostics_screen_stb(self, tester):
        self.go_to_account_system_info_stb(tester)
        self.select_menu_items(tester.menu_labels.LBL_SYSTEM_DIAGNOSTICS_STB)

    def memory_stats(self, partition=None):
        sdcard_stats = None
        sdcard_stats = self.device_filesystem_stats(partition=partition)
        if sdcard_stats is not None:
            partition = list(sdcard_stats.keys())[0]
            sdcard_stats['data'] = sdcard_stats.pop(partition)
            sdcard_stats['data'].update({'partition': partition})
            Settings.sdcard_stats = sdcard_stats

    def go_to_system_info(self, tester):
        self.log.info("Navigating to system info")
        self.select_menu_items(tester.menu_labels.LBL_SYSTEM_INFO)

    def go_to_simulate_crash(self, tester):
        self.log.info("Navigating to Simulate Crash")
        self.select_menu_items(tester.menu_labels.LBL_SIMULATE_CRASH)

    def go_to_tombstone(self, tester):
        self.log.info("Navigating to tombstone crash")
        present_crash = 1
        tombstone_crash_position = 8
        while present_crash < tombstone_crash_position:
            self.screen.base.press_down()
            present_crash += 1
        self.screen.base.press_enter()

    def go_to_java_crash(self, tester):
        self.log.info("Navigating to Java crash")
        self.screen.base.press_enter()

    def go_to_anr_crash(self, tester):
        self.log.info("Navigating to ANR crash")
        present_crash = 1
        anr_crash_position = 9
        while present_crash < anr_crash_position:
            self.screen.base.press_down()
            present_crash += 1
        self.screen.base.press_enter()

    def get_legal_acceptance_fields_details(self):
        """
        To get information about 'Personalized Ads' and 'Viewership Data Sharing' menuitems in USER PREFERENCES
        return: dict, example {"Personalized Ads": "On", "Viewership Data Sharing": "On"}
        """
        details = {}
        for item in self.get_menu_item():
            if item['text'] == self.menu_labels.LBL_PERSONALIZED_ADS \
                    or item['text'] == self.menu_labels.LBL_VIEWERSHIP_DATA_SHARING:
                details[item['text']] = item['option']['text'].replace('[ ', '').replace(' ]', '')
        return details

    def get_personalized_ads_status(self):
        """
        To get status Allow/Do Not Allow of 'Personalized Ads' menuitem in USER PREFERENCES
        return: bool
        """
        details = self.get_legal_acceptance_fields_details()
        try:
            status = details.get(self.menu_labels.LBL_PERSONALIZED_ADS).replace('[ ', '').replace(' ]', '')
            return status == self.menu_labels.LBL_ALLOW
        except LookupError:
            raise LookupError("Personalized Ads is not shown in User Preferences.")

    def get_personal_data_sharing_status(self):
        """
        To get status Allow/Do Not Allow of 'Viewership Data Sharing' menuitem in USER PREFERENCES
        return: bool
        """
        details = self.get_legal_acceptance_fields_details()
        try:
            status = details.get(self.menu_labels.LBL_VIEWERSHIP_DATA_SHARING)
            return status == self.menu_labels.LBL_ALLOW
        except LookupError:
            raise LookupError("Viewership Data Sharing is not shown in User Preferences.")

    def set_personalized_ads_status(self, enable=True):
        """
        To set status Allow/Do Not Allow for 'Personalized Ads' in USER PREFERENCES
        enable=True to set Allow, default
        enable=False to set Do Not Allow
        """
        status = self.get_personalized_ads_status()
        if status == enable:
            self.log.info(f"No changes is needed, Personalized Ads status is '{status}'.")
        else:
            item = self.menu_labels.LBL_ALLOW_PERSONALIZED_ADS if enable \
                else self.menu_labels.LBL_DO_NOT_ALLOW_PERSONALIZED_ADS
            self.select_menu(self.menu_labels.LBL_PERSONALIZED_ADS)
            self.select_menu(item)

    def set_personal_data_sharing_status(self, enable=True):
        """
        To set status Allow/Do Not Allow for 'Viewership Data Sharing' in USER PREFERENCES
        enable=True to set Allow, default
        enable=False to set Do Not Allow
        """
        status = self.get_personal_data_sharing_status()
        if status == enable:
            self.log.info(f"No changes is needed, Viewership Data Sharing status is '{status}'.")
        else:
            item = self.menu_labels.LBL_ALLOW_DATA_SHARING if enable \
                else self.menu_labels.LBL_DO_NOT_ALLOW_DATA_SHARING
            self.select_menu(self.menu_labels.LBL_VIEWERSHIP_DATA_SHARING)
            self.select_menu(item)

    def nav_menu_items(self, item):
        """
        Navigate to items in settings(navigate only)
        """
        self.screen.refresh()
        focus_index = self.return_menu_focus_index()
        item_index = self.substring_index(self.menu_list(), item)
        self.log.info("findex: {} item_index: {}".format(item_index, focus_index))
        self.menu_navigate_up_down(focus_index, item_index)

    def go_to_assert_restart(self, tester):
        self.log.info("Navigating to Assert restart")
        present_crash = 1
        assertRestart_position = 4
        while present_crash < assertRestart_position:
            self.screen.base.press_down()
            present_crash += 1
        self.screen.base.press_enter()

    def go_to_assert_crash(self, tester):
        self.log.info("Navigating to Assert crash")
        present_crash = 1
        assert_position = 3
        while present_crash < assert_position:
            self.screen.base.press_down()
            present_crash += 1
        self.screen.base.press_enter()

    def go_to_anr_outOfMemory(self, tester):
        self.log.info("Navigating to ANR outOfMemory")
        present_crash = 1
        outOfMemory_position = 7
        while present_crash < outOfMemory_position:
            self.screen.base.press_down()
            present_crash += 1
        self.screen.base.press_enter()

    def go_to_haxeAppDied(self, tester):
        self.log.info("Navigating to Haxe App Died")
        present_crash = 1
        HaxeDied_position = 6
        while present_crash < HaxeDied_position:
            self.screen.base.press_down()
            present_crash += 1
        self.screen.base.press_enter()

    def go_to_haxe_app(self, tester):
        self.log.info("Navigating to Haxe App")
        present_crash = 1
        haxe_position = 2
        while present_crash < haxe_position:
            self.screen.base.press_down()
            present_crash += 1
        self.screen.base.press_enter()

    def go_to_assert_continue(self, tester):
        self.log.info("Navigating to assert continue")
        present_crash = 1
        assert_continue = 5
        while present_crash < assert_continue:
            self.screen.base.press_down()
            present_crash += 1
        self.screen.base.press_enter()

    def format_mso_name(self, mso):
        vod = self.menu_labels.LBL_VOD
        if vod in mso:
            mso = mso[:-3]
            return mso + vod
        else:
            return mso

    def modify_onepass_recording_options_from_user_preference_option(self, tester, record=None, keep_at_most=None,
                                                                     keep_until=None):
        """
        This function helps you to modify onepass and recording options.
        """
        self.log.info("Modifying onepass and recording options: ")
        if record:
            self.nav_to_menu(tester.guide_labels.LBL_RECORD_MENU)
            tester.menu_page.nav_to_item_option(record)
        if keep_at_most:
            self.nav_to_menu(tester.guide_labels.LBL_KEEP_AT_MOST_MENU)
            tester.menu_page.nav_to_item_option(keep_at_most)
        if keep_until:
            self.nav_to_menu(tester.guide_labels.LBL_KEEP_UNTIL_MENU)
            tester.menu_page.nav_to_item_option(keep_until)

    def get_mso_name(self, tester):
        """
        This function gets MSO name through branding value
        """
        branding_value = self.service_api.branding_ui()
        mso = None
        if branding_value:
            mso_name = branding_value.distributor_name.get('value')
            mso = self.format_mso_name(mso_name)
        return mso

    def is_pc_is_on_unlocked(self):
        """
        : Description :
            Checks if Parental Controls = [ On - Unlocked]
        : return
            Boolean
        """
        return self.__is_menu_option_having_expected_value(MenuLabels.LBL_PARENTAL_CONTROLS_SHORTCUT,
                                                           MenuLabels.LBL_PARENTAL_CONTROLS_VALUE_ONUNLOCK)

    def go_to_system_diagnostics(self, tester):
        self.log.step("Navigating to system diagnostics")
        self.go_to_system_info_screen(tester)
        self.go_to_system_info(tester)
        self.select_menu_items(tester.menu_labels.LBL_SYSTEM_DIAGNOSTICS)

    def add_channel_to_favorites(self):
        """
        adds focused channel to favorites if not in favorite channels
        """
        if self.menu_labels.LBL_CHECKED not in self.menu_item_image_focus():
            self.screen.base.press_enter()
        else:
            self.log.info("channel is already in favorites")

    def check_ott_text_in_dump(self, ott_app):
        found_ott = False
        count = 0
        while count < 3 and not found_ott:
            self.screen.refresh()
            menuitems = self.get_menu_item()
            for option in menuitems:
                if option['text'] == ott_app:
                    found_ott = True
                    break
            else:
                for i in range(len(menuitems)):
                    self.log.info(f"Going to  for loop  {i} time")
                    self.screen.base.press_down()
                count += 1
        return found_ott

    def select_provider_on_all_streaming_options_overlay(self, content_id, vp_partner_id, availability=None,
                                                         label=None, _screen="other"):
        """
        Menu items on All Streaming Options overlay are prepared in a bit different way, not like standard menus,
        so we need a specific handling for selecting a particular provider

        Args:
            content_id (str): e.g. tivo:ct.438764951
            vp_partner_id (str): e.g. tivo:pt.4576
            availability (str): e.g. 'Included with your subscription' or 'HD $3';
                                Note: if None, the 1st offer with vp_partner_id is taken (consider label)
            label (str): label to select, e.g. 'Purchase on VUDU' or just 'Netflix', or just 'Rent on' etc.;
                         Note: if None, the 1st offer with vp_partner_id is taken (consider availability)
            _screen (str): screen name the overlay was reached from e.g. entered program screen from Guide;
                           one of (guide, other); logic may differ depending on screen
        """
        self.log.info(f"Selecting '{vp_partner_id}' ('{label}' label) provider with '{availability}' availability "
                      "on All Streaming Options overlay")
        reached_from_guide_screen = _screen.lower() == "guide"
        exclude_socu_partner_id = socu_partner_id[Settings.mso] if reached_from_guide_screen else None
        vod_ott_list = self.service_api.get_vod_ott_action_details(content_id, exclude_socu_partner_id, True)
        menu_list = self.menu_list()
        # Let's find indexes of items that match vp_partner_id
        items_position_list = []  # there may be several offers from one provider e.g. Rent on Vudu, Purchase on Vudu
        for index in range(0, len(vod_ott_list)):
            if vp_partner_id == vod_ott_list[index].partner_id:
                items_position_list.append(index)
        position_on_ui = None
        for position in items_position_list:
            menu_item_row = menu_list[position]
            provider_label = menu_item_row[0]
            if label and label in provider_label and availability in menu_item_row or \
               not label and availability in menu_item_row:
                position_on_ui = position
                break
        for pos in range(position_on_ui):
            self.press_down_button(refresh=False)
        self.press_ok_button(refresh=False)
