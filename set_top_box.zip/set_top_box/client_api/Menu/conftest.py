import configparser

import pytest

from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.client_api.my_shows.assertions import MyShowsAssertions
from set_top_box.client_api.apps_and_games.assertions import AppsAndGamesAssertions
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.client_api.guide.assertions import GuideAssertions
from set_top_box.client_api.VOD.assertions import VODAssertions
from set_top_box.test_settings import Settings
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from tools.logger.logger import Logger
from core_api.stb.base import StreamerBase

__logger = Logger(__name__)


@pytest.fixture(autouse=True, scope="class")
def setup_menu(request):
    """
    Configure steps to be executed before the test cases run
    :param request:
    :return:
    """
    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_labels = request.cls.home_page.home_labels = LabelFactory("home", Settings)
    request.cls.home_page.home_labels = request.cls.home_labels
    request.cls.home_assertions = HomeAssertions(request.cls.screen)
    request.cls.home_assertions.home_page = request.cls.home_page

    request.cls.acc_locked_page = PageFactory("account_locked", Settings, request.cls.screen)

    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)
    request.cls.menu_labels = request.cls.menu_page.menu_labels = LabelFactory("Menu", Settings)
    request.cls.menu_page.menu_labels = request.cls.menu_labels

    request.cls.my_shows_labels = LabelFactory("my_shows", Settings)
    request.cls.my_shows_page = PageFactory("my_shows", Settings, request.cls.screen)
    request.cls.my_shows_assertions = MyShowsAssertions(request.cls.screen)

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)
    request.cls.guide_page.guide_labels = request.cls.guide_labels
    request.cls.guide_assertions.guide_labels = request.cls.guide_labels
    request.cls.home_page.guide_page = request.cls.guide_page

    request.cls.watchvideo_assertions = WatchVideoAssertions(request.cls.screen)
    request.cls.watchvideo_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.watchvideo_labels = request.cls.liveTv_labels = LabelFactory("watchvideo", Settings)

    request.cls.vod_page = PageFactory("VOD", Settings, request.cls.screen)
    request.cls.vod_assertions = VODAssertions(request.cls.screen)
    request.cls.vod_labels = request.cls.vod_page.vod_labels = LabelFactory("VOD", Settings)

    request.cls.apps_and_games_page = PageFactory("apps_and_games", Settings, request.cls.screen)
    request.cls.apps_and_games_assertions = AppsAndGamesAssertions(request.cls.screen)
    request.cls.apps_and_games_labels = LabelFactory("apps_and_games", Settings)

    request.cls.text_search_page = PageFactory("text_search", Settings, request.cls.screen)

    request.cls.wtw_page = PageFactory("wtw", Settings, request.cls.screen)

    request.cls.base = StreamerBase(request.cls.screen)

    request.getfixturevalue('pre_run_setup')  # should be run before other fixtures
    request.getfixturevalue('device_reboot_to_imporve_device_perf')
    request.getfixturevalue('clean_ftux_and_sign_in')
    request.getfixturevalue('disable_parental_controls')


def get_flat_list(list_recevied):
    strip_list = []
    for item in list_recevied:
        if type(item) == list:
            strip_list.extend(item)
        else:
            strip_list.append(item)
    return strip_list


@pytest.fixture(autouse=False, scope="function")
def setup_parental_control(request):
    __logger.info("Setup. Disable Parental Controls PIN, if set")
    request.cls.home_page.back_to_home_short()
    if (request.cls.home_labels.LBL_MENU_LOCK_SHORTCUT_ICON in get_flat_list(request.cls.menu_page.strip_list_type
                                                                             ("imagename"))):
        is_lock_menu_icon = True
        is_unlock_image = False
    elif (request.cls.home_labels.LBL_MENU_UNLOCK_SHORTCUT_ICON in
          get_flat_list(request.cls.menu_page.strip_list_type("imagename"))):
        is_lock_menu_icon = True
        is_unlock_image = True
    else:
        is_lock_menu_icon = False
    if is_lock_menu_icon:
        if not is_unlock_image:
            request.cls.home_page.select_menu_shortcut(request.cls.home_labels.LBL_MENU_LOCK_SHORTCUT)
        else:
            request.cls.home_page.select_menu_shortcut(request.cls.home_labels.LBL_MENU_UNLOCK_SHORTCUT)
        request.cls.menu_page.nav_to_top_of_list()
        request.cls.menu_page.select_menu_category(request.cls.menu_labels.LBL_SETTINGS_SHORTCUT)
        request.cls.menu_page.select_menu_items(request.cls.menu_page.get_parental_controls_menu_item_label())
        if request.cls.menu_page.is_parental_control_enabled():
            request.cls.menu_page.enter_default_parental_control_password(request.cls)
            request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_DISABLE_PARENTAL_CONTROLS)
            request.cls.menu_page.enter_default_parental_control_password(request.cls)


@pytest.fixture(autouse=False, scope="function")
def setup_lock_parental_and_purchase_controls(request):
    request.cls.menu_page.turnonpcsettings(request.cls, "on", "off")
    request.cls.menu_page.toggle_hide_adult_content()
    request.cls.menu_page.go_to_set_rating_limit(request.cls)
    request.cls.menu_page.set_rating_limits(rated_movie=request.cls.menu_labels.LBL_BLOCK_ALL_RATED,
                                            rated_tv_show=request.cls.menu_labels.LBL_BLOCK_ALL_RATED,
                                            unrated_tv_show=request.cls.menu_labels.LBL_BLOCK_ALL_UNRATED,
                                            unrated_movie=request.cls.menu_labels.LBL_BLOCK_ALL_UNRATED)
    request.cls.menu_page.menu_press_back()
    request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_PARENTAL_CONTROLS_MENUITEM)


@pytest.fixture(autouse=False, scope="function")
def setup_parental_controls_and_always_require_pin(request):
    request.cls.menu_page.turnonpcsettings(request.cls, "on", "off")
    request.cls.menu_page.toggle_hide_adult_content()
    request.cls.menu_page.go_to_set_rating_limit(request.cls)
    request.cls.menu_page.set_rating_limits(rated_movie=request.cls.menu_labels.LBL_BLOCK_ALL_RATED,
                                            rated_tv_show=request.cls.menu_labels.LBL_BLOCK_ALL_RATED,
                                            unrated_tv_show=request.cls.menu_labels.LBL_BLOCK_ALL_UNRATED,
                                            unrated_movie=request.cls.menu_labels.LBL_BLOCK_ALL_UNRATED)
    request.cls.menu_page.menu_press_back()
    request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_ALWAYS_REQUIRE_PIN)
    request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_ON)
    request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_PARENTAL_CONTROLS_MENUITEM)


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_parental_and_purchase_controls(request):
    """
    :description:
        Clearing of Parental Controls and Purchase Controls after running a test,
        handles Parental Controls and Parental & Purchase Controls menu shortcuts
    """
    def tear_down():
        __logger.info("Tearing down. Clearing the Parental Controls / Parental & Puchase Controls")
        request.cls.home_page.back_to_home_short()
        request.cls.menu_page.screen.refresh()
        request.cls.home_assertions.verify_screen_title(request.cls.home_labels.LBL_HOME_SCREENTITLE)
        is_unlock_menu_icon = True
        is_lock_menu_icon = True
        if request.cls.home_page.is_in_strip(request.cls.home_labels.LBL_MENU_UNLOCK_SHORTCUT_ICON, "in") is False:
            is_unlock_menu_icon = False
        if request.cls.home_page.is_in_strip(request.cls.home_labels.LBL_MENU_LOCK_SHORTCUT_ICON, "in") is False:
            is_lock_menu_icon = False
        if is_unlock_menu_icon or is_lock_menu_icon:
            request.cls.home_page.select_strip(request.cls.home_labels.LBL_MENU_SHORTCUT)
        else:
            __logger.info("Parental Lock not available! Teardown dismissed!")
            return
        request.cls.menu_page.nav_to_top_of_list()
        request.cls.menu_page.select_menu_category(request.cls.menu_labels.LBL_SETTINGS_SHORTCUT)
        request.cls.menu_page.select_menu_items(request.cls.menu_page.get_parental_controls_menu_item_label())
        request.cls.menu_page.enter_default_parental_control_password(request.cls)
        request.cls.menu_page.wait_for_screen_ready(request.cls.menu_page.get_parental_controls_menu_item_label())

        # Setting Hide Adult Content to defaults (No)
        if request.cls.menu_page.is_hide_adult_content_on():
            request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_HIDE_ADULT_CONTENT)
            request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_DONT_HIDE_ADULT_CONTENT)
        # Setting Set Rating Limits to defaults (All Ratings Allowed)
        movie_rating = request.cls.menu_page.get_highest_movie_rating()
        tv_rating = request.cls.menu_page.get_highest_tv_rating()
        request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_SET_RATING_LIMITS)
        request.cls.menu_page.set_rating_limits(rated_movie=movie_rating,
                                                rated_tv_show=tv_rating,
                                                unrated_tv_show=request.cls.menu_labels.LBL_ALLOW_ALL_UNRATED,
                                                unrated_movie=request.cls.menu_labels.LBL_ALLOW_ALL_UNRATED)

        request.cls.menu_page.menu_press_back()
        # Setting Purchase Controls to defaults (No)
        if request.cls.service_api.check_groups_enabled(request.cls.menu_labels.LBL_PURCHASE_GROUP)\
                and request.cls.menu_page.is_purchase_controls_on():
            request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_PURCHASE_CONTROLS)
            request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_PURCHASE_WITHOUTPIN_MENU)
            request.cls.menu_page.enter_default_parental_control_password(request.cls)
        # Setting Always Require PIN to defaults (No)
        if request.cls.menu_page.is_always_require_pin_on():
            request.cls.menu_page.toggle_always_require_pin(ON=False)
        request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_DISABLE_PARENTAL_CONTROLS)
        request.cls.menu_page.enter_default_parental_control_password(request.cls)
    tear_down()
    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="class")
def disable_parental_controls(request):
    """
    :description:
    Disabling of Parental and Purchase Controls before and after running a test.
    """
    def setup():
        if not request.config.getoption('skip_pc_check'):
            if Settings.is_android_tv() or Settings.is_apple_tv():
                __logger.info("Starting to disable PARENTAL CONTROLS")
                if Settings.is_unmanaged() and not request.cls.screen.base.verify_foreground_app(Settings.app_package):
                    request.cls.driver.driver.launch_app(Settings.app_package)
                request.cls.home_page.back_to_home_short()
                request.cls.home_page.screen.refresh()
                request.cls.home_page.dismiss_popup_overlay(request.cls)
                strip_list_full = request.cls.screen.screen_dump["xml"]["stripitem"]
                is_unlock_menu_icon = True if str(request.cls.home_labels.LBL_MENU_UNLOCK_SHORTCUT_ICON) in str(
                    strip_list_full) else False
                is_lock_menu_icon = True if str(request.cls.home_labels.LBL_MENU_LOCK_SHORTCUT_ICON) in str(
                    strip_list_full) else False
                if (is_unlock_menu_icon or is_lock_menu_icon):
                    request.cls.home_page.select_menu_shortcut_num(request.cls, request.cls.home_labels.LBL_MENU_SHORTCUT)
                    request.cls.menu_page.wait_for_screen_ready(request.cls.menu_labels.LBL_MENU_TITLE)
                    request.cls.home_assertions.verify_screen_title(request.cls.menu_labels.LBL_MENU_TITLE)
                else:
                    __logger.info("Parental Lock not available! Teardown dismissed!")
                    return
                request.cls.menu_page.nav_to_top_of_list()
                request.cls.menu_page.select_menu_category(request.cls.menu_labels.LBL_SETTINGS_SHORTCUT)
                request.cls.menu_page.select_menu(request.cls.menu_page.get_parental_controls_menu_item_label())
                request.cls.menu_page.enter_default_parental_control_password(request.cls)
                request.cls.menu_page.wait_for_screen_ready("SettingsParental")
                request.cls.menu_page.screen.refresh()
                request.cls.menu_page.select_menu(request.cls.menu_labels.LBL_DISABLE_PARENTAL_CONTROLS)
                request.cls.menu_page.enter_default_parental_control_password(request.cls)
    setup()
    request.addfinalizer(setup)


@pytest.fixture(autouse=False, scope="function")
def enable_netflix(request):
    """
        :description:
        Enable netflix in Video provider list
        """
    def setup():
        request.cls.menu_page.go_to_video_providers(request.cls)
        request.cls.menu_page.unchecked_option(request.cls.menu_labels.LBL_NETFLIX)
    request.addfinalizer(setup)


@pytest.fixture(autouse=False, scope="function")
def disable_video_window(request):
    """
    Disable Video Window before test execution and enable after test is complete
    """
    def video_window(turn=''):
        __logger.info(f"Turning Video window '{turn}'.")
        request.cls.home_page.back_to_home_short()
        if turn == request.cls.menu_labels.LBL_OFF and request.cls.menu_page.get_video_window_status():
            request.cls.home_page.back_to_home_short()
            request.cls.home_page.select_menu_shortcut_num(request.cls, request.cls.home_labels.LBL_MENU_SHORTCUT)
            request.cls.menu_page.nav_to_top_of_list()
            request.cls.menu_page.select_menu(request.cls.menu_labels.LBL_USER_PREFERENCES_SHORTCUT)
            request.cls.menu_page.select_menu(request.cls.menu_labels.LBL_VIDEO_BACKGROUND)
            request.cls.menu_page.nav_to_menu(request.cls.menu_labels.LBL_DISPLAY_VIDEO)
            request.cls.menu_page.nav_to_item_option(request.cls.menu_labels.LBL_NO)
            request.cls.menu_page.press_back_button()
        elif turn == request.cls.menu_labels.LBL_ON and not request.cls.menu_page.get_video_window_status():
            request.cls.home_page.back_to_home_short()
            request.cls.home_page.select_menu_shortcut_num(request.cls, request.cls.home_labels.LBL_MENU_SHORTCUT)
            request.cls.menu_page.nav_to_top_of_list()
            request.cls.menu_page.select_menu(request.cls.menu_labels.LBL_USER_PREFERENCES_SHORTCUT)
            request.cls.menu_page.select_menu(request.cls.menu_labels.LBL_VIDEO_BACKGROUND)
            request.cls.menu_page.nav_to_menu(request.cls.menu_labels.LBL_DISPLAY_VIDEO)
            request.cls.menu_page.nav_to_item_option(request.cls.menu_labels.LBL_YES)
            request.cls.menu_page.press_back_button()
        else:
            __logger.info(f"Video Window is already turned '{turn}'")
    video_window(turn=request.cls.menu_labels.LBL_OFF)
    yield
    video_window(turn=request.cls.menu_labels.LBL_ON)


@pytest.fixture(autouse=False, scope="function")
def setup_enable_video_window(request):
    """
    Enable Video Window before test execution starts
    """
    request.cls.menu_page.enable_video_window(request.cls)


@pytest.fixture(autouse=False, scope='function')
def setup_enable_full_screen_video_on_home(request):
    """
    Enable video window to be in a full screen mode on Home page
    """
    request.cls.menu_page.enable_full_screen_video_on_home(request.cls)


@pytest.fixture(autouse=False, scope='function')
def setup_enable_top_right_video_window_on_home(request):
    """
    Enable video window to be in a window mode on Home page
    """
    request.cls.menu_page.enable_top_right_video_window_on_home_page(request.cls)


@pytest.fixture(autouse=False, scope='function')
def setup_enable_atmospheric_home_background(request):
    """
    Enable home background
    """
    request.cls.menu_page.enable_background_atmospheric_image(request.cls)


@pytest.fixture(autouse=False, scope="function")
def setup_disable_closed_captioning(request):
    """
    Disable closed captioning during setup
    """
    request.cls.menu_page.disable_closed_captioning(request.cls)


@pytest.fixture(autouse=False, scope="function")
def setup_enable_closed_captioning(request):
    """
    Enable closed captioning during setup
    """
    request.cls.menu_page.enable_closed_captioning(request.cls)


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_disable_closed_captioning(request):
    """
    Disable closed captioning during cleanup
    """
    def tear_down():
        request.cls.menu_page.disable_closed_captioning(request.cls)
    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def disable_video_providers(request):
    """
    Disable video providers in Video provider list
    """
    __logger.info("Setup: Disabling video providers")
    if not Settings.is_fire_tv():
        request.cls.menu_page.go_to_video_providers(request.cls)
        request.cls.menu_page.check_or_uncheck_all_menu_items(uncheck=True)


@pytest.fixture(autouse=False, scope="function")
def enable_video_providers(request):
    """
    Enable video providers in Video provider list
    """
    def tear_down():
        __logger.info("Tearing down. enable video providers in Video provider list")
        if not Settings.is_fire_tv():
            request.cls.menu_page.go_to_video_providers(request.cls)
            request.cls.menu_page.check_or_uncheck_all_menu_items()
    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope='function')
def exit_OTT(request):
    yield
    for i in range(2):
        request.cls.watchvideo_assertions.press_exit_button()


@pytest.fixture(autouse=False, scope="function")
def push_parental_controls__from_pps_with_adult_content_true(request):

    """
    Remove Parental controls if exits and push default parental controls.
    Except HideAdult : True

    """
    __logger.info("*****************push_parental_controls__from_pps_with_adult_content_true*************")
    request.cls.pps_api_helper.disable_pc_setting_from_pps(Settings.ca_device_id)
    request.cls.pps_api_helper.enable_parental_settings_from_pps(ca_device_id=Settings.ca_device_id)
    __logger.info("*****************push_parental_controls__from_pps_with_adult_content_true************")


@pytest.fixture(autouse=False, scope="function")
def push_parental_controls__from_pps_with_movie_rating_block_all_tv_rating_block_all(request):

    """
    docs:https://wiki.tivo.com/wiki/SODI_Partner_Provisioning#A_locksLimitsRating_object
        genericRatingLimits:
            MPAA.G, MPAA.PG, MPAA.PG13, MPAA.R, MPAA.NC17
            TV.Y, TV.Y7, TV.G, TV.PG, TV.14, TV.MA

    """
    __logger.info("***push_parental_controls__from_pps_with_movie_rating_block_all_tv_rating_block_all***")
    block_all_movies_tv_shows = 'MPAA.G, TV.Y'
    request.cls.pps_api_helper.enable_parental_settings_from_pps(ca_device_id=Settings.ca_device_id,
                                                                 generic_rating_limits=block_all_movies_tv_shows)
    __logger.info("***push_parental_controls__from_pps_with_movie_rating_block_all_tv_rating_block_all*****")


@pytest.fixture(autouse=False, scope="function")
def remove_parental_controls__from_pps(request):

    """
    Remove Parental controls if exits.

    """
    def tear_down():
        __logger.info("*****************remove_parental_controls__from_pps*************")
        request.cls.home_page.back_to_home_short()
        request.cls.menu_page.go_to_settings(request.cls)
        request.cls.menu_page.select_menu_category(request.cls.menu_labels.LBL_SETTINGS_SHORTCUT)
        request.cls.menu_page.select_menu_items(request.cls.menu_page.get_parental_controls_menu_item_label())
        request.cls.menu_assertions.verify_enter_PIN_overlay()
        request.cls.menu_page.enter_default_parental_control_password(request.cls)
        parental_control = request.cls.menu_page.get_parental_controls_menu_item_label()
        request.cls.menu_page.select_menu(parental_control)
        request.cls.menu_page.wait_for_screen_ready(parental_control)
        if request.cls.service_api.check_groups_enabled(request.cls.menu_labels.LBL_PURCHASE_GROUP)\
                and request.cls.menu_page.is_purchase_controls_on():
            request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_PURCHASE_CONTROLS)
            request.cls.menu_assertions.verify_enter_PIN_overlay()
            request.cls.menu_page.enter_default_parental_control_password(request.cls)
            request.cls.menu_page.select_menu_items(request.cls.menu_labels.LBL_PURCHASE_WITHOUTPIN_MENU)
            request.cls.menu_page.enter_default_parental_control_password(request.cls)
        request.cls.menu_page.go_to_disable_parental_controls_screen()
        request.cls.menu_assertions.verify_enter_PIN_overlay()
        request.cls.menu_page.enter_default_parental_control_password(request.cls)
        request.cls.home_page.back_to_home_short()

        __logger.info("*****************remove_parental_controls__from_pps************")
    request.addfinalizer(tear_down)


@pytest.fixture()
def enable_tts(request):
    """
    Enable Text to Speech(TTS) in the beginning of the test case and disable TTS at the end.
    """
    __logger.info('enabling of TTS')
    request.cls.screen.base.TTS_on_off(tts=True)
    yield
    request.cls.screen.base.TTS_on_off()
    __logger.info("disabling of TTS")


@pytest.fixture(autouse=False, scope="function")
def setup_cleanup_remove_playback_source(request):
    """
    The url from the play_url will be removed.
    """
    def tear_down():
        __logger.info("Tearing down. Removing the URL from the play_url")
        request.cls.guide_page.set_playback_source()
    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False)
def cleanup_favorite_channels(request):
    """
    Cleanup favorite channels and switch off favorite channel filter in guide
    """
    def tear_down():
        try:
            __logger.info('Switching off guide filter')
            request.cls.api.remove_favorite_channel()
            request.cls.menu_page.update_favorite_channels_list(request.cls)
            request.cls.menu_assertions.verify_favorite_channels_screen_title()
            request.cls.home_page.back_to_home_short()
            request.cls.home_assertions.verify_home_title()
            request.cls.home_assertions.verify_menu_item_available(request.cls.home_labels.LBL_GUIDE_SHORTCUT)
            request.cls.home_page.select_menu_shortcut(request.cls.home_labels.LBL_GUIDE_SHORTCUT)
            request.cls.guide_assertions.verify_guide_title()
            if request.cls.guide_page.get_channels_list_mode() != 'all channels':
                if not request.cls.guide_page.is_menu_list():
                    request.cls.guide_page.press_ok_button()
                    assert request.cls.guide_page.is_menu_list()
                else:
                    request.cls.guide_page.switch_channel_option("All")
                    request.cls.guide_assertions.verify_channels_list_mode('all channels')
        except Exception:
            __logger.info("Failed to switch off guide filter")
    request.addfinalizer(tear_down)


@pytest.fixture(autouse=False, scope="function")
def exit_overlay(request):
    if request.cls.base.is_overlay_shown():
        request.cls.screen.base.press_back()


@pytest.fixture(autouse=False, scope="function")
def set_one_pass_record_option_to_new_only(request):
    """
    set one pass record options to new only under user preferences
    """
    def setup():
        __logger.step("setting one pass - record option to default 'new only' option")
        request.cls.menu_page.go_to_user_preferences(request.cls)
        request.cls.menu_page.wait_for_screen_ready()
        if request.cls.menu_page.is_in_menu(request.cls.guide_labels.LBL_ONEPASS_AND_RECORDING_OPTIONS):
            request.cls.menu_page.select_menu(request.cls.guide_labels.LBL_ONEPASS_AND_RECORDING_OPTIONS)
            request.cls.menu_page.wait_for_screen_ready()
        request.cls.menu_page.nav_to_menu(request.cls.guide_labels.LBL_RECORD_MENU)
        request.cls.menu_page.nav_to_item_option(request.cls.guide_labels.LBL_NEW_ONLY)
    setup()
