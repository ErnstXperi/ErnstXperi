from .labels import MenuLabels


class CablecoMenuLabels(MenuLabels):
    LBL_WATCH_NOW_FROM_SOCU = "Watch now from Cableco SOCU"
    LBL_WATCH_NOW_FROM_STARTOVER = "Watch now from Start Over"
    LBL_WATCH_NOW_FROM_CATCHUP = "Watch now from Catch Up"
    LBL_CATCH_UP_ICON = "cableco_image_primary_branding_live_tv_catch_up_60x60.png"
    LBL_ENABLE_SOCU = "Enable Cableco SOCU"
    LBL_DISABLE_SOCU = "Disable Cableco SOCU"
    LBL_ENABLE_CATCHUP = "Enable Cableco CATCHUP"
    LBL_ONDEMAND_SOURCE_ICON = "cableco_icon_source_D0_50x50.png"
