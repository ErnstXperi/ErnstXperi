from .labels import MenuLabels


class CBTMenuLabels(MenuLabels):
    LBL_WATCH_NOW_FROM_SOCU = "watch now from CBTDev SOCU"
    LBL_CATCH_UP_ICON = "altav2_fioptics_image_socu_branding_live_tv"
