from .labels import MenuLabels


class FireTVLabels(MenuLabels):

    LBL_TIPS_TRICKS = "Tips & Tricks"
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR1 = "To watch short videos that will help you get the most out of your "
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR2 = ", go to YouTube and search for "
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR3 = " or visit "
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR4 = "."

    def __init__(self):
        super().__init__()
        self.USER_PREFERENCES_OPTIONS = ["Favorite Channels", "OnePass & Recording Options", "My Shows Options",
                                         "Autoplay Next Episode", "Video Window & Background"]
        self.LBL_SYSTEM_AND_ACCOUNT_MENU_ITEMS = [self.LBL_HELP, self.LBL_TIPS_TRICKS, self.LBL_SYSTEM_INFO]
        self.SETTINGS_OPTIONS = [self.LBL_ACCESSIBILITY, self.LBL_ONEPASS_MANAGER, self.LBL_TODO_LIST,
                                 self.LBL_USER_PREFERENCES,
                                 self.LBL_PARENTAL_CONTROLS, self.LBL_AUDIO_SETTINGS]
