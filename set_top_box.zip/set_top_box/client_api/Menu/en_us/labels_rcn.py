from .labels import MenuLabels


class RCNMenuLabels(MenuLabels):
    LBL_WATCH_NOW_FROM_SOCU = "Watch now from Restart/Catchup"
    LBL_WATCH_NOW_FROM_STARTOVER = "Watch now from Restart/Catchup"
    LBL_WATCH_NOW_FROM_CATCHUP = "Watch now from Restart/Catchup"
    LBL_CATCH_UP_ICON = "hydra_icon_source_socu_50x50.png"
#    LBL_ALLOW_ALL_HIGHEST_ALLOWED_MOVIE_RATING = "Allow all except Adult"
#    LBL_ALLOW_ALL_HIGHEST_ALLOWED_TV_RATING = "Allow all except Adult"
    LBL_START_OVER = "Restart"
