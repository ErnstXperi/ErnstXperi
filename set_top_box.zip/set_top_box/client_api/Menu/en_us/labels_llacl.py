class LLACLMenuLabels():
    LBL_HIGHEST_ALLOWED_CLASIFICASION = "Highest allowed Clasificacion:"
