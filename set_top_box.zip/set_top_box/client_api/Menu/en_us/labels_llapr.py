from .labels import MenuLabels


class LLAMenuLabels(MenuLabels):
    LBL_SYSTEM_INFO = "Account & System Info"
    LBL_WATCH_NOW_FROM_SOCU = "Watch now from Replay"

    def __init__(self):
        super().__init__()
        self.SETTINGS_OPTIONS_MANAGED = [self.LBL_ACCESSIBILITY, self.LBL_ONEPASS_MANAGER, self.LBL_TODO_LIST,
                                         self.LBL_USER_PREFERENCES,
                                         self.LBL_PARENTAL_CONTROLS_SHORTCUT, self.LBL_AUDIO_SETTINGS,
                                         self.LBL_REMOTE_SETTINGS, self.LBL_DEVICE_SETTINGS]
