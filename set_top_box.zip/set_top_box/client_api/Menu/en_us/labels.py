from set_top_box.test_settings import Settings
from set_top_box.conf_constants import HydraBranches


class MenuLabels(object):
    LBL_MENU_TITLE = "MENU"
    LBL_MENU_SCREEN = "TiVoMenuScreen"
    LBL_MENU_MAIN_STRIP_LIST = [u'HELP', u'WATCH', u'MANAGE', u'SETTINGS']
    LBL_SETTINGS_SHORTCUT = "SETTINGS"
    LBL_HELP_SHORTCUT = "HELP"
    LBL_VOD = "VOD"
    LBL_USER_PREFERENCES_TITLE = "USER PREFERENCES"
    LBL_SYSTEM_AND_ACCOUNT = "SYSTEM & ACCOUNT"
    LBL_USER_PREFERENCES_SHORTCUT = "User Preferences"
    LBL_ACCOUNT_SYSTEM_INFO_STB = "Account & System Info"
    LBL_PARENTAL_CONTROLS_SHORTCUT = "Parental Controls"
    LBL_PARENTAL_AND_PURCHASE_CONTROLS_SHORTCUT = "Parental & Purchase Controls"
    LBL_CATCH_UP_ICON = "image_primary_branding_live_tv_catch_up_60x60.png"
    LBL_SOCU_SOURCE_ICON = "hydra_icon_source_socu_50x50.png"
    LBL_ONDEMAND_SOURCE_ICON = "icon_source_D0_50x50.png"
    LBL_ONEPASS_OPTIONS = "OnePass & Recording Options"
    LBL_MY_SHOWS_OPTIONS = "My Shows Options"
    LBL_RECORDING_AND_BOOKMARK_OPTIONS = "Recording & Bookmark Options"
    LBL_RECORDING_OPTIONS = "Recording Options"
    LBL_MY_VIDEO_PROVIDERS = "My Video Providers"
    LBL_CHECKED = "com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_checkbox_checked.png"
    LBL_UNCHECKED = "com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_checkbox_unchecked.png"
    LBL_CHECKMARK = "com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_checkmark.png"
    LBL_ONEPASS_MANAGER_SCREENTITLE = "ONEPASS MANAGER"
    LBL_TODO_LIST_SCREENTITLE = "TO DO LIST"
    LBL_SYSTEM_INFORMATION = "System Information"
    LBL_SYSTEM_INFORMATION_SCREENTITLE = "SYSTEM INFORMATION"
    LBL_TIPS_AND_TRICKS_YOUTUBE = "Tips & Tricks on YouTube"
    LBL_TIPS_AND_TRICKS_YOUTUBE_PREVIEW = "Click to watch short videos on YouTube " \
                                          "that will help you get the most out of your "
    LBL_PARENTAL_CONTROLS_SCREENTITLE = LBL_PARENTAL_CONTROLS_SHORTCUT
    LBL_VOICE_PREVIEW = "Learn how to use the voice control features of your "
    LBL_ACCESSIBILITY_PREVIEW = "Learn about the accessibility features available on your "
    LBL_REMOTE_DESCRIPTION = "Pair your remote with your "
    LBL_VIDEO_BACKGROUND = "Video Window & Background"
    LBL_AUTOPLAY_NEXTEPSD = "Autoplay Next Episode"
    LBL_CUSTOMER_PREVIEW = "Need more help? Learn how to contact "
    LBL_CUSTOMER_SUPPORT = "Customer Support"
    LBL_AUTOPLAY_SWTICHEDOFF = "Off"
    LBL_OFF = "Off"
    LBL_ON = "On"
    LBL_ALLOW = "Allow"
    LBL_DO_NOT_ALLOW = "Do Not Allow"
    LBL_CONFIRM_CANCEL_ONEPASS = "Yes, cancel this OnePass"
    LBL_MYSHOWS_SORTBYNAME = "Sort by Name"
    LBL_EMPTY_TODO_LIST = "There are currently no shows scheduled to be recorded.You can use the Guide, " \
                          "Search or Browse TV & Movies to find shows to record."
    LBL_CONDITIONAL_ACCESS_STB = "Conditional Access"
    LBL_SYSTEM_NOTIFICATIONS = "System Notifications"
    LBL_SYSTEM_NOTIFICATIONS_PREVIEW = "Learn how to enable System Notifications"
    # Settings lables
    LBL_ACCESSIBILITY = "Accessibility"
    LBL_VOICE = "Voice"
    LBL_ONEPASS_MANAGER = "OnePass Manager"
    LBL_TODO_LIST = "To Do List"
    LBL_USER_PREFERENCES = "User Preferences"
    LBL_PARENTAL_CONTROLS = "Parental Controls"
    LBL_AUDIO_SETTINGS = "Audio Settings"
    LBL_REMOTE_SETTINGS = "Remote Settings"
    LBL_DEVICE_SETTINGS = "Device Settings"
    # Settings lables for STB
    LBL_CHANNEL_SETTINGS_STB = "Channel Settings"
    LBL_REMOTE_DEVICES_CONDITIONALACCESS_STB = "Remote, Devices & Conditional Access"
    LBL_REMOTE_CABLECARD_DEVICE_STB = "Remote, CableCARD, & Devices"
    LBL_REMOTE_DEVICES = "Remote & Devices"
    LBL_SYSTEM_DIAGNOSTICS_STB = "System Diagnostics"
    LBL_SYSTEM_DIAGNOSTICS_TITLE_STB = "DIAGNOSTICS"
    LBL_CABLECARD_DECODER_STB = "CableCARD Decoder"
    # Channel Settings labels
    LBL_CHANNEL_LIST = "Channel List"
    LBL_FAVOURITE_CHANNELS = "Favorite Channels"
    LBL_CABLE_SIGNAL_STRENGTH = "Cable Signal Strength"
    # Accessibility
    LBL_CLOSED_CAPTIONING = "Subtitles & Closed Captioning"
    LBL_CLOSED_CAPTIONING_MENU = "Closed Captioning"
    LBL_SUBTITLE_CLOSED_CAPTION_LANGUAGE = "Subtitle & Closed Caption Language"
    LBL_CLOSED_CAPTION_PREFERENCES = "Closed Caption & Subtitle Preferences" \
        if Settings.hydra_branch() > Settings.hydra_branch(HydraBranches.STREAMER_1_18) \
        else "Closed Caption Preferences"
    LBL_LANGUAGE_AND_AUDIO_DESCRIPTION = "Language & Audio Description"
    LBL_CLOSED_CAPTIONING_SCREENTITLE = "SUBTITLES & CLOSED CAPTIONING"
    LBL_CLOSED_CAPTION_PREFERENCES_SCREENTITLE = "CLOSED CAPTION & SUBTITLE PREFERENCES" \
        if Settings.hydra_branch() > Settings.hydra_branch(HydraBranches.STREAMER_1_18) \
        else "CLOSED CAPTION PREFERENCES"
    LBL_SUBTITLE_CLOSED_CAPTION_LANGUAGE_SCREENTITLE = "SUBTITLE & CLOSED CAPTION LANGUAGE"
    LBL_LANGUAGE_AND_AUDIO_DESCRIPTION_SCREENTITLE = "LANGUAGE & AUDIO DESCRIPTION"
    ACCESSIBILITY_MENUITEMS = [LBL_CLOSED_CAPTIONING, LBL_SUBTITLE_CLOSED_CAPTION_LANGUAGE,
                               LBL_CLOSED_CAPTION_PREFERENCES,
                               LBL_LANGUAGE_AND_AUDIO_DESCRIPTION]
    LBL_REMOTE_AND_NAVIGATION = "Remote & Navigation"
    LBL_REMOTE_AND_NAVIGATION_SCREETITLE = "REMOTE & NAVIGATION"
    LBL_SUBTITLE_PREVIEW_TEXT = "Choose a default language for Subtitles and closed captions. " \
                                "To change the selected language while watching a show, press INFO."
    LBL_SPANISH = "Spanish"
    LBL_ENGLISH = "[ English ]"
    # User Preferences
    LBL_THUUZ_SPORTS_RATING = "Thuuz Sports Rating"
    LBL_PERSONALIZED_ADS = "Personalized Ads"
    LBL_VIEWERSHIP_DATA_SHARING = "Viewership Data Sharing"
    LBL_ALLOW_PERSONALIZED_ADS = "Allow Tracking for Personalized Ads"
    LBL_DO_NOT_ALLOW_PERSONALIZED_ADS = "Do Not Allow Tracking for Personalized Ads"
    LBL_ALLOW_DATA_SHARING = "Allow Sharing of My Viewership Data"
    LBL_DO_NOT_ALLOW_DATA_SHARING = "Do Not Allow Sharing of My Viewership Data"
    # Parental Controls
    LBL_PARENTAL_CONTROLS_MENUITEM = "Parental Controls"
    LBL_HIDE_ADULT_CONTENT = "Hide Adult Content"
    LBL_SET_RATING_LIMITS = "Set Rating Limits"
    LBL_SET_RATING_LIMITS_SCREEN = "SettingsSetRatingLimitsScreen"
    LBL_PURCHASE_CONTROLS = "Purchase Controls"
    LBL_PURCHASE_GROUP = "AP_purchasepin"
    LBL_DONT_HIDE_ADULT_CONTENT = "Don't hide"
    LBL_LOCK_CHANNELS = "Lock Channels"
    LBL_CHANGE_PIN = "Change PIN"
    LBL_CREATE_PIN = "Create PIN"
    LBL_NEW_PIN = "New PIN"
    LBL_CONFIRM_PIN = "Confirm PIN"
    LBL_ENTER_PIN = "Enter PIN"
    LBL_CURRENT_PIN = "Current PIN"
    LBL_INCORRECT_PIN = "Incorrect PIN"
    LBL_INCORRECT_PIN_OVERLAY_BODY = 'You have entered an incorrect PIN. Please try again.'
    LBL_PURCHASE_WITHPIN_MENU = "Require a PIN to purchase"
    LBL_PURCHASE_WITHOUTPIN_MENU = "Allow purchases without a PIN"
    LBL_PARENTAL_CONTROLS_VALUE_ONUNLOCK = "[ On - Unlocked ]"
    LBL_PARENTAL_CONTROLS_VALUE_ONLOCKED = "[ On - Locked ]"
    LBL_OPTION_VALUE_ON = "[ On ]"
    LBL_OPTION_VALUE_OFF = "[ Off ]"
    LBL_DISABLE_PARENTAL_CONTROLS = "Disable Parental Controls"
    LBL_DISABLE_PARENTAL_CONTROLS_SCREEN = "DisableParentalControlsOverlay"
    LBL_HIGHEST_ALLOWED_MOVIE_RATING = "Highest allowed movie rating:"
    LBL_HIGHEST_ALLOWED_TV_RATING = "Highest allowed TV rating:"
    LBL_UNRATED_TV_SHOWS = "Unrated TV shows:"
    LBL_UNRATED_MOVIES = "Unrated movies:"
    LBL_HIGHEST_ALLOWED_CANADA = "Highest allowed canada:"
    LBL_BLOCK_ALL_RATED = "Block all"
    LBL_BLOCK_ALL_UNRATED = "[ Block all ]"
    LBL_G_HIGHEST_ALLOWED_MOVIE_RATING = "G"
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_MOVIE_RATING = "AO - Allow all"
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_TV_RATING = "TV-MA - Allow all"
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_RATING = "Allow all"
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_MOVIE_RATING_EXCEPT_ADULT = "Allow all except Adult"
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_TV_RATING_EXCEPT_ADULT = "Allow all except Adult"
    LBL_ALLOW_ALL_UNRATED = "[ Allow all ]"
    LBL_TV_RATING_TV_G = "TV-G"
    LBL_TV_RATING_TV_PG = "TV-PG"
    LBL_ALWAYS_REQUIRE_PIN = "Always Require PIN"
    LBL_HIDE_ADULT_NEW = "Hide adult content"
    LBL_LOCK_PC = "Lock Parental Controls"
    # Audio Settings
    LBL_SOUND_EFFECTS_VOLUME = "Sound Effects Volume"
    # Remote Settings
    LBL_REMOTE_SETUP = "Remote Setup"
    LBL_REMOTE_SETUP_SCREENTITLE = "REMOTE SETUP"
    LBL_TIVO_REMOTE = "TiVo Remote"
    LBL_TIVO_REMOTE_PREVIEW = "Learn how to pair your TiVo remote."
    LBL_PAIR_YOUR_REMOTE = "Pair your remote with your"
    LBL_PAIR_YOUR_REMOTE_BOX = "Pair your remote with your box"
    LBL_WATCH_NOW_FROM_SOCU = "Watch now from Cableco SOCU"
    LBL_PARENTAL_AND_PURCHASE_CONTROLS_SCREEN = "SettingsParentalAndPurchaseControlsScreen"
    LBL_CREATE_PIN_SCREEN = "SetPINOverlay"
    LBL_ENTER_PIN_SCREEN = "EnterPINOverlay"
    LBL_CONFIRM_PIN_SCREEN = "ConfirmPINOverlay"
    LBL_CURRENT_PIN_SCREEN = "CurrentPINOverlay"
    LBL_NEW_PIN_SCREEN = "NewPINOverlay"
    LBL_PIN_OVERLAY = ['pinchallenge.PinEntryOverlayView', 'pinchallenge.SpinnerPinEntryOverlayView']
    LBL_USER_AGREEMENT = "User Agreement"
    LBL_PRIVACY_POLICY = "Privacy Policy"
    LBL_OPEN_SOURCE_NOTICES = "Open Source Notices"
    LBL_HELP = "Help"
    LBL_HELP_SCREENTITLE = "HELP"
    LBL_SYSTEM_INFO = "System Info"
    LBL_SYSTEM_DIAGNOSTICS = "System Diagnostics"
    # Refresh Account & User Data opens overlay with options
    LBL_HELP_REFRESH_ACC_AND_USER_DATA = "Refresh Account & User Data"
    LBL_REFRESH_OVERLAY_TITLE = "You are about to perform an Account & User Data refresh"
    LBL_REFRESH_OK_OPTION = "OK, continue"
    LBL_REFRESH_CANCEL_OPTION = "Cancel"
    LBL_DISPLAY_VIDEO = "Display video:"
    LBL_VIDEO_ON_HOME = "Video on HOME:"
    LBL_DISPLAY_BACKGROUND_IMAGES = "Display background images:"
    LBL_YES = "Yes"
    LBL_NO = "No"
    LBL_FULL_SCREEN = "Full screen (background)"
    LBL_VIDEO_WINDOW_TOP_RIGHT = "Video window (top right)"
    LBL_WATCH_NOW = "Watch Now"
    LBL_WATCH_NOW_RECORDING = "Watch now"
    LBL_BOOKMARK = "Bookmark"
    LBL_SOURCE_ICON = "icon_source"
    LBL_VIDEO_WINDOW_and_BACKGROUND = "VIDEO WINDOW & BACKGROUND"
    LBL_STREAMING_OPTIONS_OVERLAY = "AllStreamingOptionsOverlay"
    LBL_STREAMING_OPTIONS_OVERLAY_TITLE = "All Streaming Options"
    LBL_STREAMING_OPTIONS_PURCHASE_ON = "Purchase on "  # provider name goes after it
    LBL_STREAMING_OPTIONS_RENT_ON = "Rent on "  # provider name goes after it
    LBL_STREAMING_OPTIONS_SUBSCR = "Included with subscription"
    LBL_STREAMING_OPTIONS_SELECT_FOR_PRC = "Select for price"
    LBL_STREAMING_OPTIONS_UPGRADE = "Upgrade to watch"
    LBL_VIDEO_RESOLUTION_SD = "SD"
    LBL_VIDEO_RESOLUTION_HD = "HD"
    LBL_VIDEO_RESOLUTION_UHD = "UHD"
    LBL_STREAMING_OPTIONS = "Streaming Options"
    LBL_REMOTE_SETTINGS_SCREEN_TITLE = "REMOTE CONTROL SETUP"
    LBL_PARENTAL_CONTROLS_TITLE = "PARENTAL CONTROLS"
    LBL_NETFLIX = "Netflix"
    LBL_HULU = "Hulu"
    LBL_VUDU = "Vudu"
    LBL_HBOGO = "HBO Go"
    LBL_GOOGLE_PLAY = "Google Play Movies and TV"
    LBL_VUDU_ICON = "Vudu_Fandango"
    LBL_HIDE_ADULT_NEW = "Hide adult content"
    LBL_PIN_OVERLAY_TEXT_IMAGE = [
        'com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_image_search_keyboard_shadow_C0.png',
        'com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_image_pin_hidden_character.png']
    LBL_PIN_OVERLAY_IMAGE = [
        'com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_image_search_keyboard_shadow_C0.png',
        'com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_control_arrow_up.png',
        'com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_control_arrow_down.png']
    LBL_BOOKMARK_THIS_MOVIE = "Bookmark This Movie"
    LBL_BOOKMARK_WHISPER = "This movie has been added to My Shows"
    LBL_BOOKMARK_COMMON_WHISPER = "has been added to My Shows"
    LBL_EMPTY_RESULT = "There are no matching shows, movies, videos, or people."
    LBL_ONEPASS_AND_RECORDING_OPTIONS_LIST = ['Include:', 'Start from:', 'Rent or buy:',
                                              'Record:', 'Video quality:', 'Keep at most:',
                                              'Keep until:', 'Always display options:']
    LBL_ONEPASS_AND_RECORDING_OPTIONS_SCREEN = "SettingsOnePassAndRecordingOptions"
    LBL_RECORD_MENU = "Record:"
    LBL_NEW_ONLY = "New only"
    LBL_OPERATOR_FEATURES = "Operator Features"
    LBL_OPERATOR_FEATURES_SCREENTITLE = "OPERATOR FEATURES"
    LBL_OPERATOR_FEATURES_PREVIEW_TEXT = "Add or remove features or modify your Subscription " \
                                         "Packages directly from your Operator."
    LBL_ADD_NDVR = "Add nDVR"
    LBL_REMOVE_NDVR = "Remove nDVR"
    LBL_NDVR_STORAGE = "Increase or decrease nDVR Storage"
    LBL_START_OVER = "Start Over"
    LBL_PIN = ""
    # DEVICE SETTINGS
    LBL_DEVICE_PREFERENCES = 'Device Preferences'
    LBL_TALK_BACK = "TalkBack"
    LBL_TTS_ENABLE = 'Enable'
    LBL_TTS_STOP = "Stop TalkBack?"

    # System Information screen options
    LBL_SYSTEM_INFORMATION_SCRN_VIEW_MODE = "templates.ScrollableTwoColumnTextListScreenView"
    LBL_LAST_SERVICE_LOGIN = "Last service login:"

    # Crash Simulation
    LBL_SYSTEM_INFO_TITLE = "SYSTEM INFO"
    LBL_SIMULATE_CRASH_TITLE = "SIMULATE CRASH"
    LBL_SIMULATE_CRASH = "Simulate Crash"
    LBL_TOMBSTONE_CRASH = "CI:Tombstone"
    LBL_JAVA_CRASH_RESULT = "CI:JavaCrash"
    LBL_ANR_CRASH_RESULT = "CI:AppNotResponding"
    LBL_ASSERT_RESULT = "Assertsimulatedfromsystemsettingsscreen"
    LBL_ASSERT_RESTART = "AssertAndRestartAppsimulatedfromsystemsettingsscreen"
    LBL_OUTOFMEMORY = "OutOfMemoryError"
    LBL_HAXE_DIED = "HaxeAppDied"
    LBL_HAXE_CRASH = "HaxeUICrash"

    # To Do List
    LBL_EXCLUDED_ARTICLES = "(The |A |An |El |Los |La |Las |Lo |Un |Unos |Una |Unas )"

    def __init__(self):
        self.USER_PREFERENCES_OPTIONS = [self.LBL_MY_VIDEO_PROVIDERS, self.LBL_FAVOURITE_CHANNELS,
                                         self.LBL_ONEPASS_OPTIONS,
                                         self.LBL_MY_SHOWS_OPTIONS, self.LBL_AUTOPLAY_NEXTEPSD,
                                         self.LBL_VIDEO_BACKGROUND]
        self.USER_PREFERENCES_OPTIONS_OPERATOR_FEATURES_ENABLE = [self.LBL_MY_VIDEO_PROVIDERS,
                                                                  self.LBL_FAVOURITE_CHANNELS,
                                                                  self.LBL_OPERATOR_FEATURES,
                                                                  self.LBL_ONEPASS_OPTIONS,
                                                                  self.LBL_MY_SHOWS_OPTIONS,
                                                                  self.LBL_AUTOPLAY_NEXTEPSD,
                                                                  self.LBL_VIDEO_BACKGROUND]
        self.SETTINGS_OPTIONS_MANAGED = [self.LBL_ACCESSIBILITY, self.LBL_ONEPASS_MANAGER, self.LBL_TODO_LIST,
                                         self.LBL_USER_PREFERENCES,
                                         self.LBL_PARENTAL_CONTROLS_SHORTCUT, self.LBL_AUDIO_SETTINGS,
                                         self.LBL_REMOTE_SETTINGS,
                                         self.LBL_DEVICE_SETTINGS]
        self.SETTINGS_OPTIONS_MANAGED_WITH_PURCHASE_CONTROLS = [self.LBL_ACCESSIBILITY, self.LBL_ONEPASS_MANAGER,
                                                                self.LBL_TODO_LIST,
                                                                self.LBL_USER_PREFERENCES,
                                                                self.LBL_PARENTAL_AND_PURCHASE_CONTROLS_SHORTCUT,
                                                                self.LBL_AUDIO_SETTINGS, self.LBL_REMOTE_SETTINGS,
                                                                self.LBL_DEVICE_SETTINGS]
        self.SETTINGS_OPTIONS_UNMANAGED = [self.LBL_ACCESSIBILITY, self.LBL_ONEPASS_MANAGER, self.LBL_TODO_LIST,
                                           self.LBL_USER_PREFERENCES,
                                           self.LBL_PARENTAL_CONTROLS_SHORTCUT, self.LBL_AUDIO_SETTINGS]
        self.SETTINGS_OPTIONS_UNMANAGED_WITH_PURCHASE_CONTROLS = [self.LBL_ACCESSIBILITY, self.LBL_ONEPASS_MANAGER,
                                                                  self.LBL_TODO_LIST,
                                                                  self.LBL_USER_PREFERENCES,
                                                                  self.LBL_PARENTAL_AND_PURCHASE_CONTROLS_SHORTCUT,
                                                                  self.LBL_AUDIO_SETTINGS]
        self.SETTINGS_OPTIONS = self.SETTINGS_OPTIONS_MANAGED  # this param is used in tests
        self.ACCESSIBILITY_MENUITEMS = [self.LBL_CLOSED_CAPTIONING, self.LBL_CLOSED_CAPTION_PREFERENCES,
                                        self.LBL_LANGUAGE_AND_AUDIO_DESCRIPTION]
        self.PARENTAL_CONTROLS_MENUITEMS = [self.LBL_PARENTAL_CONTROLS_MENUITEM, self.LBL_HIDE_ADULT_CONTENT,
                                            self.LBL_SET_RATING_LIMITS]
        self.PARENTAL_AND_PURCHASE_CONTROLS_MENUITEMS = [self.LBL_PARENTAL_CONTROLS_MENUITEM,
                                                         self.LBL_HIDE_ADULT_CONTENT, self.LBL_SET_RATING_LIMITS,
                                                         self.LBL_PURCHASE_CONTROLS]
        self.AUDIO_SETTINGS_MENUITEMS = [self.LBL_LANGUAGE_AND_AUDIO_DESCRIPTION, self.LBL_SOUND_EFFECTS_VOLUME]
        self.LBL_SYSTEM_AND_ACCOUNT_MENU_ITEMS = [self.LBL_HELP, self.LBL_SYSTEM_INFO]
        self.REMOTE_SETTINGS_MENUITEMS = [self.LBL_PAIR_YOUR_REMOTE]
        self.LBL_SYSTEM_INFO_SHORTCUTS = [self.LBL_SYSTEM_INFORMATION, self.LBL_USER_AGREEMENT, self.LBL_PRIVACY_POLICY,
                                          self.LBL_OPEN_SOURCE_NOTICES]
        self.ACCESSIBILITY_MENU_ITEMS = [self.LBL_CLOSED_CAPTIONING_MENU, self.LBL_CLOSED_CAPTION_PREFERENCES,
                                         self.LBL_LANGUAGE_AND_AUDIO_DESCRIPTION]
        self.LBL_DEFAULT_WATCH_NOW_FROM_CATCHUP = "Watch now from Catch Up"
        self.LBL_DEFAULT_WATCH_NOW_FROM_STARTOVER = "Watch now from Start Over"
        self.LBL_STRING_CATCHUP_STARTOVER_NOW = "Watch now from "
        self.LBL_USER_PREF_SCREEN_NAME = "SettingsUserPreferencesMain"
        self.LBL_OPERATOR_FEATURES_OPTIONS_REMOVE_NDVR = [self.LBL_REMOVE_NDVR, self.LBL_NDVR_STORAGE]
        self.LBL_OPERATOR_FEATURES_OPTIONS_ADD_NDVR = [self.LBL_ADD_NDVR, self.LBL_NDVR_STORAGE]
