from .labels import MenuLabels


class AppleTVLabels(MenuLabels):
    LBL_TIPS_TRICKS = "Tips & Tricks"
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR1 = "To watch short videos that will help you get the most out of your "
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR2 = ", go to YouTube and search for "
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR3 = " or visit "
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR4 = "."
    LBL_OPERATOR_USER_AGREEMENT = "User Agreement"
    LBL_OPERATOR_PRIVACY_POLICY = "Privacy Policy"
    LBL_PROVISIONING_DIAGNOSTICS = "Provisioning Diagnostics"

    def __init__(self):
        super().__init__()
        self.LBL_SYSTEM_AND_ACCOUNT_MENU_ITEMS = [self.LBL_HELP, self.LBL_TIPS_TRICKS, self.LBL_SYSTEM_INFO]
        self.LBL_SYSTEM_INFO_SHORTCUTS = [self.LBL_SYSTEM_INFORMATION, self.LBL_OPERATOR_USER_AGREEMENT,
                                          self.LBL_OPERATOR_PRIVACY_POLICY,
                                          self.LBL_OPEN_SOURCE_NOTICES,
                                          self.LBL_SYSTEM_DIAGNOSTICS,
                                          self.LBL_PROVISIONING_DIAGNOSTICS,
                                          self.LBL_ENDPOINT_DIAGNOSTICS]
