from .labels import MenuLabels


class LLACRMenuLabels(MenuLabels):
    LBL_PAIR_YOUR_REMOTE = "Pair your remote with your"

    def __init__(self):
        super().__init__()
        self.LBL_SYSTEM_INFO = "Account & System Info"
