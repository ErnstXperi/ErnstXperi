from .labels import MenuLabels


class HISENSEMenuLabels(MenuLabels):
    LBL_SYSTEM_INFORMATION_SCREENTITLE = "SYSTEM INFO"
