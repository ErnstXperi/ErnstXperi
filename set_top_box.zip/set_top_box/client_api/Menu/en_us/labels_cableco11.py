from .labels import MenuLabels


class CC11MenuLabels(MenuLabels):
    LBL_WATCH_NOW_FROM_SOCU = "Watch now from Cableco11 SOCU"
    LBL_WATCH_NOW_FROM_STARTOVER = "Watch now from Start Over"
    LBL_WATCH_NOW_FROM_CATCHUP = "Watch now from Catch Up"
    LBL_CATCH_UP_ICON = "cableco11_image_primary_branding_live_tv_catch_up_60x60.png"
    LBL_ENABLE_SOCU = "Enable Cableco11 SOCU"
    LBL_DISABLE_SOCU = "Disable Cableco11 SOCU"
    LBL_ENABLE_CATCHUP = "Enable Cableco11 CATCHUP"
    LBL_ONDEMAND_SOURCE_ICON = "cableco11_icon_source_D0_50x50.png"
