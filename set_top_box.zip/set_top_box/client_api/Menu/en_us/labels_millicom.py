class MILLICOMMenuLabels:

    LBL_SYSTEM_INFO = "Account & System Info"
    LBL_HIGHEST_ALLOWED_RATING = "Highest allowed Rating:"
