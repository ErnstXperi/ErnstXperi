from .labels import MenuLabels


class CC5MenuLabels(MenuLabels):
    LBL_WATCH_NOW_FROM_SOCU = "Watch now from Cableco5 SOCU"
    LBL_WATCH_NOW_FROM_STARTOVER = "Watch now from Start Over"
    LBL_WATCH_NOW_FROM_CATCHUP = "Watch now from Catch Up"
    LBL_ENABLE_SOCU = "Enable Cableco5 SOCU"
    LBL_DISABLE_SOCU = "Disable Cableco5 SOCU"
    LBL_ENABLE_CATCHUP = "Enable Cableco5 CATCHUP"
