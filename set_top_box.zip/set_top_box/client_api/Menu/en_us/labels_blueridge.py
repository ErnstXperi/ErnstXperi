from .labels import MenuLabels


class BlueridgeMenuLabels(MenuLabels):
    LBL_ONEPASS_OPTIONS = "OnePass & Recording Options"
    SETTINGS_OPTIONS = ["Accessibility", "OnePass Manager", "User Preferences", "Parental & Purchase Controls",
                        "Audio Settings", "Device Settings"]
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_MOVIE_RATING = "AO - Allow all"
    LBL_CATCH_UP_ICON = "hydra_icon_source_socu_50x50.png"

    def __init__(self):
        super().__init__()
        self.USER_PREFERENCES_OPTIONS = ["My Video Providers", "Favorite Channels", self.LBL_ONEPASS_OPTIONS,
                                         "My Shows Options", "Video Window & Background", "Thuuz Sports Rating"]
