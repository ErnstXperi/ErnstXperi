from .labels import MenuLabels


class TelusMenuLabels(MenuLabels):
    LBL_ONEPASS_OPTIONS = "OnePass & Recording Options"
    SETTINGS_OPTIONS = ["Accessibility", "OnePass Manager", "User Preferences", "Parental & Purchase Controls",
                        "Audio Settings", "Device Settings"]
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_MOVIE_RATING = "Adult - Allow all"
    LBL_WATCH_NOW_FROM_SOCU = "Watch now from Telus SoCu"
    LBL_WATCH_NOW_FROM_STARTOVER = "Watch now from Telus SoCu"
    LBL_WATCH_NOW_FROM_CATCHUP = "Watch now from Telus SoCu"
    LBL_CATCH_UP_ICON = "hydra_icon_source_socu_50x50.png"

    def __init__(self):
        super().__init__()
        self.USER_PREFERENCES_OPTIONS = ["My Video Providers", "Favorite Channels", "OnePass & Recording Options",
                                         "My Shows Options", "Video Window & Background", "Thuuz Sports Rating"]
