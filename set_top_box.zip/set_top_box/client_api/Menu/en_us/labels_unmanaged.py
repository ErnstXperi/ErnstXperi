from set_top_box.client_api.Menu.en_us.labels import MenuLabels
from set_top_box.test_settings import Settings


class UnManagedMenuLabels(MenuLabels):
    LBL_SETTINGS_SHORTCUT = "SETTINGS"
    LBL_SYSTEM_AND_ACCOUNT = "SYSTEM & ACCOUNT"
    LBL_USER_PREFERENCES_SHORTCUT = "User Preferences"
    LBL_PARENTAL_CONTROLS_SHORTCUT = "Parental Controls"
    LBL_SYSTEM_INFO = "System Info"
    LBL_ONEPASS_OPTIONS = "OnePass & Recording Options"
    LBL_MY_SHOWS_OPTIONS = "My Shows Options"
    LBL_RECORDING_AND_BOOKMARK_OPTIONS = "Recording & Bookmark Options"
    LBL_MY_VIDEO_PROVIDERS = "My Video Providers"
    USER_PREFERENCES_OPTIONS = ["My Video Providers", "Favorite Channels", LBL_ONEPASS_OPTIONS, LBL_MY_SHOWS_OPTIONS,
                                "Autoplay Next Episode", "Video Window & Background"]
    LBL_OPERATOR_USER_AGREEMENT = "Operator User Agreement"
    LBL_OPERATOR_PRIVACY_POLICY = "Operator Privacy Policy"
    LBL_TIVO_USER_AGREEMENT = "TiVo User Agreement"
    LBL_TIVO_PRIVACY_POLICY = "TiVo Privacy Policy"
    LBL_ENDPOINT_DIAGNOSTICS = "Endpoint Diagnostics"

    if Settings.is_purchase_controls_enabled():
        SETTINGS_OPTIONS = MenuLabels().SETTINGS_OPTIONS_UNMANAGED_WITH_PURCHASE_CONTROLS
    else:
        SETTINGS_OPTIONS = MenuLabels().SETTINGS_OPTIONS_UNMANAGED

    def __init__(self):
        super().__init__()
        self.LBL_SYSTEM_INFO_SHORTCUTS = [self.LBL_SYSTEM_INFORMATION, self.LBL_OPERATOR_USER_AGREEMENT,
                                          self.LBL_OPERATOR_PRIVACY_POLICY,
                                          self.LBL_TIVO_USER_AGREEMENT, self.LBL_TIVO_PRIVACY_POLICY,
                                          self.LBL_OPEN_SOURCE_NOTICES,
                                          self.LBL_ENDPOINT_DIAGNOSTICS]
