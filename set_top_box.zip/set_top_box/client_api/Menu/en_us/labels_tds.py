from .labels import MenuLabels


class TDSMenuLabels(MenuLabels):
    LBL_WATCH_NOW_FROM_SOCU = "Watch now from Start Over"
    LBL_WATCH_NOW_FROM_STARTOVER = "Watch now from Start Over"
    LBL_WATCH_NOW_FROM_CATCHUP = "Watch now from Start Over"
    LBL_CATCH_UP_ICON = "TDS_SocuPlayback_60x60.png"
