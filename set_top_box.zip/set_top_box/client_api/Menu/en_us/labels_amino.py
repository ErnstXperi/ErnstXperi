from .labels import MenuLabels


class AminoMenuLabels(MenuLabels):
    LBL_TIVO_REMOTE = "Rectangular Remote"
    LBL_TIVO_REMOTE_PREVIEW = "Learn how to pair your Rectangular Remote."
