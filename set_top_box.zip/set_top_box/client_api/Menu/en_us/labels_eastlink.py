class EastlinkMenuLabels():
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_MOVIE_RATING = "Adult - Allow all"
    LBL_TV_RATING_TV_G = "G"
    LBL_TV_RATING_TV_PG = "PG"
    LBL_CATCH_UP_ICON = "eastlink_image_socu_branding_live_tv_60x60_v2.png"
