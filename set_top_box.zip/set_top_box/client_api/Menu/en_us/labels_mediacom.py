class MediacomMenuLabels:
    LBL_ONEPASS_OPTIONS = "OnePass Options"

    def __init__(self):
        super().__init__()
        self.USER_PREFERENCES_OPTIONS = [self.LBL_MY_VIDEO_PROVIDERS,
                                         self.LBL_FAVOURITE_CHANNELS,
                                         self.LBL_ONEPASS_OPTIONS,
                                         self.LBL_MY_SHOWS_OPTIONS,
                                         self.LBL_VIDEO_BACKGROUND,
                                         self.LBL_THUUZ_SPORTS_RATING]
