from .labels import SpanishMenuLabels


class SpanishFireTVLabels(SpanishMenuLabels):
    LBL_TIPS_TRICKS = "Sugerencias y trucos"
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR1 = "Para ver videos cortos que le ayudarán a descubrir lo máximo de su "
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR2 = ", vaya a YouTube y busque por "
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR3 = " o visite "
    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR4 = "."

    def __init__(self):
        super().__init__()
        self.LBL_SYSTEM_AND_ACCOUNT_MENU_ITEMS = [self.LBL_HELP, self.LBL_TIPS_TRICKS]
