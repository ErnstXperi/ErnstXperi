from .labels import SpanishMenuLabels
from set_top_box.test_settings import Settings


class SpUnManagedMenuLabels(SpanishMenuLabels):
    LBL_SETTINGS_SHORTCUT = "AJUSTES"
    LBL_SYSTEM_AND_ACCOUNT = "SISTEMA Y CUENTA"
    LBL_USER_PREFERENCES_SHORTCUT = "Preferencias de usuario"
    LBL_PARENTAL_CONTROLS_SHORTCUT = "Control parental y compras"
    LBL_PARENTAL_AND_PURCHASE_CONTROLS_SHORTCUT = "Control parental y compras"
    LBL_SYSTEM_INFO = "InformaciÃ³n del sistema"
    LBL_ONEPASS_OPTIONS = "OnePass y opciones de grabaciÃ³n"
    LBL_MY_SHOWS_OPTIONS = "Opciones de Mis Programas"
    LBL_RECORDING_AND_BOOKMARK_OPTIONS = "OnePass y opciones de grabaciÃ³n"
    LBL_FAVOURITE_CHANNELS = "Canales Favoritos"
    LBL_VIDEO_BACKGROUND = "Ventana de video"
    LBL_MY_VIDEO_PROVIDERS = "My Video Providers"
    LBL_AUTOPLAY_NEXTEPSD = "Reproducir auto. prox. episodio"
    USER_PREFERENCES_OPTIONS = [LBL_FAVOURITE_CHANNELS, LBL_ONEPASS_OPTIONS, LBL_MY_SHOWS_OPTIONS,
                                LBL_AUTOPLAY_NEXTEPSD, LBL_VIDEO_BACKGROUND, "ClasificaciÃ³n Thuuz Deportes"]

    if Settings.is_purchase_controls_enabled():
        SETTINGS_OPTIONS = SpanishMenuLabels().SETTINGS_OPTIONS_UNMANAGED_WITH_PURCHASE_CONTROLS
    else:
        SETTINGS_OPTIONS = SpanishMenuLabels().SETTINGS_OPTIONS_UNMANAGED

    def __init__(self):
        super().__init__()
        self.LBL_HOME_MENU_ITEMS = [self.LBL_MENU_SHORTCUT, self.LBL_LIVETV_SHORTCUT, self.LBL_MYSHOWS_SHORTCUT,
                                    self.LBL_WHATTOWATCH_SHORTCUT, self.LBL_GUIDE_SHORTCUT, self.LBL_ONDEMAND_SHORTCUT,
                                    self.LBL_SEARCH_SHORTCUT]
        self.LBL_HOME_MENU_ITEMS_SHORTCUTS = [self.LBL_MENU_SHORTCUT, self.LBL_LIVETV_SHORTCUT,
                                              self.LBL_MYSHOWS_SHORTCUT,
                                              self.LBL_WHATTOWATCH_SHORTCUT, self.LBL_GUIDE_SHORTCUT,
                                              self.LBL_ONDEMAND_SHORTCUT,
                                              self.LBL_SEARCH_SHORTCUT]
