class SpanishMenuLabels(object):
    LBL_MENU_SHORTCUT = "MENÃ\x9a"
    LBL_MENU_TITLE = "MENÃ\x9a"
    LBL_WATCHVIDEO_SHORTCUT = "VER TV"
    LBL_GUIDE_SHORTCUT = "GUÃ\x8dA"
    LBL_MYSHOWS_SHORTCUT = "MIS PROGRAMAS"
    LBL_SEARCH_SHORTCUT = "BUSCAR"
    LBL_WHATTOWATCH_SHORTCUT = "QUÃ\x89 VER"
    LBL_LIVETV_SHORTCUT = "VER TV"
    LBL_NOTIFICATION_SHORTCUT = "NOTIFICATIONS"
    LBL_APPSANDGAME_SHORTCUT = "APPS Y JUEGOS"
    LBL_ONDEMAND_SHORTCUT = "ON DEMAND"
    LBL_HOME_MENU_ITEMS = [LBL_MENU_SHORTCUT, LBL_LIVETV_SHORTCUT, LBL_MYSHOWS_SHORTCUT,
                           LBL_WHATTOWATCH_SHORTCUT, LBL_GUIDE_SHORTCUT, LBL_APPSANDGAME_SHORTCUT,
                           LBL_ONDEMAND_SHORTCUT, LBL_SEARCH_SHORTCUT]
    LBL_FTUX_TITLE = "FIRST TIME UX"
    LBL_FTUX_VIEW_MODE = "ftux.FtuxOnePassScreenView"
    LBL_HOME_SCREENTITLE = "INICIO"
    LBL_HOME_SCREEN_NAME = "HomeMainScreen"
    LBL_HELP = "Ayuda"
    LBL_HOME_MENU_ITEMS_SHORTCUTS = [LBL_MENU_SHORTCUT, LBL_LIVETV_SHORTCUT,
                                     LBL_MYSHOWS_SHORTCUT,
                                     LBL_WHATTOWATCH_SHORTCUT, LBL_GUIDE_SHORTCUT,
                                     LBL_APPSANDGAME_SHORTCUT,
                                     LBL_ONDEMAND_SHORTCUT, LBL_SEARCH_SHORTCUT
                                     ]
    LBL_SETTINGS_SHORTCUT = "AJUSTES"
    LBL_USER_PREFERENCES_TITLE = "PREFERENCIAS DE USUARIO"
    LBL_CHECKED = "com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_checkbox_checked.png"
    LBL_UNCHECKED = "com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_checkbox_unchecked.png"
    LBL_CHECKMARK = "com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_checkmark.png"
    LBL_SYSTEM_AND_ACCOUNT = "SISTEMA Y CUENTA"
    LBL_USER_PREFERENCES_SHORTCUT = "Preferencias de usuario"
    LBL_PARENTAL_CONTROLS_SHORTCUT = "Control parental y compras"
    LBL_PARENTAL_AND_PURCHASE_CONTROLS_SHORTCUT = "Control parental y compras"
    LBL_PARENTAL_CONTROLS_SCREENTITLE = "CONTROL PARENTAL"
    LBL_MENU_SCREEN = "TiVoMenuScreen"
    LBL_ONEPASS_MANAGER_SCREENTITLE = "ADMIN. DE ONEPASS"
    LBL_ONEPASS_OPTIONS = "OnePass y opciones de grabaciÃ³n"
    LBL_MY_SHOWS_OPTIONS = "Opciones de Mis Programas"
    LBL_RECORDING_AND_BOOKMARK_OPTIONS = "OnePass y opciones de grabaciÃ³n"
    LBL_FAVOURITE_CHANNELS = "Canales Favoritos"
    LBL_VIDEO_BACKGROUND = "Ventana de video"
    LBL_AUTOPLAY_NEXTEPSD = "Reproducir auto. prox. episodio"
    LBL_TODO_LIST_SCREENTITLE = "LISTA DE TAREAS"
    LBL_SYSTEM_INFORMATION = "InformaciÃ³n del sistema"
    LBL_SYSTEM_INFORMATION_SCREENTITLE = "INFORMACIÃ\x93N DEL SISTEMA"
    LBL_USER_AGREEMENT = "Acuerdo de usuario"
    LBL_PRIVACY_POLICY = "Privacy Policy"
    LBL_OPEN_SOURCE_NOTICES = "Avisos de fuente abierta"
    LBL_SYSTEM_INFO = "InformaciÃ³n del sistema"
    LBL_AUTOPLAY_SWTICHEDOFF = "Desactivar"
    LBL_OFF = "Desactivar"
    LBL_ON = "Activar"
    # Settings lables
    LBL_ACCESSIBILITY = "Accesibilidad"
    LBL_ONEPASS_MANAGER = "Admin. de OnePass"
    LBL_TODO_LIST = "Lista de tareas"
    LBL_USER_PREFERENCES = "Preferencias de usuario"
    LBL_PARENTAL_CONTROLS = "Control parental y compras"
    LBL_AUDIO_SETTINGS = "Ajustes de audio y video"
    LBL_REMOTE_SETTINGS = "ConfiguraciÃ³n del control remoto"
    LBL_DEVICE_SETTINGS = "ConfiguraciÃ³n del dispositivo"
    # Accessibility
    LBL_CLOSED_CAPTIONING = "SubtÃ\xadtulos y SubtÃ\xadtulos ocultos"
    LBL_SUBTITLE_CLOSED_CAPTION_LANGUAGE = "Idioma de SubtÃ\xadtulos y Subtitulado oculto"
    LBL_CLOSED_CAPTION_PREFERENCES = "Preferencias de subtÃ\xadtulos ocultos"
    LBL_LANGUAGE_AND_AUDIO_DESCRIPTION = "DescripciÃ³n de idioma y audio"
    LBL_CLOSED_CAPTIONING_SCREENTITLE = "SUBTÃ\x8dTULOS Y SUBTÃ\x8dTULOS OCULTOS"
    LBL_SUBTITLE_CLOSED_CAPTION_LANGUAGE_SCREENTITLE = "IDIOMA DE SUBTÃ\x8dTULOS Y SUBTITULADO OCULTO"
    LBL_LANGUAGE_AND_AUDIO_DESCRIPTION_SCREENTITLE = "DESCRIPCIÃ\x93N DE IDIOMA Y AUDIO"
    ACCESSIBILITY_MENUITEMS = [LBL_CLOSED_CAPTIONING, LBL_SUBTITLE_CLOSED_CAPTION_LANGUAGE,
                               LBL_CLOSED_CAPTION_PREFERENCES,
                               LBL_LANGUAGE_AND_AUDIO_DESCRIPTION]
    # Parental Controls
    LBL_PARENTAL_CONTROLS_MENUITEM = "Control parental y compras"
    LBL_HIDE_ADULT_CONTENT = "Ocultar contenido para adultos"
    LBL_SET_RATING_LIMITS = "Establecer los lÃ\xadmites de calificaciÃ³n"
    LBL_SET_RATING_LIMITS_SCREEN = "ESTABLECER LOS LÃ\x8dMITES DE CALIFICACIÃ\x93N"
    LBL_DONT_HIDE_ADULT_CONTENT = "No ocultar"
    LBL_CREATE_PIN = "Crear PIN"
    LBL_CONFIRM_PIN = "Confirmar PIN"
    LBL_ENTER_PIN = "Introducir PIN"
    LBL_INCORRECT_PIN = "PIN incorrecto"
    LBL_INCORRECT_PIN_OVERLAY_BODY = 'Ha ingresado un PIN incorrecto. Favor intente de nuevo.'
    LBL_PARENTAL_CONTROLS_VALUE_ONUNLOCK = "[ Activado - desbloqueado ]"
    LBL_PARENTAL_CONTROLS_VALUE_ONLOCKED = "[ Activado - bloqueado ]"
    LBL_DISABLE_PARENTAL_CONTROLS = "Deshabilitar el Control parental"
    LBL_DISABLE_PARENTAL_CONTROLS_SCREEN = "Deshabilitar el Control parental"
    LBL_HIGHEST_ALLOWED_MOVIE_RATING = "Calif. max. de movie rating:"
    LBL_HIGHEST_ALLOWED_TV_RATING = "Calif. max. de TV rating:"
    LBL_UNRATED_TV_SHOWS = "Progr. de TV sin clasificar:"
    LBL_UNRATED_MOVIES = "PelÃ\xadculas sin calificar:"
    LBL_BLOCK_ALL_RATED = "Bloquear todo"
    LBL_BLOCK_ALL_UNRATED = "[ Bloquear todo ]"
    LBL_G_HIGHEST_ALLOWED_MOVIE_RATING = "G"
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_MOVIE_RATING = "AO - Permitir todo"
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_TV_RATING = "TV-MA - Permitir todo"
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_MOVIE_RATING_EXCEPT_ADULT = "Permitir todo excepto adultos"
    LBL_ALLOW_ALL_HIGHEST_ALLOWED_TV_RATING_EXCEPT_ADULT = "Permitir todo excepto adultos"
    LBL_ALLOW_ALL_UNRATED = "[ Permitir todo ]"
    LBL_CREATE_PIN_SCREEN = "SetPINOverlay"
    LBL_ENTER_PIN_SCREEN = "EnterPINOverlay"
    LBL_CONFIRM_PIN_SCREEN = "ConfirmPINOverlay"
    LBL_CATCH_UP_ICON = "image_primary_branding_live_tv_catch_up_60x60.png"
    LBL_PIN_OVERLAY_TEXT_IMAGE = ['com/tivo/applib/ResAppLibImages/applib/images/hydra/\
            hydra_image_search_keyboard_shadow_C0.png',
                                  'com/tivo/applib/ResAppLibImages/applib/images/hydra/\
                                  hydra_image_pin_hidden_character.png']
    LBL_PIN_OVERLAY_IMAGE = ['com/tivo/applib/ResAppLibImages/applib/images/hydra/\
            hydra_image_search_keyboard_shadow_C0.png',
                             'com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_control_arrow_up.png',
                             'com/tivo/applib/ResAppLibImages/applib/images/hydra/hydra_icon_control_arrow_down.png']
    LBL_PIN_OVERLAY = ['pinchallenge.PinEntryOverlayView', 'pinchallenge.SpinnerPinEntryOverlayView']
    LBL_BOOKMARK_THIS_MOVIE = "Marcar episodio como favorito "
    LBL_BOOKMARK_WHISPER = "Este episodio se agregÃ³ a Mis Programas."
    LBL_OPTION_VALUE_ON = "[ Activar ]"
    LBL_OPTION_VALUE_OFF = "[ Desactivar ]"
    LBL_PURCHASE_CONTROLS = "Control de Compras"
    LBL_PURCHASE_WITHPIN_MENU = "Se necesita un PIN para comprar"
    LBL_PURCHASE_WITHOUTPIN_MENU = "Permitir comprar sin un PIN"

    # Audio Settings
    LBL_SOUND_EFFECTS_VOLUME = "Volumen de los efectos de sonido"
    # Remote Settings
    LBL_PAIR_YOUR_REMOTE = "Enlace su control remoto a su decodificador"
    LBL_PARENTAL_CONTROLS_TITLE = "CONTROL PARENTAL"
    LBL_NETFLIX = "Netflix"
    LBL_HULU = "Hulu"
    LBL_VUDU = "Vudu"
    LBL_HBOGO = "HBO Go"
    LBL_MY_VIDEO_PROVIDERS = "Mis proveedores de video"

    def __init__(self):
        self.LBL_SYSTEM_INFO_SHORTCUTS = [self.LBL_SYSTEM_INFORMATION, self.LBL_USER_AGREEMENT, self.LBL_PRIVACY_POLICY,
                                          self.LBL_OPEN_SOURCE_NOTICES]
        self.SETTINGS_OPTIONS_UNMANAGED = [self.LBL_ACCESSIBILITY, self.LBL_ONEPASS_MANAGER, self.LBL_TODO_LIST,
                                           self.LBL_USER_PREFERENCES,
                                           self.LBL_PARENTAL_CONTROLS_SHORTCUT, self.LBL_AUDIO_SETTINGS]
        self.SETTINGS_OPTIONS_MANAGED = [self.LBL_ACCESSIBILITY, self.LBL_ONEPASS_MANAGER, self.LBL_TODO_LIST,
                                         self.LBL_USER_PREFERENCES,
                                         self.LBL_PARENTAL_CONTROLS_SHORTCUT, self.LBL_AUDIO_SETTINGS,
                                         self.LBL_REMOTE_SETTINGS,
                                         self.LBL_DEVICE_SETTINGS]
        self.SETTINGS_OPTIONS_MANAGED_WITH_PURCHASE_CONTROLS = [self.LBL_ACCESSIBILITY, self.LBL_ONEPASS_MANAGER,
                                                                self.LBL_TODO_LIST,
                                                                self.LBL_USER_PREFERENCES,
                                                                self.LBL_PARENTAL_AND_PURCHASE_CONTROLS_SHORTCUT,
                                                                self.LBL_AUDIO_SETTINGS, self.LBL_REMOTE_SETTINGS,
                                                                self.LBL_DEVICE_SETTINGS]
        self.SETTINGS_OPTIONS_UNMANAGED_WITH_PURCHASE_CONTROLS = [self.LBL_ACCESSIBILITY, self.LBL_ONEPASS_MANAGER,
                                                                  self.LBL_TODO_LIST,
                                                                  self.LBL_USER_PREFERENCES,
                                                                  self.LBL_PARENTAL_AND_PURCHASE_CONTROLS_SHORTCUT,
                                                                  self.LBL_AUDIO_SETTINGS]
        self.AUDIO_SETTINGS_MENUITEMS = [self.LBL_LANGUAGE_AND_AUDIO_DESCRIPTION, self.LBL_SOUND_EFFECTS_VOLUME]
        self.REMOTE_SETTINGS_MENUITEMS = [self.LBL_PAIR_YOUR_REMOTE]
        self.LBL_SYSTEM_AND_ACCOUNT_MENU_ITEMS = [self.LBL_HELP, self.LBL_SYSTEM_INFO]
        self.PARENTAL_CONTROLS_MENUITEMS = [self.LBL_PARENTAL_CONTROLS_MENUITEM, self.LBL_HIDE_ADULT_CONTENT,
                                            self.LBL_SET_RATING_LIMITS]
        self.LBL_DEFAULT_WATCH_NOW_FROM_CATCHUP = "Ver ahora desde Catch Up"
        self.LBL_DEFAULT_WATCH_NOW_FROM_STARTOVER = "Ver ahora desde Start Over"
        self.LBL_STRING_CATCHUP_STARTOVER_NOW = "Ver ahora desde "
