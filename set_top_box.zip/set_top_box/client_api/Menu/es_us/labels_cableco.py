from .labels import SpanishMenuLabels


class SpanishCablecoMenuLabels(SpanishMenuLabels):
    LBL_WATCH_NOW_FROM_STARTOVER = "Ver ahora desde Start Over"
    LBL_WATCH_NOW_FROM_CATCHUP = "Ver ahora desde Catch Up"
    LBL_CATCH_UP_ICON = "cableco_image_primary_branding_live_tv_catch_up_60x60.png"
