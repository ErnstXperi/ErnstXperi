import re
import time

from hamcrest.core import assert_that
from hamcrest import has_item, not_none, greater_than, equal_to, has_value, any_of, has_items, contains_string, is_
from hamcrest import equal_to_ignoring_case

from set_top_box.client_api.Menu.page import MenuPage
from tools.logger.logger import Logger
from set_top_box.test_settings import Settings
from mind_api.middle_mind.field import socu_partner_id
from tools.utils import DateTimeUtils


class MenuAssertions(MenuPage):
    __logger = Logger(__name__)

    def verify_menu_item_available(self, menu_item, expected=True, mode="contains"):
        """
        Verifying if menu item or list is available/not available,
        pressing down loop_attempts times if not found at first time.

        Args:
            menu_item (str/list): menu item label or list of menu labels
            expected (bool): if True - check item presence, if False - check item absence
            mode (str): contains - (order check) check if passed list is contained in list on UI;
                        equal - (order check) check if passed list is exactly the same as list on UI
                                applicable mostly for list, str item is always checked as contained in;
        """
        self.log.step("verifying availability of {}".format(menu_item))
        loop_attempts = 10
        self.screen.refresh()

        def check_item(menu_item, expected):
            if type(menu_item) is not list:
                self.verify_menu_item(menu_item, expected)
            else:
                self.verify_menu_list(menu_item, expected, mode)

        # TODO
        # Make it shorter
        if isinstance(menu_item, list):
            for item in menu_item:
                while item not in self.menu_list():
                    self.press_down_button(refresh=True)
                    loop_attempts -= 1
                    if loop_attempts <= 0:
                        break
                if item in self.menu_list():
                    break
            check_item(menu_item, expected)
        else:
            while menu_item not in self.menu_list():
                self.press_down_button(refresh=True)
                loop_attempts -= 1
                if loop_attempts <= 0:
                    break
            check_item(menu_item, expected)

    def verify_menu_items_availability(self, menu_items_list):
        '''
        :description:
            SETTINGS screen should be opened to call the method
            Verifies all the menu items
        '''
        self.log.step("Verifying whether {} is available or not".format(menu_items_list))
        self.screen.refresh()
        for item in menu_items_list:
            self.verify_menu_item_available(item)

    def verify_items_are_same(self, m, n):
        self.log.step(f"comparing menu {m} and {n}")
        assert_that(m, n)

    def verify_accessibility_screen_title(self, tester):
        self.log.info("Verifying current screen title is accessibility")
        self.verify_screen_title(tester.menu_labels.LBL_ACCESSIBILITY.upper())

    def verify_screen_text(self, tester):
        self.log.info("Verifying empty TO DO LIST message")
        assert_that(tester.menu_labels.LBL_EMPTY_TODO_LIST, equal_to(self.get_bodytext()))

    def verify_onepass_manager_empty_screen(self):
        self.__logger.info("Verify OnePass Manager is empty")
        screen_dump = self.screen.get_json()["xml"]
        is_empty = "menuitem" not in screen_dump
        assert_that(is_empty, "OnePass Manager is not empty; screen dump: \n{}".format(screen_dump))

    def verify_toDo_screen_title(self, tester):
        self.verify_screen_title(tester.menu_labels.LBL_TODO_LIST_SCREENTITLE)

    def verify_menu_screen_title(self):
        self.verify_screen_title(self.menu_labels.LBL_MENU_TITLE)

    def verify_onepass_manager_screen_title(self, tester):
        self.verify_screen_title(tester.menu_labels.LBL_ONEPASS_MANAGER_SCREENTITLE)

    def verify_user_pref_screen_title(self):
        self.verify_screen_title(self.menu_labels.LBL_USER_PREFERENCES.upper())

    def verify_favorite_channels_screen_title(self):
        self.verify_screen_title(self.menu_labels.LBL_FAVOURITE_CHANNELS.upper())

    def verify_favorite_channels_list_item(self):
        item = self.menu_focus()
        self.log.step("Verifying entry not empty {}".format(item))
        assert_that(item[0], not_none(), "Channel number empty")
        assert_that(item[1], not_none(), "Channel call sign empty")
        assert_that(item[2], not_none(), "Channel name empty")

    def verify_one_pass_exists(self, content=None):
        self.log.step("verifying existence of One Pass")
        content = self.remove_service_symbols(content)
        menuitem = self.screen.get_screen_dump_item('menuitem')
        assert_that(len(menuitem), greater_than(0), "Menuitem was not available in screendump")
        if content:
            assert_that(self.is_in_menu(content))

    def verify_item_option_focus(self, option):
        self.log.info("Verifying {} option".format(option))
        self.pause(2)
        self.screen.refresh()
        assert_that(self.menu_item_option_focus(), contains_string(option))

    def verify_build_and_branch(self, settings_branch, settings_build):
        menuitem = self.screen.get_screen_dump_item('menuitem')
        branchbuild = ""
        for item in menuitem:
            if item['text'] == "App version:":
                branchbuild = item['option']['text']
        branch, build = branchbuild.split("/")
        assert_that(branch, settings_branch)
        assert_that(build, settings_build)

    def verify_item_checked(self, entry, tester):
        menuitem = self.get_menu_item()
        self.log.step("Verifying {} focused item checked".format(menuitem))
        for item in menuitem:
            if item.get('text', None) == entry or (isinstance(item.get('text'), list) and entry in item.get('text')):
                assert_that(item, has_value(any_of(has_items(tester.menu_labels.LBL_CHECKED),
                                                   tester.menu_labels.LBL_CHECKED, tester.menu_labels.LBL_CHECKMARK)))
                return
        assert False

    def verify_item_unchecked(self, entry, tester):
        menuitem = self.get_menu_item()
        self.log.step("Verifying {} focused item unchecked".format(menuitem))
        if not isinstance(menuitem, list):
            if 'text' in menuitem.keys() and 'imagename' in menuitem.keys():
                if entry in menuitem['text'] and menuitem['imagename'] == tester.menu_labels.LBL_UNCHECKED:
                    return
                else:
                    raise AssertionError("Expected {} to be unchecked, but it is checked".format(entry))
        else:
            for item in menuitem:
                if item.get('text') == entry or (isinstance(item.get('text'), list) and entry in item.get('text')):
                    assert_that(item, has_value(tester.menu_labels.LBL_UNCHECKED),
                                "Expected {} to be unchecked, but it is checked".format(entry))
                    return
        assert False

    def verify_toDo_list_items_ordered(self, ch_len, removedItem=None):
        self.log.info("Verifying order of items in To Do List")
        pattern = re.compile(self.menu_labels.LBL_EXCLUDED_ARTICLES)
        if ch_len > 0:
            menu = list(map(lambda title: pattern.sub("", title), self.menu_list()))
            menu = [(i.title()).lower() for i in menu]
            ordered = sorted(menu)
            assert_that(menu, equal_to(ordered))
            assert removedItem not in menu
        else:
            self.verify_screen_text(self)

    def verify_toDo_list_empty(self, tester):
        self.verify_toDo_screen_title(tester)
        assert self.get_time_info()
        self.verify_screen_text(tester)

    def verify_cc_state(self, tester, ON=True):
        entry = "On" if ON else "Off"
        self.log.info("Verifying cc state")
        self.verify_item_checked(entry, tester)

    def verify_accesssibility_menu_items(self, content_list):
        self.log.step("Checking Accessibility menu items")
        for i in content_list:
            assert_that(self.is_in_menu(i))

    def verify_user_preferences_menu_items(self, content_list):
        self.log.step("Checking User Preferences menu items")
        for i in content_list:
            assert_that(self.is_in_menu(i))

    def verify_parental_controls_menu_items(self, content_list):
        self.log.step("Checking Parental Controls menu items")
        for i in content_list:
            assert_that(self.is_in_menu(i))

    def verify_audio_settings_menu_items(self, content_list):
        self.log.step("Checking Audio Settings menu items")
        for i in content_list:
            assert_that(self.is_in_menu(i))

    def verify_remote_settings_menu_items(self, content_list):
        self.log.step("Checking Remote Settings menu items")
        menu_list = self.menu_list()
        for i in content_list:
            result = any(re.match(i, setting) for setting in menu_list)
            if not result:
                assert_that(result, f"{i} not found in {menu_list}")

    def verify_create_PIN_overlay(self):
        self.log.step("Verifying Create PIN overlay")
        try:
            self.wait_for_screen_ready(self.menu_labels.LBL_CREATE_PIN_SCREEN)
            self.verify_overlay_title(self.menu_labels.LBL_CREATE_PIN)
        except Exception:
            raise Exception("Create PIN overlay was not shown.")

    def verify_confirm_PIN_overlay(self):
        try:
            self.wait_for_screen_ready(self.menu_labels.LBL_CONFIRM_PIN_SCREEN)
            self.verify_overlay_title(self.menu_labels.LBL_CONFIRM_PIN)
        except Exception:
            raise Exception("Confirm PIN overlay was not shown.")

    def verify_current_PIN_overlay(self):
        self.wait_for_screen_ready(self.menu_labels.LBL_CURRENT_PIN_SCREEN)
        if self.is_overlay_shown():
            assert_that(self.get_overlay_title(), is_(self.menu_labels.LBL_CURRENT_PIN),
                        "Overlay Title was not Current PIN. Curr title: {}".format(self.get_overlay_title()))
        else:
            raise AssertionError("Overlay was not shown. Curr screen: {}".format(self.view_mode()))

    def verify_new_PIN_overlay(self):
        self.wait_for_screen_ready(self.menu_labels.LBL_NEW_PIN_SCREEN)
        if self.is_overlay_shown():
            assert_that(self.get_overlay_title(), is_(self.menu_labels.LBL_NEW_PIN),
                        "Overlay Title was not New PIN. Curr title: {}".format(self.get_overlay_title()))
        else:
            raise AssertionError("Overlay was not shown. Curr screen: {}".format(self.view_mode()))

    def verify_enter_PIN_overlay(self):
        self.log.step("Verify pin overlay displayed")
        # Get the Enter Pin overlay from livetv OSD when PC is on
        if self.osd_shown():
            if self.get_trickplay_visible():
                self.log.info("Trickplay bar is still visible. waiting for it to dismiss")
                self.pause(Settings.trickplay_bar_timeout)  # added 10 sec override to infobanner timeout
            self.screen.base.press_enter()
            self.pause(2)
            self.wait_for_screen_ready(self.menu_labels.LBL_ENTER_PIN_SCREEN)
        assert_that(self.enter_PIN_overlay_visibility(self), "Enter PIN overlay was not shown.")

    def verify_enter_PIN_overlay_not_shown(self):
        assert_that(not self.enter_PIN_overlay_visibility(self), "Enter PIN overlay was shown.")

    def verify_wrong_PIN_overlay(self):
        self.wait_for_screen_ready(self.menu_labels.LBL_ENTER_PIN_SCREEN)
        self.wait_loading_indicator_disappear()
        self.verify_overlay_title(self.menu_labels.LBL_INCORRECT_PIN)
        self.verify_overlay_body(self.menu_labels.LBL_INCORRECT_PIN_OVERLAY_BODY)
        self.verify_pin_overlay_entry_empty()

    def verify_disable_parental_control_overlay(self):
        try:
            self.wait_for_screen_ready(self.menu_labels.LBL_DISABLE_PARENTAL_CONTROLS_SCREEN)
            self.verify_overlay_title(self.menu_labels.LBL_DISABLE_PARENTAL_CONTROLS)
        except Exception:
            raise Exception("Disable Parental Controls overlay was not shown.")

    def verify_no_pin_chanllenge_on_parental_controls_entrance(self, tester):
        tester.home_page.back_to_home_short()
        tester.home_assertions.verify_menu_item_available(tester.home_labels.LBL_MENU_SHORTCUT)
        tester.home_page.select_menu_shortcut(tester.home_labels.LBL_MENU_SHORTCUT)
        self.nav_to_top_of_list()
        tester.menu_page.select_menu_category(self.menu_labels.LBL_SETTINGS_SHORTCUT)
        parental_control = tester.menu_page.get_parental_controls_menu_item_label()
        self.select_menu_items(parental_control)
        assert_that(self.screen_title().lower(), equal_to(parental_control.lower()))

    def validate_watch_now_streamingoption_strip(self, tester):
        self.log.step("Checking watch now option")
        found = False
        tries = 0
        watchnow = self.menu_labels.LBL_WATCH_NOW
        source = self.menu_labels.LBL_SOURCE_ICON
        options = self.menu_labels.LBL_STREAMING_OPTIONS
        try:
            while tries < 5:
                self.screen.base.press_enter()
                self.wait_for_screen_ready()
                time.sleep(3)
                self.screen.refresh()
                text = self.menu_focus()
                image = self.strip_image_focus()
                if text is None and image is None:
                    raise AssertionError("Menu or strip item value not loaded")
                if text == self.menu_labels.LBL_WATCH_NOW:
                    value = re.search(source, image) or re.search(self.menu_labels.LBL_VUDU_ICON, image)
                    if value:
                        found = True
                    else:
                        assert False, "Content is not available from any source provider"
                    self.select_strip(options)
                    self.wait_for_screen_ready()
                    self.verify_all_streaming_options_overlay()
                    break
                else:
                    self.screen.base.press_back(time=1000)
                    time.sleep(3)
                    self.screen.base.press_right(time=1000)
                    tries += 1
            assert_that(found)
        except Exception:
            result = self.vod_api.get_FVOD_package()
            title = tester.vod_page.extract_title(result)
            tester.home_page.back_to_home_short()
            tester.home_assertions.verify_menu_item_available(tester.home_labels.LBL_SEARCH_SHORTCUT)
            tester.home_page.select_menu_shortcut(tester.home_labels.LBL_SEARCH_SHORTCUT)
            movieYear = None
            if result['offer'].movie_year:
                movieYear = result['offer'].movie_year
            if movieYear:
                tester.text_search_page.search_and_select(title, title, year=movieYear)
            else:
                tester.text_search_page.search_and_select(title, title)
            self.wait_for_screen_ready()
            self.screen.refresh()
            text = self.menu_focus()
            image = self.strip_image_focus()
            if text is None and image is None:
                raise AssertionError("Menu or strip item value not loaded")
            if text == watchnow:
                value = re.search(source, image) or re.search(self.menu_labels.LBL_VUDU_ICON, image)
                if not value:
                    assert False, "Content is not available from any source provider"
            self.select_strip(options)
            self.wait_for_screen_ready()
            self.verify_all_streaming_options_overlay()

    def verify_all_streaming_options_overlay(self):
        self.log.step("Checking all streaming options")
        state = self.wait_for_screen_ready(self.menu_labels.LBL_STREAMING_OPTIONS_OVERLAY, 30000)
        assert_that(state, "Streaming Options overlay did not appear")

    def verify_all_streaming_options_overlay_rent_on_ott_goes_before_purchase_on_ott(self):
        """
        Verifying All Streaming Options overlay items' if Rent on OTT item goes before Purchase on OTT one.
        Overlay title may differ depending on screen it's started from, usually, it's All Streaming Options.
        Applicable since Hydra 1.19

        Checks if:
            Rent on OTT option goes before Purchase on OTT one when both available for the same OTT e.g.:
               Rent on Prime Video
               Purchase on Prime Video
        """
        self.log.info("Verifying if Rent on OTT goes before Purchase on OTT on All Streaming Options overlay")
        rent_on = self.menu_labels.LBL_STREAMING_OPTIONS_RENT_ON
        purchase_on = self.menu_labels.LBL_STREAMING_OPTIONS_PURCHASE_ON
        index = 0
        menu_list = self.menu_list()
        for index in range(0, len(menu_list)):
            provider_row_ui = menu_list[index]
            provider_name_ui = provider_row_ui[0]
            # Let's retrieve provider name from current row
            if provider_name_ui.find(rent_on) != -1:
                provider_name_ret = provider_name_ui.replace(rent_on, "").strip()
            elif provider_name_ui.find(purchase_on) != -1:
                provider_name_ret = provider_name_ui.replace(purchase_on, "").strip()
            else:
                provider_name_ret = provider_name_ui
            # There can be 3 types of records: Rent on OTT, Purchase on OTT, and provider_name, and
            # let's check if item with Rent on OTT label goes before Purchase on OTT one
            if index < len(menu_list) - 1:
                prov_name_next = menu_list[index + 1][0]
                if purchase_on in provider_name_ui and provider_name_ret in prov_name_next and rent_on in prov_name_next:
                    raise AssertionError(f"{rent_on}{provider_name_ret} row does not go before "
                                         f"{purchase_on}{provider_name_ret}")

    def verify_all_streaming_options_overlay_availability_column(self, content_id, _screen="other"):
        """
        Verifying All Streaming Options overlay items' availability comlumn.
        Overlay title may differ depending on screen it's started from, usually, it's All Streaming Options.
        Applicable since Hydra 1.19

        Checks if:
            1. Prices are listed in order (UHD, HD, SD)
            2. "Included with your subscription" or "Select for price" is shown if there's no price for an OTT offer

        Args:
            content_id (str): e.g. tivo:ct.438764951
            _screen (str): screen name the overlay was reached from e.g. entered program screen from Guide;
                           one of (guide, other); logic may differ depending on screen
        """
        self.log.info("Verifying availability column on All Streaming Options overlay")
        reached_from_guide_screen = _screen.lower() == "guide"
        included_with_subscr = self.menu_labels.LBL_STREAMING_OPTIONS_SUBSCR
        socu_provider_name = self.service_api.partner_info_search(
            socu_partner_id[Settings.mso], use_cached_response=True).get("partnerInfo")[0].get("vodAppName")
        exclude_socu_partner_id = socu_partner_id[Settings.mso] if reached_from_guide_screen else None
        vod_ott_list = self.service_api.get_vod_ott_action_details(content_id, exclude_socu_partner_id, True)
        index = 0
        menu_list = self.menu_list()
        for index in range(0, len(menu_list)):
            provider_row_ui = menu_list[index]
            provider_name_ui = provider_row_ui[0]
            resolution_price_api = vod_ott_list[index].resolution_price
            is_empty_price_api_list = []
            # Let's check prices, there may be up to 3 prices (UHD, HD, SD)
            for price_index in range(0, len(resolution_price_api)):
                # The 1st cell in a row represents provider label on UI screen dump, we need the rest of items
                if len(resolution_price_api) != len(provider_row_ui) - 1:
                    raise AssertionError(f"Number of price items does not match API vs. UI; "
                                         f"from API: {len(resolution_price_api)}; on UI: {len(provider_row_ui) - 1}")
                ui_price_index = price_index + 1  # there's provider label on the 1st position in the list
                ui_price = provider_row_ui[ui_price_index]
                price = resolution_price_api[price_index]
                # On UI, video resolution is written in upper case
                api_formatted_price = price.video_resolution.upper() + " " + price.formatted_price \
                    if price.formatted_price is not None else None
                is_empty_price_api_list.append(True if api_formatted_price is None else False)
                if api_formatted_price is not None and api_formatted_price != ui_price:
                    raise AssertionError(f"Price does not match API vs. UI; from API: {api_formatted_price}; "
                                         f"on UI: {provider_row_ui[ui_price_index]}; label: {provider_name_ui}")
            # "Included with your subscription" or "Select for price" availability labels are expected
            # if no price for OTT offer
            if (all(is_empty_price_api_list) or not is_empty_price_api_list) and \
               socu_provider_name not in provider_name_ui and included_with_subscr != provider_row_ui[1]:
                raise AssertionError(f"{included_with_subscr} availability is not present for {provider_name_ui} provider")

    def verify_all_streaming_options_overlay_items_view_compare_with_api(self, content_id, _screen="other"):
        """
        Verifying All Streaming Options overlay items view.
        Overlay title may differ depending on screen it's started from, usually, it's All Streaming Options.
        Applicable since Hydra 1.19

        Checks if:
            1. SOCU offers are NOT shown on the All Streaming Options overlay when it reached from Guide
            2. SOCU offers are shown in the 1st place on the All Streaming Options overlay
            3. Channel call sign is shown for a SOCU offer with Included with your subscription availability
            4. Start time is shown for a SOCU offer
            5. verify_all_streaming_options_overlay_rent_on_ott_goes_before_purchase_on_ott()
            6. verify_all_streaming_options_overlay_availability_column()

        Args:
            content_id (str): e.g. tivo:ct.438764951
            _screen (str): screen name the overlay was reached from e.g. entered program screen from Guide;
                           one of (guide, other); logic may differ depending on screen
        """
        self.log.info("Verifying items view on All Streaming Options overlay")
        reached_from_guide_screen = _screen.lower() == "guide"
        upgrade_to_watch_lbl = self.menu_labels.LBL_STREAMING_OPTIONS_UPGRADE
        socu_provider_name = self.service_api.partner_info_search(
            socu_partner_id[Settings.mso], use_cached_response=True).get("partnerInfo")[0].get("vodAppName")
        exclude_socu_partner_id = socu_partner_id[Settings.mso] if reached_from_guide_screen else None
        vod_ott_list = self.service_api.get_vod_ott_action_details(content_id, exclude_socu_partner_id, True)
        self.screen.get_json()
        self.verify_overlay_title(self.menu_labels.LBL_STREAMING_OPTIONS_OVERLAY_TITLE)
        index = 0
        is_socu_on_the_ui = False
        menu_list = self.menu_list()
        for index in range(0, len(menu_list)):
            provider_row_ui = menu_list[index]
            provider_name_ui = provider_row_ui[0]
            chan_call_sign_ui = provider_row_ui[1] if vod_ott_list[index].call_sign else None
            start_time_ui = None
            if vod_ott_list[index].start_time:
                start_time_ui = provider_row_ui[2] if vod_ott_list[index].call_sign else provider_row_ui[1]
            start_time_api = DateTimeUtils.convert_date_with_box_time_zone(
                vod_ott_list[index].start_time, self.get_current_time(), self.service_api.MIND_DATE_TIME_FORMAT,
                self.service_api.MIND_DATE_TIME_FORMAT) if vod_ott_list[index].start_time else None
            socu_call_sign = vod_ott_list[index].call_sign
            # Checking provider label start time, and channel call sign matching API vs. UI
            if socu_provider_name in provider_name_ui and reached_from_guide_screen:
                raise AssertionError("SOCU is shown on the overlay when reached from Guide to it")
            if vod_ott_list[index].label != provider_name_ui:
                raise AssertionError(f"Provider label does not match API vs. UI; from API: {vod_ott_list[index].label}; "
                                     f"on UI: {provider_name_ui}")
            if upgrade_to_watch_lbl not in provider_row_ui and vod_ott_list[index].call_sign != chan_call_sign_ui:
                # There's no channel call sign for an offer with Upgrade to watch availability
                raise AssertionError(f"Channel call sign does not match API vs. UI; from API: {socu_call_sign}; "
                                     f"on UI: {chan_call_sign_ui}")
            if vod_ott_list[index].start_time and start_time_api != start_time_ui:
                raise AssertionError(f"SOCU start time does not match API vs. UI; from API: {start_time_api}; "
                                     f"on UI: {start_time_ui}")
            if socu_provider_name in provider_name_ui:
                is_socu_on_the_ui = True
        # Checking if SOCU is the 1st item on the All Streaming Options overlay
        if is_socu_on_the_ui and not reached_from_guide_screen and socu_provider_name not in menu_list[0][0]:
            raise AssertionError("SOCU is not the 1st item on the overlay")
        self.verify_all_streaming_options_overlay_rent_on_ott_goes_before_purchase_on_ott()
        self.verify_all_streaming_options_overlay_availability_column(content_id, _screen)

    def verify_option(self, option_item, option_value):
        """
        :description:
               verify value for option item
        :param option_item: Option item label
               option_value: option value
        :return:
        """
        screen = self.screen.get_json()['xml']
        print(screen)
        for menuitem in screen['menuitem']:
            if menuitem['text'] == option_item:
                assert_that(menuitem['option']['text'], contains_string(option_value))
                return
        else:
            raise Exception("Option item not found")

    def verify_PIN_overlay_in_settings_submenus(self, parental=''):
        """
        To verify PIN overlay is shown in settings submenus if 'On - Locked' set and not shown if 'On - Unlocked'
        Note: Enter to Parental Controls menu always requires PIN challenge
        Parental Controls modes:
        'On - Locked' - LBL_PARENTAL_CONTROLS_VALUE_ONLOCKED
        'On - Unlocked' - LBL_PARENTAL_CONTROLS_VALUE_ONUNLOCK
        :param parental: str, 'On - Locked'/'On - Unlocked'
        """
        settings_list = self.get_settings_menu_items_list()
        for menu in settings_list:
            self.log.info(f"Verifying PIN overlay on attempt to open '{menu}' "
                          f"when Parental Controls are '{parental}'")
            self.select_menu(menu)
            self.wait_for_screen_ready()
            if parental == self.menu_labels.LBL_PARENTAL_CONTROLS_VALUE_ONLOCKED or 'parental' in menu.lower():
                assert_that(self.enter_PIN_overlay_visibility(self),
                            f"PIN challenge overlay wasn't shown when entering '{menu}' "
                            f"and parental controls are '{parental}'")
                assert_that(self.screen_title(), is_(self.menu_labels.LBL_MENU_TITLE))
            elif parental == self.menu_labels.LBL_PARENTAL_CONTROLS_VALUE_ONUNLOCK:
                assert_that(not self.enter_PIN_overlay_visibility(self),
                            f"PIN challenge overlay was shown when entering '{menu}' "
                            f"and parental controls are '{parental}'")
                if menu == self.menu_labels.LBL_REMOTE_SETTINGS:
                    assert_that(self.screen_title(), is_(self.menu_labels.LBL_REMOTE_SETTINGS_SCREEN_TITLE))
                elif menu == self.menu_labels.LBL_DEVICE_SETTINGS:
                    assert_that(self.screen_title(), is_(self.menu_labels.LBL_MENU_TITLE))
                else:
                    assert_that(self.screen_title(), is_(menu.upper()))
            self.menu_press_back()

    def verify_menu_strip_items(self, tester):
        self.log.step("Verifying strip list items")
        self.nav_to_top_of_list()
        self.screen.refresh()
        assert_that(self.strip_list(), has_items(tester.menu_labels.LBL_SETTINGS_SHORTCUT,
                                                 tester.menu_labels.LBL_SYSTEM_AND_ACCOUNT))

    def verify_selected_audio_language_options(self, language, menulist):
        self.log.step("Verifying audio language option was modified or not")
        for i in range(len(menulist)):
            if self.screen.get_screen_dump_item('menuitem')[i].__contains__('imagename'):
                if self.menu_labels.LBL_CHECKMARK not in self.screen.get_screen_dump_item('menuitem')[i]['imagename'] and \
                        language != self.screen.get_screen_dump_item('menuitem')[i]['text']:
                    assert False
            self.screen.base.press_down()
            self.screen.base.press_enter()
            self.wait_for_screen_ready()
            self.screen.refresh()
            language = self.screen.get_screen_dump_item('menuitem')[0]['option']['text']
            self.select_menu(self.menu_labels.LBL_LANGUAGE_AND_AUDIO_DESCRIPTION)
            self.wait_for_screen_ready()

    def verify_WTW_content_strip_title(self, category):
        self.log.step(f"Verifying WTW content strip title for {category}")
        self.screen.refresh()
        assert_that(self.is_strip_focus())
        assert_that(self.screen_title().lower(), contains_string(category.lower()))

    def store_the_value_and_move_the_highlight_to_next_box(self, tester):
        self.log.step("Verifying focus movement on entering value in pin overlay")
        for i in range(3):
            self.screen.base.press_enter()
            self.screen.refresh()
            overlay = self.screen.get_screen_dump_item('pinentry')
            value = overlay[i + 1]
            if 'hasfocus' in value:
                image = overlay[i]
                if image['imagename'] != self.menu_labels.LBL_PIN_OVERLAY_TEXT_IMAGE:
                    raise AssertionError("Imagename and stored values are not expected.")
        self.screen.base.press_enter()

    def check_enter_pin_overlay_navigation(self):
        self.log.step("Verifying enter pin overlay navigation")
        for i in range(2):
            self.screen.base.press_right()
            self.screen.refresh()
            overlay = self.screen.get_screen_dump_item('pinentry')
            if Settings.hydra_branch() >= Settings.hydra_branch("b-hydra-streamer-1-11"):
                value = overlay[i + 1]
            else:
                value = overlay[0]
            if value['hasfocus'] != 'true':
                raise AssertionError("Managed devices shouldn't move to next pin box.")

    def verify_tips_and_tricks_screen_text(self, tester):
        branding_value = self.service_api.branding_ui()
        device_name = branding_value.device_name.get('value')
        search_term = branding_value.mso_tutorial_channel_info.get('tipsAndTricksSearchTerm').get('value')
        channel_url = branding_value.mso_tutorial_channel_info.get('tipsAndTricksWebUrl').get('value')
        screen_msg = self.get_body_text()
        screen_msg = screen_msg.encode('iso-8859-1').decode()
        assert_that(tester.menu_labels.LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR1 + device_name + tester.menu_labels.
                    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR2 + search_term + tester.menu_labels.
                    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR3 + channel_url + tester.menu_labels.
                    LBL_TIPS_TRICKS_SCREEN_MESSAGE_STR4, equal_to(screen_msg))

    def verify_hide_adult_content_on(self):
        assert_that(self.is_hide_adult_content_on(), "Hide adult content is not on")

    def verify_movie_rating_block_all(self):
        assert_that(self.is_movie_rating_block_all(), "movie rating are not block all state")

    def verify_is_tv_rating_block_all(self):
        assert_that(self.is_tv_rating_block_all(), "TV rating are not block all state")

    def verify_is_movie_rating_allow_all_except_adult(self):
        assert_that(self.is_movie_rating_allow_all_except_adult(), "Movie rating are not allowed all except adult state"
                    )

    def verify_is_tv_rating_allow_all_except_adult(self):
        assert_that(self.is_tv_rating_allow_all_except_adult(), "Tv rating are not allowed all except adult state")

    def verify_remote_type(self):
        """
        Should be used to verify remote type only on managed devices
        """
        assert Settings.is_managed(), "The function supports only managed devices."
        assert_that(self.get_remote_type(), is_(self.menu_labels.LBL_TIVO_REMOTE))

    def verify_remote_setup_preview(self):
        """
        Should be used to verify remote type only on managed devices
        """
        assert Settings.is_managed(), "The function supports only managed devices."
        preview_panel = self.get_preview_panel()
        if type(preview_panel) is dict and preview_panel.get('text'):
            preview_panel_text = preview_panel.get('text')
        else:
            raise LookupError("Preview panel doesn't contain 'text' item. PP: {}".format(preview_panel))
        assert_that(preview_panel_text, is_(self.menu_labels.LBL_TIVO_REMOTE_PREVIEW))

    def validate_one_pass_and_recording_option(self, tester, option_name):
        self.wait_for_screen_ready(self.menu_labels.LBL_ONEPASS_AND_RECORDING_OPTIONS_SCREEN)
        self.verify_screen_title(option_name.upper())
        menu = self.screen.get_screen_dump_item('menuitem')
        for i in range(len(menu)):
            self.log.info("menu items: {}".format(menu[i].get('text')))
            if menu[i].get('text') not in tester.menu_labels.LBL_ONEPASS_AND_RECORDING_OPTIONS_LIST:
                assert False, "Expected item is not present in the recording options"

    def verify_preview_text(self, actual_preview_text):
        self.log.step("Verifying the expected preview text")
        expected_preview_text = self.menu_labels.LBL_SUBTITLE_PREVIEW_TEXT
        self.log.info("Actual text {}".format(actual_preview_text))
        self.log.info("Expected text {}".format(expected_preview_text))
        assert_that(actual_preview_text, equal_to_ignoring_case(expected_preview_text), "preview text is not as expected")

    def verify_subtitle_lang_change(self, expected_language, refresh=False):
        self.log.info("Verifying the language")
        if refresh:
            self.screen.refresh()
        changed_language = self.screen.get_screen_dump_item('menuitem')[1]['option']['text']
        self.log.info("Language is {}".format(changed_language))
        assert_that(changed_language, equal_to_ignoring_case(expected_language), "Language change is not as expected")

    def verify_device_settings_screen_title(self, tester, screen_title):
        self.log.step("Verifying Device Settings screen title")
        if screen_title != tester.home_labels.LBL_DEVICE_SETTINGS_TITLE:
            raise AssertionError("Device Settings screen title does not match")

    def verify_channel_signal_strength_option(self, tester):
        """
        Curently only for Smartbox and Series7-Topaz device, IPonly mode is enabled
        So need to check the mode type for both the device
        According to the mode type, need to check the channel signal strength availability
        """
        if Settings.is_smartbox() or Settings.is_topaz():
            device_mode = self.get_stb_mode(tester)
            if device_mode == "IP-STB":
                self.log.info("box is in IP only mode")
                self.verify_menu_item_available(tester.menu_labels.LBL_CABLE_SIGNAL_STRENGTH, False)
            elif device_mode == "HD-STB":
                self.log.info("box is in HD-STB only mode")
                self.verify_menu_item_available(tester.menu_labels.LBL_CABLE_SIGNAL_STRENGTH, True)
            else:
                self.log.info("Box is in mini mode and channel list option won't be available")
        else:
            self.log.info("box is in hybrid mode only mode")
            self.verify_menu_item_available(tester.menu_labels.LBL_CABLE_SIGNAL_STRENGTH, True)

    def verify_conditional_access_option(self, tester):
        """
        conditional access screen is applicable only for smartbox
        conditional access option is available only when smartbox is in zapper mode mini mode not on IP/mini mode
        """
        device_mode = self.get_stb_mode(tester)
        if device_mode == "IP-STB" or "Mini":
            self.verify_menu_item_available(tester.menu_labels.LBL_CONDITIONAL_ACCESS_STB, False)
        else:
            self.verify_menu_item_available(tester.menu_labels.LBL_CONDITIONAL_ACCESS_STB, True)

    def verify_account_system_info_screen_title_stb(self, tester):
        self.log.info("Verifying current screen title is account & system info")
        self.verify_screen_title(tester.menu_labels.LBL_ACCOUNT_SYSTEM_INFO_STB.upper())

    def verify_system_information_screen_title_stb(self, tester):
        self.log.info("Verifying current screen title is system information")
        self.verify_screen_title(tester.menu_labels.LBL_SYSTEM_INFORMATION.upper())

    def verify_channel_settings_screen_title_stb(self, tester):
        self.log.info("Verifying current screen title is channel settings")
        self.verify_screen_title(tester.menu_labels.LBL_CHANNEL_SETTINGS_STB.upper())

    def verify_remote_device_screen_title_stb(self, device_mode):
        self.log.info("Verifying remote device cablecard conditional access screen title")
        if Settings.is_smartbox():
            if device_mode == "IP-STB" or "Mini":
                self.verify_screen_title(
                    self.menu_labels.LBL_REMOTE_DEVICES.upper())
            else:
                self.verify_screen_title(
                    self.menu_labels.LBL_REMOTE_DEVICES_CONDITIONALACCESS_STB.upper())
        elif Settings.is_topaz():
            if device_mode == "IP-STB":
                self.verify_screen_title(
                    self.menu_labels.LBL_REMOTE_DEVICES.upper())
            else:
                self.verify_screen_title(
                    self.menu_labels.LBL_REMOTE_CABLECARD_DEVICE_STB.upper())
        else:
            self.log.info("Box is dvr and not TOPAZ/SMARTBOX")
            self.verify_screen_title(
                self.menu_labels.LBL_REMOTE_CABLECARD_DEVICE_STB.upper())

    def verify_system_diagnostics_screen_title_stb(self):
        self.log.info("Verify the system diagnostics screen title in STB")
        self.verify_screen_title(self.menu_labels.LBL_SYSTEM_DIAGNOSTICS_TITLE_STB)

    def verify_cablecard_decoder_option(self, device_mode):
        if device_mode == "IP-STB":
            self.verify_menu_item_available(self.menu_labels.LBL_CABLECARD_DECODER_STB, False)
        else:
            self.verify_menu_item_available(self.menu_labels.LBL_CABLECARD_DECODER_STB, True)

    def verify_string_in_adb_logs(self, expected_string):
        raw_log = self.screen.base.find_str_in_log(string=expected_string, since="start")
        if not raw_log:
            raise AssertionError("expected string not found")
        else:
            self.log.step("expected string found")

    def verify_preview_pane(self, expected_preview, preview='previewPane'):
        self.log.info("Verify the preview pane message")
        preview_panel = self.get_preview_panel(preview)
        if type(preview_panel) is dict and preview_panel.get('text'):
            actual_preview = preview_panel.get('text')
        else:
            raise LookupError("Preview panel doesn't contain 'text' item. PP: {}".format(preview_panel))
        if expected_preview != actual_preview:
            raise AssertionError("Preview Pane message is not as expected."
                                 "\n Expected : {} \n Actual : {}".format(expected_preview, actual_preview))

    def verify_personalized_ads_enabled(self, status=True):
        """
        Should be called from USER PREFERENCES screen
        """
        self.log.info(f"Verifying that Personalized Ads enabled - '{status}'")
        self.verify_menu_item_available(self.menu_labels.LBL_PERSONALIZED_ADS)
        curr_stat = self.get_personalized_ads_status()
        assert_that(curr_stat, is_(status), f"Expected status '{status}', but actual is '{curr_stat}'.")

    def verify_data_sharing_enabled(self, status=True):
        """
        Should be called from USER PREFERENCES screen
        """
        self.verify_menu_item_available(self.menu_labels.LBL_VIEWERSHIP_DATA_SHARING)
        curr_stat = self.get_personal_data_sharing_status()
        assert_that(curr_stat, is_(status), f"Expected status '{status}', but actual is '{curr_stat}'.")

    def validate_branding_bundle_field_value(self, value, preview_text):
        """
        Validates values returned from branding ui bundle get against preview text
        """
        if value not in preview_text:
            raise AssertionError("{} is not displayed in Preview {}".format(value, preview_text))

    def get_device_name(self, tester):
        """
        Get device name from branding Ui.
        If branding UI doesn't return device name .It will search in partner info and returns.
        If both places doesn't have it then returns none.
        """
        try:
            device_name = self.service_api.branding_ui(field="device_name")
            self.log.info("device_name={}".format(device_name))
        except Exception:
            response = self.service_api.getTivoPartnerId(mso=Settings.mso,
                                                         test_environment=Settings.test_environment,
                                                         result=True)
            if response['partnerInfo'][0]['msoContactInfo']["deviceName"]:
                device_name = response['partnerInfo'][0]['msoContactInfo']["deviceName"]
            else:
                device_name = None
        if device_name is None:
            raise AssertionError("Device Name is not available in branding ui and partner info search.")
        return device_name

    def verify_device_name_remote_setting(self, dev_name):
        """
        Verifies device name is same in UI in remote settings screen
        Params: Pass device name obtained through service api
        """
        ui_variable = None
        item = self.menu_labels.LBL_REMOTE_DESCRIPTION
        self.log.info("Verifying device name in remote setting")
        menu_items = self.screen.get_screen_dump_item('menuitem')
        length = len(menu_items)
        if length < 3:
            ui_variable = menu_items['text']
        else:
            for i in range(length):
                if item in menu_items[i]['text']:
                    ui_variable = menu_items[i]['text']
                    break
        assert_that(ui_variable, (item + dev_name), "Device name is different")

    def verify_pc_value_is_on_unlocked(self):
        assert_that(self.is_pc_is_on_unlocked(), "Parental Controls Value is not: ",
                    is_(self.menu_labels.LBL_PARENTAL_CONTROLS_VALUE_ONUNLOCK))
