from core_api.stb.assertions import CoreAssertions
from test_settings import Settings
from tools.logger.logger import Logger
from set_top_box.client_api.Menu.page import MenuPage as DefaultMenuPg


class MillicomMenuPage(DefaultMenuPg):

    def set_rating_limits(self, rated_movie, **kwargs):
        """
        :description:
            Set Rating Limits screen in the Parental Controls should be opened before setting values
        :params:
            rated_movie = Highest alowed movie rating
            rated_tv_show = Highest allowed TV rating
            unrated_tv_show = Unrated TV shows
            unrated_movie = Unrated movies
        :return:
        """
        self.log.info("Modifying rating limit options for rated programs : milicom")

        def get_current_state():
            ret = {}
            for item in self.get_menu_item():
                ret[item["text"]] = item["option"]['text']
            return ret
        expected_values = {self.menu_labels.LBL_HIGHEST_ALLOWED_RATING: rated_movie}
        self.log.step("Setting rating limit options to {}".format(expected_values))
        try:
            state = get_current_state()
            for k, v in expected_values.items():
                self.log.info(f"Setting {k} to value {v}")
                if v in state[k]:
                    self.log.info("Value {} already setted for option {}".format(v, k))
                    continue
                self.nav_to_menu(k)
                self.screen.refresh()
                self.nav_to_item_option(v)
            self.log.info("Changed all options")
        except Exception:
            # TODO Remove if new realization stable
            self.log.info("Smth went wrong setting rating limits")
            self.nav_to_menu(self.menu_labels.LBL_HIGHEST_ALLOWED_RATING)
            self.screen.refresh()
            self.nav_to_item_option(rated_movie)
            self.screen.refresh()
