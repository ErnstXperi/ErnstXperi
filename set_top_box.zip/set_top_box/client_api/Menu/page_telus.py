from core_api.stb.assertions import CoreAssertions
from test_settings import Settings
from tools.logger.logger import Logger
from set_top_box.client_api.Menu.page import MenuPage as DefaultMenuPg


class TELUSMenuPage(DefaultMenuPg):
    __logger = Logger(__name__)

    def set_rating_limits(self, rated_movie, unrated_tv_show, unrated_movie, **kwargs):
        """
        :description:
            Set Rating Limits screen in the Parental Controls should be opened before setting values
        :params:
            rated_movie = Highest alowed movie rating
            rated_tv_show = Highest allowed TV rating
            unrated_tv_show = Unrated TV shows
            unrated_movie = Unrated movies
        :return:
        """
        self.log.info("Modifying rating limit options for rated/unrated TV/Movies")

        def get_current_state():
            ret = {}
            for item in self.get_menu_item():
                ret[item["text"]] = item["option"]['text']
            return ret
        expected_values = {self.menu_labels.LBL_HIGHEST_ALLOWED_CANADA: rated_movie,
                           self.menu_labels.LBL_UNRATED_TV_SHOWS: unrated_tv_show,
                           self.menu_labels.LBL_UNRATED_MOVIES: unrated_movie}
        self.log.step("Setting rating limit options to {}".format(expected_values))
        try:
            state = get_current_state()
            for k, v in expected_values.items():
                self.log.info(f"Setting {k} to value {v}")
                if v in state[k]:
                    self.log.info("Value {} already setted for option {}".format(v, k))
                    continue
                self.nav_to_menu(k)
                self.screen.refresh()
                self.nav_to_item_option(v)
            self.log.info("Changed all options")
        except Exception:
            # TODO Remove if new realization stable
            self.log.info("Smth went wrong setting rating limits")
            self.nav_to_menu(self.menu_labels.LBL_HIGHEST_ALLOWED_CANADA)
            self.screen.refresh()
            self.nav_to_item_option(rated_movie)
            self.nav_to_menu(self.menu_labels.LBL_UNRATED_TV_SHOWS)
            self.screen.refresh()
            self.nav_to_item_option(unrated_tv_show)
            self.nav_to_menu(self.menu_labels.LBL_UNRATED_MOVIES)
            self.screen.refresh()
            self.nav_to_item_option(unrated_movie)

    def lock_pc_with_ratings(self, tester, rated_movie=None, rated_tv_show=None, unrated_tv_show=None,
                             unrated_movie=None):
        if not rated_movie:
            rated_movie = self.get_movie_rating()
        if not unrated_tv_show:
            unrated_tv_show = self.menu_labels.LBL_ALLOW_ALL_UNRATED
        if not unrated_movie:
            unrated_movie = self.menu_labels.LBL_ALLOW_ALL_UNRATED
        self.log.step("Changing rating limit options for parental controls")
        self.turnonpcsettings(tester, "on", "off")
        self.go_to_set_rating_limit(self)
        self.set_rating_limits(rated_movie=rated_movie,
                               unrated_tv_show=unrated_tv_show, unrated_movie=unrated_movie)
        self.menu_press_back()
        self.select_menu_items(self.menu_labels.LBL_PARENTAL_CONTROLS)
