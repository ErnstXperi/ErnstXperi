from hamcrest import assert_that, has_item
import pytest

from set_top_box.client_api.provisioning.page import ProvisioningPage


class ProvisioningAssertions(ProvisioningPage):

    def verify_branding_labels(self, response):
        self.log.step("Verifying Branding labels")
        if response:
            assert_that(response, has_item('msoPartnerId'))
            assert_that(response, has_item('deviceType'))
            assert_that(response, has_item('msoServiceId'))
            self.log.info("branding UI items found")
        else:
            pytest.fail("Could not find Banding ui values")

    def verify_branding_ui_values(self, actual_list, expected_list):
        self.log.step("Verifying Branding labels values")
        for i in range(len(expected_list)):
            if expected_list[i] not in actual_list:
                assert_that(False, "{} doesn't match".format(expected_list[i]))
