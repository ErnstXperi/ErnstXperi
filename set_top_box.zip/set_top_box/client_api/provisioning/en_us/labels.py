class ProvisioningLabels:

    LBL_NDVR_ACTIVATED_OVERLAY = "Recording Feature Enabled"
    LBL_NDVR_CANCEL_OVERLAY = "Recording Feature Disabled"
    LBL_ACC_LOCKED_SCREEN_VIEW_MODE = "accountlockout.AccountLockoutScreenView"
    CUBIWARE_URL = {
        "vp1": "http://10.10.241.204:10380/",
        "vp2": "http://10.10.241.203:10380/",
        "vp3": "http://10.10.241.202:10380/",
        "vp4": "http://10.10.241.237:10380/",
        "vp6": "http://10.100.216.108:10380/",
        "vp7": "http://10.100.216.109:10380/",
        "vp8": "http://l-cc5-vp8-mw1.cubi.sj.tivo.com:10380/",
        "vp10": "http://l-cc11-vp10-mw1.cubi.sj.tivo.com:10380/",
        "vp11": "http://l-cc11-vp11-mw1.cubi.sj.tivo.com:10380/",
        "vp12": "http://l-cc5-vp12-mw1.cubi.sj.tivo.com:10380/",
        "vp13": "http://l-cc11-vp13-mw1.cubi.sj.tivo.com:10380/",
        "vp14": "http://l-cc11-vp14-mw1.cubi.sj.tivo.com:10380/",
        "vp15": "http://l-cc5-vp15-mw1.cubi.sj.tivo.com:10380/",
        "vp16": "http://l-cc5-vp16-mw1.cubi.sj.tivo.com:10380/",
        "vp17": "http://l-cc5-vp17-mw1.cubi.sj.tivo.com:10380/",
        "vp18": "http://l-cc11-vp18-mw1.cubi.sj.tivo.com:10380/",
        "vp19": "http://l-cc11-vp19-mw1.cubi.sj.tivo.com:10380/"
    }
    CUBIWARE_TOKEN = {
        "vp1": "VUlC5QaPLWb3dnamDfCm",
        "vp2": "5m2nVBhsmgqOoJVpOPBM",
        "vp3": "8oHurzHGylyyJ2d4h3ao",
        "vp4": "VUlC5QaPLWb3dnamDfCm",
        "vp6": "LGHB5nBh3ElfpK7KMeu4",
        "vp7": "MPcSUtDfNuAflYQoxqaP",
        "vp8": "z6We2bfs5UUAr66eaYJR",
        "vp10": "Rq7rpWE69cxsUf2rOwwc",
        "vp11": "6nW8eM8vU9XUPZ2WSA",
        "vp12": "ynxv89BNNTg9dQr7wwLS",
        "vp13": "z6We2bfs5UUAr66eaYJR",
        "vp14": "p9GFmaLGrw5Yu6Bm4B4K",
        "vp15": "pkDKmJPPrzTHMcvqWw0k",
        "vp16": "DRmxYI2tW3ap9ogiCdjE",
        "vp17": "2JsPVMoBO4rk0W7kc2G6",
        "vp18": "D5qvKdAJUKBXZdNW9Eej",
        "vp19": "YFDjZhADTZT98YGqf8Ep"
    }
    CUBIWARE_ENVS = {
        "vp1": "USQE1",
        "vp2": "CDVRQE1",
        "vp3": "USQE1",
        "vp4": "STAGING",
        "vp6": "USQE1",
        "vp7": "STAGING",
        "vp8": "CDVRQE1",
        "vp10": "USQE1",
        "vp11": "STAGING",
        "vp12": "USQE1",
        "vp13": "USQE1",
        "vp14": "STAGING",
        "vp15": "STAGING",
        "vp16": "CDVRQE1",
        "vp17": "CDVRQE1",
        "vp18": "USQE1",
        "vp19": "STAGING"
    }
    SEACHANGE_URL = "http://SCpub.tivo.com:8080/Publisher/BO/CRM/Customers/"

    LBL_BRANDING_ATTRIBUTES = ["phoneCustomerSupportNumber", "urlError",
                               "urlCustomerSupport", "customerSupportName",
                               "deviceNameShort", "dvrService"]
