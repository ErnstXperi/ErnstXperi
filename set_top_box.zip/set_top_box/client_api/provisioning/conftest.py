import os
import shutil
from datetime import time
from inspect import isclass
from itertools import chain
from operator import itemgetter

import pytest

from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.my_shows.assertions import MyShowsAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.client_api.Menu.conftest import disable_parental_controls  # noqa: F401
from set_top_box.client_api.guide.assertions import GuideAssertions
from set_top_box.client_api.VOD.assertions import VODAssertions
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.client_api.apps_and_games.assertions import AppsAndGamesAssertions
from set_top_box.client_api.home.labels_loki import Loki_HomeLabels
from set_top_box.client_api.wtw.assertions import WhatToWatchAssertions
from set_top_box.client_api.program_options.assertions import ProgramOptionsAssertions
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from set_top_box.test_settings import Settings
from core_api.stb.base import StreamerBase
from tools.logger.logger import Logger
from set_top_box.client_api.provisioning.assertions import ProvisioningAssertions
from set_top_box.conf_constants import FeaturesList
from health.DS_setup_reboot.DS_setup_tools import DsSetupTools

__log = Logger(__name__)


@pytest.fixture(autouse=True, scope="class")
def setup_provisioning(request):
    """
    Configure steps to be executed before the test cases run
    :param request:
    :return:
    """
    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_labels = request.cls.home_page.home_labels = LabelFactory("home", Settings)
    request.cls.home_page.home_labels = request.cls.home_labels
    request.cls.home_assertions = HomeAssertions(request.cls.screen)

    request.cls.loki_labels = Loki_HomeLabels()
    request.cls.home_assertions.home_page = request.cls.home_page

    request.cls.provisioning_page = PageFactory("provisioning", Settings, request.cls.screen)
    request.cls.provisioning_labels = request.cls.provisioning_page.provisioning_labels = LabelFactory("provisioning",
                                                                                                       Settings)
    request.cls.provisioning_page.provisoning_labels = request.cls.home_labels
    request.cls.provisioning_assertions = ProvisioningAssertions(request.cls.screen)

    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)
    request.cls.menu_labels = request.cls.menu_page.menu_labels = LabelFactory("Menu", Settings)

    request.cls.my_shows_labels = LabelFactory("my_shows", Settings)
    request.cls.my_shows_page = PageFactory("my_shows", Settings, request.cls.screen)
    request.cls.home_page.my_shows_page = request.cls.my_shows_page
    request.cls.my_shows_assertions = MyShowsAssertions(request.cls.screen)

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)

    request.cls.vod_assertions = VODAssertions(request.cls.screen)
    request.cls.vod_page = PageFactory("VOD", Settings, request.cls.screen)
    request.cls.vod_labels = LabelFactory("VOD", Settings)

    request.cls.wtw_page = PageFactory("wtw", Settings, request.cls.screen)
    request.cls.wtw_assertions = WhatToWatchAssertions(request.cls.screen)
    request.cls.wtw_page.labels = request.cls.wtw_labels = LabelFactory("wtw", Settings)

    request.cls.watchvideo_assertions = WatchVideoAssertions(request.cls.screen)

    request.cls.text_search_page = PageFactory("text_search", Settings, request.cls.screen)

    request.cls.watchvideo_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.watchvideo_labels = request.cls.liveTv_labels = LabelFactory("watchvideo", Settings)

    request.cls.apps_and_games_labels = LabelFactory("apps_and_games", Settings)
    request.cls.apps_and_games_assertions = AppsAndGamesAssertions(request.cls.screen)
    request.cls.apps_and_games_page = PageFactory("apps_and_games", Settings, request.cls.screen)

    request.cls.program_options_assertions = ProgramOptionsAssertions(request.cls.screen)
    request.cls.program_options_page = PageFactory("program_options", Settings, request.cls.screen)
    request.cls.program_options_labels = LabelFactory("program_options", Settings)

    request.cls.system_page = PageFactory("system", Settings, request.cls.screen)
    request.cls.system_labels = LabelFactory("system", Settings)
    request.cls.system_page.system_labels = request.cls.system_labels
    request.cls.home_page.system_labels = request.cls.system_labels

    request.cls.acc_locked_labels = LabelFactory("account_locked", Settings)
    request.cls.acc_locked_page = PageFactory("account_locked", Settings, request.cls.screen)
    request.cls.acc_locked_page.acc_locked_labels = request.cls.acc_locked_labels

    request.cls.dst = DsSetupTools()
    request.cls.provisioning_page.menu_page = request.cls.menu_page
    request.cls.provisioning_page.home_page = request.cls.home_page
    request.cls.provisioning_page.home_labels = request.cls.home_labels
    request.cls.provisioning_page.menu_labels = request.cls.menu_labels
    request.cls.provisioning_page.home_assertions = request.cls.home_assertions


@pytest.fixture(autouse=False, scope="function")
def activate_ndvr(request):
    """
    Method to activate ndvr
    """
    pr1_prov_account_get = request.cls.iptv_prov_api.pr1_prov_account_get(
        request.cls.service_api.getPartnerCustomerId(Settings.tsn),
        request.cls.service_api.get_mso_partner_id(Settings.tsn))
    dictionary = pr1_prov_account_get.get("provDevice")
    if dictionary is not None:
        value = "platformName"
        resource = [sub[value] for sub in dictionary]
        if "npvrPlatform" not in resource:
            request.cls.iptv_prov_api.pr1_prov_device_activate(
                'NpvrSmallPackage',
                request.cls.service_api.getPartnerCustomerId(Settings.tsn),
                request.cls.service_api.get_mso_partner_id(Settings.tsn),
                request.cls.service_api.fe_device_mso_service_id_get()["msoServiceId"])
            if request.cls.provisioning_page.is_ndvr_enabled_overlay():
                request.cls.home_page.press_enter()
            request.cls.home_page.wait_for_screen_ready(timeout=40000)
            channel = request.cls.guide_page.guide_streaming_channel_number(request.cls)
            request.cls.home_page.go_to_guide(request.cls)
            request.cls.guide_page.wait_for_screen_ready(request.cls.guide_labels.LBL_GUIDE_SCREEN)
            request.cls.guide_assertions.verify_guide_screen(request.cls)
            request.cls.guide_page.enter_channel_number(channel)
            program = request.cls.guide_page.get_live_program_name(request.cls)
            request.cls.guide_page.create_live_recording()
            request.cls.home_page.go_to_my_shows()
            request.cls.my_shows_page.select_my_shows_category(request.cls,
                                                               request.cls.my_shows_labels.LBL_SERIES_RECORDINGS)
            request.cls.my_shows_assertions.verify_content_under_recordings_filter(request.cls, program)


def activate_ndvr_simple(request):
    """
    Enabling nDVR and restarting the Hydra app, if nDVR is not enabled
    """
    is_ndvr_enabled = request.cls.service_api.get_feature_status(FeaturesList.NDVR)
    if not is_ndvr_enabled:
        __log.info("Enabling nDVR")
        request.cls.iptv_prov_api.pr1_prov_device_activate(
            'NpvrSmallPackage',
            request.cls.service_api.getPartnerCustomerId(Settings.tsn),
            request.cls.service_api.get_mso_partner_id(Settings.tsn),
            request.cls.service_api.fe_device_mso_service_id_get()["msoServiceId"])
        request.cls.home_page.wait_for_screen_ready(request.cls.home_labels.LBL_RECORDING_ENABLED, timeout=30000)
        request.cls.screen.refresh()
        for _ in range(10, 60, 10):
            if request.cls.home_page.is_overlay_shown() and \
               request.cls.home_page.get_overlay_title() == request.cls.home_labels.LBL_RECORDING_ENABLED:
                __log.info("PTCM overlay shown. Selecting {}".format(request.cls.home_labels.LBL_RESTART_THE_BOX_NDVR))
                request.cls.home_page.select_menu(request.cls.home_labels.LBL_RESTART_THE_BOX_NDVR)
                request.cls.home_page.back_to_home_short()
                break
            else:
                request.cls.home_page.pause(_ / 2)
        else:
            request.cls.home_page.relaunch_hydra_app()
    else:
        __log.warning("Skipping nDVR enabling since it is alrealdy enabled")


def cancel_ndvr_simple(request):
    """
    Disabling nDVR and restarting the Hydra app, if nDVR is not disabled
    """
    is_ndvr_enabled = request.cls.service_api.get_feature_status(FeaturesList.NDVR)
    if is_ndvr_enabled:
        __log.info("Disabling nDVR")
        request.cls.iptv_prov_api.pr1_prov_device_cancel(
            request.cls.service_api.getPartnerCustomerId(Settings.tsn),
            request.cls.service_api.get_mso_partner_id(Settings.tsn))
        request.cls.home_page.wait_for_screen_ready(request.cls.home_labels.LBL_RECORDING_DISABLED, timeout=30000)
        request.cls.screen.refresh()
        for _ in range(10, 60, 10):
            if request.cls.home_page.is_overlay_shown() and \
               request.cls.home_page.get_overlay_title() == request.cls.home_labels.LBL_RECORDING_DISABLED:
                __log.info("PTCM overlay shown. Selecting {}".format(request.cls.home_labels.LBL_RESTART_THE_BOX_NDVR))
                request.cls.home_page.select_menu(request.cls.home_labels.LBL_RESTART_THE_BOX_NDVR)
                request.cls.home_page.back_to_home_short()
                break
            else:
                request.cls.home_page.pause(_ / 2)
        else:
            request.cls.home_page.relaunch_hydra_app()
    else:
        __log.warning("Skipping nDVR disabling since it is alrealdy disabled")


@pytest.fixture(autouse=False, scope="function")
def cleanup_activate_ndvr_simple(request):
    """
    Enabling nDVR and restarting the Hydra app, if nDVR is not enabled
    """
    yield
    __log.info("Cleanup")
    activate_ndvr_simple(request)


@pytest.fixture(autouse=False, scope="function")
def setup_add_new_channel(request):
    """
    Create new linear channel
    """
    __log.info("Creating a new channel")
    if not is_channel_present(request):
        request.cls.iptv_prov_api.lsp(request.cls.service_api.get_mso_partner_id(Settings.tsn))


def is_channel_present(request):
    yield
    __log.info("Creating a new channel")
    channel_info = request.cls.iptv_prov_api.get_linear_service_search(
        request.cls.service_api.getPartnerCustomerId(Settings.tsn),
        request.cls.service_api.fe_device_mso_service_id_get()["msoServiceId"])
    for channel_id in channel_info["packagedServiceList"]["packagedService"]:
        if channel_id['packagedServiceId'] != request.cls.iptv_prov_api.get_lsid():
            __log.info(f"Channel {request.cls.iptv_prov_api.get_channel_num()} is not present on Guide")
            return False
        else:
            return True


@pytest.fixture(autouse=False, scope="function")
def delete_new_channel(request):
    """
    Delete the newly created channel 901
    """
    if is_channel_present(request):
        request.cls.iptv_prov_api.lsr(request.cls.service_api.get_mso_partner_id(Settings.tsn))
