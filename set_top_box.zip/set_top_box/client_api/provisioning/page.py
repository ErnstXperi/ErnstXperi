import re
import os
import timeit
import time

import pytest

from core_api.stb.assertions import CoreAssertions
from set_top_box.test_settings import Settings
from tools.logger.logger import Logger
from set_top_box.client_api.provisioning.en_us.labels import ProvisioningLabels

import json
import requests
from lxml import etree
import xmltodict
from requests.exceptions import *


class ProvisioningPage(CoreAssertions):
    log = Logger(__name__)

    def __init__(self, screen):
        super().__init__(screen)
        self.provisioning_labels = ProvisioningLabels()

    def is_ndvr_enabled_overlay(self):
        """
        Method to verify ndvr activated overlay
        """
        reference_lbl = self.provisioning_labels.LBL_NDVR_ACTIVATED_OVERLAY
        if self.is_overlay_shown() and self.get_overlay_title() == reference_lbl:
            return True

    def is_ndvr_disabled_overlay(self):
        """
        Method to verify ndvr cancelled overlay
        """
        reference_lbl = self.provisioning_labels.LBL_NDVR_CANCEL_OVERLAY
        if self.is_overlay_shown() and self.get_overlay_title() == reference_lbl:
            return True

    def get_customer_support_screen_dump(self):
        self.home_page.back_to_home_short()
        self.menu_page.go_to_system_info_screen(self)
        self.menu_page.select_menu_items("Help")
        self.home_assertions.verify_screen_title("HELP")
        self.menu_page.select_menu_items("Customer Support")
        self.screen.refresh()
        dump = self.screen.get_screen_dump_item()
        return dump

    def get_authentication_lp_url(self):
        """
        :param request:
        :return: licenseplateurl
        """
        get_authentication_conf = self.api.get_authentication_configuration_search()
        if 'licensePlateUrl' in get_authentication_conf['authenticationConfiguration'][0]:
            return get_authentication_conf['authenticationConfiguration'][0]['licensePlateUrl']

    def determine_cubi_vp(self):
        account_details = self.pps_api_helper.get_account_details_pps(self.service_api.getPartnerCustomerId())
        if account_details and type(account_details) is dict:
            pcid = account_details['partnerCustomerId']
            service_tier = account_details['serviceTier']
            vp = str(re.findall(r"VP\d+", service_tier)).lower().strip('[').strip(']').strip("'").strip(",")
            return (vp, pcid)
        return None

    def cubiware_svod_account_info(self):
        vp, pcid = self.determine_cubi_vp()
        if vp is None or pcid is None:
            return [{'error': 'Unable to determine vp / pcid '}]
        tokenData = [self.provisioning_labels.CUBIWARE_URL[vp], self.provisioning_labels.CUBIWARE_TOKEN[vp],
                     self.provisioning_labels.CUBIWARE_ENVS[vp]]
        params = {'searchavailable': '1', 'identifier_type': 'external_id', 'page': '1'}
        try:
            r = requests.get("{}rest/customers/{}/entitlements".format(tokenData[0], pcid),
                             params=params, auth=(tokenData[1], ''), timeout=10)
        except error:
            return None
        r_dict = xmltodict.parse(r.text)
        return r_dict['entitlements']['entitlement']

    def cubi_svod_package_addition(self):
        vp, pcid = self.determine_cubi_vp()
        if vp is None or pcid is None:
            return [{'error': 'Unable to determine vp / pcid '}]
        tokenData = [self.provisioning_labels.CUBIWARE_URL[vp], self.provisioning_labels.CUBIWARE_TOKEN[vp],
                     self.provisioning_labels.CUBIWARE_ENVS[vp]]
        response = list()
        entitlement = etree.Element("entitlement")
        etree.SubElement(entitlement, "customer-external-id").text = pcid
        etree.SubElement(entitlement, "offer-external-id").text = "super-svod"
        etree.SubElement(entitlement, "expires-at").text = "2050-12-22T14:16:21Z"
        xml = etree.tostring(entitlement).decode('utf-8')
        xml = '<?xml version="1.0" encoding="UTF-8"?>' + xml
        params = {'identifier_type': 'external_id'}
        headers = {'Content-Type': 'application/xml', 'Accept': 'application/xml'}
        try:
            r = requests.post("{}rest/entitlements".format(tokenData[0]), params=params, data=xml, headers=headers,
                              auth=(tokenData[1], ''), timeout=10)
            response.append(json.loads(json.dumps(xmltodict.parse(r.text, process_namespaces=True))))
            response[0] = response[0]['entitlements']['entitlement']
        except (Timeout, ConnectionError, ReadTimeout, ValueError):
            response.append({"error": "Couldn't resolve URL / Some error occured"})
        except KeyError:
            pass
        return response

    def cubiware_svod_package_removal(self):
        vp, pcid = self.determine_cubi_vp()
        if vp is None or pcid is None:
            return [{'error': 'Unable to determine vp / pcid '}]
        tokenData = [self.provisioning_labels.CUBIWARE_URL[vp], self.provisioning_labels.CUBIWARE_TOKEN[vp],
                     self.provisioning_labels.CUBIWARE_ENVS[vp]]
        response = list()
        text = self.cubiware_svod_account_info()
        if text is None or text == "":
            return [{'error': 'Issue occured while getting entitlement data for provided identifier/package pair'}]
        tree = etree.ElementTree(etree.fromstring(text.encode('utf-8')))
        root = etree.Element("entitlements")
        for i in tree.findall('entitlement'):
            if i.find('offer-external-id').text == pcid:
                entitlement = etree.SubElement(root, "entitlement")
                etree.SubElement(entitlement, "id").text = i.find('id').text
        xml = etree.tostring(root).decode('utf-8')
        xml = '<?xml version="1.0" encoding="UTF-8"?>' + xml
        headers = {'Content-Type': 'application/xml', 'Accept': 'application/xml'}
        try:
            r = requests.put("{}rest/entitlements/bulk_revert".format(tokenData[0]), data=xml, headers=headers,
                             auth=(tokenData[1], ''), timeout=10)
            if r.status_code == 200:
                response.append([{"Success": "Entitlement reverted successfully"}])
            else:
                try:
                    response.append(json.loads(json.dumps(xmltodict.parse(r.text))))
                except (Timeout, ConnectionError, ReadTimeout, ValueError):
                    return [{"error": "Error in parsing response.Possibly No entitlements in active state"}]
                if vp == "vp4":
                    response[0] = response[0]['multistatus']['response']
                else:
                    response[0] = response[0]['entitlements']['entitlement']
                m = dict()
                for ii in range(0, len(response[0])):
                    if vp == "vp4":
                        z = response[0][ii]['entitlement']['id']
                    else:
                        z = response[0][ii]['id']
                    if isinstance(z, dict):
                        z = z['#text']
                    m[z] = response[0][ii]
                response[0] = m
        except (Timeout, ConnectionError):
            response.append({"error": "Couldn't resolve URL"})
        except KeyError:
            pass
        return response

    def cubiware_account_deletion(self):
        vp, pcid = self.determine_cubi_vp()
        if vp is None or pcid is None:
            return [{'error': 'Unable to determine vp / pcid '}]
        tokenData = [self.provisioning_labels.CUBIWARE_URL[vp], self.provisioning_labels.CUBIWARE_TOKEN[vp],
                     self.provisioning_labels.CUBIWARE_ENVS[vp]]
        response = list()
        deleteType = "customers"
        if type == "devices":
            deleteType = "devices"
            resp = self.cubiware_account_unbind()
            if 'error' in resp[0].keys() or 'errors' in resp[0].keys():
                return resp
            params = {'identifier_type': 'external_id'}
            try:
                r = requests.delete("{}rest/".format(tokenData[0]) + deleteType + "/{}".format(pcid),
                                    params=params, auth=(tokenData[1], ''), timeout=10)
                if r.status_code == 200:
                    response.append({"Success": "Deleted successfully"})
                else:
                    try:
                        response.append(json.loads(json.dumps(xmltodict.parse(r.text))))
                    except (Timeout, ConnectionError, ReadTimeout, ValueError):
                        response.append({"error": "Error in parsing response"})
            except (Timeout, ConnectionError):
                response.append({"error": "Couldn't resolve URL"})
            except KeyError:
                response.append({"error": "Could not find account for identifier/videoProvider pair"})
            return response

    def cubiware_account_unbind(self):
        vp, pcid = self.determine_cubi_vp()
        if vp is None or pcid is None:
            return [{'error': 'Unable to determine vp / pcid '}]
        tokenData = [self.provisioning_labels.CUBIWARE_URL[vp], self.provisioning_labels.CUBIWARE_TOKEN[vp],
                     self.provisioning_labels.CUBIWARE_ENVS[vp]]
        response = list()
        root = etree.Element("device")
        etree.SubElement(root, "customer-id")
        xml = etree.tostring(root).decode('utf-8')
        xml = '<?xml version="1.0" encoding="UTF-8"?>' + xml
        params = {'identifier_type': 'external_id'}
        headers = {'Content-Type': 'application/xml', 'Accept': 'application/xml'}
        try:
            r = requests.put("{}rest/devices/{}".format(tokenData[0], pcid), params=params, data=xml,
                             headers=headers,
                             auth=(tokenData[1], ''), timeout=10)
            if r.status_code == 200:
                response.append({"Success": "Unbinded successfully"})
            else:
                try:
                    response.append(json.loads(json.dumps(xmltodict.parse(r.text, process_namespaces=True))))
                except KeyError:
                    response.append({"error": "Error in parsing response"})
        except (Timeout, ConnectionError, KeyError):
            response.append({"error": "Couldn't resolve URL"})
        return response

    def cubiware_account_activation(self):
        vp, pcid = self.determine_cubi_vp()
        if vp is None or pcid is None:
            return [{'error': 'Unable to determine vp / pcid '}]
        tokenData = [self.provisioning_labels.CUBIWARE_URL[vp], self.provisioning_labels.CUBIWARE_TOKEN[vp],
                     self.provisioning_labels.CUBIWARE_ENVS[vp]]
        response = list()
        root = etree.Element("customer")
        etree.SubElement(root, "first-name").text = "Customer"
        etree.SubElement(root, "last-name").text = "Test"
        etree.SubElement(root, "external-id").text = pcid
        etree.SubElement(root, "billing-period-id").text = "1"
        etree.SubElement(root, "credits-limit").text = "100000"
        xml = etree.tostring(root).decode('utf-8')
        xml = '<?xml version="1.0" encoding="UTF-8"?>' + xml
        params = {'identifier_type': 'external_id'}
        headers = {'Content-Type': 'application/xml', 'Accept': 'application/xml'}
        try:
            r = requests.post("{}rest/customers".format(tokenData[0]), params=params, data=xml, headers=headers,
                              auth=(tokenData[1], ''), timeout=10)
            try:
                response.append(json.loads(json.dumps(xmltodict.parse(r.text, process_namespaces=True))))
            except KeyError:
                response.append({"error": "Error in parsing response"})
            response[0] = response[0]['customer']
        except (Timeout, ConnectionError, ReadTimeout):
            response.append({"error": "Couldn't resolve URL"})
        except KeyError:
            response.append({"error": "Could not find account for identifier/videoProvider pair"})
        return response

    def seachange_account_check(self):
        account_details = self.pps_api_helper.get_account_details_pps(self.service_api.getPartnerCustomerId())
        pcid = account_details['partnerCustomerId']
        url = self.provisioning_labels.SEACHANGE_URL + pcid
        headers = {"Content-Type: application/xml; charset=utf-8"}
        try:
            r = requests.get(headers=headers, url=url)
        except (Timeout, ConnectionError, KeyError):
            r.append({"error": "PCID/Account does not exist in SeaChange. There is nothing to check."})
        return r.text

    def seachange_add_svod(self):
        account_details = self.pps_api_helper.get_account_details_pps(self.service_api.getPartnerCustomerId())
        pcid = account_details['partnerCustomerId']
        url = self.provisioning_labels.SEACHANGE_URL + pcid
        url_hbo = url + "/SubscriptionProducts/1"
        url_sho = url + "/SubscriptionProducts/2"
        headers = {"Content-Type: application/xml; charset=utf-8"}
        try:
            r = requests.put(headers=headers, url=url_hbo)
            r = requests.put(headers=headers, url=url_sho)
        except (Timeout, ConnectionError, KeyError):
            r.append({"error": "PCID/Account does not exist in SeaChange. There is nothing to check."})
        return r

    def sechange_remove_svod(self):
        account_details = self.pps_api_helper.get_account_details_pps(self.service_api.getPartnerCustomerId())
        pcid = account_details['partnerCustomerId']
        url = self.provisioning_labels.SEACHANGE_URL + pcid
        url_hbo = url + "/SubscriptionProducts/1"
        url_sho = url + "/SubscriptionProducts/2"
        headers = {"Content-Type: application/xml; charset=utf-8"}
        try:
            r = requests.delete(headers=headers, url=url_hbo)
            r = requests.delete(headers=headers, url=url_sho)
        except (Timeout, ConnectionError, KeyError):
            r.append({"error": "PCID/Account does not exist in SeaChange. There is nothing to check."})
        return r

    def seachange_add_account(self):
        account_details = self.pps_api_helper.get_account_details_pps(self.service_api.getPartnerCustomerId())
        pcid = account_details['partnerCustomerId']
        response = self.seachange_account_check()
        if response == "200":
            xml = f"<?xml version=\"1.0\" encoding=\"utf-8\" ?>" \
                  f"<Customer id=\"{pcid}\" xmlns=\"urn:eventis:crm:2.0\">" \
                  "</Customer>"
            headers = "Content-Type: application/xml; charset=utf-8"
            url = self.provisioning_labels.SEACHANGE_URL + pcid
            r = requests.put(headers=headers, data=xml, url=url)
        else:
            r = {"error": "PCID/Account does not exist in SeaChange. There is nothing to check"}
        return r

    def seachange_remove_account(self):
        account_details = self.pps_api_helper.get_account_details_pps(self.service_api.getPartnerCustomerId())
        pcid = account_details['partnerCustomerId']
        response = self.seachange_account_check()
        if response == "200":
            xml = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>" \
                  f"<Customer id=\"{pcid}\" xmlns=\"urn:eventis:crm:2.0\">" \
                  "</Customer>"
            headers = "Content-Type: application/xml; charset=utf-8"
            url = self.provisioning_labels.SEACHANGE_URL + pcid
            r = requests.delete(headers=headers, data=xml, url=url)
        else:
            r = {"error": "PCID/Account does not exist in SeaChange. There is nothing to check"}
        return r

    def find_vod_site_id_cc11(self):
        account_details = self.pps_api_helper.get_account_details_pps(self.service_api.getPartnerCustomerId())
        vodSiteId = account_details['vodSiteId']
        return vodSiteId

    def get_branding_ui_labels_values(self, branding_value):
        values_list = []
        for attr in self.provisioning_labels.LBL_BRANDING_ATTRIBUTES:
            values_list.append(branding_value[attr]["value"])
        return values_list
