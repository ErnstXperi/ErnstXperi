

class MetronetAppsandGamesLabels:
    LBL_BAIL_BUTTONS = ["home", "guide", "exit", "back", "apps"]
