"""
    @author: alexandra.cernat@tivo.com
    @created: Apr-14-2020
"""

import pytest
from hamcrest import assert_that, contains_string, is_in, is_, equal_to, has_items, has_value, not_none

from set_top_box.client_api.voice_search.en_us.labels import VoiceSearchLabels
from set_top_box.client_api.voice_search.page import VoiceSearchBase
from tools.logger.logger import Logger


class VoiceSearchAssertions(VoiceSearchBase):
    voice_search_labels = VoiceSearchLabels()
    log = Logger(__name__)

    def verify_voice_button_open_ga(self):
        """
        Verifies that voice button calls Google Assistant
        """
        self.screen.base.press_google_voice(3000)
        self.verify_foreground_package_name(self.voice_search_labels.LBL_VOICE_SEARCH_KATNISS)

    def verify_availability_of_text(self, text):
        """
        Verifies whether a desired text is available on the voice strip/result
        """
        result = self.screen.base.check_text_availability(text)
        assert_that(result, "Expected text {} is not available".format(text))

    def verify_if_voice_feature_is_on(self, tester, search_text, expected=True):
        """
        Verifying whether Voice feature is on or off.
        Results available on the MSO provider should be in the 1st row.

        Note:
            Voice feature will be recognized as turned off if making the voice search while the Hydra app is closed.

        Args:
            tester: test class instance
            search_text (str): text the results are provided for
            expected (bool): True - feature is expected to be on, False - it's expected to be off
        """
        self.log.info(f"Verifying if Voice feature is {expected}")
        is_warning = self.is_warning_text_mso_results_not_available_shown(tester)
        is_voice_on = tester.voicesearch_page.is_content_description_for_provider_shown(tester, search_text)
        result = True if (is_voice_on or is_warning) and expected or \
            not is_voice_on and not is_warning and not expected else False
        ui_dump = self.screen.base.get_uiautomator_dump()
        assert_that(result, f"The Voice feature is {result}; expected = {expected} \n\n UI Dump: \n\n{ui_dump}")

    def verify_compact_overlay_shown(self, tester):
        assert_that(self.is_ga_compact_results_displayed(tester), is_(True),
                    "Compact GA results overlay is not displayed")

    def verify_entity_overlay_shown(self, tester):
        assert_that(self.is_ga_entity_overlay_displayed(tester), is_(True), "Entity GA overlay not displayed")

    def verify_mso_warning_message(self, tester):
        if self.is_warning_text_mso_results_not_available_shown(tester):
            pytest.skip(self.screen.base.get_text_by_locator(
                tester.voice_search_labels.LBL_VOICE_WARNING_RESOURCE_ID_DICT))

    def verify_general_search_results_overlay(self, tester):
        """
        Verifies that GA overlay has MSO identifiers in case of C2C feature for a general search
        """
        self.log.info("Verify compact GA results overlay")
        self.screen.base.driver.uiautomator_device(
            resourceId=tester.voice_search_labels.LBL_VOICE_GA_COMPACT_RESOURCE_ID).wait.exists(timeout=20000)
        compact = self.screen.base.driver.uiautomator_device(
            resourceId=tester.voice_search_labels.LBL_VOICE_GA_COMPACT_RESOURCE_ID).exists
        if compact:
            self.verify_mso_warning_message(tester)
            self.verify_mso_name(tester)
            self.verify_mso_logo(tester)
        else:
            assert_that(compact, "Compact GA results overlay is not displayed")

    def get_entity_details(self, tester):
        if self.is_ga_compact_results_displayed(tester):
            title = self.screen.base.get_text_by_locator(
                tester.voice_search_labels.LBL_VOICE_ENTITY_TITLE_RESOURCE_ID_DICT)
            # year = self.screen.base.get_text_by_locator(
            #     tester.voice_search_labels.LBL_VOICE_ENTITY_DATE_RESOURCE_ID_DICT)
            # genre = self.screen.base.get_text_by_locator(
            #     tester.voice_search_labels.LBL_VOICE_ENTITY_GENRE_RESOURCE_ID_DICT)
            # rating = self.screen.base.get_text_by_locator(
            #     tester.voice_search_labels.LBL_VOICE_ENTITY_RATING_RESOURCE_ID_DICT)
            return title

    def get_selected_item_details(self, tester):
        compact = self.is_ga_compact_results_displayed(tester)
        if compact:
            if not self.screen.base.driver.uiautomator_device(resourceId="com.google.android.katniss:id/row_content") \
                    .child(className="android.widget.FrameLayout", focused=True).exists:
                self.screen.base.driver.uiautomator_device.press("up")
            if self.screen.base.driver.uiautomator_device(resourceId="com.google.android.katniss:id/row_content") \
                    .child(className="android.widget.FrameLayout", focused=True).exists:
                title = self.screen.base.driver.uiautomator_device(
                    resourceId="com.google.android.katniss:id/row_content") \
                    .child(className="android.widget.FrameLayout", focused=True) \
                    .child(resourceId="com.google.android.katniss:id/title").text
                if title:
                    return title
                else:
                    assert_that(compact, "Title of the selected item could not be obtained")
        else:
            assert_that(compact, "Compact GA results overlay is not displayed")

    def verify_mso_name(self, tester):
        assert_that(self.is_provider_name_shown(tester), is_(True), "MSO Name is not visible")

    def verify_mso_logo(self, tester):
        assert_that(self.is_provider_logo_shown(tester), is_(True), "MSO Logo is not visible")

    def verify_mso_open_cta(self, tester):
        assert_that(self.is_open_cta_shown(tester), is_(True), "MSO Open CTA is not visible")

    def verify_mso_play_cta(self, tester):
        assert_that(self.is_play_cta_shown(tester), is_(True), "MSO Play CTA is not visible")

    def verify_mso_record_cta(self, tester):
        assert_that(self.is_record_cta_shown(tester), is_(True), "MSO Record CTA is not visible")

    def verify_mso_create_onepass_cta(self, tester):
        assert_that(self.is_create_onepass_cta_shown(tester), is_(True), "MSO OnePass CTA is not visible")

    def verify_cta_list(self, tester):
        assert_that(self.is_cta_list_present(tester), is_(True), "List of CTAs is not visible in GA overlay")

    def verify_cta_in_focus(self, cta_text, tester):
        assert_that(self.is_cta_in_focus(cta_text=cta_text, tester=tester), is_(True),
                    "{} CTA is not in focus in GA overlay".format(cta_text))

    def click_on_open_cta(self, tester):
        self.log.step("Move focus to Open CTA in GA overlay")
        count = self.get_cta_count(tester)
        for i in range(count):
            if not self.is_cta_in_focus(cta_text=tester.voice_search_labels.LBL_VOICE_OPEN_CTA, tester=tester):
                self.screen.base.driver.uiautomator_device.press("left")
                self.screen.base.driver.uiautomator_device.wait.update()
            else:
                self.log.step("Click on Open from GA overlay")
                self.screen.base.driver.uiautomator_device.press("enter")
                break
        else:
            raise AssertionError("Create Open could not be Focused")

    def click_on_play_cta(self, tester):
        self.log.step("Move focus to Play CTA in GA overlay")
        if not self.is_cta_in_focus(tester=tester, cta_text=tester.voice_search_labels.LBL_VOICE_PLAY_CTA):
            focused = self.get_focused_cta(tester)
            if focused == tester.voice_search_labels.LBL_VOICE_OPEN_CTA:
                self.screen.base.driver.uiautomator_device.press("right")
                self.screen.base.driver.uiautomator_device.wait.update()
            elif focused == tester.voice_search_labels.LBL_VOICE_RECORD_CTA_CTA:
                self.screen.base.driver.uiautomator_device.press("left")
                self.screen.base.driver.uiautomator_device.wait.update()
        if self.is_cta_in_focus(tester=tester, cta_text=tester.voice_search_labels.LBL_VOICE_PLAY_CTA):
            self.log.step("Click on Play CTA from GA overlay")
            self.screen.base.driver.uiautomator_device.press("enter")
        else:
            raise AssertionError("Create Play CTA could not be Focused")

    def click_on_record_cta(self, tester):
        self.log.step("Move focus to Record CTA in GA overlay")
        count = self.get_cta_count(tester)
        for i in range(count):
            if not self.is_cta_in_focus(cta_text=tester.voice_search_labels.LBL_VOICE_RECORD_CTA,
                                        tester=tester):
                self.screen.base.driver.uiautomator_device.press("right")
            else:
                self.log.step("Click on Record CTA from GA overlay")
                self.screen.base.driver.uiautomator_device.press("enter")
                break
        else:
            raise AssertionError("Create Record CTA could not be Focused")

    def click_on_create_onepass_cta(self, tester):
        self.log.step("Move focus to Create OnePass CTA in GA overlay")
        count = self.get_cta_count(tester)
        for i in range(count):
            if not self.is_cta_in_focus(cta_text=tester.voice_search_labels.LBL_VOICE_CREATE_ONEPASS_CTA,
                                        tester=tester):
                self.screen.base.driver.uiautomator_device.press("right")
            else:
                self.log.step("Click on Create OnePass CTA from GA overlay")
                self.screen.base.driver.uiautomator_device.press("enter")
                break
        else:
            raise AssertionError("Create OnePass CTA could not be Focused")

    def verify_entity_ga_overlay(self, tester, open_cta=True, play_cta=False, record_cta=False,
                                 create_onepass_cta=False):
        """
        Verifies that GA overlay has MSO identifiers in case of C2C feature for a general search
        """
        self.verify_compact_overlay_shown(tester)
        if open_cta:
            self.verify_mso_open_cta(tester)
        if play_cta:
            self.verify_mso_play_cta(tester)
        if record_cta:
            self.verify_mso_record_cta(tester)
        if create_onepass_cta:
            self.verify_mso_create_onepass_cta(tester)

    def get_title_recognized_by_ga(self, titles_list, tester, media_type=''):
        """'
        Returs first content in list recognized by google as MSO available
        :param titles_list: the list with titles
        :param media_type: movie/series/shows or ''
        :param tester:
        :return: Returns first content in list recognized by google as available on MSO side
        """
        if titles_list:
            for title in titles_list:
                name = title[2]
                if title[3] == 'None':
                    year = ''
                else:
                    year = title[3]
                self.action_command_by_title_with_google_assistant(title=name, media_type=media_type, year=year)
                self.wait_ga_compact_overlay(tester)
                if self.is_open_cta_shown(tester):
                    self.dismiss_compact_ga_overlay(tester)
                    self.log.info("Selected content : {}".format(title))
                    return title
                else:
                    self.dismiss_compact_ga_overlay(tester)
            else:
                pytest.skip("No titles recognized by GA")
                return
        else:
            pytest.skip("No titles to be checked with GA")
            return

    def get_filter_search_recognized_by_ga(self, filter_list, tester, media_type=''):
        """
        Filter search is considered recognized by google as MSO result if MSO logo appears on GA general search overlay
        :param filter_list: the list of filters((strings)e.g: character names, keywords ["finanicial crysis", "war"])
        :param media_type: movie/series/shows or ''
        :preposition
        :param tester:
        :return: Returns first filter in list recognized by google as available on MSO side
        """
        if filter_list:
            for filter in filter_list:
                search_content = media_type + filter
                self.general_search_with_google_assistant(search_content=search_content)
                self.wait_ga_compact_overlay(tester)
                if self.is_provider_name_shown(tester):
                    self.dismiss_compact_ga_overlay(tester)
                    self.log.info("Selected filter : {}".format(filter))
                    return filter
                else:
                    self.dismiss_compact_ga_overlay(tester)
            else:
                pytest.skip("No filter recognized by GA")
                return
        else:
            pytest.skip("No filters to be checked with GA")
            return

    def verify_availability_of_row_content(self, expected=True):
        row_content = self.is_row_content_shown()
        if row_content:
            result = True
        else:
            result = False
        assert_that(result, f"Row content availibility is {result}; expected = {expected}")

    def verify_year_in_decade(self, year, start_year):
        """
        start_year = start year of decade
        year = year to verify
        """
        assert_that(year, is_in(range(start_year, start_year + 10)), "Year not in specified decade")
