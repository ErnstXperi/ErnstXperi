"""
Created on Aug 1, 2017

@author: sghosh
"""

import time
import re

import pytest

from core_api.stb.assertions import CoreAssertions
from set_top_box.client_api.voice_search.en_us.labels import VoiceSearchLabels
from tools.logger.logger import Logger


class VoiceSearchBase(CoreAssertions):
    log = Logger(__name__)
    voice_search_labels = VoiceSearchLabels()

    def navigate_to_screen_with_google_assistant(self, screen_title, nav_cmd=""):
        self.log.step("{} {} with Google Assistant".format(nav_cmd, screen_title))
        nav_utterance = nav_cmd + screen_title
        self.screen.base.tell_google_assistant(nav_utterance)

    def switch_to_channel_with_google_assistant(self, nav_cmd, channel):
        self.log.step("{} {} with Google Assistant".format(nav_cmd, channel))
        nav_utterance = nav_cmd + channel
        self.screen.base.tell_google_assistant(nav_utterance)
        # wait for Katniss to process the command.
        time.sleep(10)
        self.wait_for_screen_ready()
        self.screen.refresh()

    def sent_media_command_with_google_assistant(self, media_command):
        self.log.step("{} LiveTV with Google Assistant".format(media_command))
        self.screen.base.tell_google_assistant(media_command)
        # wait for Katniss to process the command.
        time.sleep(10)
        self.screen.refresh()

    def navigate_in_guide_with_google_assistant(self, nav_cmd, channel="", time_interval=""):
        self.log.step("Navigate within Guide sending '{} {}{}' to GA".format(nav_cmd, channel, time_interval))
        search_utterance = nav_cmd + channel + time_interval
        self.screen.base.tell_google_assistant(search_utterance)
        # wait for Katniss to process the command.
        time.sleep(5)
        self.wait_for_screen_ready()
        self.screen.refresh()

    def action_command_by_title_with_google_assistant(self, action="", title="", year="", media_type=""):
        """
        :description:
            Sends commands by content title to GA
        :params:
            search_command - search command to use: find, search, show, play, record
            title - content title to search
            year - release year of the searched content
            media_type - content type to search: movies, series, tv shows
        """
        # Removes special characters from title. Special characters cannot be sent by voice
        title = re.sub(r'\W+', ' ', title)
        self.log.step("{} {} {} {} with Google Assistant".format(action, title, year, media_type))
        search_utterance = action + title + ' ' + year + ' ' + media_type
        self.screen.base.tell_google_assistant(search_utterance)

    def general_search_with_google_assistant(self, search_action="", search_content=""):
        """
        :description:
            Sends general search command to GA (use this for general search like "comedy movies,
            Search movies from the 90s")
        :params:
            composed
                search_action - search command to use: find, search, show
                search_content - used to compose utterances (e.g. "from" , "without") with the other parameters
        """
        self.log.step("{} {} with Google Assistant".format(search_action, search_content))
        search_utterance = search_action + search_content
        self.screen.base.tell_google_assistant(search_utterance)

    def send_empty_voice(self):
        self.log.step("Press the voice button and utter nothing")
        self.screen.base.tell_device_assistant("")

    def is_provider_name_shown(self, tester):
        """
        Provider name element is displayed only when several items in the voice strip with VOICE feature ON

        Note:
            Fow now, the method does not detect if provider name is shown.
            uiautomator dump does not contain provider name while it's shown on UI for the Jenkins job Arris box
            (firmware version: 04.01.15.120, build: PTT1.201216.001)
        """
        is_provider_name = self.screen.base.is_exist_by_resource_id(
            tester.voice_search_labels.LBL_VOICE_MSO_NAME_RESOURCE_ID) and self.screen.base.is_text_present(
            tester.voice_search_labels.LBL_VOICE_MSO_NAME)
        return is_provider_name

    def is_content_description_for_provider_shown(self, tester, search_text):
        """
        If the 1st row_content element in the Voice search results has < Results for "$searchText" > text,
        then Voice feature is ON else it's OFF

        Returns:
            bool, True - Voice feature is ON, False - it's OFF
        """
        cable_search_results_txt = tester.voicesearch_labels.LBL_SEARCH_RESULTS_FOR_TXT + ' "' + search_text + '"'
        resource_id = tester.voicesearch_labels.LBL_VOICE_SEARCH_ROW_TITLE_RESOURCE_ID
        row_title = self.screen.base.driver.get_uiautomator_element({"resourceId": resource_id}).contentDescription
        self.log.debug(f"Voice search 1st content row title is '{row_title}'")
        result = row_title == cable_search_results_txt
        return result

    def is_provider_logo_shown(self, tester):
        """
        Provider name element is displayed only when several items in the voice strip with VOICE feature ON
        """
        return self.screen.base.is_exist_by_resource_id(tester.voice_search_labels.LBL_VOICE_MSO_LOGO_RESOURCE_ID)
        # return self.screen.base.is_exist_by_resource_id("com.google.android.katniss:id/row_header_provider_icon")

    def is_warning_text_mso_results_not_available_shown(self, tester):
        """
        When MSO offers are failed to be got in the result, this warning is shown (only when VOICE feature ON)
        Approxiamte text for the warning is "CableCo results are unavailable at the moment."
        """
        return self.screen.base.is_exist_by_resource_id(tester.voice_search_labels.LBL_VOICE_WARNING_RESOURCE_ID)

    def is_ga_compact_results_displayed(self, tester):
        return self.screen.base.driver.uiautomator_device(
            resourceId=tester.voice_search_labels.LBL_VOICE_GA_COMPACT_RESOURCE_ID).exists

    def is_ga_entity_overlay_displayed(self, tester):
        return self.screen.base.is_exist_by_resource_id(tester.voice_search_labels.LBL_VOICE_GA_ENTITY_RESOURCE_ID)

    def is_open_cta_shown(self, tester):
        """
        check Open CTA
        """
        self.screen.base.is_text_present(tester.voice_search_labels.LBL_VOICE_OPEN_CTA)
        return self.screen.base.is_text_present(tester.voice_search_labels.LBL_VOICE_OPEN_CTA)

    def is_play_cta_shown(self, tester):
        """
        check Play CTA
        """
        return self.screen.base.is_text_present(tester.voice_search_labels.LBL_VOICE_PLAY_CTA)

    def is_record_cta_shown(self, tester):
        """
        check Record CTA
        """
        return self.screen.base.is_text_present(tester.voice_search_labels.LBL_VOICE_RECORD_CTA)

    def is_ga_in_foreground(self, tester):
        return self.screen.base.driver.uiautomator_device(packageName=tester.voice_search_labels.KATNISS_PACKAGE_NAME) \
            .exists

    def is_create_onepass_cta_shown(self, tester):
        """
        check Create OnePass CTA
        """
        return self.screen.base.is_text_present(tester.voice_search_labels.LBL_VOICE_CREATE_ONEPASS_CTA)

    def wait_ga_compact_overlay(self, tester):
        self.log.info("Wait for compact GA results overlay")
        self.screen.base.driver.uiautomator_device(
            resourceId=tester.voice_search_labels.LBL_VOICE_GA_COMPACT_RESOURCE_ID).wait.exists(timeout=20000)
        # tester.voicesearch_assertions.verify_compact_overlay_shown(tester)

    def wait_ga_entity_overlay(self, tester):
        self.log.info("Wait for entity GA overlay")
        self.screen.base.wait_ui_element_appear(tester.voice_search_labels.LBL_VOICE_GA_ENTITY_RESOURCE_ID_DICT, 20000)
        tester.voicesearch_assertions.verify_entity_overlay_shown(tester)

    def wait_ga_to_be_dismissed(self, tester):
        self.log.info("Wait for GA to be dismissed")
        if self.is_ga_in_foreground(tester):
            self.screen.base.driver.uiautomator_device(packageName=tester.voice_search_labels.KATNISS_PACKAGE_NAME) \
                .wait.gone()

    def dismiss_compact_ga_overlay(self, tester):
        self.log.info("Dismiss GA overlay and go to HomeScreen")
        if self.is_ga_in_foreground(tester):
            self.press_home_button()
            self.screen.base.driver.uiautomator_device(packageName=tester.voice_search_labels.KATNISS_PACKAGE_NAME) \
                .wait.gone()

    def is_cta_in_focus(self, cta_text, tester):
        focused = self.get_focused_cta(tester)
        return focused == cta_text

    def get_cta_count(self, tester):
        tester.voicesearch_assertions.verify_cta_list(tester)
        return self.screen.base.driver.uiautomator_device(
            resourceId=tester.voice_search_labels.LBL_VOICE_CTA_LIST_RESOURCE_ID).childCount

    def is_cta_list_present(self, tester):
        return self.screen.base.is_exist_by_resource_id(tester.voice_search_labels.LBL_VOICE_CTA_LIST_RESOURCE_ID)

    def get_focused_cta(self, tester):
        tester.voicesearch_assertions.verify_cta_list(tester)
        if not self.screen.base.driver.uiautomator_device(resourceId="com.google.android.katniss:id/action_list") \
                .child(className="android.widget.LinearLayout", focused=True) \
                .child(resourceId="com.google.android.katniss:id/entity_detail_action_title").exists:
            self.screen.base.driver.uiautomator_device.press("up")
        return self.screen.base.driver.uiautomator_device(resourceId="com.google.android.katniss:id/action_list") \
            .child(className="android.widget.LinearLayout", focused=True) \
            .child(resourceId="com.google.android.katniss:id/entity_detail_action_title").text

    def open_selected_search_item(self):
        if not self.screen.base.driver.uiautomator_device(resourceId="com.google.android.katniss:id/row_content") \
                .child(className="android.widget.FrameLayout", focused=True).exists:
            self.screen.base.driver.uiautomator_device.press.up()
        if self.screen.base.driver.uiautomator_device(resourceId="com.google.android.katniss:id/row_content") \
                .child(className="android.widget.FrameLayout", focused=True).exists:
            self.screen.base.driver.uiautomator_device.press.enter()
        else:
            raise AssertionError("Item in GA results not in focused")

    def is_row_content_shown(self):
        return self.screen.base.is_exist_by_resource_id("com.google.android.katniss:id/row_content")

    def get_available_text(self, tester):
        expected_text = tester.voicesearch_labels.LBL_VOICE_MEDIA_PLAY
        if not self.screen.base.is_text_present(expected_text):
            expected_text = tester.voicesearch_labels.LBL_OPEN
        self.log.info("Expected text: {}".format(expected_text))
        return expected_text

    def get_year(self, title):
        """
        Gets year from movie title as int
        """
        self.log.info("movie title {} : ".format(title))
        try:
            year = int(re.sub('[()]', '', title.split()[-1]))
            return year
        except ValueError:
            raise ValueError("Year not found at the end of the title: {}".format(title))

    def get_current_focused_item(self):
        """
        Method used to retreive the current focused item name.
        Returns: item name.
        """
        self.screen.refresh()
        return self.get_focused_item(self.get_menu_item_array())['text'].lower()
