import pytest

from set_top_box.client_api.voice_search.assertions import VoiceSearchAssertions
from set_top_box.client_api.Menu.assertions import MenuAssertions
from set_top_box.factory.page_factory import PageFactory
from set_top_box.factory.label_factory import LabelFactory
from set_top_box.test_settings import Settings
from set_top_box.client_api.home.assertions import HomeAssertions
from set_top_box.client_api.guide.assertions import GuideAssertions
from set_top_box.client_api.watchvideo.assertions import WatchVideoAssertions
from set_top_box.client_api.my_shows.assertions import MyShowsAssertions
from tools.logger.logger import Logger
from set_top_box.client_api.movie_cdp.assertions import MovieCDPAssertions
from set_top_box.client_api.wtw.assertions import WhatToWatchAssertions
from set_top_box.client_api.VOD.assertions import VODAssertions
from set_top_box.client_api.apps_and_games.assertions import AppsAndGamesAssertions
from set_top_box.client_api.program_options.assertions import ProgramOptionsAssertions
__log = Logger(__name__)


@pytest.fixture(autouse=True, scope="class")
def setup_voice_search(request):
    """
    Configure steps to be executed before the test cases run
    :param request:
    :return:
    """
    request.cls.voicesearch_page = PageFactory("voice_search", Settings, request.cls.screen)
    request.cls.voicesearch_assertions = VoiceSearchAssertions(request.cls.screen)
    request.cls.voicesearch_labels = request.cls.voice_search_labels = LabelFactory("voice_search", Settings)

    request.cls.home_page = PageFactory("home", Settings, request.cls.screen)
    request.cls.home_labels = request.cls.home_page.home_labels = LabelFactory("home", Settings)
    request.cls.home_assertions = HomeAssertions(request.cls.screen)

    request.cls.guide_page = PageFactory("guide", Settings, request.cls.screen)
    request.cls.guide_labels = LabelFactory("guide", Settings)
    request.cls.guide_assertions = GuideAssertions(request.cls.screen)

    request.cls.watchvideo_assertions = WatchVideoAssertions(request.cls.screen)
    request.cls.watchvideo_page = PageFactory("watchvideo", Settings, request.cls.screen)
    request.cls.watchvideo_labels = request.cls.liveTv_labels = LabelFactory("watchvideo", Settings)

    request.cls.my_shows_page = PageFactory("my_shows", Settings, request.cls.screen)
    request.cls.my_shows_labels = LabelFactory("my_shows", Settings)
    request.cls.my_shows_assertions = MyShowsAssertions(request.cls.screen)

    request.cls.apps_and_games_page = PageFactory("apps_and_games", Settings, request.cls.screen)
    request.cls.apps_and_games_labels = LabelFactory("apps_and_games", Settings)
    request.cls.apps_and_games_assertions = AppsAndGamesAssertions(request.cls.screen)

    request.cls.programs_options_assertions = ProgramOptionsAssertions(request.cls.screen)

    request.cls.vod_page = PageFactory("VOD", Settings, request.cls.screen)
    request.cls.vod_assertions = VODAssertions(request.cls.screen)
    request.cls.vod_labels = request.cls.vod_page.vod_labels = LabelFactory("VOD", Settings)

    request.cls.system_labels = LabelFactory("system", Settings)
    request.cls.system_page = PageFactory("system", Settings, request.cls.screen)
    request.cls.system_page.system_labels = request.cls.system_labels

    request.cls.menu_labels = LabelFactory("Menu", Settings)
    request.cls.menu_page = PageFactory("Menu", Settings, request.cls.screen)
    request.cls.menu_assertions = MenuAssertions(request.cls.screen)

    request.cls.movie_cdp_page = PageFactory("movie_cdp", Settings, request.cls.screen)

    request.cls.wtw_page = PageFactory("wtw", Settings, request.cls.screen)
    request.cls.wtw_assertions = WhatToWatchAssertions(request.cls.screen)
    request.cls.wtw_labels = LabelFactory("wtw", Settings)

    request.getfixturevalue('device_reboot_to_imporve_device_perf')
    request.getfixturevalue('clean_ftux_and_sign_in')
    request.getfixturevalue('disable_parental_controls')


@pytest.fixture(autouse=False, scope="class")
def get_uiautomator_dump(request):
    __log.info("Start: get_uiautomator_dump")
    request.cls.screen.base.get_uiautomator_dump()
    __log.info("Finish: get_uiautomator_dump")


@pytest.fixture(autouse=False, scope="function")
def ga_compact_overlay_check(request):
    """
    Sanity check for google assistant general search compact overlay. Compact overlay must contain compact search and
    provider name, with or without C2C enabled in case of search like "Movies", "comedies". Information might be missing
    from dump for some katniss versions because of device performance in getting the dump
    """
    __log.info("Start: ga_compact_overlay_check")
    request.cls.voicesearch_page.general_search_with_google_assistant("Movies")
    request.cls.voicesearch_page.wait_ga_compact_overlay(request.cls)
    if not request.cls.screen.base.driver.is_native_obj_exist(
            locator=request.cls.voice_search_labels.LBL_VOICE_GA_COMPACT_RESOURCE_ID):
        pytest.skip("missing resource ID from Android dump")
    if not request.cls.base.driver.is_native_obj_exist(
            locator=request.cls.voice_search_labels.LBL_VOICE_MSO_NAME_RESOURCE_ID):
        pytest.skip("missing information from Android dump. Provider name is missing")
    __log.info("Finish: ga_compact_overlay_check")


@pytest.fixture(autouse=False, scope="class")
def setup_add_google_account(request):
    """
    Adding a Google account if it's not set
    """
    __log.info("Setting up test Google account...")
    request.cls.system_page.launch_device_settings_screen()
    if request.cls.system_page.is_google_account_present():
        __log.info("Skipping adding Google account since it's already added")
    else:
        __log.info("Didn't find any Google account, adding one")
        request.cls.system_page.signin_google_account(Settings.google_account, Settings.google_password)
        request.cls.home_page.back_to_home_short()


@pytest.fixture(autouse=False, scope="class")
def setup_voice_google_assistant(request):
    """
    Sometimes e.g. when first using, Google Assistant needs to be set up.
    To do so, you need to confirm a few screens (screens with Continue, Continue, Yes buttons,
    if there's added Google account)
    """
    __log.info("Setting up voice Google Assistant")
    # Adding a Google account, if there's no one
    request.getfixturevalue("setup_add_google_account")
    # Initiating search to check if Google Assistant is set up
    request.cls.voicesearch_page.sent_media_command_with_google_assistant("movies")
    cur_pkg = request.cls.screen.base.driver.get_info_for_node_item()["packageName"]
    if cur_pkg != request.cls.screen.base.driver.google_assistant_pkg:
        raise AssertionError(f"Google Assistant is not displayed, cur package: {cur_pkg}")
    # Setting up Google Assistant is not required if there's no Continue button
    if request.cls.screen.base.is_text_present(request.cls.system_labels.LBL_CONTINUE_BTN):
        request.cls.voicesearch_page.press_ok_button(False)
        request.cls.voicesearch_page.pause(0.4, "Waiting for the new screen to show")
        # Something's wrong if there's no Continue button on the second screen
        if request.cls.screen.base.is_text_present(request.cls.system_labels.LBL_CONTINUE_BTN):
            request.cls.voicesearch_page.press_ok_button(False)
            request.cls.voicesearch_page.pause(0.4, "Waiting for the new screen to show")
        else:
            cur_pkg = request.cls.screen.base.driver.get_info_for_node_item()["packageName"]
            raise AssertionError(f"There's no {request.cls.system_labels.LBL_CONTINUE_BTN} button "
                                 f"during setting up Google Assistant, cur package: {cur_pkg}")
        if request.cls.screen.base.is_text_present(request.cls.system_labels.LBL_YES_BTN):
            request.cls.voicesearch_page.press_ok_button(False)
            request.cls.voicesearch_page.pause(3, "Waiting for the YouTube app to start")
        else:
            cur_pkg = request.cls.screen.base.driver.get_info_for_node_item()["packageName"]
            raise AssertionError(f"There's no {request.cls.system_labels.LBL_YES_BTN} button "
                                 f"during setting up Google Assistant, cur package: {cur_pkg}")
        # YouTube app with how-to video is expected in the end
        cur_pkg = request.cls.screen.base.driver.get_info_for_node_item()["packageName"]
        if cur_pkg != request.cls.screen.base.driver.youtube_pkg:
            raise AssertionError(f"YouTube is not displayed, cur package: {cur_pkg}")
