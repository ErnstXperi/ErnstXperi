'''
    @author: alexandra.cernat@tivo.com
    @created: Apr-14-2020
'''
from set_top_box.test_settings import Settings


class VoiceSearchLabels:

    # commands for navigation
    LBL_VOICE_NAVIGATION_GO = "Go "
    LBL_VOICE_NAVIGATION_GO_TO = "Go to "
    LBL_VOICE_NAVIGATION_SWITCH_TO = "Switch to "
    LBL_VOICE_NAVIGATION_SHOW = "Show "
    LBL_VOICE_NAVIGATION_OPEN = "Open "
    LBL_VOICE_NAVIGATION_WHATS_ON = "What\\'s on "
    LBL_VOICE_NAVIGATION_WHATS_ON_CHANNEL = "What\\'s on channel "
    LBL_VOICE_NAVIGATION_WATCH_CHANNEL = "Watch channel "

    # commands for tune to channel
    LBL_VOICE_TUNE_TO_CHANNEL = "Tune to channel "
    LBL_VOICE_SWITCH_CHANNEL = "Switch to channel "
    LBL_VOICE_GO_TO_CHANNEL = "Go to channel "
    # Common Channel Aliases. GA recognizes channels by Aliases.
    # TODO: to be removed once the light channel ingestion to Google is done
    LBL_VOICE_COMMON_CHANNEL_ALIAS_NAME = {
        "staging": {
            "alias": "FOX",
            "callsign": "KTVUDT"
        },
        "prod": {
            "alias": "FOX",
            "callsign": "KTVUDT"
        }
    }
    LBL_MOVIE = "Movies about the "

    # Time intervals
    LBL_VOICE_TIME_NOW = "now"
    LBL_VOICE_TIME_TONIGHT = "tonight"
    LBL_VOICE_TIME_DECADE = "from the \\'90s "

    # C2C screen title
    LBL_VOICE_MY_LIBRARY = "My Library "
    LBL_VOICE_MY_RECORDINGS = "My Recordings "
    LBL_VOICE_MY_APPS = "My apps "
    LBL_VOICE_HOMESCREEN = "homescreen"

    # commands for media
    LBL_VOICE_MEDIA_PLAY = "Play"
    LBL_VOICE_MEDIA_PAUSE = "Pause"
    LBL_VOICE_MEDIA_RESUME = "Resume"
    LBL_VOICE_MEDIA_STOP = "Stop"

    LBL_FRAMELAYOUT = {"resourceId": "com.google.android.katniss:id/fragment_view_wrapper"}
    LBL_OPEN = "Open"

    # general GA commands
    LBL_VOICE_SEARCH_CMD = "Search "
    LBL_VOICE_FIND_CMD = "Find "
    LBL_VOICE_PLAY_CMD = "Play "
    LBL_VOICE_RECORD_CMD = "Record "
    LBL_VOICE_OPEN_CMD = "Open "

    LBL_VOICE_MOVIES = "movies "
    LBL_VOICE_MOVIE = "movie "
    LBL_VOICE_SERIES = "series "
    LBL_VOICE_SHOWS = "shows "
    LBL_VOICE_GENRE_COMEDY = "comedy "
    LBL_SEARCH_MOVIE = "Search movie"
    LBL_VOICE_WITH = "with "
    LBL_VOICE_WITHOUT = "without "
    LBL_VOICE_AT = "at "
    LBL_VOICE_DIRECTED_BY = "directed by "
    LBL_VOICE_ON = "on "

    # Popular character names:
    LBL_VOICE_CHARACTERS = ["Clark Kent", "Princess Fiona", "Bruce Wayne", "Peter Parker", "Michael CLBL_VOICE_WITHorleone"]

    # locators ids in GA overlay
    LBL_VOICE_MSO_NAME = "CableCo"  # may not correspond to MSO name e.g. CableCo when MSO is CableCo3
    LBL_SEARCH_RESULTS_FOR_TXT = "Results for"  # beginning of the search results title when Voice feature is ON
    KATNISS_PACKAGE_NAME = "com.google.android.katniss"
    LBL_VOICE_SEARCH_KATNISS = "katniss"
    LBL_VOICE_SEARCH_ROW_TITLE_RESOURCE_ID = "com.google.android.katniss:id/row_content"
    LBL_VOICE_MSO_NAME_RESOURCE_ID = "com.google.android.katniss:id/row_header_provider_name"
    LBL_VOICE_MSO_NAME_RESOURCE_ID_DICT = {"resourceId": "com.google.android.katniss:id/row_header_provider_name"}
    LBL_VOICE_MSO_LOGO_RESOURCE_ID = "com.google.android.katniss:id/row_header_provider_icon"
    LBL_VOICE_GA_COMPACT_RESOURCE_ID = "com.google.android.katniss:id/compact_results_container"
    LBL_VOICE_GA_COMPACT_RESOURCE_ID_DICT = {"resourceId": "com.google.android.katniss:id/compact_results_container"}
    LBL_VOICE_GA_FULL_RESOURCE_ID = "com.google.android.katniss:id/fullscreen_results_container"
    LBL_VOICE_GA_FULL_RESOURCE_ID_DICT = {"resourceId": "com.google.android.katniss:id/fullscreen_results_container"}
    LBL_VOICE_CTA_LIST_RESOURCE_ID = "com.google.android.katniss:id/entity_action_flexbox"
    LBL_VOICE_WARNING_RESOURCE_ID = "com.google.android.katniss:id/m3_warning"
    LBL_VOICE_WARNING_RESOURCE_ID_DICT = {"resourceId": "com.google.android.katniss:id/m3_warning"}
    LBL_VOICE_GA_ENTITY_RESOURCE_ID = "com.google.android.katniss:id/entity_card"
    LBL_VOICE_GA_ENTITY_RESOURCE_ID_DICT = {"resourceId": "com.google.android.katniss:id/entity_card"}
    LBL_VOICE_CTA_RESOURCE_ID_DICT = {"resourceId": "com.google.android.katniss:id/entity_detail_action_title"}
    LBL_VOICE_ENTITY_TITLE_RESOURCE_ID_DICT = {"resourceId": "com.google.android.katniss:id/entity_row_header_title"}
    LBL_VOICE_ENTITY_RATING_RESOURCE_ID_DICT = {"resourceId": "com.google.android.katniss:id/display_rating"}
    LBL_VOICE_ENTITY_GENRE_RESOURCE_ID_DICT = {"resourceId": "com.google.android.katniss:id/genre"}
    LBL_VOICE_ENTITY_DATE_RESOURCE_ID_DICT = {"resourceId": "com.google.android.katniss:id/display_date"}
    LBL_VOICE_ITEM_TITLE_RESOURCE_ID_DICT = {"resourceId": "com.google.android.katniss:id/title"}

    # CTA texts in GA entity results overlay
    LBL_VOICE_OPEN_CTA = "Open"
    LBL_VOICE_PLAY_CTA = "Play"
    LBL_VOICE_RECORD_CTA = "Record"
    LBL_VOICE_CREATE_ONEPASS_CTA = "Create OnePass"
    LBL_FVOD_CC3 = "Ella Enchanted"
