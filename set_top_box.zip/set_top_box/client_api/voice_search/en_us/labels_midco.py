
class midcoVoiceSearchLabels:

    # Common Channel Aliases. GA recognizes channels by Aliases.
    LBL_VOICE_COMMON_CHANNEL_ALIAS_NAME = {
        "staging": {
            "alias": "FOX",
            "callsign": "KBRRDT"
        },
        "prod": {
            "alias": "FOX",
            "callsign": "KBRRDT"
        }
    }
    LBL_VOICE_MSO_NAME = "midco"
