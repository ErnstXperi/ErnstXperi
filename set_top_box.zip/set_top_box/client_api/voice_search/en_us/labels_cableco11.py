from .labels import VoiceSearchLabels


class CCO11VoiceSearchLabels(VoiceSearchLabels):

    # Common Channel Aliases. GA recognizes channels by Aliases.
    LBL_VOICE_COMMON_CHANNEL_ALIAS_NAME = {
        "staging": {
            "alias": "FOX",
            "callsign": "KTVUDT2"
        }
    }

    LBL_VOICE_MSO_NAME = "CableCo"
