from .labels import VoiceSearchLabels


class llaprVoiceSearchLabels:
    # Common Channel Aliases. GA recognizes channels by Aliases.
    LBL_VOICE_COMMON_CHANNEL_ALIAS_NAME = {
        "prod": {
            "alias": "FOX",
            "callsign": "WSJX-LD"
        }
    }
    LBL_VOICE_MSO_NAME = "llapr"
