from .labels import VoiceSearchLabels


class armstrongVoiceSearchLabels(VoiceSearchLabels):

    # Common Channel Aliases. GA recognizes channels by Aliases.
    LBL_VOICE_COMMON_CHANNEL_ALIAS_NAME = {
        "staging": {
            "alias": "FOX",
            "callsign": "WMSNDT"
        },
        "prod": {
            "alias": "FOX",
            "callsign": "WPGHDT"
        }
    }

    LBL_VOICE_MSO_NAME = "Armstrong"
