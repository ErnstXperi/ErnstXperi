from .labels import VoiceSearchLabels


class CCO3VoiceSearchLabels(VoiceSearchLabels):

    # Common Channel Aliases. GA recognizes channels by Aliases.
    LBL_VOICE_COMMON_CHANNEL_ALIAS_NAME = {
        "staging": {
            "alias": "FOX",
            "callsign": "KTVUDT"
        }
    }

    LBL_VOICE_MSO_NAME = "CableCo"
