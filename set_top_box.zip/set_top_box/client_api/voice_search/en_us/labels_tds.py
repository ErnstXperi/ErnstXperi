from .labels import VoiceSearchLabels


class TDSVoiceSearchLabels(VoiceSearchLabels):

    # Common Channel Aliases. GA recognizes channels by Aliases.
    LBL_VOICE_COMMON_CHANNEL_ALIAS_NAME = {
        "staging": {
            "alias": "FOX",
            "callsign": "WMSNDT"
        },
        "prod": {
            "alias": "Cartoon Network",
            "callsign": "TOONHD-W"
        }
    }
    LBL_VOICE_MSO_NAME = "TDS"
